import { n as __exportAll } from "../chunks/rolldown-runtime.js";
import { F as isElement, L as makeRAFCycle, N as hasParent, O as addEvent, R as removeEvent, T as fixedClientZoom, V as setIdleInterval$1, _ as setStyleProperty, k as addEvents, m as loadInlineStyle, o as DOMMixin, p as loadAsAdopted, s as addRoot, z as setAttributesIfNull } from "../fest/dom.js";
import { n as stripUserScopePrefix, r as userPathCandidates } from "../fest/core.js";
import { S as UUIDv4, c as ref, d as addToCallChain, f as safe, o as observe } from "../fest/object.js";
import { o as createWorkerChannel, s as QueuedWorkerChannel } from "../fest/uniform.js";
import { $ as scrollLink, A as bindWith, B as matchMediaRef, C as $observeAttribute, D as alives, E as addToBank, F as CSSCalc, G as attrLink, H as sizeRef, I as attrRef, J as localStorageLink, K as checkedLink, L as checkedRef, M as reflectControllers, N as removeFromBank, O as bindCtrl, P as ReactiveViewport, Q as mutationTrigger, R as localStorageRef, S as $mapped, T as $virtual, U as valueAsNumberRef, V as scrollRef, W as valueRef, X as makeLinker, Y as localStorageLinkMap, Z as matchMediaLink, _ as isEffectivelyEmptyStyleText, a as html, at as unregisterCloseable, b as pruneEmptyStyleAttribute, c as E, d as Q, et as sizeLink, f as C, g as compileInlineStyleAttribute, h as bindStyle, i as H, it as registerModal, j as elMap, k as bindHandler, l as Qp, m as applyNormalizedInlineStyle, nt as valueLink, o as htmlBuilder, ot as historyState, p as S, q as eventTrigger, r as createHistoryManager, rt as registerCloseable, s as $createElement, st as navigate, t as HistoryManager, tt as valueAsNumberLink, u as M, v as isNativeCSSStyleValue, w as $observeInput, x as $behavior, y as isReactiveStyleValue, z as makeRef } from "./app.js";
import { a as parseDataUrl, i as normalizeDataAsset, n as decodeBase64ToBytes, o as stringToBlob, r as isBase64Like, s as stringToBlobOrFile, t as blobToBytes } from "./app3.js";
import { a as VoiceInputManager, i as createFileHandler, n as lazyLoadComponent, o as getSpeechPrompt, r as FileHandler, t as getCachedComponent } from "./app5.js";
import { a as hostnameToFaviconRef, c as parseDesktopItemCompact, d as clampCell, i as faviconUrlForHostname, l as serializeDesktopItemCompact, n as compactIconSrcForStorage, o as normalizeIconSrcFromPayload, r as expandIconSrcForDom, s as packHrefInline, t as ITEM_COMPACT_KIND, u as unpackHrefInline } from "./app8.js";
//#region ../../modules/projects/lur.e/src/lure/misc/Glit.ts
var styleCache = /* @__PURE__ */ new Map();
var styleElementCache = /* @__PURE__ */ new WeakMap();
var propStore = /* @__PURE__ */ new WeakMap();
var CSM = /* @__PURE__ */ new WeakMap();
var camelToKebab = (str) => str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
var whenBoxValid = (name) => {
	const cb = camelToKebab(name);
	if ([
		"border-box",
		"content-box",
		"device-pixel-content-box"
	].indexOf(cb) >= 0) return cb;
	return null;
};
var whenAxisValid = (name) => {
	const cb = camelToKebab(name);
	if (cb?.startsWith?.("inline")) return "inline";
	if (cb?.startsWith?.("block")) return "block";
	return null;
};
var inRenderKey = Symbol.for("@render@");
var defKeys = Symbol.for("@defKeys@");
var defaultStyle = typeof document != "undefined" ? document?.createElement?.("style") : null;
var defineSource = (source, holder, name) => {
	if (source == "attr") return attrRef.bind(null, holder, name || "");
	if (source == "media") return matchMediaRef;
	if (source == "query") return (val) => Q?.(name || val || "", holder);
	if (source == "query-shadow") return (val) => Q?.(name || val || "", holder?.shadowRoot ?? holder);
	if (source == "localStorage") return localStorageRef;
	if (source == "inline-size") return sizeRef.bind(null, holder, "inline", whenBoxValid(name) || "border-box");
	if (source == "content-box") return sizeRef.bind(null, holder, whenAxisValid(name) || "inline", "content-box");
	if (source == "block-size") return sizeRef.bind(null, holder, "block", whenBoxValid(name) || "border-box");
	if (source == "border-box") return sizeRef.bind(null, holder, whenAxisValid(name) || "inline", "border-box");
	if (source == "scroll") return scrollRef.bind(null, holder, whenAxisValid(name) || "inline");
	if (source == "device-pixel-content-box") return sizeRef.bind(null, holder, whenAxisValid(name) || "inline", "device-pixel-content-box");
	if (source == "checked") return checkedRef.bind(null, holder);
	if (source == "value") return valueRef.bind(null, holder);
	if (source == "value-as-number") return valueAsNumberRef.bind(null, holder);
	return ref;
};
if (defaultStyle) typeof document != "undefined" && document.querySelector?.("head")?.appendChild?.(defaultStyle);
var getDef = (source) => {
	if (source == "query") return "input";
	if (source == "query-shadow") return "input";
	if (source == "media") return false;
	if (source == "localStorage") return null;
	if (source == "attr") return null;
	if (source == "inline-size") return 0;
	if (source == "block-size") return 0;
	if (source == "border-box") return 0;
	if (source == "content-box") return 0;
	if (source == "scroll") return 0;
	if (source == "device-pixel-content-box") return 0;
	if (source == "checked") return false;
	if (source == "value") return "";
	if (source == "value-as-number") return 0;
	return null;
};
if (defaultStyle) defaultStyle.innerHTML = `@layer ux-preload {
        :host { display: none; }
    }`;
function withProperties(ctr) {
	const proto = ctr.prototype ?? Object.getPrototypeOf(ctr) ?? ctr;
	const $prev = proto?.$init ?? ctr?.$init;
	proto.$init = function(...args) {
		$prev?.call?.(this, ...args);
		const allDefs = {};
		let p = Object.getPrototypeOf(this) ?? this;
		while (p) {
			if (Object.hasOwn(p, defKeys)) {
				const defs = Object.assign({}, Object.getOwnPropertyDescriptors(p), p[defKeys] ?? {});
				for (const k of Object.keys(defs)) if (!(k in allDefs)) allDefs[k] = defs[k];
			}
			p = Object.getPrototypeOf(p);
		}
		for (const [key, def] of Object.entries(allDefs)) {
			const exists = this[key];
			if (def != null) Object.defineProperty(this, key, def);
			try {
				this[key] = exists || this[key];
			} catch (e) {}
		}
		return this;
	};
	return ctr;
}
function defineElement(name, options) {
	return function(target, _key) {
		const registry = globalThis?.customElements;
		try {
			if (!registry || !name) return target;
			if (typeof registry.get !== "function" || typeof registry.define !== "function") return target;
			const existing = registry.get(name);
			if (existing) return existing;
			registry?.define?.(name, target, options);
		} catch (e) {
			if (e?.name === "NotSupportedError" || /has already been used|already been defined/i.test(e?.message || "")) return registry?.get?.(name) ?? target;
			throw e;
		}
		return target;
	};
}
function property(options = {}) {
	const { attribute, source, name, from } = options;
	return function(target, key) {
		const attrName = typeof attribute == "string" ? attribute : name ?? key;
		if (attribute !== false && attrName != null) {
			const ctor = target.constructor;
			if (!ctor.observedAttributes) ctor.observedAttributes = [];
			if (ctor.observedAttributes.indexOf(attrName) < 0) ctor.observedAttributes.push(attrName);
		}
		if (!Object.hasOwn(target, defKeys)) target[defKeys] = {};
		target[defKeys][key] = {
			get() {
				const ROOT = this;
				const inRender = ROOT[inRenderKey];
				const sourceTarget = !from ? ROOT : from instanceof HTMLElement ? from : typeof from == "string" ? Q?.(from, ROOT) : ROOT;
				let store = propStore.get(ROOT);
				let stored = store?.get?.(key);
				if (stored == null && source != null) {
					if (!store) propStore.set(ROOT, store = /* @__PURE__ */ new Map());
					if (!store?.has?.(key)) store?.set?.(key, stored = defineSource(source, sourceTarget, name || key)?.(getDef(source)));
				}
				if (inRender) return stored;
				if (stored?.element instanceof HTMLElement) return stored?.element;
				return (typeof stored == "object" || typeof stored == "function") && (stored?.value != null || "value" in stored) ? stored?.value : stored;
			},
			set(newValue) {
				const ROOT = this;
				const sourceTarget = !from ? ROOT : from instanceof HTMLElement ? from : typeof from == "string" ? Q?.(from, ROOT) : ROOT;
				let store = propStore.get(ROOT);
				let stored = store?.get?.(key);
				if (stored == null && source != null) {
					if (!store) propStore.set(ROOT, store = /* @__PURE__ */ new Map());
					if (!store?.has?.(key)) {
						const initialValue = (typeof newValue == "object" || typeof newValue == "function" ? newValue?.value : null) ?? newValue ?? getDef(source);
						store?.set?.(key, stored = defineSource(source, sourceTarget, name || key)?.(initialValue));
					}
				} else if (typeof stored == "object" || typeof stored == "function") try {
					if (typeof newValue == "object" && newValue != null && (newValue?.value == null && !("value" in newValue) || typeof newValue?.value == "object" || typeof newValue?.value == "function")) Object.assign(stored, newValue?.value ?? newValue);
					else stored.value = (typeof newValue == "object" || typeof newValue == "function" ? newValue?.value : null) ?? newValue;
				} catch (e) {
					console.warn("Error setting property value:", e);
				}
			},
			enumerable: true,
			configurable: true
		};
	};
}
var adoptedStyleSheetsCache = /* @__PURE__ */ new WeakMap();
var addAdoptedSheetToElement = (bTo, sheet) => {
	let adoptedSheets = adoptedStyleSheetsCache.get(bTo);
	if (!adoptedSheets) adoptedStyleSheetsCache.set(bTo, adoptedSheets = []);
	if (sheet && adoptedSheets.indexOf(sheet) < 0) adoptedSheets.push(sheet);
	if (bTo.shadowRoot) bTo.shadowRoot.adoptedStyleSheets = [...bTo.shadowRoot.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !bTo.shadowRoot.adoptedStyleSheets?.includes(s))];
};
var loadCachedStyles = (bTo, src) => {
	if (!src) return null;
	let resolvedSrc = src;
	if (typeof src == "function") try {
		const weak = new WeakRef(bTo);
		resolvedSrc = src.call(bTo, weak);
	} catch (e) {
		console.warn("Error calling styles function:", e);
		return null;
	}
	if (resolvedSrc && typeof CSSStyleSheet != "undefined" && resolvedSrc instanceof CSSStyleSheet) {
		addAdoptedSheetToElement(bTo, resolvedSrc);
		return null;
	}
	if (resolvedSrc instanceof Promise) {
		resolvedSrc.then((result) => {
			if (result instanceof CSSStyleSheet) addAdoptedSheetToElement(bTo, result);
			else if (result != null) loadCachedStyles(bTo, result);
		}).catch((e) => {
			console.warn("Error loading adopted stylesheet:", e);
		});
		return null;
	}
	if (typeof resolvedSrc == "string" || resolvedSrc instanceof Blob || resolvedSrc instanceof File) {
		const adopted = loadAsAdopted(resolvedSrc, "");
		if (adopted) {
			let adoptedSheets = adoptedStyleSheetsCache.get(bTo);
			if (!adoptedSheets) adoptedStyleSheetsCache.set(bTo, adoptedSheets = []);
			const addAdoptedSheet = (sheet) => {
				if (sheet && adoptedSheets.indexOf(sheet) < 0) adoptedSheets.push(sheet);
				if (bTo.shadowRoot) bTo.shadowRoot.adoptedStyleSheets = [...bTo.shadowRoot.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !bTo.shadowRoot.adoptedStyleSheets?.includes(s))];
			};
			if (adopted instanceof Promise) {
				adopted.then(addAdoptedSheet).catch((e) => {
					console.warn("Error loading adopted stylesheet:", e);
				});
				return null;
			} else {
				addAdoptedSheet(adopted);
				return null;
			}
		}
	}
	const source = typeof src == "function" || typeof src == "object" ? styleElementCache : styleCache;
	const cached = source.get(src);
	let styleElement = cached?.styleElement;
	let vars = cached?.vars;
	if (!cached) {
		let styles = ``;
		let props = [];
		if (typeof resolvedSrc == "string") styles = resolvedSrc || "";
		else if (typeof resolvedSrc == "object" && resolvedSrc != null) if (resolvedSrc instanceof HTMLStyleElement) styleElement = resolvedSrc;
		else {
			styles = typeof resolvedSrc.css == "string" ? resolvedSrc.css : typeof resolvedSrc == "string" ? resolvedSrc : String(resolvedSrc);
			props = resolvedSrc?.props ?? props;
			vars = resolvedSrc?.vars ?? vars;
		}
		if (!styleElement && styles) styleElement = loadInlineStyle(styles, bTo, "ux-layer");
		source.set(src, {
			css: styles,
			props,
			vars,
			styleElement
		});
	}
	return styleElement;
};
var isNotExtended = (el) => {
	return !(el instanceof HTMLDivElement || el instanceof HTMLImageElement || el instanceof HTMLVideoElement || el instanceof HTMLCanvasElement) && !(el?.hasAttribute?.("is") || el?.getAttribute?.("is") != null);
};
/**
* GLitElement: Создаёт базовый класс для кастомных элементов с расширенными возможностями.
* Поддерживает все lifecycle callbacks Web Components.
* 
* @param derivate - Базовый класс для расширения (по умолчанию HTMLElement).
* @returns Конструктор расширенного класса с полной поддержкой lifecycle.
* 
* @example
* ```typescript
* // Базовое использование
* class MyElement extends GLitElement() {
*     connectedCallback() {
*         super.connectedCallback();
*         console.log('Connected!');
*     }
*     
*     render() {
*         return H`<div>Hello</div>`;
*     }
* }
* 
* // С наследованием от другого элемента
* class MyButton extends GLitElement(HTMLButtonElement) {
*     static observedAttributes = ['disabled'];
*     
*     attributeChangedCallback(name, oldVal, newVal) {
*         console.log(`${name} changed from ${oldVal} to ${newVal}`);
*     }
* }
* 
* // С декоратором
* @defineElement('my-element')
* class MyElement extends GLitElement() {
*     @property({ source: 'attr', name: 'value' })
*     value: string = '';
*     
*     disconnectedCallback() {
*         console.log('Disconnected!');
*     }
* }
* ```
*/
function GLitElement(derivate) {
	const fallbackBase = globalThis.HTMLElement ?? class {};
	const Base = derivate ?? fallbackBase;
	const cached = CSM.get(Base);
	if (cached) return cached;
	/**
	* Внутренний класс с полной реализацией lifecycle
	*/
	class GLitElementImpl extends Base {
		#shadowDOM;
		#styleElement;
		#defaultStyle;
		#initialized = false;
		styleLibs = [];
		adoptedStyleSheets = [];
		get styles() {}
		get initialAttributes() {}
		styleLayers() {
			return [];
		}
		render(_weak) {
			return document.createElement("slot");
		}
		constructor(...args) {
			super(...args);
			if (isNotExtended(this)) {
				const shadowRoot = addRoot(this.shadowRoot ?? this.createShadowRoot?.() ?? this.attachShadow({ mode: "open" }));
				const defStyle = this.#defaultStyle ??= defaultStyle?.cloneNode?.(true);
				const layersStyle = shadowRoot.querySelector(`style[data-type="ux-layer"]`);
				if (layersStyle) layersStyle.after(defStyle);
				else shadowRoot.prepend(defStyle);
			}
			this.styleLibs ??= [];
		}
		$makeLayers() {
			return `@layer ${[
				"ux-preload",
				"ux-layer",
				...this.styleLayers?.() ?? []
			].join?.(",") ?? ""};`;
		}
		onInitialize(_weak) {
			return this;
		}
		onRender(_weak) {
			return this;
		}
		getProperty(key) {
			const current = this[inRenderKey];
			this[inRenderKey] = true;
			const cp = this[key];
			this[inRenderKey] = current;
			if (!current) delete this[inRenderKey];
			return cp;
		}
		loadStyleLibrary($module) {
			const root = this.shadowRoot;
			const module = typeof $module == "function" ? $module?.(root) : $module;
			if (module instanceof HTMLStyleElement) {
				this.styleLibs?.push?.(module);
				if (this.#styleElement?.isConnected) this.#styleElement?.before?.(module);
				else this.shadowRoot?.prepend?.(module);
			} else if (module instanceof CSSStyleSheet) {
				let adoptedSheets = adoptedStyleSheetsCache.get(this);
				if (!adoptedSheets) adoptedStyleSheetsCache.set(this, adoptedSheets = []);
				if (adoptedSheets.indexOf(module) < 0) adoptedSheets.push(module);
				if (root) root.adoptedStyleSheets = [...root.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !root.adoptedStyleSheets?.includes(s))];
			} else {
				const adopted = loadAsAdopted(module, "ux-layer");
				let adoptedSheets = adoptedStyleSheetsCache.get(this);
				if (!adoptedSheets) adoptedStyleSheetsCache.set(this, adoptedSheets = []);
				const addAdoptedSheet = (sheet) => {
					if (sheet && adoptedSheets.indexOf(sheet) < 0) adoptedSheets.push(sheet);
					if (root) root.adoptedStyleSheets = [...root.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !root.adoptedStyleSheets?.includes(s))];
				};
				if (adopted instanceof Promise) adopted.then(addAdoptedSheet).catch(() => {});
				else if (adopted) addAdoptedSheet(adopted);
			}
			return this;
		}
		createShadowRoot() {
			return this.shadowRoot ?? this.attachShadow({ mode: "open" });
		}
		/**
		* Вызывается когда элемент добавлен в DOM
		*/
		connectedCallback() {
			if (super.connectedCallback) super.connectedCallback();
			const weak = new WeakRef(this);
			if (!this.#initialized) {
				this.#initialized = true;
				const shadowRoot = isNotExtended(this) ? this.createShadowRoot?.() ?? this.shadowRoot ?? this.attachShadow({ mode: "open" }) : this.shadowRoot;
				const ctor = this.constructor;
				const init = this.$init ?? ctor.prototype?.$init;
				if (typeof init === "function") init.call(this);
				const attrs = typeof this.initialAttributes == "function" ? this.initialAttributes() : this.initialAttributes;
				setAttributesIfNull(this, attrs);
				this.onInitialize?.call(this, weak);
				this[inRenderKey] = true;
				if (isNotExtended(this) && shadowRoot) {
					const rendered = this.render?.call?.(this, weak) ?? document.createElement("slot");
					const styleElement = loadCachedStyles(this, this.styles);
					if (styleElement instanceof HTMLStyleElement) this.#styleElement = styleElement;
					const elements = [
						H`<style data-type="ux-layer" prop:innerHTML=${this.$makeLayers()}></style>`,
						this.#defaultStyle,
						...this.styleLibs.map((x) => x.cloneNode?.(true)) || [],
						styleElement,
						rendered
					].filter((x) => x != null && isElement(x));
					shadowRoot.append(...elements);
					const adoptedSheets = adoptedStyleSheetsCache.get(this) || [];
					if (adoptedSheets.length > 0) shadowRoot.adoptedStyleSheets = [...adoptedSheets.filter((s) => !shadowRoot.adoptedStyleSheets?.includes(s)), .../* @__PURE__ */ new Set([...shadowRoot.adoptedStyleSheets || []])];
				}
				this.onRender?.call?.(this, weak);
				delete this[inRenderKey];
				if (shadowRoot) addRoot(shadowRoot);
			}
		}
		/**
		* Вызывается когда элемент удалён из DOM
		*/
		disconnectedCallback() {
			if (super.disconnectedCallback) super.disconnectedCallback();
		}
		/**
		* Вызывается когда элемент перемещён в новый документ
		*/
		adoptedCallback() {
			if (super.adoptedCallback) super.adoptedCallback();
		}
		/**
		* Вызывается когда наблюдаемый атрибут изменился
		*/
		attributeChangedCallback(name, oldValue, newValue) {
			if (super.attributeChangedCallback) super.attributeChangedCallback(name, oldValue, newValue);
		}
	}
	const result = withProperties(GLitElementImpl);
	CSM.set(Base, result);
	console.log("result", result);
	return result;
}
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/LazyEvents.ts
var hubsByTarget = /* @__PURE__ */ new WeakMap();
var keyOf = (type, options) => {
	return `${type}|c:${options?.capture ? "1" : "0"}|p:${options?.passive ? "1" : "0"}`;
};
var lazyAddEventListener = (target, type, handler, options = {}) => {
	if (!target || typeof target.addEventListener !== "function") return () => {};
	const normalized = {
		capture: Boolean(options.capture),
		passive: Boolean(options.passive)
	};
	const key = keyOf(type, normalized);
	let hubs = hubsByTarget.get(target);
	if (!hubs) {
		hubs = /* @__PURE__ */ new Map();
		hubsByTarget.set(target, hubs);
	}
	let hub = hubs.get(key);
	if (!hub) {
		const handlers = /* @__PURE__ */ new Set();
		const listener = (ev) => {
			for (const cb of Array.from(handlers)) try {
				cb(ev);
			} catch (e) {
				console.warn(e);
			}
		};
		hubs.set(key, hub = {
			handlers,
			listener,
			options: normalized
		});
		target.addEventListener(type, listener, normalized);
	}
	hub.handlers.add(handler);
	return () => {
		const hubsNow = hubsByTarget.get(target);
		const hubNow = hubsNow?.get(key);
		if (!hubNow) return;
		hubNow.handlers.delete(handler);
		if (hubNow.handlers.size > 0) return;
		target.removeEventListener(type, hubNow.listener, hubNow.options);
		hubsNow?.delete(key);
		if (hubsNow && hubsNow.size === 0) hubsByTarget.delete(target);
	};
};
var proxiedByRoot = /* @__PURE__ */ new WeakMap();
var resolveHTMLElement = (el) => {
	const resolved = el?.element ?? el;
	return resolved instanceof HTMLElement ? resolved : null;
};
var shouldApply = (when, hadMatch, hadHandled) => {
	if (!when) return false;
	if (when === "handled") return hadHandled;
	return hadMatch;
};
/**
* Proxied events:
* - Installs **one** real DOM listener on `root` (per event/options/config), but only after the first element handler registers.
* - Routes events to registered element handlers based on the composed path.
* - Can conditionally call preventDefault/stop* only when a trigger matches (or when handled).
*/
var addProxiedEvent = (root, type, options = {
	capture: true,
	passive: false
}, config = {}) => {
	const target = root;
	if (!target || typeof target.addEventListener !== "function") return (_element, _handler) => () => {};
	const normalized = {
		capture: Boolean(options.capture),
		passive: Boolean(options.passive)
	};
	const strategy = config.strategy ?? "closest";
	const key = `${type}|c:${normalized.capture ? "1" : "0"}|p:${normalized.passive ? "1" : "0"}|s:${strategy}|pd:${String(config.preventDefault ?? "")}|sp:${String(config.stopPropagation ?? "")}|sip:${String(config.stopImmediatePropagation ?? "")}`;
	let hubs = proxiedByRoot.get(target);
	if (!hubs) {
		hubs = /* @__PURE__ */ new Map();
		proxiedByRoot.set(target, hubs);
	}
	let hub = hubs.get(key);
	if (!hub) {
		const targets = /* @__PURE__ */ new Map();
		const dispatch = (ev) => {
			let hadMatch = false;
			let hadHandled = false;
			const callSet = (set) => {
				if (!set || set.size === 0) return;
				hadMatch = true;
				for (const cb of Array.from(set)) if (cb(ev)) hadHandled = true;
			};
			const path = ev?.composedPath?.();
			if (Array.isArray(path)) if (strategy === "closest") for (const n of path) {
				const el = resolveHTMLElement(n);
				if (!el) continue;
				const set = targets.get(el);
				if (!set) continue;
				callSet(set);
				break;
			}
			else for (const n of path) {
				const el = resolveHTMLElement(n);
				if (!el) continue;
				callSet(targets.get(el));
			}
			else {
				let cur = resolveHTMLElement(ev?.target);
				while (cur) {
					const set = targets.get(cur);
					if (set) {
						callSet(set);
						if (strategy === "closest") break;
					}
					const r = cur.getRootNode?.();
					cur = cur.parentElement || (r instanceof ShadowRoot ? r.host : null);
				}
			}
			if (shouldApply(config.preventDefault, hadMatch, hadHandled)) ev?.preventDefault?.();
			if (shouldApply(config.stopImmediatePropagation, hadMatch, hadHandled)) ev?.stopImmediatePropagation?.();
			if (shouldApply(config.stopPropagation, hadMatch, hadHandled)) ev?.stopPropagation?.();
		};
		hub = {
			targets,
			unbindGlobal: null,
			options: normalized,
			strategy,
			config,
			dispatch
		};
		hubs.set(key, hub);
	}
	return (element, handler) => {
		const el = resolveHTMLElement(element);
		if (!el) return () => {};
		if (hub.targets.size === 0 && !hub.unbindGlobal) hub.unbindGlobal = lazyAddEventListener(target, type, hub.dispatch, hub.options);
		let set = hub.targets.get(el);
		if (!set) {
			set = /* @__PURE__ */ new Set();
			hub.targets.set(el, set);
		}
		set.add(handler);
		return () => {
			const hubsNow = proxiedByRoot.get(target);
			const h = hubsNow?.get(key);
			if (!h) return;
			const resolved = resolveHTMLElement(element);
			if (!resolved) return;
			const s = h.targets.get(resolved);
			if (!s) return;
			s.delete(handler);
			if (s.size === 0) h.targets.delete(resolved);
			if (h.targets.size === 0) {
				h.unbindGlobal?.();
				h.unbindGlobal = null;
				hubsNow?.delete(key);
				if (hubsNow && hubsNow.size === 0) proxiedByRoot.delete(target);
			}
		};
	};
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/Trigger.ts
var ROOT = typeof document != "undefined" ? document?.documentElement : null;
var makeShiftTrigger = (callable, newItem) => ((evc) => {
	const ev = evc;
	newItem ??= ev?.target ?? newItem;
	if (!newItem.dataset.dragging) {
		const n_coord = [ev.clientX, ev.clientY];
		if (ev?.pointerId >= 0) newItem?.setPointerCapture?.(ev?.pointerId);
		const shifting = ((evc_l) => {
			const ev_l = evc_l;
			ev_l?.preventDefault?.();
			if (ev_l?.pointerId == ev?.pointerId) {
				const coord = [evc_l.clientX, evc_l.clientY];
				const shift = [coord[0] - n_coord[0], coord[1] - n_coord[1]];
				if (Math.hypot(...shift) > 2) {
					newItem?.style?.setProperty?.("will-change", "inset, transform, translate, z-index");
					unbind?.(ev_l);
					callable?.(ev);
				}
			}
		});
		const releasePointer = ((evc_l) => {
			const ev_l = evc_l;
			if (ev_l?.pointerId == ev?.pointerId) {
				newItem?.releasePointerCapture?.(ev?.pointerId);
				unbind?.(ev_l);
			}
		});
		const handler = {
			"pointermove": shifting,
			"pointercancel": releasePointer,
			"pointerup": releasePointer
		};
		const unbind = ((evc_l) => {
			if (evc_l?.pointerId == ev?.pointerId) bindings?.forEach((binding) => binding?.());
		});
		const bindings = addEvents(ROOT, handler);
	}
});
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/PointerAPI.ts
/**
* Pointer helpers for orient-aware UIs. For launcher / speed-dial grids (cell hit-test, placement),
* use `fest/dom` `resolveGridCellFromClientPoint` + Veela `compute_grid_item_cell` / `.ui-launcher-grid`.
*/
var elementPointerMap = /* @__PURE__ */ new WeakMap();
var preventedPointers = /* @__PURE__ */ new Map();
var clickPrevention = (element, pointerId = 0) => {
	if (preventedPointers.has(pointerId)) return;
	const rmev = () => {
		preventedPointers.delete(pointerId);
		dce?.forEach?.((unbind) => unbind?.());
		ece?.forEach?.((unbind) => unbind?.());
	};
	const preventClick = (e) => {
		if (e?.pointerId == pointerId || e?.pointerId == null || pointerId == null || pointerId < 0) {
			e.preventDefault();
			preventedPointers.set(pointerId, true);
			rmev();
		} else preventedPointers.delete(pointerId);
	};
	const emt = [preventClick, { once: true }];
	const doc = [preventClick, {
		once: true,
		capture: true
	}];
	const dce = addEvents(document.documentElement, {
		"click": doc,
		"pointerdown": doc,
		"contextmenu": doc
	});
	const ece = addEvents(element, {
		"click": emt,
		"pointerdown": emt,
		"contextmenu": emt
	});
	setTimeout(rmev, 10);
};
var PointerEventDrag = null;
if (typeof PointerEvent != "undefined") PointerEventDrag = class PointerEventDrag extends PointerEvent {
	#holding;
	constructor(type, eventInitDict) {
		super(type, eventInitDict);
		this.#holding = eventInitDict?.holding;
	}
	get holding() {
		return this.#holding;
	}
	get event() {
		return this.#holding?.event;
	}
	get result() {
		return this.#holding?.result;
	}
	get shifting() {
		return this.#holding?.shifting;
	}
	get modified() {
		return this.#holding?.modified;
	}
	get canceled() {
		return this.#holding?.canceled;
	}
	get duration() {
		return this.#holding?.duration;
	}
	get element() {
		return this.#holding?.element?.deref?.() ?? null;
	}
	get propertyName() {
		return this.#holding?.propertyName ?? "drag";
	}
};
else PointerEventDrag = class PointerEventDrag {
	#holding;
	constructor(type, eventInitDict) {
		this.#holding = eventInitDict?.holding;
	}
	get holding() {
		return this.#holding;
	}
};
var grabForDrag = (em, ex = {
	pointerId: 0,
	pointerType: "mouse"
}, { shifting = [0, 0], result = [{ value: 0 }, { value: 0 }] } = {}) => {
	let frameTime = .01, lastLoop = performance.now(), thisLoop;
	const filterStrength = 100;
	const computeDuration = () => {
		var thisFrameTime = (thisLoop = performance.now()) - lastLoop;
		frameTime += (thisFrameTime - frameTime) / filterStrength;
		lastLoop = thisLoop;
		return frameTime;
	};
	const hm = {
		result,
		movement: [...ex?.movement || [0, 0]],
		shifting: [...shifting],
		modified: [...shifting],
		canceled: false,
		duration: frameTime,
		element: new WeakRef(em),
		client: null
	};
	const moveEvent = [((evc) => {
		if (ex?.pointerId == evc?.pointerId) {
			evc?.preventDefault?.();
			if (hasParent(evc?.target, em)) {
				const client = [...evc?.client || [evc?.clientX || 0, evc?.clientY || 0]];
				hm.duration = computeDuration();
				hm.movement = [...hm.client ? [client?.[0] - (hm.client?.[0] || 0), client?.[1] - (hm.client?.[1] || 0)] : [0, 0]];
				hm.client = client;
				hm.shifting[0] += hm.movement[0] || 0, hm.shifting[1] += hm.movement[1] || 0;
				hm.modified[0] = (hm.shifting[0] ?? hm.modified[0]) || 0, hm.modified[1] = (hm.shifting[1] ?? hm.modified[1]) || 0;
				em?.dispatchEvent?.(new PointerEventDrag("m-dragging", {
					...evc,
					bubbles: true,
					holding: hm,
					event: evc
				}));
				if (hm?.result?.[0] != null) hm.result[0].value = hm.modified[0] || 0;
				if (hm?.result?.[1] != null) hm.result[1].value = hm.modified[1] || 0;
				if (hm?.result?.[2] != null) hm.result[2].value = 0;
			}
		}
	}), { capture: true }];
	const promised = Promise.withResolvers();
	const releaseEvent = [((evc) => {
		if (ex?.pointerId == evc?.pointerId) {
			const elm = em?.element || em;
			if (hasParent(evc?.target, elm) || evc?.currentTarget?.contains?.(elm) || evc?.target == elm) {
				if (evc?.type == "pointerup") clickPrevention(elm, evc?.pointerId);
				queueMicrotask(() => promised?.resolve?.(result));
				bindings?.forEach?.((binding) => binding?.());
				elm?.releaseCapturePointer?.(evc?.pointerId);
				elm?.dispatchEvent?.(new PointerEventDrag("m-dragend", {
					...evc,
					bubbles: true,
					holding: hm,
					event: evc
				}));
				hm.canceled = true;
				try {
					ex.pointerId = -1;
				} catch (_) {}
			}
		}
	}), { capture: true }];
	let bindings = null;
	clickPrevention(em, ex?.pointerId);
	queueMicrotask(() => {
		if (em?.dispatchEvent?.(new PointerEventDrag("m-dragstart", {
			...ex,
			bubbles: true,
			holding: hm,
			event: ex
		}))) {
			em?.setPointerCapture?.(ex?.pointerId);
			bindings = addEvents(em, {
				"pointermove": moveEvent,
				"pointercancel": releaseEvent,
				"pointerup": releaseEvent
			});
			bindings?.push?.(...addEvents(document.documentElement, {
				"pointercancel": releaseEvent,
				"pointerup": releaseEvent
			}));
		} else hm.canceled = true;
	});
	return promised?.promise ?? result;
};
var bindDraggable = (elementOrEventListener, onEnd = () => {}, draggable = [{ value: 0 }, { value: 0 }], shifting = [0, 0]) => {
	if (!draggable) return;
	const process = (ev, el) => grabForDrag(el ?? elementOrEventListener, ev, {
		result: draggable,
		shifting: typeof shifting == "function" ? shifting?.(draggable) : shifting
	})?.then?.(onEnd);
	if (typeof elementOrEventListener?.addEventListener == "function") addEvent(elementOrEventListener, "pointerdown", process);
	else if (typeof elementOrEventListener == "function") elementOrEventListener(process);
	else throw new Error("bindDraggable: elementOrEventListener is not a function or an object with addEventListener");
	const dispose = () => {
		if (typeof elementOrEventListener?.removeEventListener == "function") removeEvent(elementOrEventListener, "pointerdown", process);
	};
	return {
		draggable,
		dispose,
		process
	};
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/LongPress.ts
var defaultOptions = {
	anyPointer: true,
	mouseImmediate: true,
	minHoldTime: 100,
	maxHoldTime: 2e3,
	maxOffsetRadius: 10
};
/** Suppress the synthetic click after long-press without blocking other listeners on the same target. */
var preventor = [(ev) => {
	ev.preventDefault();
	ev.stopPropagation();
}, { once: true }];
var LongPressHandler = class {
	#holder;
	#preventedPointers;
	constructor(holder, options = { ...defaultOptions }, fx) {
		(this.#holder = holder)["@control"] = this;
		this.#preventedPointers = /* @__PURE__ */ new Set();
		if (!holder) throw Error("Element is null...");
		if (!options) options = { ...defaultOptions };
		const currentClone = { ...options };
		Object.assign(options, defaultOptions, currentClone);
		if (options) this.longPress(options, fx);
	}
	defaultHandler(ev, weakRef) {
		return weakRef?.deref()?.dispatchEvent?.(new PointerEvent("long-press", {
			...ev,
			bubbles: true
		}));
	}
	longPress(options = { ...defaultOptions }, fx) {
		const ROOT = document.documentElement;
		const weakRef = new WeakRef(this.#holder);
		const actionState = this.initializeActionState();
		this.holding = {
			actionState,
			options,
			fx: fx || ((ev) => this.defaultHandler(ev, weakRef))
		};
		const pointerDownListener = (ev) => this.onPointerDown(this.holding, ev, weakRef);
		const pointerMoveListener = (ev) => this.onPointerMove(this.holding, ev);
		const pointerUpListener = (ev) => this.onPointerUp(this.holding, ev);
		addEvents(ROOT, {
			"pointerdown": pointerDownListener,
			"pointermove": pointerMoveListener,
			"pointerup": pointerUpListener,
			"pointercancel": pointerUpListener
		});
	}
	initializeActionState() {
		return {
			timerId: null,
			immediateTimerId: null,
			pointerId: -1,
			startCoord: [0, 0],
			lastCoord: [0, 0],
			isReadyForLongPress: false,
			cancelCallback: () => {},
			cancelPromiseResolver: null,
			cancelPromiseRejector: null
		};
	}
	preventFromClicking(self, ev) {
		if (!this.#preventedPointers.has(ev.pointerId)) {
			this.#preventedPointers.add(ev.pointerId);
			self?.addEventListener?.("click", ...preventor);
			self?.addEventListener?.("contextmenu", ...preventor);
		}
	}
	releasePreventing(self, pointerId) {
		if (this.#preventedPointers.has(pointerId)) {
			this.#preventedPointers.delete(pointerId);
			self?.removeEventListener?.("click", ...preventor);
			self?.removeEventListener?.("contextmenu", ...preventor);
		}
	}
	onPointerDown(self, ev, weakRef) {
		if (!this.isValidTarget(self, ev.target, weakRef) || !(self.options?.anyPointer || ev?.pointerType == "touch")) return;
		ev.preventDefault();
		this.resetAction(self, self.actionState);
		const { actionState } = self;
		actionState.pointerId = ev.pointerId;
		actionState.startCoord = [ev.clientX, ev.clientY];
		actionState.lastCoord = [...actionState.startCoord];
		const $withResolver = Promise.withResolvers();
		actionState.cancelPromiseResolver = $withResolver.resolve;
		actionState.cancelPromiseRejector = $withResolver.reject;
		actionState.cancelCallback = () => {
			clearTimeout(actionState.timerId);
			clearTimeout(actionState.immediateTimerId);
			actionState.isReadyForLongPress = false;
			$withResolver.resolve();
			this.resetAction(self, actionState);
		};
		if (self.options?.mouseImmediate && ev.pointerType === "mouse") {
			self.fx?.(ev);
			return actionState.cancelCallback();
		}
		actionState.timerId = setTimeout(() => {
			actionState.isReadyForLongPress = true;
		}, self.options?.minHoldTime);
		actionState.immediateTimerId = setTimeout(() => {
			if (this.isInPlace(self)) {
				this.preventFromClicking(self, ev);
				self.fx?.(ev);
				actionState.cancelCallback();
			}
		}, self.options?.maxHoldTime);
		Promise.race([$withResolver.promise, new Promise((_, reject) => setTimeout(() => reject(/* @__PURE__ */ new Error("Timeout")), 3e3))]).catch(console.warn);
	}
	onPointerMove(self, ev) {
		const { actionState } = self;
		if (ev.pointerId !== actionState.pointerId) return;
		actionState.lastCoord = [ev.clientX, ev.clientY];
		if (!this.isInPlace(self)) return actionState.cancelCallback();
		this.preventFromClicking(self, ev);
		actionState.startCoord = [ev.clientX, ev.clientY];
	}
	resetAction(self, actionState) {
		this.releasePreventing(self, actionState.pointerId);
		actionState.pointerId = -1;
		actionState.cancelPromiseResolver = null;
		actionState.cancelPromiseRejector = null;
		actionState.isReadyForLongPress = false;
		actionState.cancelCallback = null;
	}
	onPointerUp(self, ev) {
		const { actionState } = self;
		if (ev.pointerId !== actionState.pointerId) return;
		actionState.lastCoord = [ev.clientX, ev.clientY];
		if (actionState.isReadyForLongPress && this.isInPlace(self)) {
			self.fx?.(ev);
			this.preventFromClicking(self, ev);
		}
		actionState.cancelCallback();
		this.resetAction(self, actionState);
	}
	holding = {
		fx: null,
		options: {},
		actionState: {}
	};
	hasParent(current, parent) {
		while (current) {
			if (current === parent) return true;
			current = current.parentElement;
		}
	}
	isInPlace(self) {
		const { actionState } = self;
		const [startX, startY] = actionState.startCoord;
		const [lastX, lastY] = actionState.lastCoord;
		return Math.hypot(lastX - startX, lastY - startY) <= self.options?.maxOffsetRadius;
	}
	isValidTarget(self, target, weakRef) {
		const weakElement = weakRef?.deref?.();
		return weakElement && (this.hasParent(target, weakElement) || target === weakElement) && (!self.options?.handler || target.matches(self.options?.handler));
	}
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/mixins/types.ts
function junctionToBox(a, b) {
	const left = Math.min(a.x, b.x);
	const top = Math.min(a.y, b.y);
	const right = Math.max(a.x, b.x);
	const bottom = Math.max(a.y, b.y);
	return {
		left,
		top,
		right,
		bottom,
		width: right - left,
		height: bottom - top
	};
}
var JUNCTION_SELECT_EVENTS = {
	start: "junction-select:start",
	move: "junction-select:move",
	end: "junction-select:end",
	cancel: "junction-select:cancel"
};
var JUNCTION_DRAG_EVENTS = {
	start: "junction-drag:start",
	move: "junction-drag:move",
	end: "junction-drag:end"
};
var JUNCTION_RESIZE_EVENTS = {
	start: "junction-resize:start",
	move: "junction-resize:move",
	end: "junction-resize:end"
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/mixins/Junction.ts
/**
* Junction-based DOM mixins: selection (A/B), drag, resize.
*/
var mixinDisposers = /* @__PURE__ */ new WeakMap();
var pushDisposable = (host, mixinName, fn) => {
	const map = mixinDisposers.get(host) ?? /* @__PURE__ */ new Map();
	const list = map.get(mixinName) ?? [];
	list.push(fn);
	map.set(mixinName, list);
	mixinDisposers.set(host, map);
};
var runDisposers = (host, mixinName) => {
	const map = mixinDisposers.get(host);
	const list = map?.get(mixinName);
	if (!list) return;
	for (const fn of list) try {
		fn();
	} catch {}
	map.delete(mixinName);
	if (map.size === 0) mixinDisposers.delete(host);
};
var parsePxVar = (host, name) => {
	const raw = globalThis.getComputedStyle?.(host)?.getPropertyValue?.(name)?.trim?.() ?? "";
	const n = parseFloat(raw);
	return Number.isFinite(n) ? n : 0;
};
var queryHandle = (host, attr, fallback) => {
	const sel = host.getAttribute(attr)?.trim();
	if (!sel) return fallback;
	const found = host.querySelector(sel);
	return found instanceof HTMLElement ? found : fallback;
};
var JunctionSelectMixin = class extends DOMMixin {
	constructor() {
		super("ui-junction-select");
	}
	connect(wEl) {
		const host = wEl?.deref?.();
		if (!host) return this;
		const overlay = document.createElement("div");
		overlay.className = "ui-junction-select-overlay";
		overlay.setAttribute("data-junction-overlay", "");
		overlay.style.cssText = "position:absolute;pointer-events:none;z-index:9999;box-sizing:border-box;border:1px dashed color-mix(in oklab, #3794ff 70%, transparent);background:color-mix(in oklab, #3794ff 14%, transparent);display:none;inset:auto;min-width:0;min-height:0;";
		const ensurePositioned = () => {
			if ((globalThis.getComputedStyle?.(host))?.position === "static") host.style.position = "relative";
		};
		ensurePositioned();
		host.appendChild(overlay);
		let active = false;
		let a = {
			x: 0,
			y: 0
		};
		let b = {
			x: 0,
			y: 0
		};
		const localPoint = (ev) => {
			const r = host.getBoundingClientRect();
			return {
				x: ev.clientX - r.left,
				y: ev.clientY - r.top
			};
		};
		const applyOverlay = () => {
			const box = junctionToBox(a, b);
			if (box.width < 1 && box.height < 1) {
				overlay.style.display = "none";
				return;
			}
			overlay.style.display = "block";
			overlay.style.left = `${box.left}px`;
			overlay.style.top = `${box.top}px`;
			overlay.style.width = `${box.width}px`;
			overlay.style.height = `${box.height}px`;
		};
		const onDown = (ev) => {
			if (ev.button !== 0) return;
			if (ev.target?.closest?.("[data-junction-ignore-select], [data-junction-drag-handle], [data-junction-resize-handle], button, a, input, textarea, select")) return;
			if (!(ev.target === host || host.contains(ev.target))) return;
			active = true;
			a = localPoint(ev);
			b = { ...a };
			host.setPointerCapture(ev.pointerId);
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.start, {
				bubbles: true,
				detail: {
					a: { ...a },
					b: { ...b },
					host
				}
			}));
			applyOverlay();
		};
		const onMove = (ev) => {
			if (!active) return;
			b = localPoint(ev);
			applyOverlay();
			const box = junctionToBox(a, b);
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.move, {
				bubbles: true,
				detail: {
					a: { ...a },
					b: { ...b },
					box,
					host
				}
			}));
		};
		const end = (ev) => {
			if (!active) return;
			active = false;
			try {
				host.releasePointerCapture(ev.pointerId);
			} catch {}
			const box = junctionToBox(a, b);
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.end, {
				bubbles: true,
				detail: {
					a: { ...a },
					b: { ...b },
					box,
					host
				}
			}));
		};
		const onUp = (ev) => {
			if (!active) return;
			end(ev);
		};
		const onCancel = (ev) => {
			if (!active) return;
			active = false;
			overlay.style.display = "none";
			try {
				host.releasePointerCapture(ev.pointerId);
			} catch {}
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.cancel, {
				bubbles: true,
				detail: { host }
			}));
		};
		pushDisposable(host, "ui-junction-select", () => {
			overlay.remove();
		});
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointerdown", onDown));
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointermove", onMove));
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointerup", onUp));
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointercancel", onCancel));
		return this;
	}
	disconnect(wEl) {
		const host = wEl?.deref?.();
		if (host) runDisposers(host, "ui-junction-select");
		return this;
	}
};
var JunctionDragMixin = class extends DOMMixin {
	constructor() {
		super("ui-junction-drag");
	}
	connect(wEl) {
		const host = wEl?.deref?.();
		if (!host) return this;
		setStyleProperty(host, "--jx-drag-x", parsePxVar(host, "--jx-drag-x"));
		setStyleProperty(host, "--jx-drag-y", parsePxVar(host, "--jx-drag-y"));
		const previousTransform = host.style.transform;
		if (!host.style.transform || host.style.transform === "none") host.style.transform = "translate3d(calc(var(--jx-drag-x, 0) * 1px), calc(var(--jx-drag-y, 0) * 1px), 0)";
		const handle = queryHandle(host, "data-junction-drag-handle", host);
		let dragging = false;
		let startX = 0;
		let startY = 0;
		let baseX = 0;
		let baseY = 0;
		const onDown = (ev) => {
			if (ev.button !== 0) return;
			if (ev.target !== handle && !handle.contains(ev.target)) return;
			dragging = true;
			startX = ev.clientX;
			startY = ev.clientY;
			baseX = parsePxVar(host, "--jx-drag-x");
			baseY = parsePxVar(host, "--jx-drag-y");
			handle.setPointerCapture(ev.pointerId);
			host.dispatchEvent(new CustomEvent(JUNCTION_DRAG_EVENTS.start, {
				bubbles: true,
				detail: {
					host,
					clientX: ev.clientX,
					clientY: ev.clientY,
					baseX,
					baseY
				}
			}));
		};
		const onMove = (ev) => {
			if (!dragging) return;
			const dx = ev.clientX - startX;
			const dy = ev.clientY - startY;
			const nx = baseX + dx;
			const ny = baseY + dy;
			setStyleProperty(host, "--jx-drag-x", nx);
			setStyleProperty(host, "--jx-drag-y", ny);
			host.dispatchEvent(new CustomEvent(JUNCTION_DRAG_EVENTS.move, {
				bubbles: true,
				detail: {
					host,
					dx,
					dy,
					x: nx,
					y: ny
				}
			}));
		};
		const onUp = (ev) => {
			if (!dragging) return;
			dragging = false;
			try {
				handle.releasePointerCapture(ev.pointerId);
			} catch {}
			host.dispatchEvent(new CustomEvent(JUNCTION_DRAG_EVENTS.end, {
				bubbles: true,
				detail: {
					host,
					x: parsePxVar(host, "--jx-drag-x"),
					y: parsePxVar(host, "--jx-drag-y")
				}
			}));
		};
		pushDisposable(host, "ui-junction-drag", () => {
			host.style.transform = previousTransform;
		});
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointerdown", onDown));
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointermove", onMove));
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointerup", onUp));
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointercancel", onUp));
		return this;
	}
	disconnect(wEl) {
		const host = wEl?.deref?.();
		if (host) runDisposers(host, "ui-junction-drag");
		return this;
	}
};
var JunctionResizeMixin = class extends DOMMixin {
	constructor() {
		super("ui-junction-resize");
	}
	connect(wEl) {
		const host = wEl?.deref?.();
		if (!host) return this;
		const handle = queryHandle(host, "data-junction-resize-handle", host);
		let resizing = false;
		let sx = 0;
		let sy = 0;
		let sw = 0;
		let sh = 0;
		const minW = Math.max(120, parseFloat(host.getAttribute("data-junction-resize-min-w") || "") || 120);
		const minH = Math.max(80, parseFloat(host.getAttribute("data-junction-resize-min-h") || "") || 80);
		const onDown = (ev) => {
			if (ev.button !== 0) return;
			if (ev.target !== handle && !handle.contains(ev.target)) return;
			resizing = true;
			sx = ev.clientX;
			sy = ev.clientY;
			sw = host.offsetWidth;
			sh = host.offsetHeight;
			handle.setPointerCapture(ev.pointerId);
			host.dispatchEvent(new CustomEvent(JUNCTION_RESIZE_EVENTS.start, {
				bubbles: true,
				detail: {
					host,
					width: sw,
					height: sh
				}
			}));
		};
		const onMove = (ev) => {
			if (!resizing) return;
			const nw = Math.max(minW, sw + (ev.clientX - sx));
			const nh = Math.max(minH, sh + (ev.clientY - sy));
			host.style.width = `${nw}px`;
			host.style.height = `${nh}px`;
			host.dispatchEvent(new CustomEvent(JUNCTION_RESIZE_EVENTS.move, {
				bubbles: true,
				detail: {
					host,
					width: nw,
					height: nh
				}
			}));
		};
		const onUp = (ev) => {
			if (!resizing) return;
			resizing = false;
			try {
				handle.releasePointerCapture(ev.pointerId);
			} catch {}
			host.dispatchEvent(new CustomEvent(JUNCTION_RESIZE_EVENTS.end, {
				bubbles: true,
				detail: {
					host,
					width: host.offsetWidth,
					height: host.offsetHeight
				}
			}));
		};
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointerdown", onDown));
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointermove", onMove));
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointerup", onUp));
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointercancel", onUp));
		return this;
	}
	disconnect(wEl) {
		const host = wEl?.deref?.();
		if (host) runDisposers(host, "ui-junction-resize");
		return this;
	}
};
new JunctionSelectMixin();
new JunctionDragMixin();
new JunctionResizeMixin();
typeof document !== "undefined" && document?.documentElement && addProxiedEvent(document.documentElement, "contextmenu", {
	capture: true,
	passive: false
}, {
	strategy: "closest",
	preventDefault: "handled",
	stopImmediatePropagation: "handled"
});
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/Clipboard.ts
var CLIPBOARD_CHANNEL = "rs-clipboard";
/** Beyond this, legacy execCommand + textarea.select() can freeze the tab for seconds. */
var CLIPBOARD_LEGACY_MAX_CHARS = 256e3;
/** Hard cap — clipboard APIs and string work degrade badly above this. */
var CLIPBOARD_TEXT_MAX_CHARS = 2e6;
/** Failsafe if the browser never settles clipboard read/write. */
var CLIPBOARD_OPERATION_TIMEOUT_MS = 12e3;
var scheduleClipboardFrame = (cb) => {
	if (typeof globalThis.requestAnimationFrame === "function") {
		globalThis.requestAnimationFrame(cb);
		return;
	}
	if (typeof MessageChannel !== "undefined") {
		const channel = new MessageChannel();
		channel.port1.onmessage = () => cb();
		channel.port2.postMessage(void 0);
		return;
	}
	if (typeof setTimeout === "function") {
		setTimeout(() => cb(), 16);
		return;
	}
	if (typeof queueMicrotask === "function") {
		queueMicrotask(() => cb());
		return;
	}
	cb();
};
/**
* Convert data to string safely
*/
var toText = (data) => {
	if (data == null) return "";
	if (typeof data === "string") return data;
	try {
		return JSON.stringify(data, null, 2);
	} catch {
		return String(data);
	}
};
var raceClipboardWrite = (write, ms) => Promise.race([write.then(() => "ok").catch(() => "error"), new Promise((res) => {
	globalThis.setTimeout(() => res("timeout"), ms);
})]);
/**
* Write text to clipboard using modern API
*/
var writeText = async (text) => {
	const raw = toText(text);
	if (!raw.trim()) return {
		ok: false,
		error: "Empty content"
	};
	if (raw.length > CLIPBOARD_TEXT_MAX_CHARS) return {
		ok: false,
		error: "Content too large to copy safely"
	};
	const trimmed = raw.trim();
	return new Promise((resolve) => {
		scheduleClipboardFrame(() => {
			if (typeof document !== "undefined" && document.hasFocus && !document.hasFocus()) globalThis?.focus?.();
			const tryClipboardAPI = async () => {
				const tryWriteText = async () => {
					if (typeof navigator === "undefined" || !navigator.clipboard?.writeText) return false;
					const outcome = await raceClipboardWrite(navigator.clipboard.writeText(trimmed), CLIPBOARD_OPERATION_TIMEOUT_MS);
					if (outcome === "ok") return true;
					if (outcome === "timeout") console.warn("[Clipboard] writeText timed out");
					return false;
				};
				try {
					if (await tryWriteText()) {
						resolve({
							ok: true,
							data: trimmed,
							method: "clipboard-api"
						});
						return;
					}
				} catch (err) {
					console.warn("[Clipboard] Direct write failed:", err);
				}
				if (trimmed.length > CLIPBOARD_LEGACY_MAX_CHARS) {
					resolve({
						ok: false,
						error: "Content too large for fallback copy"
					});
					return;
				}
				try {
					if (typeof document !== "undefined") {
						const textarea = document.createElement("textarea");
						textarea.value = trimmed;
						textarea.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0;pointer-events:none;";
						document.body.appendChild(textarea);
						textarea.select();
						textarea.remove();
					}
				} catch (err) {
					console.warn("[Clipboard] Legacy execCommand failed:", err);
				}
				resolve({
					ok: false,
					error: "All clipboard methods failed"
				});
			};
			tryClipboardAPI();
		});
	});
};
/**
* Write HTML content to clipboard (with text fallback)
*/
var writeHTML = async (html, plainText) => {
	const htmlContent = html.trim();
	const textContent = (plainText ?? htmlContent).trim();
	if (!htmlContent) return {
		ok: false,
		error: "Empty content"
	};
	return new Promise((resolve) => {
		scheduleClipboardFrame(() => {
			if (typeof document !== "undefined" && document.hasFocus && !document.hasFocus()) globalThis?.focus?.();
			const tryHTMLClipboard = async () => {
				try {
					if (typeof navigator !== "undefined" && navigator.clipboard?.write) {
						const htmlBlob = new Blob([htmlContent], { type: "text/html" });
						const textBlob = new Blob([textContent], { type: "text/plain" });
						await navigator.clipboard.write([new ClipboardItem({
							"text/html": htmlBlob,
							"text/plain": textBlob
						})]);
						return resolve({
							ok: true,
							data: htmlContent,
							method: "clipboard-api"
						});
					}
				} catch (err) {
					console.warn("[Clipboard] HTML write failed:", err);
				}
				resolve(await writeText(textContent));
			};
			tryHTMLClipboard();
		});
	});
};
/**
* Write image to clipboard
*/
var writeImage = async (blob) => {
	return new Promise((resolve) => {
		scheduleClipboardFrame(async () => {
			if (typeof document !== "undefined" && document.hasFocus && !document.hasFocus()) globalThis?.focus?.();
			try {
				let imageBlob;
				if (typeof blob === "string") if (blob.startsWith("data:")) imageBlob = await (await fetch(blob)).blob();
				else imageBlob = await (await fetch(blob)).blob();
				else imageBlob = blob;
				if (typeof navigator !== "undefined" && navigator.clipboard?.write) {
					const pngBlob = imageBlob.type === "image/png" ? imageBlob : await convertToPng(imageBlob);
					await navigator.clipboard.write([new ClipboardItem({ [pngBlob.type]: pngBlob })]);
					resolve({
						ok: true,
						method: "clipboard-api"
					});
					return;
				}
			} catch (err) {
				console.warn("[Clipboard] Image write failed:", err);
			}
			resolve({
				ok: false,
				error: "Image clipboard not supported"
			});
		});
	});
};
/**
* Convert image blob to PNG
*/
var convertToPng = async (blob) => {
	return new Promise((resolve, reject) => {
		if (typeof document === "undefined") {
			reject(/* @__PURE__ */ new Error("No document context"));
			return;
		}
		const img = new Image();
		const url = URL.createObjectURL(blob);
		img.onload = () => {
			const canvas = document.createElement("canvas");
			canvas.width = img.naturalWidth;
			canvas.height = img.naturalHeight;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Canvas context failed"));
				return;
			}
			ctx.drawImage(img, 0, 0);
			canvas.toBlob((pngBlob) => {
				URL.revokeObjectURL(url);
				if (pngBlob) resolve(pngBlob);
				else reject(/* @__PURE__ */ new Error("PNG conversion failed"));
			}, "image/png");
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Image load failed"));
		};
		img.src = url;
	});
};
/**
* Unified copy function with automatic type detection
*/
var copy = async (data, options = {}) => {
	const { type, showFeedback = false, silentOnError = false } = options;
	return new Promise((resolve) => {
		scheduleClipboardFrame(async () => {
			let result;
			if (data instanceof Blob) if (data.type.startsWith("image/")) result = await writeImage(data);
			else result = await writeText(await data.text());
			else if (type === "html" || typeof data === "string" && data.trim().startsWith("<")) result = await writeHTML(String(data));
			else if (type === "image") result = await writeImage(data);
			else result = await writeText(toText(data));
			if (showFeedback && (result.ok || !silentOnError)) broadcastClipboardFeedback(result);
			resolve(result);
		});
	});
};
/**
* Broadcast clipboard feedback for toast display
*/
var broadcastClipboardFeedback = (result) => {
	try {
		const channel = new BroadcastChannel("rs-toast");
		channel.postMessage({
			type: "show-toast",
			options: {
				message: result.ok ? "Copied to clipboard" : result.error || "Copy failed",
				kind: result.ok ? "success" : "error",
				duration: 2e3
			}
		});
		channel.close();
	} catch (e) {
		console.warn("[Clipboard] Feedback broadcast failed:", e);
	}
};
/** One logical listener for rs-clipboard — multiple initClipboardReceiver calls must not stack handlers (duplicate copy() freezes UI). */
var _clipboardBroadcastChannel = null;
var _clipboardBroadcastRefCount = 0;
var _clipboardBroadcastHandler = null;
/** Serialize SW/client broadcast copies so overlapping clipboard API work does not wedge the main thread. */
var _clipboardBroadcastQueue = Promise.resolve();
/**
* Listen for clipboard operation requests
*/
var listenForClipboardRequests = () => {
	if (typeof BroadcastChannel === "undefined") return () => {};
	if (_clipboardBroadcastRefCount === 0) {
		const channel = new BroadcastChannel(CLIPBOARD_CHANNEL);
		const handler = (event) => {
			if (event.data?.type !== "copy") return;
			const opts = event.data.options || {};
			const data = event.data.data;
			_clipboardBroadcastQueue = _clipboardBroadcastQueue.then(async () => {
				try {
					await copy(data, {
						...opts,
						showFeedback: opts.showFeedback !== false,
						silentOnError: opts.silentOnError === true
					});
				} catch (err) {
					console.warn("[Clipboard] Broadcast copy failed:", err);
				}
			});
		};
		channel.addEventListener("message", handler);
		_clipboardBroadcastChannel = channel;
		_clipboardBroadcastHandler = handler;
	}
	_clipboardBroadcastRefCount++;
	return () => {
		_clipboardBroadcastRefCount--;
		if (_clipboardBroadcastRefCount <= 0) {
			const ch = _clipboardBroadcastChannel;
			const h = _clipboardBroadcastHandler;
			if (ch && h) {
				ch.removeEventListener("message", h);
				ch.close();
			}
			_clipboardBroadcastChannel = null;
			_clipboardBroadcastHandler = null;
			_clipboardBroadcastRefCount = 0;
		}
	};
};
/**
* Initialize clipboard listener for receiving copy requests
*/
var initClipboardReceiver = () => {
	return listenForClipboardRequests();
};
var collectProviders = (ev, action) => {
	const providers = /* @__PURE__ */ new Set();
	let el = ev?.target || document.activeElement || document.body;
	if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el.isContentEditable) return [];
	let current = el;
	const visited = /* @__PURE__ */ new Set();
	while (current && !visited.has(current)) {
		visited.add(current);
		if (typeof current[action] === "function") providers.add(current);
		if (current.operativeInstance && typeof current.operativeInstance[action] === "function") providers.add(current.operativeInstance);
		const shadowHost = current.shadowRoot?.host;
		if (shadowHost && shadowHost !== current) current = shadowHost;
		else {
			const rootHost = (current.getRootNode?.())?.host;
			const next = current.parentElement || rootHost;
			current = next && next !== current ? next : null;
		}
	}
	if (ev.currentTarget instanceof Node || typeof document !== "undefined") {
		const root = ev.currentTarget instanceof Node ? ev.currentTarget instanceof Document ? ev.currentTarget.body : ev.currentTarget : document.body;
		if (root) {
			const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, { acceptNode(node) {
				if (typeof node[action] === "function" || node.operativeInstance && typeof node.operativeInstance[action] === "function") return NodeFilter.FILTER_ACCEPT;
				return NodeFilter.FILTER_SKIP;
			} });
			while (walker.nextNode()) {
				const node = walker.currentNode;
				if (typeof node[action] === "function") providers.add(node);
				if (node.operativeInstance && typeof node.operativeInstance[action] === "function") providers.add(node.operativeInstance);
			}
		}
	}
	return Array.from(providers);
};
var handleClipboardEvent = (ev, type) => {
	const providers = collectProviders(ev, type);
	const handled = /* @__PURE__ */ new Set();
	for (const provider of providers) {
		if (handled.has(provider)) continue;
		const operative = provider?.operativeInstance;
		if (operative && handled.has(operative)) continue;
		handled.add(provider);
		if (operative) handled.add(operative);
		provider[type]?.(ev);
	}
};
var initialized = false;
var initGlobalClipboard = () => {
	if (typeof window === "undefined" || initialized) return;
	initialized = true;
	lazyAddEventListener(window, "copy", (ev) => handleClipboardEvent(ev, "onCopy"), {
		capture: false,
		passive: true
	});
	lazyAddEventListener(window, "cut", (ev) => handleClipboardEvent(ev, "onCut"), {
		capture: false,
		passive: true
	});
	lazyAddEventListener(window, "paste", (ev) => handleClipboardEvent(ev, "onPaste"), {
		capture: false,
		passive: false
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/DesktopStateStorage.ts
/**
* Versioned JSON persistence for the orient-layer speed dial / desktop grid.
* - Main key: canonical layout + items
* - Draft key: debounced snapshot while dragging (crash recovery if main never flushed)
*/
var DESKTOP_MAIN_KEY = "cw-oriented-desktop-layout-v1";
var DESKTOP_DRAFT_KEY = `${DESKTOP_MAIN_KEY}.draft`;
var safeGet = (key) => {
	try {
		return localStorage.getItem(key);
	} catch {
		return null;
	}
};
var safeSet = (key, value) => {
	try {
		localStorage.setItem(key, value);
	} catch {}
};
var safeRemove = (key) => {
	try {
		localStorage.removeItem(key);
	} catch {}
};
/** Encode grid state as compact JSON (ISO timestamp for debugging / sync). */
function encodeDesktopState(columns, rows, items) {
	const payload = {
		v: 2,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		columns,
		rows,
		items
	};
	return JSON.stringify(payload);
}
/**
* Decode persisted JSON. Accepts v2 envelope or legacy flat `{ columns, rows, items }`.
*/
function decodeDesktopState(raw) {
	try {
		const p = JSON.parse(raw);
		if (!p || typeof p !== "object") return null;
		const items = p.items;
		if (!Array.isArray(items)) return null;
		const columns = Math.max(0, Number(p.columns));
		const rows = Math.max(0, Number(p.rows));
		if (p.v === 2 && Number.isFinite(columns) && Number.isFinite(rows)) return {
			v: 2,
			updatedAt: String(p.updatedAt || (/* @__PURE__ */ new Date()).toISOString()),
			columns: columns || 6,
			rows: rows || 8,
			items
		};
		return {
			v: 2,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			columns: Number.isFinite(columns) && columns > 0 ? columns : 6,
			rows: Number.isFinite(rows) && rows > 0 ? rows : 8,
			items
		};
	} catch {
		return null;
	}
}
function loadDesktopRaw() {
	const main = safeGet(DESKTOP_MAIN_KEY);
	const draft = safeGet(DESKTOP_DRAFT_KEY);
	if (!main) return draft;
	if (!draft) return main;
	const mainDec = decodeDesktopState(main);
	const draftDec = decodeDesktopState(draft);
	if (!mainDec) return draft;
	if (!draftDec) return main;
	const mainT = Date.parse(mainDec.updatedAt || "");
	const draftT = Date.parse(draftDec.updatedAt || "");
	if (Number.isFinite(draftT) && Number.isFinite(mainT) && draftT > mainT) return draft;
	return main;
}
/** Write main snapshot and drop draft (commit). */
function persistDesktopMain(columns, rows, items) {
	safeSet(DESKTOP_MAIN_KEY, encodeDesktopState(columns, rows, items));
	safeRemove(DESKTOP_DRAFT_KEY);
}
/** Intermediate snapshot only (e.g. while dragging). */
function persistDesktopDraft(columns, rows, items) {
	safeSet(DESKTOP_DRAFT_KEY, encodeDesktopState(columns, rows, items));
}
//#endregion
//#region ../../node_modules/jsox/lib/jsox.mjs
var _JSON = JSON;
/**
* JSOX container for all JSOX methods.
* @namespace
*/
var JSOX = {};
JSOX.JSOX = JSOX;
JSOX.version = "1.2.125";
var hasBigInt = typeof BigInt === "function";
var VALUE_UNDEFINED = -1;
var VALUE_UNSET = 0;
var VALUE_NULL = 1;
var VALUE_TRUE = 2;
var VALUE_FALSE = 3;
var VALUE_STRING = 4;
var VALUE_NUMBER = 5;
var VALUE_OBJECT = 6;
var VALUE_NEG_NAN = 7;
var VALUE_NAN = 8;
var VALUE_NEG_INFINITY = 9;
var VALUE_INFINITY = 10;
var VALUE_EMPTY = 12;
var VALUE_ARRAY = 13;
var knownArrayTypeNames = [
	"ab",
	"u8",
	"cu8",
	"s8",
	"u16",
	"s16",
	"u32",
	"s32",
	"u64",
	"s64",
	"f32",
	"f64"
];
var arrayToJSOX = null;
var mapToJSOX = null;
var knownArrayTypes = [
	ArrayBuffer,
	Uint8Array,
	Uint8ClampedArray,
	Int8Array,
	Uint16Array,
	Int16Array,
	Uint32Array,
	Int32Array,
	null,
	null,
	Float32Array,
	Float64Array
];
var WORD_POS_RESET = 0;
var WORD_POS_TRUE_1 = 1;
var WORD_POS_TRUE_2 = 2;
var WORD_POS_TRUE_3 = 3;
var WORD_POS_FALSE_1 = 5;
var WORD_POS_FALSE_2 = 6;
var WORD_POS_FALSE_3 = 7;
var WORD_POS_FALSE_4 = 8;
var WORD_POS_NULL_1 = 9;
var WORD_POS_NULL_2 = 10;
var WORD_POS_NULL_3 = 11;
var WORD_POS_UNDEFINED_1 = 12;
var WORD_POS_UNDEFINED_2 = 13;
var WORD_POS_UNDEFINED_3 = 14;
var WORD_POS_UNDEFINED_4 = 15;
var WORD_POS_UNDEFINED_5 = 16;
var WORD_POS_UNDEFINED_6 = 17;
var WORD_POS_UNDEFINED_7 = 18;
var WORD_POS_UNDEFINED_8 = 19;
var WORD_POS_NAN_1 = 20;
var WORD_POS_NAN_2 = 21;
var WORD_POS_INFINITY_1 = 22;
var WORD_POS_INFINITY_2 = 23;
var WORD_POS_INFINITY_3 = 24;
var WORD_POS_INFINITY_4 = 25;
var WORD_POS_INFINITY_5 = 26;
var WORD_POS_INFINITY_6 = 27;
var WORD_POS_INFINITY_7 = 28;
var WORD_POS_FIELD = 29;
var WORD_POS_AFTER_FIELD = 30;
var WORD_POS_END = 31;
var WORD_POS_AFTER_FIELD_VALUE = 32;
var CONTEXT_UNKNOWN = 0;
var CONTEXT_IN_ARRAY = 1;
var CONTEXT_OBJECT_FIELD = 2;
var CONTEXT_OBJECT_FIELD_VALUE = 3;
var CONTEXT_CLASS_FIELD = 4;
var CONTEXT_CLASS_VALUE = 5;
var CONTEXT_CLASS_FIELD_VALUE = 6;
var keywords = {
	["true"]: true,
	["false"]: false,
	["null"]: null,
	["NaN"]: NaN,
	["Infinity"]: Infinity,
	["undefined"]: void 0
};
/**
* Extend Date type with a nanosecond field.
* @constructor
* @param {Date} original_date
* @param {Number} nanoseconds in milli-seconds of Date ( 0 to 1_000_000 )
*/
var DateNS = class extends Date {
	constructor(a, b) {
		super(a);
		this.ns = b || 0;
	}
};
JSOX.DateNS = DateNS;
var contexts = [];
/**
* get a context from stack (reuse contexts)
* @internal
*/
function getContext() {
	let ctx = contexts.pop();
	if (!ctx) ctx = {
		context: CONTEXT_UNKNOWN,
		current_proto: null,
		current_class: null,
		current_class_field: 0,
		arrayType: -1,
		valueType: VALUE_UNSET,
		elements: null
	};
	return ctx;
}
/**
* return a context to the stack (reuse contexts)
* @internal
*/
function dropContext(ctx) {
	contexts.push(ctx);
}
/**
* SACK jsox compatibility; hands maps to internal C++ code in other case.
* @internal
*/
JSOX.updateContext = function() {};
var buffers = [];
function getBuffer() {
	let buf = buffers.pop();
	if (!buf) buf = {
		buf: null,
		n: 0
	};
	else buf.n = 0;
	return buf;
}
function dropBuffer(buf) {
	buffers.push(buf);
}
/**
* Provide minimal escapes for a string to be encapsulated as a JSOX string in quotes.
*
* @param {string} string 
* @returns {string}
*/
JSOX.escape = function(string) {
	let n;
	let output = "";
	if (!string) return string;
	for (n = 0; n < string.length; n++) {
		if (string[n] == "\"" || string[n] == "\\" || string[n] == "`" || string[n] == "'") output += "\\";
		output += string[n];
	}
	return output;
};
var toProtoTypes = /* @__PURE__ */ new WeakMap();
var toObjectTypes = /* @__PURE__ */ new Map();
var fromProtoTypes = /* @__PURE__ */ new Map();
var commonClasses = [];
/**
* reset JSOX parser entirely; clears all type mappings
*
* @returns {void}
*/
JSOX.reset = function() {
	toProtoTypes = /* @__PURE__ */ new WeakMap();
	toObjectTypes = /* @__PURE__ */ new Map();
	fromProtoTypes = /* @__PURE__ */ new Map();
	commonClasses = [];
};
/**
* Create a streaming parser.  Add data with parser.write(data); values that
* are found are dispatched to the callback.
*
* @param {(value:any) => void} [cb]
* @param {(this: any, key: string, value: any) => any} [reviver] 
* @returns {JSOXParser}
*/
JSOX.begin = function(cb, reviver) {
	const val = {
		name: null,
		value_type: VALUE_UNSET,
		string: "",
		contains: null,
		className: null
	};
	const pos = {
		line: 1,
		col: 1
	};
	let n = 0;
	let str;
	let localFromProtoTypes = /* @__PURE__ */ new Map();
	let word = WORD_POS_RESET, status = true, redefineClass = false, negative = false, result = null, rootObject = null, elements = void 0, context_stack = {
		first: null,
		last: null,
		saved: null,
		push(node) {
			let recover = this.saved;
			if (recover) {
				this.saved = recover.next;
				recover.node = node;
				recover.next = null;
				recover.prior = this.last;
			} else recover = {
				node,
				next: null,
				prior: this.last
			};
			if (!this.last) this.first = recover;
			else this.last.next = recover;
			this.last = recover;
			this.length++;
		},
		pop() {
			let result = this.last;
			if (!(this.last = result.prior)) this.first = null;
			result.next = this.saved;
			if (this.last) this.last.next = null;
			if (!result.next) result.first = null;
			this.saved = result;
			this.length--;
			return result.node;
		},
		length: 0
	}, classes = [], protoTypes = {}, current_proto = null, current_class = null, current_class_field = 0, arrayType = -1, parse_context = CONTEXT_UNKNOWN, comment = 0, fromHex = false, decimal = false, exponent = false, exponent_sign = false, exponent_digit = false, inQueue = {
		first: null,
		last: null,
		saved: null,
		push(node) {
			let recover = this.saved;
			if (recover) {
				this.saved = recover.next;
				recover.node = node;
				recover.next = null;
				recover.prior = this.last;
			} else recover = {
				node,
				next: null,
				prior: this.last
			};
			if (!this.last) this.first = recover;
			else this.last.next = recover;
			this.last = recover;
		},
		shift() {
			let result = this.first;
			if (!result) return null;
			if (!(this.first = result.next)) this.last = null;
			result.next = this.saved;
			this.saved = result;
			return result.node;
		},
		unshift(node) {
			let recover = this.saved;
			this.saved = recover.next;
			recover.node = node;
			recover.next = this.first;
			recover.prior = null;
			if (!this.first) this.last = recover;
			this.first = recover;
		}
	}, gatheringStringFirstChar = null, gatheringString = false, gatheringNumber = false, stringEscape = false, cr_escaped = false, unicodeWide = false, stringUnicode = false, stringHex = false, hex_char = 0, hex_char_len = 0, completed = false, date_format = false, isBigInt = false;
	function throwEndError(leader) {
		throw new Error(`${leader} at ${n} [${pos.line}:${pos.col}]`);
	}
	return {
		/**
		* Define a class that can be used to deserialize objects of this type.
		* @param {string} prototypeName 
		* @param {new ():any} o 
		* @param {(any)=>any} f 
		*/
		fromJSOX(prototypeName, o, f) {
			if (localFromProtoTypes.get(prototypeName)) throw new Error("Existing fromJSOX has been registered for prototype");
			function privateProto() {}
			if (!o) o = privateProto;
			if (o && !("constructor" in o)) throw new Error("Please pass a prototype like thing...");
			localFromProtoTypes.set(prototypeName, {
				protoCon: o.prototype.constructor,
				cb: f
			});
		},
		registerFromJSOX(prototypeName, o) {
			throw new Error("registerFromJSOX is deprecated, please update to use fromJSOX instead:" + prototypeName + o.toString());
		},
		finalError() {
			if (comment !== 0) {
				if (comment === 1) throwEndError("Comment began at end of document");
				if (comment === 2);
				if (comment === 3) throwEndError("Open comment '/*' is missing close at end of document");
				if (comment === 4) throwEndError("Incomplete '/* *' close at end of document");
			}
			if (gatheringString) throwEndError("Incomplete string");
		},
		value() {
			this.finalError();
			let r = result;
			result = void 0;
			return r;
		},
		/**
		* Reset the parser to a blank state.
		*/
		reset() {
			word = WORD_POS_RESET;
			status = true;
			if (inQueue.last) inQueue.last.next = inQueue.save;
			inQueue.save = inQueue.first;
			inQueue.first = inQueue.last = null;
			if (context_stack.last) context_stack.last.next = context_stack.save;
			context_stack.length = 0;
			context_stack.save = inQueue.first;
			context_stack.first = context_stack.last = null;
			elements = void 0;
			parse_context = CONTEXT_UNKNOWN;
			classes = [];
			protoTypes = {};
			current_proto = null;
			current_class = null;
			current_class_field = 0;
			val.value_type = VALUE_UNSET;
			val.name = null;
			val.string = "";
			val.className = null;
			pos.line = 1;
			pos.col = 1;
			negative = false;
			comment = 0;
			completed = false;
			gatheringString = false;
			stringEscape = false;
			cr_escaped = false;
			date_format = false;
		},
		usePrototype(className, protoType) {
			protoTypes[className] = protoType;
		},
		/**
		* Add input to the parser to get parsed.
		* @param {string} msg 
		*/
		write(msg) {
			let retcode;
			if (typeof msg !== "string" && typeof msg !== "undefined") msg = String(msg);
			if (!status) throw new Error("Parser is still in an error state, please reset before resuming");
			for (retcode = this._write(msg, false); retcode > 0; retcode = this._write()) {
				if (typeof reviver === "function") (function walk(holder, key) {
					let k, v, value = holder[key];
					if (value && typeof value === "object") {
						for (k in value) if (Object.prototype.hasOwnProperty.call(value, k)) {
							v = walk(value, k);
							if (v !== void 0) value[k] = v;
							else delete value[k];
						}
					}
					return reviver.call(holder, key, value);
				})({ "": result }, "");
				result = cb(result);
				if (retcode < 2) break;
			}
		},
		/**
		* Parse a string and return the result.
		* @template T
		* @param {string} msg
		* @param {(key:string,value:any)=>any} [reviver]
		* @returns {T}
		*/
		parse(msg, reviver) {
			if (typeof msg !== "string") msg = String(msg);
			this.reset();
			const writeResult = this._write(msg, true);
			if (writeResult > 0) {
				if (writeResult > 1) {}
				let result = this.value();
				if ("undefined" === typeof result && writeResult > 1) throw new Error("Pending value could not complete");
				result = typeof reviver === "function" ? function walk(holder, key) {
					let k, v, value = holder[key];
					if (value && typeof value === "object") {
						for (k in value) if (Object.prototype.hasOwnProperty.call(value, k)) {
							v = walk(value, k);
							if (v !== void 0) value[k] = v;
							else delete value[k];
						}
					}
					return reviver.call(holder, key, value);
				}({ "": result }, "") : result;
				return result;
			}
			this.finalError();
		},
		_write(msg, complete_at_end) {
			let cInt;
			let input;
			let buf;
			let retval = 0;
			function throwError(leader, c) {
				throw new Error(`${leader} '${String.fromCodePoint(c)}' unexpected at ${n} (near '${buf.substr(n > 4 ? n - 4 : 0, n > 4 ? 3 : n - 1)}[${String.fromCodePoint(c)}]${buf.substr(n, 10)}') [${pos.line}:${pos.col}]`);
			}
			function RESET_VAL() {
				val.value_type = VALUE_UNSET;
				val.string = "";
				val.contains = null;
			}
			function convertValue() {
				let fp = null;
				switch (val.value_type) {
					case VALUE_NUMBER:
						if ((val.string.length > 13 || val.string.length == 13 && val[0] > "2") && !date_format && !exponent_digit && !exponent_sign && !decimal) isBigInt = true;
						if (isBigInt) if (hasBigInt) return BigInt(val.string);
						else throw new Error("no builtin BigInt()", 0);
						if (date_format) {
							const r = val.string.match(/\.(\d\d\d\d*)/);
							const frac = r ? r[1] : null;
							if (!frac || frac.length < 4) {
								const r = new Date(val.string);
								if (isNaN(r.getTime())) throwError("Bad Date format", cInt);
								return r;
							} else {
								let ns = frac.substr(3);
								while (ns.length < 6) ns = ns + "0";
								const r = new DateNS(val.string, Number(ns));
								if (isNaN(r.getTime())) throwError("Bad DateNS format" + r + r.getTime(), cInt);
								return r;
							}
						}
						return (negative ? -1 : 1) * Number(val.string);
					case VALUE_STRING:
						if (val.className) {
							fp = localFromProtoTypes.get(val.className);
							if (!fp) fp = fromProtoTypes.get(val.className);
							if (fp && fp.cb) {
								val.className = null;
								return fp.cb.call(val.string);
							} else throw new Error("Double string error, no constructor for: new " + val.className + "(" + val.string + ")");
						}
						return val.string;
					case VALUE_TRUE: return true;
					case VALUE_FALSE: return false;
					case VALUE_NEG_NAN: return NaN;
					case VALUE_NAN: return NaN;
					case VALUE_NEG_INFINITY: return -Infinity;
					case VALUE_INFINITY: return Infinity;
					case VALUE_NULL: return null;
					case VALUE_UNDEFINED: return;
					case VALUE_EMPTY: return;
					case VALUE_OBJECT:
						if (val.className) {
							fp = localFromProtoTypes.get(val.className);
							if (!fp) fp = fromProtoTypes.get(val.className);
							val.className = null;
							if (fp && fp.cb) return val.contains = fp.cb.call(val.contains);
						}
						return val.contains;
					case VALUE_ARRAY:
						if (arrayType >= 0) {
							let ab;
							if (val.contains.length) ab = DecodeBase64(val.contains[0]);
							else ab = DecodeBase64(val.string);
							if (arrayType === 0) {
								arrayType = -1;
								return ab;
							} else {
								const newab = new knownArrayTypes[arrayType](ab);
								arrayType = -1;
								return newab;
							}
						} else if (arrayType === -2) {
							let obj = rootObject;
							let lvl;
							const pathlen = val.contains.length;
							for (lvl = 0; lvl < pathlen; lvl++) {
								const idx = val.contains[lvl];
								let nextObj = obj[idx];
								if (!nextObj) {
									let ctx = context_stack.first;
									let p = 0;
									while (ctx && p < pathlen && p < context_stack.length) {
										const thisKey = val.contains[p];
										if (!ctx.next || thisKey !== ctx.next.node.name) break;
										if (ctx.next) if ("number" === typeof thisKey) {
											const actualObject = ctx.next.node.elements;
											if (actualObject && thisKey >= actualObject.length) if (p === context_stack.length - 1) {
												console.log("This is actually at the current object so use that", p, val.contains, elements);
												nextObj = elements;
												p++;
												ctx = ctx.next;
												break;
											} else {
												if (ctx.next.next && thisKey === actualObject.length) {
													nextObj = ctx.next.next.node.elements;
													ctx = ctx.next;
													p++;
													obj = nextObj;
													continue;
												}
												nextObj = elements;
												p++;
												break;
											}
										} else if (thisKey !== ctx.next.node.name) {
											nextObj = ctx.next.node.elements[thisKey];
											lvl = p;
											break;
										} else if (ctx.next.next) nextObj = ctx.next.next.node.elements;
										else nextObj = elements;
										else nextObj = nextObj[thisKey];
										ctx = ctx.next;
										p++;
									}
									if (p < pathlen) lvl = p - 1;
									else lvl = p;
								}
								if ("object" === typeof nextObj && !nextObj) throw new Error("Path did not resolve properly:" + val.contains + " at " + idx + "(" + lvl + ")");
								obj = nextObj;
							}
							arrayType = -3;
							return obj;
						}
						if (val.className) {
							fp = localFromProtoTypes.get(val.className);
							if (!fp) fp = fromProtoTypes.get(val.className);
							val.className = null;
							if (fp && fp.cb) return fp.cb.call(val.contains);
						}
						return val.contains;
					default:
						console.log("Unhandled value conversion.", val);
						break;
				}
			}
			function arrayPush() {
				if (arrayType == -3) {
					if (val.value_type === VALUE_OBJECT) elements.push(val.contains);
					arrayType = -1;
					return;
				}
				switch (val.value_type) {
					case VALUE_EMPTY:
						elements.push(void 0);
						delete elements[elements.length - 1];
						break;
					default:
						elements.push(convertValue());
						break;
				}
				RESET_VAL();
			}
			function objectPush() {
				if (arrayType === -3 && val.value_type === VALUE_ARRAY) {
					RESET_VAL();
					arrayType = -1;
					return;
				}
				if (val.value_type === VALUE_EMPTY) return;
				if (!val.name && current_class) val.name = current_class.fields[current_class_field++];
				let value = convertValue();
				if (current_proto && current_proto.protoDef && current_proto.protoDef.cb) {
					value = current_proto.protoDef.cb.call(elements, val.name, value);
					if (value) elements[val.name] = value;
				} else elements[val.name] = value;
				RESET_VAL();
			}
			function recoverIdent(cInt) {
				if (word !== WORD_POS_RESET) {
					if (negative) throwError("Negative outside of quotes, being converted to a string (would lose count of leading '-' characters)", cInt);
					switch (word) {
						case WORD_POS_END:
							switch (val.value_type) {
								case VALUE_TRUE:
									val.string += "true";
									break;
								case VALUE_FALSE:
									val.string += "false";
									break;
								case VALUE_NULL:
									val.string += "null";
									break;
								case VALUE_INFINITY:
									val.string += "Infinity";
									break;
								case VALUE_NEG_INFINITY:
									val.string += "-Infinity";
									throwError("Negative outside of quotes, being converted to a string", cInt);
									break;
								case VALUE_NAN:
									val.string += "NaN";
									break;
								case VALUE_NEG_NAN:
									val.string += "-NaN";
									throwError("Negative outside of quotes, being converted to a string", cInt);
									break;
								case VALUE_UNDEFINED:
									val.string += "undefined";
									break;
								case VALUE_STRING: break;
								case VALUE_UNSET: break;
								default: console.log("Value of type " + val.value_type + " is not restored...");
							}
							break;
						case WORD_POS_TRUE_1:
							val.string += "t";
							break;
						case WORD_POS_TRUE_2:
							val.string += "tr";
							break;
						case WORD_POS_TRUE_3:
							val.string += "tru";
							break;
						case WORD_POS_FALSE_1:
							val.string += "f";
							break;
						case WORD_POS_FALSE_2:
							val.string += "fa";
							break;
						case WORD_POS_FALSE_3:
							val.string += "fal";
							break;
						case WORD_POS_FALSE_4:
							val.string += "fals";
							break;
						case WORD_POS_NULL_1:
							val.string += "n";
							break;
						case WORD_POS_NULL_2:
							val.string += "nu";
							break;
						case WORD_POS_NULL_3:
							val.string += "nul";
							break;
						case WORD_POS_UNDEFINED_1:
							val.string += "u";
							break;
						case WORD_POS_UNDEFINED_2:
							val.string += "un";
							break;
						case WORD_POS_UNDEFINED_3:
							val.string += "und";
							break;
						case WORD_POS_UNDEFINED_4:
							val.string += "unde";
							break;
						case WORD_POS_UNDEFINED_5:
							val.string += "undef";
							break;
						case WORD_POS_UNDEFINED_6:
							val.string += "undefi";
							break;
						case WORD_POS_UNDEFINED_7:
							val.string += "undefin";
							break;
						case WORD_POS_UNDEFINED_8:
							val.string += "undefine";
							break;
						case WORD_POS_NAN_1:
							val.string += "N";
							break;
						case WORD_POS_NAN_2:
							val.string += "Na";
							break;
						case WORD_POS_INFINITY_1:
							val.string += "I";
							break;
						case WORD_POS_INFINITY_2:
							val.string += "In";
							break;
						case WORD_POS_INFINITY_3:
							val.string += "Inf";
							break;
						case WORD_POS_INFINITY_4:
							val.string += "Infi";
							break;
						case WORD_POS_INFINITY_5:
							val.string += "Infin";
							break;
						case WORD_POS_INFINITY_6:
							val.string += "Infini";
							break;
						case WORD_POS_INFINITY_7:
							val.string += "Infinit";
							break;
						case WORD_POS_RESET: break;
						case WORD_POS_FIELD: break;
						case WORD_POS_AFTER_FIELD: break;
						case WORD_POS_AFTER_FIELD_VALUE:
							throwError("String-keyword recovery fail (after whitespace)", cInt);
							break;
						default:
					}
					val.value_type = VALUE_STRING;
					if (word < WORD_POS_FIELD) word = WORD_POS_END;
				} else {
					word = WORD_POS_END;
					val.value_type = VALUE_STRING;
				}
				if (cInt == 123) openObject();
				else if (cInt == 91) openArray();
				else if (cInt == 44) {} else {
					if (cInt == 32 || cInt == 13 || cInt == 10 || cInt == 9 || cInt == 65279 || cInt == 8232 || cInt == 8233) return;
					if (cInt == 44 || cInt == 125 || cInt == 93 || cInt == 58);
					else val.string += str;
				}
			}
			function gatherString(start_c) {
				let retval = 0;
				while (retval == 0 && n < buf.length) {
					str = buf.charAt(n);
					let cInt = buf.codePointAt(n++);
					if (cInt >= 65536) {
						str += buf.charAt(n);
						n++;
					}
					pos.col++;
					if (cInt == start_c) if (stringEscape) {
						if (stringHex) throwError("Incomplete hexidecimal sequence", cInt);
						else if (stringUnicode) throwError("Incomplete long unicode sequence", cInt);
						else if (unicodeWide) throwError("Incomplete unicode sequence", cInt);
						if (cr_escaped) {
							cr_escaped = false;
							retval = 1;
						} else val.string += str;
						stringEscape = false;
					} else retval = 1;
					else if (stringEscape) {
						if (unicodeWide) {
							if (cInt == 125) {
								val.string += String.fromCodePoint(hex_char);
								unicodeWide = false;
								stringUnicode = false;
								stringEscape = false;
								continue;
							}
							hex_char *= 16;
							if (cInt >= 48 && cInt <= 57) hex_char += cInt - 48;
							else if (cInt >= 65 && cInt <= 70) hex_char += cInt - 65 + 10;
							else if (cInt >= 97 && cInt <= 102) hex_char += cInt - 97 + 10;
							else {
								throwError("(escaped character, parsing hex of \\u)", cInt);
								retval = -1;
								unicodeWide = false;
								stringEscape = false;
								continue;
							}
							continue;
						} else if (stringHex || stringUnicode) {
							if (hex_char_len === 0 && cInt === 123) {
								unicodeWide = true;
								continue;
							}
							if (hex_char_len < 2 || stringUnicode && hex_char_len < 4) {
								hex_char *= 16;
								if (cInt >= 48 && cInt <= 57) hex_char += cInt - 48;
								else if (cInt >= 65 && cInt <= 70) hex_char += cInt - 65 + 10;
								else if (cInt >= 97 && cInt <= 102) hex_char += cInt - 97 + 10;
								else {
									throwError(stringUnicode ? "(escaped character, parsing hex of \\u)" : "(escaped character, parsing hex of \\x)", cInt);
									retval = -1;
									stringHex = false;
									stringEscape = false;
									continue;
								}
								hex_char_len++;
								if (stringUnicode) {
									if (hex_char_len == 4) {
										val.string += String.fromCodePoint(hex_char);
										stringUnicode = false;
										stringEscape = false;
									}
								} else if (hex_char_len == 2) {
									val.string += String.fromCodePoint(hex_char);
									stringHex = false;
									stringEscape = false;
								}
								continue;
							}
						}
						switch (cInt) {
							case 13:
								cr_escaped = true;
								pos.col = 1;
								continue;
							case 8232:
							case 8233: pos.col = 1;
							case 10:
								if (!cr_escaped) pos.col = 1;
								else cr_escaped = false;
								pos.line++;
								break;
							case 116:
								val.string += "	";
								break;
							case 98:
								val.string += "\b";
								break;
							case 110:
								val.string += "\n";
								break;
							case 114:
								val.string += "\r";
								break;
							case 102:
								val.string += "\f";
								break;
							case 118:
								val.string += "\v";
								break;
							case 48:
								val.string += "\0";
								break;
							case 120:
								stringHex = true;
								hex_char_len = 0;
								hex_char = 0;
								continue;
							case 117:
								stringUnicode = true;
								hex_char_len = 0;
								hex_char = 0;
								continue;
							default:
								val.string += str;
								break;
						}
						stringEscape = false;
					} else if (cInt === 92) if (stringEscape) {
						val.string += "\\";
						stringEscape = false;
					} else {
						stringEscape = true;
						hex_char = 0;
						hex_char_len = 0;
					}
					else {
						if (cr_escaped) {
							cr_escaped = false;
							pos.line++;
							pos.col = 2;
						}
						val.string += str;
					}
				}
				return retval;
			}
			function collectNumber() {
				let _n;
				while ((_n = n) < buf.length) {
					str = buf.charAt(_n);
					let cInt = buf.codePointAt(n++);
					if (cInt >= 256) {
						pos.col -= n - _n;
						n = _n;
						break;
					} else {
						if (cInt == 95) continue;
						pos.col++;
						if (cInt >= 48 && cInt <= 57) {
							if (exponent) exponent_digit = true;
							val.string += str;
						} else if (cInt == 45 || cInt == 43) if (val.string.length == 0 || exponent && !exponent_sign && !exponent_digit) {
							if (cInt == 45 && !exponent) negative = !negative;
							val.string += str;
							exponent_sign = true;
						} else {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						}
						else if (cInt == 78) {
							if (word == WORD_POS_RESET) {
								gatheringNumber = false;
								word = WORD_POS_NAN_1;
								return;
							}
							throwError("fault while parsing number;", cInt);
							break;
						} else if (cInt == 73) {
							if (word == WORD_POS_RESET) {
								gatheringNumber = false;
								word = WORD_POS_INFINITY_1;
								return;
							}
							throwError("fault while parsing number;", cInt);
							break;
						} else if (cInt == 58 && date_format) {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						} else if (cInt == 84 && date_format) {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						} else if (cInt == 90 && date_format) {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						} else if (cInt == 46) if (!decimal && !fromHex && !exponent) {
							val.string += str;
							decimal = true;
						} else {
							status = false;
							throwError("fault while parsing number;", cInt);
							break;
						}
						else if (cInt == 110) {
							isBigInt = true;
							break;
						} else if (fromHex && (cInt >= 95 && cInt <= 102 || cInt >= 65 && cInt <= 70)) val.string += str;
						else if (cInt == 120 || cInt == 98 || cInt == 111 || cInt == 88 || cInt == 66 || cInt == 79) if (!fromHex && val.string == "0") {
							fromHex = true;
							val.string += str;
						} else {
							status = false;
							throwError("fault while parsing number;", cInt);
							break;
						}
						else if (cInt == 101 || cInt == 69) if (!exponent) {
							val.string += str;
							exponent = true;
						} else {
							status = false;
							throwError("fault while parsing number;", cInt);
							break;
						}
						else if (cInt == 32 || cInt == 13 || cInt == 10 || cInt == 9 || cInt == 47 || cInt == 35 || cInt == 44 || cInt == 125 || cInt == 93 || cInt == 123 || cInt == 91 || cInt == 34 || cInt == 39 || cInt == 96 || cInt == 58) {
							pos.col -= n - _n;
							n = _n;
							break;
						} else {
							if (complete_at_end) {
								status = false;
								throwError("fault while parsing number;", cInt);
							}
							break;
						}
					}
				}
				if (!complete_at_end && n == buf.length) gatheringNumber = true;
				else {
					gatheringNumber = false;
					val.value_type = VALUE_NUMBER;
					if (parse_context == CONTEXT_UNKNOWN) completed = true;
				}
			}
			function openObject() {
				let nextMode = CONTEXT_OBJECT_FIELD;
				let cls = null;
				let tmpobj = {};
				if (word > WORD_POS_RESET && word < WORD_POS_FIELD) recoverIdent(123);
				let protoDef;
				protoDef = getProto();
				if (parse_context == CONTEXT_UNKNOWN) if (word == WORD_POS_FIELD || word == WORD_POS_END && (protoDef || val.string.length)) {
					if (protoDef && protoDef.protoDef && protoDef.protoDef.protoCon) tmpobj = new protoDef.protoDef.protoCon();
					if (!protoDef || !protoDef.protoDef && val.string) {
						cls = classes.find((cls) => cls.name === val.string);
						if (!cls) {
							function privateProto() {}
							classes.push(cls = {
								name: val.string,
								protoCon: protoDef && protoDef.protoDef && protoDef.protoDef.protoCon || privateProto.constructor,
								fields: []
							});
							nextMode = CONTEXT_CLASS_FIELD;
						} else if (redefineClass) {
							cls.fields.length = 0;
							nextMode = CONTEXT_CLASS_FIELD;
						} else {
							tmpobj = new cls.protoCon();
							nextMode = CONTEXT_CLASS_VALUE;
						}
						redefineClass = false;
					}
					current_class = cls;
					word = WORD_POS_RESET;
				} else word = WORD_POS_FIELD;
				else if (word == WORD_POS_FIELD || parse_context === CONTEXT_IN_ARRAY || parse_context === CONTEXT_OBJECT_FIELD_VALUE || parse_context == CONTEXT_CLASS_VALUE) if (word != WORD_POS_RESET || val.value_type == VALUE_STRING) {
					if (protoDef && protoDef.protoDef) tmpobj = new protoDef.protoDef.protoCon();
					else {
						cls = classes.find((cls) => cls.name === val.string);
						if (!cls) {
							function privateProto() {}
							localFromProtoTypes.set(val.string, {
								protoCon: privateProto.prototype.constructor,
								cb: null
							});
							tmpobj = new privateProto();
						} else {
							nextMode = CONTEXT_CLASS_VALUE;
							tmpobj = {};
						}
					}
					word = WORD_POS_RESET;
				} else word = WORD_POS_RESET;
				else if (parse_context == CONTEXT_OBJECT_FIELD && word == WORD_POS_RESET) {
					throwError("fault while parsing; getting field name unexpected ", cInt);
					status = false;
					return false;
				}
				let old_context = getContext();
				val.value_type = VALUE_OBJECT;
				if (parse_context === CONTEXT_UNKNOWN) elements = tmpobj;
				else if (parse_context == CONTEXT_IN_ARRAY) {
					if (arrayType == -1) {}
					val.name = elements.length;
				} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE || parse_context == CONTEXT_CLASS_VALUE) {
					if (!val.name && current_class) val.name = current_class.fields[current_class_field++];
					elements[val.name] = tmpobj;
				}
				old_context.context = parse_context;
				old_context.elements = elements;
				old_context.name = val.name;
				old_context.current_proto = current_proto;
				old_context.current_class = current_class;
				old_context.current_class_field = current_class_field;
				old_context.valueType = val.value_type;
				old_context.arrayType = arrayType;
				old_context.className = val.className;
				val.className = null;
				val.name = null;
				current_proto = protoDef;
				current_class = cls;
				current_class_field = 0;
				elements = tmpobj;
				if (!rootObject) rootObject = elements;
				context_stack.push(old_context);
				RESET_VAL();
				parse_context = nextMode;
				return true;
			}
			function openArray() {
				if (word > WORD_POS_RESET && word < WORD_POS_FIELD) recoverIdent(91);
				if (word == WORD_POS_END && val.string.length) {
					let typeIndex = knownArrayTypeNames.findIndex((type) => type === val.string);
					word = WORD_POS_RESET;
					if (typeIndex >= 0) {
						arrayType = typeIndex;
						val.className = val.string;
						val.string = null;
					} else if (val.string === "ref") {
						val.className = null;
						arrayType = -2;
					} else if (localFromProtoTypes.get(val.string)) val.className = val.string;
					else if (fromProtoTypes.get(val.string)) val.className = val.string;
					else throwError(`Unknown type '${val.string}' specified for array`, cInt);
				} else if (parse_context == CONTEXT_OBJECT_FIELD || word == WORD_POS_FIELD || word == WORD_POS_AFTER_FIELD) {
					throwError("Fault while parsing; while getting field name unexpected", cInt);
					status = false;
					return false;
				}
				{
					let old_context = getContext();
					val.value_type = VALUE_ARRAY;
					let tmparr = [];
					if (parse_context == CONTEXT_UNKNOWN) elements = tmparr;
					else if (parse_context == CONTEXT_IN_ARRAY) {
						if (arrayType == -1) elements.push(tmparr);
						val.name = elements.length;
					} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
						if (!val.name) {
							console.log("This says it's resolved.......");
							arrayType = -3;
						}
						if (current_proto && current_proto.protoDef) if (current_proto.protoDef.cb) {
							const newarr = current_proto.protoDef.cb.call(elements, val.name, tmparr);
							if (newarr !== void 0) tmparr = elements[val.name] = newarr;
						} else elements[val.name] = tmparr;
						else elements[val.name] = tmparr;
					}
					old_context.context = parse_context;
					old_context.elements = elements;
					old_context.name = val.name;
					old_context.current_proto = current_proto;
					old_context.current_class = current_class;
					old_context.current_class_field = current_class_field;
					old_context.valueType = val.value_type;
					old_context.arrayType = arrayType == -1 ? -3 : arrayType;
					old_context.className = val.className;
					arrayType = -1;
					val.className = null;
					val.name = null;
					current_proto = null;
					current_class = null;
					current_class_field = 0;
					elements = tmparr;
					if (!rootObject) rootObject = tmparr;
					context_stack.push(old_context);
					RESET_VAL();
					parse_context = CONTEXT_IN_ARRAY;
				}
				return true;
			}
			function getProto() {
				const result = {
					protoDef: null,
					cls: null
				};
				if (result.protoDef = localFromProtoTypes.get(val.string)) {
					if (!val.className) {
						val.className = val.string;
						val.string = null;
					}
				} else if (result.protoDef = fromProtoTypes.get(val.string)) {
					if (!val.className) {
						val.className = val.string;
						val.string = null;
					}
				}
				if (val.string) {
					result.cls = classes.find((cls) => cls.name === val.string);
					if (!result.protoDef && !result.cls) {}
				}
				return result.protoDef || result.cls ? result : null;
			}
			if (!status) return -1;
			if (msg && msg.length) {
				input = getBuffer();
				input.buf = msg;
				inQueue.push(input);
			} else {
				if (gatheringNumber) {
					gatheringNumber = false;
					val.value_type = VALUE_NUMBER;
					if (parse_context == CONTEXT_UNKNOWN) completed = true;
					retval = 1;
				}
				if (parse_context !== CONTEXT_UNKNOWN) throwError("Unclosed object at end of stream.", cInt);
			}
			while (status && (input = inQueue.shift())) {
				n = input.n;
				buf = input.buf;
				if (gatheringString) {
					let string_status = gatherString(gatheringStringFirstChar);
					if (string_status < 0) status = false;
					else if (string_status > 0) {
						gatheringString = false;
						if (status) val.value_type = VALUE_STRING;
					}
				}
				if (gatheringNumber) collectNumber();
				while (!completed && status && n < buf.length) {
					str = buf.charAt(n);
					cInt = buf.codePointAt(n++);
					if (cInt >= 65536) {
						str += buf.charAt(n);
						n++;
					}
					pos.col++;
					if (comment) {
						if (comment == 1) if (cInt == 42) comment = 3;
						else if (cInt != 47) return throwError("fault while parsing;", cInt);
						else comment = 2;
						else if (comment == 2) {
							if (cInt == 10 || cInt == 13) comment = 0;
						} else if (comment == 3) {
							if (cInt == 42) comment = 4;
						} else if (cInt == 47) comment = 0;
						else comment = 3;
						continue;
					}
					switch (cInt) {
						case 35:
							comment = 2;
							break;
						case 47:
							comment = 1;
							break;
						case 123:
							openObject();
							break;
						case 91:
							openArray();
							break;
						case 58:
							if (parse_context == CONTEXT_CLASS_VALUE) {
								word = WORD_POS_RESET;
								val.name = val.string;
								val.string = "";
								val.value_type = VALUE_UNSET;
							} else if (parse_context == CONTEXT_OBJECT_FIELD || parse_context == CONTEXT_CLASS_FIELD) if (parse_context == CONTEXT_CLASS_FIELD) {
								if (!Object.keys(elements).length) {
									console.log("This is a full object, not a class def...", val.className);
									const privateProto = () => {};
									localFromProtoTypes.set(context_stack.last.node.current_class.name, {
										protoCon: privateProto.prototype.constructor,
										cb: null
									});
									elements = new privateProto();
									parse_context = CONTEXT_OBJECT_FIELD_VALUE;
									val.name = val.string;
									word = WORD_POS_RESET;
									val.string = "";
									val.value_type = VALUE_UNSET;
									console.log("don't do default;s do a revive...");
								}
							} else {
								if (word != WORD_POS_RESET && word != WORD_POS_END && word != WORD_POS_FIELD && word != WORD_POS_AFTER_FIELD) recoverIdent(32);
								word = WORD_POS_RESET;
								val.name = val.string;
								val.string = "";
								parse_context = parse_context === CONTEXT_OBJECT_FIELD ? CONTEXT_OBJECT_FIELD_VALUE : CONTEXT_CLASS_FIELD_VALUE;
								val.value_type = VALUE_UNSET;
							}
							else if (parse_context == CONTEXT_UNKNOWN) {
								console.log("Override colon found, allow class redefinition", parse_context);
								redefineClass = true;
								break;
							} else {
								if (parse_context == CONTEXT_IN_ARRAY) throwError("(in array, got colon out of string):parsing fault;", cInt);
								else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) throwError("String unexpected", cInt);
								else throwError("(outside any object, got colon out of string):parsing fault;", cInt);
								status = false;
							}
							break;
						case 125:
							if (word == WORD_POS_END) word = WORD_POS_RESET;
							if (parse_context == CONTEXT_CLASS_FIELD) if (current_class) {
								if (val.string) current_class.fields.push(val.string);
								RESET_VAL();
								let old_context = context_stack.pop();
								parse_context = CONTEXT_UNKNOWN;
								word = WORD_POS_RESET;
								val.name = old_context.name;
								elements = old_context.elements;
								current_class = old_context.current_class;
								current_class_field = old_context.current_class_field;
								arrayType = old_context.arrayType;
								val.value_type = old_context.valueType;
								val.className = old_context.className;
								rootObject = null;
								dropContext(old_context);
							} else throwError("State error; gathering class fields, and lost the class", cInt);
							else if (parse_context == CONTEXT_OBJECT_FIELD || parse_context == CONTEXT_CLASS_VALUE) {
								if (val.value_type != VALUE_UNSET) {
									if (current_class) val.name = current_class.fields[current_class_field++];
									objectPush();
								}
								val.value_type = VALUE_OBJECT;
								if (current_proto && current_proto.protoDef) {
									console.log("SOMETHING SHOULD AHVE BEEN REPLACED HERE??", current_proto);
									console.log("The other version only revives on init");
									elements = new current_proto.protoDef.cb(elements, void 0, void 0);
								}
								val.contains = elements;
								val.string = "";
								let old_context = context_stack.pop();
								parse_context = old_context.context;
								val.name = old_context.name;
								elements = old_context.elements;
								current_class = old_context.current_class;
								current_proto = old_context.current_proto;
								current_class_field = old_context.current_class_field;
								arrayType = old_context.arrayType;
								val.value_type = old_context.valueType;
								val.className = old_context.className;
								dropContext(old_context);
								if (parse_context == CONTEXT_UNKNOWN) completed = true;
							} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
								if (val.value_type === VALUE_UNSET) if (word == WORD_POS_RESET) throwError("Fault while parsing; unexpected", cInt);
								else recoverIdent(cInt);
								objectPush();
								val.value_type = VALUE_OBJECT;
								val.contains = elements;
								word = WORD_POS_RESET;
								let old_context = context_stack.pop();
								parse_context = old_context.context;
								val.name = old_context.name;
								elements = old_context.elements;
								current_proto = old_context.current_proto;
								current_class = old_context.current_class;
								current_class_field = old_context.current_class_field;
								arrayType = old_context.arrayType;
								val.value_type = old_context.valueType;
								val.className = old_context.className;
								dropContext(old_context);
								if (parse_context == CONTEXT_UNKNOWN) completed = true;
							} else {
								throwError("Fault while parsing; unexpected", cInt);
								status = false;
							}
							negative = false;
							break;
						case 93:
							if (word >= WORD_POS_AFTER_FIELD) word = WORD_POS_RESET;
							if (parse_context == CONTEXT_IN_ARRAY) {
								if (val.value_type != VALUE_UNSET) arrayPush();
								else if (word !== WORD_POS_RESET) {
									recoverIdent(cInt);
									arrayPush();
								}
								val.contains = elements;
								{
									let old_context = context_stack.pop();
									val.name = old_context.name;
									val.className = old_context.className;
									parse_context = old_context.context;
									elements = old_context.elements;
									current_proto = old_context.current_proto;
									current_class = old_context.current_class;
									current_class_field = old_context.current_class_field;
									arrayType = old_context.arrayType;
									val.value_type = old_context.valueType;
									dropContext(old_context);
								}
								val.value_type = VALUE_ARRAY;
								if (parse_context == CONTEXT_UNKNOWN) completed = true;
							} else {
								throwError(`bad context ${parse_context}; fault while parsing`, cInt);
								status = false;
							}
							negative = false;
							break;
						case 44:
							if (word < WORD_POS_AFTER_FIELD && word != WORD_POS_RESET) recoverIdent(cInt);
							if (word == WORD_POS_END || word == WORD_POS_FIELD) word = WORD_POS_RESET;
							if (parse_context == CONTEXT_CLASS_FIELD) if (current_class) {
								current_class.fields.push(val.string);
								val.string = "";
								word = WORD_POS_FIELD;
							} else throwError("State error; gathering class fields, and lost the class", cInt);
							else if (parse_context == CONTEXT_OBJECT_FIELD) {
								if (current_class) {
									val.name = current_class.fields[current_class_field++];
									if (val.value_type != VALUE_UNSET) {
										objectPush();
										RESET_VAL();
									}
								} else if (val.string || val.value_type) throwError("State error; comma in field name and/or lost the class", cInt);
							} else if (parse_context == CONTEXT_CLASS_VALUE) {
								if (current_class) {
									if (arrayType != -3 && !val.name) val.name = current_class.fields[current_class_field++];
									if (val.value_type != VALUE_UNSET) {
										if (arrayType != -3) objectPush();
										RESET_VAL();
									}
								} else if (val.value_type != VALUE_UNSET) {
									objectPush();
									RESET_VAL();
								}
								val.name = null;
							} else if (parse_context == CONTEXT_IN_ARRAY) {
								if (val.value_type == VALUE_UNSET) val.value_type = VALUE_EMPTY;
								arrayPush();
								RESET_VAL();
								word = WORD_POS_RESET;
							} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE && val.value_type != VALUE_UNSET) {
								parse_context = CONTEXT_OBJECT_FIELD;
								if (val.value_type != VALUE_UNSET) {
									objectPush();
									RESET_VAL();
								}
								word = WORD_POS_RESET;
							} else {
								status = false;
								throwError("bad context; excessive commas while parsing;", cInt);
							}
							negative = false;
							break;
						default:
							switch (cInt) {
								default:
									if (parse_context == CONTEXT_UNKNOWN || parse_context == CONTEXT_OBJECT_FIELD_VALUE && word == WORD_POS_FIELD || parse_context == CONTEXT_OBJECT_FIELD || word == WORD_POS_FIELD || parse_context == CONTEXT_CLASS_FIELD) switch (cInt) {
										case 96:
										case 34:
										case 39:
											if (word == WORD_POS_RESET || word == WORD_POS_FIELD) {
												if (val.string.length) {
													console.log("IN ARRAY AND FIXING?");
													val.className = val.string;
													val.string = "";
												}
												if (gatherString(cInt)) val.value_type = VALUE_STRING;
												else {
													gatheringStringFirstChar = cInt;
													gatheringString = true;
												}
											} else throwError("fault while parsing; quote not at start of field name", cInt);
											break;
										case 10:
											pos.line++;
											pos.col = 1;
										case 13:
										case 32:
										case 8232:
										case 8233:
										case 9:
										case 65279:
											if (parse_context === CONTEXT_UNKNOWN && word === WORD_POS_END) {
												word = WORD_POS_RESET;
												if (parse_context === CONTEXT_UNKNOWN) completed = true;
												break;
											}
											if (word === WORD_POS_RESET || word === WORD_POS_AFTER_FIELD) {
												if (parse_context == CONTEXT_UNKNOWN && val.value_type) completed = true;
												break;
											} else if (word === WORD_POS_FIELD) {
												if (parse_context === CONTEXT_UNKNOWN) {
													word = WORD_POS_RESET;
													completed = true;
													break;
												}
												if (val.string.length) console.log("STEP TO NEXT TOKEN.");
												word = WORD_POS_AFTER_FIELD;
											} else {
												status = false;
												throwError("fault while parsing; whitepsace unexpected", cInt);
											}
											break;
										default:
											if (word == WORD_POS_RESET && (cInt >= 48 && cInt <= 57 || cInt == 43 || cInt == 46 || cInt == 45)) {
												fromHex = false;
												exponent = false;
												date_format = false;
												isBigInt = false;
												exponent_sign = false;
												exponent_digit = false;
												decimal = false;
												val.string = str;
												input.n = n;
												collectNumber();
												break;
											}
											if (word === WORD_POS_AFTER_FIELD) {
												status = false;
												throwError("fault while parsing; character unexpected", cInt);
											}
											if (word === WORD_POS_RESET) {
												word = WORD_POS_FIELD;
												val.value_type = VALUE_STRING;
												val.string += str;
												break;
											}
											if (val.value_type == VALUE_UNSET) {
												if (word !== WORD_POS_RESET && word !== WORD_POS_END) recoverIdent(cInt);
											} else {
												if (word === WORD_POS_END || word === WORD_POS_FIELD) {
													val.string += str;
													break;
												}
												if (parse_context == CONTEXT_OBJECT_FIELD) {
													if (word == WORD_POS_FIELD) {
														val.string += str;
														break;
													}
													throwError("Multiple values found in field name", cInt);
												}
												if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) throwError("String unexpected", cInt);
											}
											break;
									}
									else {
										if (word == WORD_POS_RESET && (cInt >= 48 && cInt <= 57 || cInt == 43 || cInt == 46 || cInt == 45)) {
											fromHex = false;
											exponent = false;
											date_format = false;
											isBigInt = false;
											exponent_sign = false;
											exponent_digit = false;
											decimal = false;
											val.string = str;
											input.n = n;
											collectNumber();
										} else if (val.value_type == VALUE_UNSET) if (word != WORD_POS_RESET) recoverIdent(cInt);
										else {
											word = WORD_POS_END;
											val.string += str;
											val.value_type = VALUE_STRING;
										}
										else if (parse_context == CONTEXT_OBJECT_FIELD) throwError("Multiple values found in field name", cInt);
										else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
											if (val.value_type != VALUE_STRING) {
												if (val.value_type == VALUE_OBJECT || val.value_type == VALUE_ARRAY) throwError("String unexpected", cInt);
												recoverIdent(cInt);
											}
											if (word == WORD_POS_AFTER_FIELD) if (getProto()) val.string = str;
											else throwError("String unexpected", cInt);
											else if (word == WORD_POS_END) val.string += str;
											else throwError("String unexpected", cInt);
										} else if (parse_context == CONTEXT_IN_ARRAY) {
											if (word == WORD_POS_AFTER_FIELD) {
												if (!val.className) {
													val.className = val.string;
													val.string = "";
												}
												val.string += str;
												break;
											} else if (word == WORD_POS_END) val.string += str;
										}
										break;
									}
									break;
								case 96:
								case 34:
								case 39:
									if (val.string) val.className = val.string;
									val.string = "";
									if (gatherString(cInt)) {
										val.value_type = VALUE_STRING;
										word = WORD_POS_END;
									} else {
										gatheringStringFirstChar = cInt;
										gatheringString = true;
									}
									break;
								case 10:
									pos.line++;
									pos.col = 1;
								case 32:
								case 9:
								case 13:
								case 8232:
								case 8233:
								case 65279:
									if (word == WORD_POS_END) {
										if (parse_context == CONTEXT_UNKNOWN) {
											word = WORD_POS_RESET;
											completed = true;
											break;
										} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
											word = WORD_POS_AFTER_FIELD_VALUE;
											break;
										} else if (parse_context == CONTEXT_OBJECT_FIELD) {
											word = WORD_POS_AFTER_FIELD;
											break;
										} else if (parse_context == CONTEXT_IN_ARRAY) {
											word = WORD_POS_AFTER_FIELD;
											break;
										}
									}
									if (word == WORD_POS_RESET || word == WORD_POS_AFTER_FIELD) break;
									else if (word == WORD_POS_FIELD) {
										if (val.string.length) word = WORD_POS_AFTER_FIELD;
									} else if (word < WORD_POS_END) recoverIdent(cInt);
									break;
								case 116:
									if (word == WORD_POS_RESET) word = WORD_POS_TRUE_1;
									else if (word == WORD_POS_INFINITY_6) word = WORD_POS_INFINITY_7;
									else recoverIdent(cInt);
									break;
								case 114:
									if (word == WORD_POS_TRUE_1) word = WORD_POS_TRUE_2;
									else recoverIdent(cInt);
									break;
								case 117:
									if (word == WORD_POS_TRUE_2) word = WORD_POS_TRUE_3;
									else if (word == WORD_POS_NULL_1) word = WORD_POS_NULL_2;
									else if (word == WORD_POS_RESET) word = WORD_POS_UNDEFINED_1;
									else recoverIdent(cInt);
									break;
								case 101:
									if (word == WORD_POS_TRUE_3) {
										val.value_type = VALUE_TRUE;
										word = WORD_POS_END;
									} else if (word == WORD_POS_FALSE_4) {
										val.value_type = VALUE_FALSE;
										word = WORD_POS_END;
									} else if (word == WORD_POS_UNDEFINED_3) word = WORD_POS_UNDEFINED_4;
									else if (word == WORD_POS_UNDEFINED_7) word = WORD_POS_UNDEFINED_8;
									else recoverIdent(cInt);
									break;
								case 110:
									if (word == WORD_POS_RESET) word = WORD_POS_NULL_1;
									else if (word == WORD_POS_UNDEFINED_1) word = WORD_POS_UNDEFINED_2;
									else if (word == WORD_POS_UNDEFINED_6) word = WORD_POS_UNDEFINED_7;
									else if (word == WORD_POS_INFINITY_1) word = WORD_POS_INFINITY_2;
									else if (word == WORD_POS_INFINITY_4) word = WORD_POS_INFINITY_5;
									else recoverIdent(cInt);
									break;
								case 100:
									if (word == WORD_POS_UNDEFINED_2) word = WORD_POS_UNDEFINED_3;
									else if (word == WORD_POS_UNDEFINED_8) {
										val.value_type = VALUE_UNDEFINED;
										word = WORD_POS_END;
									} else recoverIdent(cInt);
									break;
								case 105:
									if (word == WORD_POS_UNDEFINED_5) word = WORD_POS_UNDEFINED_6;
									else if (word == WORD_POS_INFINITY_3) word = WORD_POS_INFINITY_4;
									else if (word == WORD_POS_INFINITY_5) word = WORD_POS_INFINITY_6;
									else recoverIdent(cInt);
									break;
								case 108:
									if (word == WORD_POS_NULL_2) word = WORD_POS_NULL_3;
									else if (word == WORD_POS_NULL_3) {
										val.value_type = VALUE_NULL;
										word = WORD_POS_END;
									} else if (word == WORD_POS_FALSE_2) word = WORD_POS_FALSE_3;
									else recoverIdent(cInt);
									break;
								case 102:
									if (word == WORD_POS_RESET) word = WORD_POS_FALSE_1;
									else if (word == WORD_POS_UNDEFINED_4) word = WORD_POS_UNDEFINED_5;
									else if (word == WORD_POS_INFINITY_2) word = WORD_POS_INFINITY_3;
									else recoverIdent(cInt);
									break;
								case 97:
									if (word == WORD_POS_FALSE_1) word = WORD_POS_FALSE_2;
									else if (word == WORD_POS_NAN_1) word = WORD_POS_NAN_2;
									else recoverIdent(cInt);
									break;
								case 115:
									if (word == WORD_POS_FALSE_3) word = WORD_POS_FALSE_4;
									else recoverIdent(cInt);
									break;
								case 73:
									if (word == WORD_POS_RESET) word = WORD_POS_INFINITY_1;
									else recoverIdent(cInt);
									break;
								case 78:
									if (word == WORD_POS_RESET) word = WORD_POS_NAN_1;
									else if (word == WORD_POS_NAN_2) {
										val.value_type = negative ? VALUE_NEG_NAN : VALUE_NAN;
										negative = false;
										word = WORD_POS_END;
									} else recoverIdent(cInt);
									break;
								case 121:
									if (word == WORD_POS_INFINITY_7) {
										val.value_type = negative ? VALUE_NEG_INFINITY : VALUE_INFINITY;
										negative = false;
										word = WORD_POS_END;
									} else recoverIdent(cInt);
									break;
								case 45:
									if (word == WORD_POS_RESET) negative = !negative;
									else recoverIdent(cInt);
									break;
								case 43:
									if (word !== WORD_POS_RESET) recoverIdent(cInt);
									break;
							}
							break;
					}
					if (completed) {
						if (word == WORD_POS_END) word = WORD_POS_RESET;
						break;
					}
				}
				if (n == buf.length) {
					dropBuffer(input);
					if (val.value_type == VALUE_UNSET && complete_at_end && word != WORD_POS_RESET) recoverIdent(32);
					if (gatheringString || gatheringNumber || parse_context == CONTEXT_OBJECT_FIELD) retval = 0;
					else if (parse_context == CONTEXT_UNKNOWN && (val.value_type != VALUE_UNSET || result)) {
						completed = true;
						retval = 1;
					}
				} else {
					input.n = n;
					inQueue.unshift(input);
					retval = 2;
				}
				if (completed) {
					rootObject = null;
					break;
				}
			}
			if (!status) return -1;
			if (completed && val.value_type != VALUE_UNSET) {
				word = WORD_POS_RESET;
				result = convertValue();
				negative = false;
				val.string = "";
				val.value_type = VALUE_UNSET;
			}
			completed = false;
			return retval;
		}
	};
};
var _parser = [Object.freeze(JSOX.begin())];
var _parse_level = 0;
/**
* parse a string resulting with one value from it.
*
* @template T
* @param {string} msg 
* @param {(this: any, key: string, value: any) => any} [reviver] 
* @returns {T}
*/
JSOX.parse = function(msg, reviver) {
	let parse_level = _parse_level++;
	let parser;
	if (_parser.length <= parse_level) _parser.push(Object.freeze(JSOX.begin()));
	parser = _parser[parse_level];
	if (typeof msg !== "string") msg = String(msg);
	parser.reset();
	const writeResult = parser._write(msg, true);
	if (writeResult > 0) {
		if (writeResult > 1) {}
		let result = parser.value();
		if ("undefined" === typeof result && writeResult > 1) throw new Error("Pending value could not complete");
		result = typeof reviver === "function" ? function walk(holder, key) {
			let k, v, value = holder[key];
			if (value && typeof value === "object") {
				for (k in value) if (Object.prototype.hasOwnProperty.call(value, k)) {
					v = walk(value, k);
					if (v !== void 0) value[k] = v;
					else delete value[k];
				}
			}
			return reviver.call(holder, key, value);
		}({ "": result }, "") : result;
		_parse_level--;
		return result;
	}
	parser.finalError();
};
function this_value() {
	return this && this.valueOf();
}
/**
* Define a class to be used for serialization; the class allows emitting the class fields ahead of time, and just provide values later.
* @param {string} name 
* @param {object} obj 
*/
JSOX.defineClass = function(name, obj) {
	let cls;
	let denormKeys = Object.keys(obj);
	for (let i = 1; i < denormKeys.length; i++) {
		let a, b;
		if ((a = denormKeys[i - 1]) > (b = denormKeys[i])) {
			denormKeys[i - 1] = b;
			denormKeys[i] = a;
			if (i) i -= 2;
			else i--;
		}
	}
	commonClasses.push(cls = {
		name,
		tag: denormKeys.toString(),
		proto: Object.getPrototypeOf(obj),
		fields: Object.keys(obj)
	});
	for (let n = 1; n < cls.fields.length; n++) if (cls.fields[n] < cls.fields[n - 1]) {
		let tmp = cls.fields[n - 1];
		cls.fields[n - 1] = cls.fields[n];
		cls.fields[n] = tmp;
		if (n > 1) n -= 2;
	}
	if (cls.proto === Object.getPrototypeOf({})) cls.proto = null;
};
/**
* deprecated; define a class to be used for serialization
*
* @param {string} named
* @param {class} ptype
* @param {(any)=>any} f
*/
JSOX.registerToJSOX = function(name, ptype, f) {
	throw new Error("registerToJSOX deprecated; please use toJSOX:" + prototypeName + prototype.toString());
};
/**
* define a class with special serialization rules.
*
* @param {string} named
* @param {class} ptype
* @param {(any)=>any} f
*/
JSOX.toJSOX = function(name, ptype, f) {
	if (!ptype.prototype || ptype.prototype !== Object.prototype) {
		if (toProtoTypes.get(ptype.prototype)) throw new Error("Existing toJSOX has been registered for prototype");
		toProtoTypes.set(ptype.prototype, {
			external: true,
			name: name || f.constructor.name,
			cb: f
		});
	} else {
		let key = Object.keys(ptype).toString();
		if (toObjectTypes.get(key)) throw new Error("Existing toJSOX has been registered for object type");
		toObjectTypes.set(key, {
			external: true,
			name,
			cb: f
		});
	}
};
/**
* define a class to be used for deserialization
* @param {string} prototypeName 
* @param {class} o 
* @param {(any)=>any} f 
*/
JSOX.fromJSOX = function(prototypeName, o, f) {
	function privateProto() {}
	if (!o) o = privateProto.prototype;
	if (fromProtoTypes.get(prototypeName)) throw new Error("Existing fromJSOX has been registered for prototype");
	if (o && !("constructor" in o)) throw new Error("Please pass a prototype like thing...");
	fromProtoTypes.set(prototypeName, {
		protoCon: o.prototype.constructor,
		cb: f
	});
};
/**
* deprecated; use fromJSOX instead
*/
JSOX.registerFromJSOX = function(prototypeName, o) {
	throw new Error("deprecated; please adjust code to use fromJSOX:" + prototypeName + o.toString());
};
/**
* Define serialization and deserialization methods for a class.
* This is the same as registering separately with toJSOX and fromJSOX methods.
* 
* @param {string} name - Name used to prefix objects of this type encoded in JSOX
* @param {class} prototype - prototype to match when serializing, and to create instaces of when deserializing.
* @param {(stringifier:JSOXStringifier)=>{string}} to - `this` is the value to convert; function to call to encode JSOX from an object
* @param {(field:string,val:any)=>{any}} from - handle storing revived value in class
*/
JSOX.addType = function(prototypeName, prototype, to, from) {
	JSOX.toJSOX(prototypeName, prototype, to);
	JSOX.fromJSOX(prototypeName, prototype, from);
};
JSOX.registerToFrom = function(prototypeName, prototype) {
	throw new Error("registerToFrom deprecated; please use addType:" + prototypeName + prototype.toString());
};
/**
* Create a stringifier to convert objects to JSOX text.  Allows defining custom serialization for objects.
* @returns {JSOXStringifier}
*/
JSOX.stringifier = function() {
	let classes = [];
	let useQuote = "\"";
	let fieldMap = /* @__PURE__ */ new WeakMap();
	const path = [];
	let encoding = [];
	const localToProtoTypes = /* @__PURE__ */ new WeakMap();
	const localToObjectTypes = /* @__PURE__ */ new Map();
	let objectToJSOX = null;
	const stringifying = [];
	let ignoreNonEnumerable = false;
	function getIdentifier(s) {
		if ("string" === typeof s && s === "") return "\"\"";
		if ("number" === typeof s && !isNaN(s)) return [
			"'",
			s.toString(),
			"'"
		].join("");
		if (s.includes("﻿")) return useQuote + JSOX.escape(s) + useQuote;
		return s in keywords || /[0-9\-]/.test(s[0]) || /[\n\r\t #\[\]{}()<>\~!+*/.:,\-"'`]/.test(s) ? useQuote + JSOX.escape(s) + useQuote : s;
	}
	if (!toProtoTypes.get(Object.prototype)) {
		toProtoTypes.set(Object.prototype, {
			external: false,
			name: Object.prototype.constructor.name,
			cb: null
		});
		toProtoTypes.set(Date.prototype, {
			external: false,
			name: "Date",
			cb: function() {
				if (this.getTime() === -621672192e5) return "0000-01-01T00:00:00.000Z";
				let tzo = -this.getTimezoneOffset(), dif = tzo >= 0 ? "+" : "-", pad = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 10 ? "0" : "") + norm;
				}, pad3 = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 100 ? "0" : "") + (norm < 10 ? "0" : "") + norm;
				};
				return [
					this.getFullYear(),
					"-",
					pad(this.getMonth() + 1),
					"-",
					pad(this.getDate()),
					"T",
					pad(this.getHours()),
					":",
					pad(this.getMinutes()),
					":",
					pad(this.getSeconds()),
					"." + pad3(this.getMilliseconds()) + dif,
					pad(tzo / 60),
					":",
					pad(tzo % 60)
				].join("");
			}
		});
		toProtoTypes.set(DateNS.prototype, {
			external: false,
			name: "DateNS",
			cb: function() {
				let tzo = -this.getTimezoneOffset(), dif = tzo >= 0 ? "+" : "-", pad = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 10 ? "0" : "") + norm;
				}, pad3 = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 100 ? "0" : "") + (norm < 10 ? "0" : "") + norm;
				}, pad6 = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 1e5 ? "0" : "") + (norm < 1e4 ? "0" : "") + (norm < 1e3 ? "0" : "") + (norm < 100 ? "0" : "") + (norm < 10 ? "0" : "") + norm;
				};
				return [
					this.getFullYear(),
					"-",
					pad(this.getMonth() + 1),
					"-",
					pad(this.getDate()),
					"T",
					pad(this.getHours()),
					":",
					pad(this.getMinutes()),
					":",
					pad(this.getSeconds()),
					"." + pad3(this.getMilliseconds()) + pad6(this.ns) + dif,
					pad(tzo / 60),
					":",
					pad(tzo % 60)
				].join("");
			}
		});
		toProtoTypes.set(Boolean.prototype, {
			external: false,
			name: "Boolean",
			cb: this_value
		});
		toProtoTypes.set(Number.prototype, {
			external: false,
			name: "Number",
			cb: function() {
				if (isNaN(this)) return "NaN";
				return isFinite(this) ? String(this) : this < 0 ? "-Infinity" : "Infinity";
			}
		});
		toProtoTypes.set(String.prototype, {
			external: false,
			name: "String",
			cb: function() {
				return "\"" + JSOX.escape(this_value.apply(this)) + "\"";
			}
		});
		if (typeof BigInt === "function") toProtoTypes.set(BigInt.prototype, {
			external: false,
			name: "BigInt",
			cb: function() {
				return this + "n";
			}
		});
		toProtoTypes.set(ArrayBuffer.prototype, {
			external: true,
			name: "ab",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this)) + "]";
			}
		});
		toProtoTypes.set(Uint8Array.prototype, {
			external: true,
			name: "u8",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Uint8ClampedArray.prototype, {
			external: true,
			name: "uc8",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Int8Array.prototype, {
			external: true,
			name: "s8",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Uint16Array.prototype, {
			external: true,
			name: "u16",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Int16Array.prototype, {
			external: true,
			name: "s16",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Uint32Array.prototype, {
			external: true,
			name: "u32",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Int32Array.prototype, {
			external: true,
			name: "s32",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Float32Array.prototype, {
			external: true,
			name: "f32",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Float64Array.prototype, {
			external: true,
			name: "f64",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Float64Array.prototype, {
			external: true,
			name: "f64",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(RegExp.prototype, mapToJSOX = {
			external: true,
			name: "regex",
			cb: function(o, stringifier) {
				return "'" + escape(this.source) + "'";
			}
		});
		fromProtoTypes.set("regex", {
			protoCon: RegExp,
			cb: function(field, val) {
				return new RegExp(this);
			}
		});
		toProtoTypes.set(Map.prototype, mapToJSOX = {
			external: true,
			name: "map",
			cb: null
		});
		fromProtoTypes.set("map", {
			protoCon: Map,
			cb: function(field, val) {
				if (field) {
					this.set(field, val);
					return;
				}
				return this;
			}
		});
		toProtoTypes.set(Array.prototype, arrayToJSOX = {
			external: false,
			name: Array.prototype.constructor.name,
			cb: null
		});
	}
	const stringifier = {
		defineClass(name, obj) {
			let cls;
			let denormKeys = Object.keys(obj);
			for (let i = 1; i < denormKeys.length; i++) {
				let a, b;
				if ((a = denormKeys[i - 1]) > (b = denormKeys[i])) {
					denormKeys[i - 1] = b;
					denormKeys[i] = a;
					if (i) i -= 2;
					else i--;
				}
			}
			classes.push(cls = {
				name,
				tag: denormKeys.toString(),
				proto: Object.getPrototypeOf(obj),
				fields: Object.keys(obj)
			});
			for (let n = 1; n < cls.fields.length; n++) if (cls.fields[n] < cls.fields[n - 1]) {
				let tmp = cls.fields[n - 1];
				cls.fields[n - 1] = cls.fields[n];
				cls.fields[n] = tmp;
				if (n > 1) n -= 2;
			}
			if (cls.proto === Object.getPrototypeOf({})) cls.proto = null;
		},
		setDefaultObjectToJSOX(cb) {
			objectToJSOX = cb;
		},
		isEncoding(o) {
			return !!encoding.find((eo, i) => eo === o && i < encoding.length - 1);
		},
		encodeObject(o) {
			if (objectToJSOX) return objectToJSOX.apply(o, [this]);
			return o;
		},
		stringify(o, r, s) {
			return stringify(o, r, s);
		},
		setQuote(q) {
			useQuote = q;
		},
		registerToJSOX(n, p, f) {
			return this.toJSOX(n, p, f);
		},
		toJSOX(name, ptype, f) {
			if (ptype.prototype && ptype.prototype !== Object.prototype) {
				if (localToProtoTypes.get(ptype.prototype)) throw new Error("Existing toJSOX has been registered for prototype");
				localToProtoTypes.set(ptype.prototype, {
					external: true,
					name: name || f.constructor.name,
					cb: f
				});
			} else {
				let key = Object.keys(ptype).toString();
				if (localToObjectTypes.get(key)) throw new Error("Existing toJSOX has been registered for object type");
				localToObjectTypes.set(key, {
					external: true,
					name,
					cb: f
				});
			}
		},
		get ignoreNonEnumerable() {
			return ignoreNonEnumerable;
		},
		set ignoreNonEnumerable(val) {
			ignoreNonEnumerable = val;
		}
	};
	return stringifier;
	/**
	* get a reference to a previously seen object
	* @param {any} here 
	* @returns reference to existing object, or undefined if not found.
	*/
	function getReference(here) {
		if (here === null) return void 0;
		let field = fieldMap.get(here);
		if (!field) {
			fieldMap.set(here, _JSON.stringify(path));
			return;
		}
		return "ref" + field;
	}
	/**
	* find the prototype definition for a class
	* @param {object} o 
	* @param {map} useK 
	* @returns object
	*/
	function matchObject(o, useK) {
		let k;
		let cls;
		let prt = Object.getPrototypeOf(o);
		cls = classes.find((cls) => {
			if (cls.proto && cls.proto === prt) return true;
		});
		if (cls) return cls;
		if (classes.length || commonClasses.length) {
			if (useK) {
				useK = useK.map((v) => {
					if (typeof v === "string") return v;
					else return void 0;
				});
				k = useK.toString();
			} else {
				let denormKeys = Object.keys(o);
				for (let i = 1; i < denormKeys.length; i++) {
					let a, b;
					if ((a = denormKeys[i - 1]) > (b = denormKeys[i])) {
						denormKeys[i - 1] = b;
						denormKeys[i] = a;
						if (i) i -= 2;
						else i--;
					}
				}
				k = denormKeys.toString();
			}
			cls = classes.find((cls) => {
				if (cls.tag === k) return true;
			});
			if (!cls) cls = commonClasses.find((cls) => {
				if (cls.tag === k) return true;
			});
		}
		return cls;
	}
	/**
	* Serialize an object to JSOX text.
	* @param {any} object 
	* @param {(key:string,value:any)=>string} replacer 
	* @param {string|number} space 
	* @returns 
	*/
	function stringify(object, replacer, space) {
		if (object === void 0) return "undefined";
		if (object === null) return;
		let gap;
		let indent;
		let rep;
		let i;
		const spaceType = typeof space;
		const repType = typeof replacer;
		gap = "";
		indent = "";
		if (spaceType === "number") for (i = 0; i < space; i += 1) indent += " ";
		else if (spaceType === "string") indent = space;
		rep = replacer;
		if (replacer && repType !== "function" && (repType !== "object" || typeof replacer.length !== "number")) throw new Error("JSOX.stringify");
		path.length = 0;
		fieldMap = /* @__PURE__ */ new WeakMap();
		const finalResult = str("", { "": object });
		commonClasses.length = 0;
		return finalResult;
		function str(key, holder) {
			var mind = gap;
			const doArrayToJSOX_ = arrayToJSOX.cb;
			const mapToObject_ = mapToJSOX.cb;
			arrayToJSOX.cb = doArrayToJSOX;
			mapToJSOX.cb = mapToObject;
			const v = str_(key, holder);
			arrayToJSOX.cb = doArrayToJSOX_;
			mapToJSOX.cb = mapToObject_;
			return v;
			function doArrayToJSOX() {
				let v;
				let partial = [];
				let thisNodeNameIndex = path.length;
				for (let i = 0; i < this.length; i += 1) {
					path[thisNodeNameIndex] = i;
					partial[i] = str(i, this) || "null";
				}
				path.length = thisNodeNameIndex;
				encoding.length = thisNodeNameIndex;
				v = partial.length === 0 ? "[]" : gap ? [
					"[\n",
					gap,
					partial.join(",\n" + gap),
					"\n",
					mind,
					"]"
				].join("") : "[" + partial.join(",") + "]";
				return v;
			}
			function mapToObject() {
				let tmp = { tmp: null };
				let out = "{";
				let first = true;
				for (let [key, value] of this) {
					tmp.tmp = value;
					let thisNodeNameIndex = path.length;
					path[thisNodeNameIndex] = key;
					out += (first ? "" : ",") + getIdentifier(key) + ":" + str("tmp", tmp);
					path.length = thisNodeNameIndex;
					first = false;
				}
				out += "}";
				return out;
			}
			function str_(key, holder) {
				let i;
				let k;
				let v;
				let length;
				let partialClass;
				let partial;
				let thisNodeNameIndex = path.length;
				let isValue = true;
				let value = holder[key];
				let isObject = typeof value === "object";
				let c;
				if (isObject && value !== null) {
					if (objectToJSOX) {
						if (!stringifying.find((val) => val === value)) {
							stringifying.push(value);
							encoding[thisNodeNameIndex] = value;
							isValue = false;
							value = objectToJSOX.apply(value, [stringifier]);
							isObject = typeof value === "object";
							stringifying.pop();
							encoding.length = thisNodeNameIndex;
							isObject = typeof value === "object";
						}
					}
				}
				const objType = value !== void 0 && value !== null && Object.getPrototypeOf(value);
				let protoConverter = objType && (localToProtoTypes.get(objType) || toProtoTypes.get(objType) || null);
				let objectConverter = !protoConverter && value !== void 0 && value !== null && (localToObjectTypes.get(Object.keys(value).toString()) || toObjectTypes.get(Object.keys(value).toString()) || null);
				if (typeof rep === "function") {
					isValue = false;
					value = rep.call(holder, key, value);
				}
				let toJSOX = protoConverter && protoConverter.cb || objectConverter && objectConverter.cb;
				if (value !== void 0 && value !== null && typeof value === "object" && typeof toJSOX === "function") if (!stringifying.find((val) => val === value)) {
					if (typeof value === "object") {
						v = getReference(value);
						if (v) return v;
					}
					stringifying.push(value);
					encoding[thisNodeNameIndex] = value;
					value = toJSOX.call(value, stringifier);
					isValue = false;
					stringifying.pop();
					if (protoConverter && protoConverter.name) {
						if ("string" === typeof value && value[0] !== "-" && (value[0] < "0" || value[0] > "9") && value[0] !== "\"" && value[0] !== "'" && value[0] !== "`" && value[0] !== "[" && value[0] !== "{") value = " " + value;
					}
					encoding.length = thisNodeNameIndex;
				} else v = getReference(value);
				else if (typeof value === "object") {
					v = getReference(value);
					if (v) return v;
				}
				switch (typeof value) {
					case "bigint": return value + "n";
					case "string": {
						value = isValue ? getIdentifier(value) : value;
						let c = "";
						if (key === "") c = classes.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "") + commonClasses.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "") + (gap ? "\n" : "");
						if (protoConverter && protoConverter.external) return c + protoConverter.name + value;
						if (objectConverter && objectConverter.external) return c + objectConverter.name + value;
						return c + value;
					}
					case "number":
					case "boolean":
					case "null": return String(value);
					case "object":
						if (v) return v;
						if (!value) return "null";
						gap += indent;
						partialClass = null;
						partial = [];
						if (rep && typeof rep === "object") {
							length = rep.length;
							partialClass = matchObject(value, rep);
							for (i = 0; i < length; i += 1) if (typeof rep[i] === "string") {
								k = rep[i];
								path[thisNodeNameIndex] = k;
								v = str(k, value);
								if (v !== void 0) if (partialClass) partial.push(v);
								else partial.push(getIdentifier(k) + (gap ? ": " : ":") + v);
							}
							path.splice(thisNodeNameIndex, 1);
						} else {
							partialClass = matchObject(value);
							let keys = [];
							for (k in value) {
								if (ignoreNonEnumerable) {
									if (!Object.prototype.propertyIsEnumerable.call(value, k)) continue;
								}
								if (Object.prototype.hasOwnProperty.call(value, k)) {
									let n;
									for (n = 0; n < keys.length; n++) if (keys[n] > k) {
										keys.splice(n, 0, k);
										break;
									}
									if (n == keys.length) keys.push(k);
								}
							}
							for (let n = 0; n < keys.length; n++) {
								k = keys[n];
								if (Object.prototype.hasOwnProperty.call(value, k)) {
									path[thisNodeNameIndex] = k;
									v = str(k, value);
									if (v !== void 0) if (partialClass) partial.push(v);
									else partial.push(getIdentifier(k) + (gap ? ": " : ":") + v);
								}
							}
							path.splice(thisNodeNameIndex, 1);
						}
						if (key === "") c = (classes.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "") || commonClasses.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "")) + (gap ? "\n" : "");
						else c = "";
						if (protoConverter && protoConverter.external) c = c + getIdentifier(protoConverter.name);
						let ident = null;
						if (partialClass) ident = getIdentifier(partialClass.name);
						v = c + (partial.length === 0 ? "{}" : gap ? (partialClass ? ident : "") + "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : (partialClass ? ident : "") + "{" + partial.join(",") + "}");
						gap = mind;
						return v;
				}
			}
		}
	}
};
var encodings = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789$_";
var decodings = {
	"~": -1,
	"=": -1,
	"$": 62,
	"_": 63,
	"+": 62,
	"-": 62,
	".": 62,
	"/": 63,
	",": 63
};
for (let x = 0; x < 64; x++) decodings[encodings[x]] = x;
Object.freeze(decodings);
function base64ArrayBuffer(arrayBuffer) {
	let base64 = "";
	let bytes = new Uint8Array(arrayBuffer);
	let byteLength = bytes.byteLength;
	let byteRemainder = byteLength % 3;
	let mainLength = byteLength - byteRemainder;
	let a, b, c, d;
	let chunk;
	for (let i = 0; i < mainLength; i = i + 3) {
		chunk = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
		a = (chunk & 16515072) >> 18;
		b = (chunk & 258048) >> 12;
		c = (chunk & 4032) >> 6;
		d = chunk & 63;
		base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d];
	}
	if (byteRemainder == 1) {
		chunk = bytes[mainLength];
		a = (chunk & 252) >> 2;
		b = (chunk & 3) << 4;
		base64 += encodings[a] + encodings[b] + "==";
	} else if (byteRemainder == 2) {
		chunk = bytes[mainLength] << 8 | bytes[mainLength + 1];
		a = (chunk & 64512) >> 10;
		b = (chunk & 1008) >> 4;
		c = (chunk & 15) << 2;
		base64 += encodings[a] + encodings[b] + encodings[c] + "=";
	}
	return base64;
}
function DecodeBase64(buf) {
	let outsize;
	if (buf.length % 4 == 1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 3;
	else if (buf.length % 4 == 2) outsize = ((buf.length + 3) / 4 | 0) * 3 - 2;
	else if (buf.length % 4 == 3) outsize = ((buf.length + 3) / 4 | 0) * 3 - 1;
	else if (decodings[buf[buf.length - 3]] == -1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 3;
	else if (decodings[buf[buf.length - 2]] == -1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 2;
	else if (decodings[buf[buf.length - 1]] == -1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 1;
	else outsize = ((buf.length + 3) / 4 | 0) * 3;
	let ab = new ArrayBuffer(outsize);
	let out = new Uint8Array(ab);
	let n;
	let l = buf.length + 3 >> 2;
	for (n = 0; n < l; n++) {
		let index0 = decodings[buf[n * 4]];
		let index1 = n * 4 + 1 < buf.length ? decodings[buf[n * 4 + 1]] : -1;
		let index2 = index1 >= 0 && n * 4 + 2 < buf.length ? decodings[buf[n * 4 + 2]] : -1;
		let index3 = index2 >= 0 && n * 4 + 3 < buf.length ? decodings[buf[n * 4 + 3]] : -1;
		if (index1 >= 0) out[n * 3 + 0] = index0 << 2 | index1 >> 4;
		if (index2 >= 0) out[n * 3 + 1] = index1 << 4 | index2 >> 2 & 15;
		if (index3 >= 0) out[n * 3 + 2] = index2 << 6 | index3 & 63;
	}
	return ab;
}
/**
* @param {unknown} object 
* @param {(this: unknown, key: string, value: unknown)} [replacer] 
* @param {string | number} [space] 
* @returns {string}
*/
JSOX.stringify = function(object, replacer, space) {
	return JSOX.stringifier().stringify(object, replacer, space);
};
[[
	0,
	256,
	[
		16767487,
		16739071,
		130048,
		3670016,
		0,
		16777208,
		16777215,
		8388607
	]
]].map((row) => {
	return {
		firstChar: row[0],
		lastChar: row[1],
		bits: row[2]
	};
});
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/UIState.ts
var mapEntriesFrom = (source) => {
	if (!source) return [];
	if (source instanceof Map) return Array.from(source.entries());
	if (Array.isArray(source)) return source.map((value, index) => {
		if (Array.isArray(value) && value.length === 2) return value;
		return [index, value];
	});
	if (source instanceof Set) return Array.from(source.values()).map((value, index) => [index, value]);
	if (typeof source === "object") return Object.entries(source);
	return [];
};
var ownProp = Object.prototype.hasOwnProperty;
var isPlainObject$1 = (value) => {
	if (!value || typeof value !== "object") return false;
	if (Array.isArray(value)) return false;
	return !(value instanceof Map) && !(value instanceof Set);
};
var identityOf = (value, fallback) => {
	if (value && typeof value === "object") {
		if ("id" in value && value.id != null) return value.id;
		if ("key" in value && value.key != null) return value.key;
	}
	return fallback;
};
var resolveEntryKey = (entryKey, value, fallback) => {
	if (entryKey != null) return entryKey;
	const identity = identityOf(value);
	if (identity != null) return identity;
	return fallback;
};
var mergePlainObject = (target, source) => {
	for (const key of Object.keys(source)) {
		const nextValue = source[key];
		const currentValue = target[key];
		if (isPlainObject$1(currentValue) && isPlainObject$1(nextValue)) {
			mergePlainObject(currentValue, nextValue);
			continue;
		}
		if (currentValue !== nextValue) target[key] = nextValue;
	}
	return target;
};
var mergeValue = (target, source) => {
	if (target === source) return target;
	const sourceIsObject = source && typeof source === "object";
	if (target instanceof Map && sourceIsObject) {
		reloadInto(target, source);
		return target;
	}
	if (target instanceof Set && sourceIsObject) {
		reloadInto(target, source);
		return target;
	}
	if (Array.isArray(target) && sourceIsObject) {
		reloadInto(target, source);
		return target;
	}
	if (isPlainObject$1(target) && isPlainObject$1(source)) {
		mergePlainObject(target, source);
		return target;
	}
	return source;
};
var reloadInto = (items, map) => {
	if (!items || !map) return items;
	const entries = mapEntriesFrom(map);
	if (!entries.length) return items;
	if (items instanceof Set) {
		const existingByKey = /* @__PURE__ */ new Map();
		for (const value of items.values()) {
			const key = identityOf(value);
			if (key != null) existingByKey.set(key, value);
		}
		const usedKeys = /* @__PURE__ */ new Set();
		for (const [entryKey, incoming] of entries) {
			const key = resolveEntryKey(entryKey, incoming);
			if (key == null) {
				if (!items.has(incoming)) items.add(incoming);
				continue;
			}
			const hasCurrent = existingByKey.has(key);
			const current = hasCurrent ? existingByKey.get(key) : void 0;
			if (hasCurrent) {
				const merged = mergeValue(current, incoming);
				if (merged !== current) {
					items.delete(current);
					items.add(merged);
					existingByKey.set(key, merged);
				}
			} else {
				items.add(incoming);
				existingByKey.set(key, incoming);
			}
			usedKeys.add(key);
		}
		if (usedKeys.size) for (const value of Array.from(items.values())) {
			const key = identityOf(value);
			if (key != null && !usedKeys.has(key)) items.delete(value);
		}
		return items;
	}
	if (items instanceof Map) {
		const nextMap = new Map(entries);
		for (const key of Array.from(items.keys())) if (!nextMap.has(key)) items.delete(key);
		for (const [key, incoming] of nextMap.entries()) if (items.has(key)) {
			const current = items.get(key);
			const merged = mergeValue(current, incoming);
			if (merged !== current) items.set(key, merged);
		} else items.set(key, incoming);
		return items;
	}
	if (Array.isArray(items)) {
		const availableIndexes = /* @__PURE__ */ new Set();
		const existingByKey = /* @__PURE__ */ new Map();
		const existingByObject = /* @__PURE__ */ new WeakMap();
		items.forEach((value, index) => {
			availableIndexes.add(index);
			const key = identityOf(value, index);
			if (key != null && !existingByKey.has(key)) existingByKey.set(key, index);
			if (value && typeof value === "object") existingByObject.set(value, index);
		});
		const takeIndex = (index) => {
			if (index == null) return void 0;
			if (!availableIndexes.has(index)) return void 0;
			availableIndexes.delete(index);
			return index;
		};
		const takeNextAvailable = () => {
			const iterator = availableIndexes.values().next();
			if (iterator.done) return void 0;
			const index = iterator.value;
			availableIndexes.delete(index);
			return index;
		};
		let writeIndex = 0;
		let fallbackIndex = 0;
		for (const [entryKey, incoming] of entries) {
			const key = resolveEntryKey(entryKey, incoming, fallbackIndex++);
			let claimedIndex = takeIndex(key != null ? existingByKey.get(key) : void 0);
			if (claimedIndex == null && incoming && typeof incoming === "object") claimedIndex = takeIndex(existingByObject.get(incoming));
			if (claimedIndex == null) claimedIndex = takeNextAvailable();
			const current = claimedIndex != null ? items[claimedIndex] : void 0;
			const merged = current !== void 0 ? mergeValue(current, incoming) : incoming;
			if (writeIndex < items.length) {
				if (items[writeIndex] !== merged) items[writeIndex] = merged;
			} else items.push(merged);
			writeIndex++;
		}
		while (items.length > writeIndex) items.pop();
		return items;
	}
	if (typeof items === "object") {
		const nextKeys = new Set(entries.map(([key]) => String(key)));
		for (const prop of Object.keys(items)) if (!nextKeys.has(prop)) delete items[prop];
		for (const [entryKey, incoming] of entries) {
			const prop = String(entryKey);
			if (ownProp.call(items, prop)) {
				const current = items[prop];
				const merged = mergeValue(current, incoming);
				if (merged !== current) items[prop] = merged;
			} else items[prop] = incoming;
		}
		return items;
	}
	return items;
};
var mergeByKey = (items, key = "id") => {
	if (items && (items instanceof Set || Array.isArray(items))) {
		const entries = Array.from(items?.values?.() || []).map((I) => [I?.[key], I]).filter((I) => I?.[0] != null);
		return reloadInto(items, new Map(entries));
	}
	return items;
};
var hasChromeStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var makeUIState = (storageKey, initialCb, unpackCb, packCb = (items) => safe(items), key = "id", saveInterval = 6e3) => {
	let state = null;
	state = mergeByKey(initialCb?.() || {}, key);
	if (hasChromeStorage()) chrome.storage.local.get([storageKey], (result) => {
		if (result[storageKey]) {
			const unpacked = unpackCb(JSOX.parse(result?.[storageKey] || "{}"));
			reloadInto(state, unpacked);
		}
	});
	else if (typeof localStorage !== "undefined") if (localStorage.getItem(storageKey)) {
		state = unpackCb(JSOX.parse(localStorage.getItem(storageKey) || "{}"));
		mergeByKey(state, key);
	} else localStorage.setItem(storageKey, JSOX.stringify(packCb(state)));
	const saveInStorage = (ev) => {
		const packed = JSOX.stringify(packCb(mergeByKey(state, key)));
		if (hasChromeStorage()) chrome.storage.local.set({ [storageKey]: packed });
		else if (typeof localStorage !== "undefined") localStorage.setItem(storageKey, packed);
	};
	setIdleInterval$1(saveInStorage, saveInterval);
	if (typeof window !== "undefined" && typeof document !== "undefined") {
		const listening = [
			addEvent(document, "visibilitychange", (ev) => {
				if (document.visibilityState === "hidden") saveInStorage(ev);
			}),
			addEvent(window, "beforeunload", (ev) => saveInStorage(ev)),
			addEvent(window, "pagehide", (ev) => saveInStorage(ev)),
			addEvent(window, "storage", (ev) => {
				if (ev.storageArea == localStorage && ev.key == storageKey) reloadInto(state, unpackCb(JSOX.parse(ev?.newValue || JSOX.stringify(packCb(mergeByKey(state, key))))));
			})
		];
		addToCallChain(state, Symbol.dispose, () => listening.forEach((ub) => ub?.()));
	}
	if (hasChromeStorage()) {
		const listener = (changes, area) => {
			if (area === "local" && changes[storageKey]) {
				const newValue = changes[storageKey].newValue;
				if (newValue) reloadInto(state, unpackCb(JSOX.parse(newValue)));
			}
		};
		chrome.storage.onChanged.addListener(listener);
	}
	if (state && typeof state === "object") try {
		Object.defineProperty(state, "$save", {
			value: saveInStorage,
			configurable: true,
			enumerable: false,
			writable: true
		});
	} catch (e) {
		state.$save = saveInStorage;
	}
	return state;
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/ScrollBar.ts
makeRAFCycle();
try {
	CSS.registerProperty({
		name: "--percent-x",
		syntax: "<number>",
		inherits: true,
		initialValue: "0"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--percent-y",
		syntax: "<number>",
		inherits: true,
		initialValue: "0"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--scroll-coef",
		syntax: "<number>",
		inherits: true,
		initialValue: "1"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--determinant",
		syntax: "<number>",
		inherits: true,
		initialValue: "0"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--scroll-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--content-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--clamped-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--thumb-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--max-offset",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--max-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/TemplateManager.ts
var TemplateManager = class {
	storageKey;
	templates = [];
	defaultTemplates;
	constructor(options = {}) {
		this.storageKey = options.storageKey || "rs-prompt-templates";
		this.defaultTemplates = options.defaultTemplates || this.getDefaultTemplates();
		this.loadTemplates();
	}
	/**
	* Get all templates
	*/
	getAllTemplates() {
		return [...this.templates];
	}
	/**
	* Get template by ID
	*/
	getTemplateById(id) {
		return this.templates.find((t) => t.id === id);
	}
	/**
	* Add a new template
	*/
	addTemplate(template) {
		const newTemplate = {
			...template,
			id: this.generateId(),
			createdAt: Date.now(),
			updatedAt: Date.now(),
			usageCount: 0
		};
		this.templates.push(newTemplate);
		this.saveTemplates();
		return newTemplate;
	}
	/**
	* Update an existing template
	*/
	updateTemplate(id, updates) {
		const index = this.templates.findIndex((t) => t.id === id);
		if (index === -1) return false;
		this.templates[index] = {
			...this.templates[index],
			...updates,
			updatedAt: Date.now()
		};
		this.saveTemplates();
		return true;
	}
	/**
	* Remove a template
	*/
	removeTemplate(id) {
		const index = this.templates.findIndex((t) => t.id === id);
		if (index === -1) return false;
		this.templates.splice(index, 1);
		this.saveTemplates();
		return true;
	}
	/**
	* Increment usage count for a template
	*/
	incrementUsageCount(id) {
		const template = this.templates.find((t) => t.id === id);
		if (template) {
			template.usageCount = (template.usageCount || 0) + 1;
			this.saveTemplates();
		}
	}
	/**
	* Search templates by name or content
	*/
	searchTemplates(query) {
		const lowercaseQuery = query.toLowerCase();
		return this.templates.filter((template) => template.name.toLowerCase().includes(lowercaseQuery) || template.prompt.toLowerCase().includes(lowercaseQuery) || template.tags?.some((tag) => tag.toLowerCase().includes(lowercaseQuery)));
	}
	/**
	* Get templates by category
	*/
	getTemplatesByCategory(category) {
		return this.templates.filter((template) => template.category === category);
	}
	/**
	* Get most used templates
	*/
	getMostUsedTemplates(limit = 5) {
		return this.templates.sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0)).slice(0, limit);
	}
	/**
	* Export templates as JSON
	*/
	exportTemplates() {
		return JSON.stringify(this.templates, null, 2);
	}
	/**
	* Import templates from JSON
	*/
	importTemplates(jsonData) {
		try {
			const importedTemplates = JSON.parse(jsonData);
			if (!Array.isArray(importedTemplates)) throw new Error("Invalid template data: not an array");
			for (const template of importedTemplates) if (!template.name || !template.prompt) throw new Error("Invalid template: missing name or prompt");
			const templatesWithIds = importedTemplates.map((template) => ({
				...template,
				id: this.generateId(),
				createdAt: template.createdAt || Date.now(),
				updatedAt: Date.now()
			}));
			this.templates.push(...templatesWithIds);
			this.saveTemplates();
			return true;
		} catch (error) {
			console.error("Failed to import templates:", error);
			return false;
		}
	}
	/**
	* Reset to default templates
	*/
	resetToDefaults() {
		this.templates = this.defaultTemplates.map((template) => ({
			...template,
			id: this.generateId(),
			createdAt: Date.now(),
			updatedAt: Date.now(),
			usageCount: 0
		}));
		this.saveTemplates();
	}
	/**
	* Create template editor modal
	*/
	createTemplateEditor(container, onSave) {
		const modal = H`<div class="template-editor-modal">
      <div class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>Prompt Templates</h3>
          </div>

          <div class="template-list">
            ${this.templates.map((template, index) => H`<div class="template-item">
                <div class="template-header">
                  <input type="text" class="template-name" value="${template.name}" data-index="${index}" placeholder="Template name">
                  <button class="btn small remove-template" data-index="${index}" title="Remove template">✕</button>
                </div>
                <textarea class="template-prompt" data-index="${index}" placeholder="Enter your prompt template...">${template.prompt}</textarea>
                <div class="template-meta">
                  ${template.usageCount ? H`<span class="usage-count">Used ${template.usageCount} times</span>` : ""}
                  ${template.category ? H`<span class="category">${template.category}</span>` : ""}
                </div>
              </div>`)}
          </div>

          <div class="modal-actions">
            <button class="btn" data-action="add-template">Add Template</button>
            <button class="btn" data-action="reset-defaults">Reset to Defaults</button>
            <button class="btn primary" data-action="save-templates">Save Changes</button>
            <button class="btn" data-action="close-editor">Close</button>
          </div>
        </div>
      </div>
    </div>`;
		modal.addEventListener("click", (e) => {
			const target = e.target;
			const action = target.getAttribute("data-action");
			const index = target.getAttribute("data-index");
			if (action === "add-template") {
				this.addTemplate({
					name: "New Template",
					prompt: "Enter your prompt template here...",
					category: "Custom"
				});
				modal.remove();
				this.createTemplateEditor(container, onSave);
			} else if (action === "reset-defaults") {
				if (confirm("Are you sure you want to reset all templates to defaults? This will remove all custom templates.")) {
					this.resetToDefaults();
					modal.remove();
					this.createTemplateEditor(container, onSave);
				}
			} else if (action === "save-templates") {
				const nameInputs = modal.querySelectorAll(".template-name");
				const promptInputs = modal.querySelectorAll(".template-prompt");
				this.templates = Array.from(nameInputs).map((input, i) => {
					const index = parseInt(input.getAttribute("data-index") || "0");
					return {
						...this.templates[index],
						name: input.value.trim() || "Untitled Template",
						prompt: promptInputs[i].value.trim() || "Enter your prompt...",
						updatedAt: Date.now()
					};
				});
				this.saveTemplates();
				modal.remove();
				onSave?.();
			} else if (action === "close-editor") modal.remove();
			else if (target.classList.contains("remove-template") && index !== null) {
				const templateIndex = parseInt(index);
				const template = this.templates[templateIndex];
				if (confirm(`Remove template "${template.name}"?`)) {
					this.removeTemplate(template.id);
					modal.remove();
					this.createTemplateEditor(container, onSave);
				}
			}
		});
		container.append(modal);
	}
	/**
	* Create template selector dropdown
	*/
	createTemplateSelect(selectedPrompt) {
		const select = document.createElement("select");
		select.className = "template-select";
		const defaultOption = document.createElement("option");
		defaultOption.value = "";
		defaultOption.textContent = "Select Template...";
		select.append(defaultOption);
		this.templates.forEach((template) => {
			const option = document.createElement("option");
			option.value = template.prompt;
			option.textContent = template.name;
			if (template.category) option.textContent += ` (${template.category})`;
			select.append(option);
		});
		if (selectedPrompt) select.value = selectedPrompt;
		return select;
	}
	getDefaultTemplates() {
		return [].map((template) => ({
			...template,
			id: this.generateId(),
			createdAt: Date.now(),
			updatedAt: Date.now(),
			usageCount: 0
		}));
	}
	generateId() {
		return `template_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
	}
	loadTemplates() {
		try {
			const stored = localStorage.getItem(this.storageKey);
			if (stored) {
				const parsedTemplates = JSON.parse(stored);
				this.templates = parsedTemplates.map((template) => ({
					...template,
					id: template.id || this.generateId(),
					createdAt: template.createdAt || Date.now(),
					updatedAt: template.updatedAt || Date.now(),
					usageCount: template.usageCount || 0
				}));
			} else this.resetToDefaults();
		} catch (error) {
			console.warn("Failed to load templates from storage:", error);
			this.resetToDefaults();
		}
	}
	saveTemplates() {
		try {
			localStorage.setItem(this.storageKey, JSON.stringify(this.templates));
		} catch (error) {
			console.warn("Failed to save templates to storage:", error);
		}
	}
};
/**
* Utility function to create a template manager
*/
function createTemplateManager(options) {
	return new TemplateManager(options);
}
//#endregion
//#region ../../modules/projects/lur.e/src/design/color/DynamicEngine.ts
var runWhenIdle = (cb, timeout = 100) => {
	if (typeof globalThis.requestIdleCallback === "function") return globalThis.requestIdleCallback(cb, { timeout });
	return setTimeout(() => cb({
		didTimeout: false,
		timeRemaining: () => 0
	}), 0);
};
var electronAPI = "electronBridge";
function extractAlpha(input) {
	if (typeof input !== "string") return null;
	let color = input.trim().toLowerCase();
	if (color === "transparent") return 0;
	if (color.startsWith("#")) {
		const hex = color;
		if (hex.length === 4) return 1;
		if (hex.length === 7) return 1;
		if (hex.length === 5) {
			const a = hex[4];
			const aa = a + a;
			return clamp(parseInt(aa, 16) / 255, 0, 1);
		}
		if (hex.length === 9) {
			const aa = hex.slice(7, 9);
			return clamp(parseInt(aa, 16) / 255, 0, 1);
		}
		return null;
	}
	const fnMatch = color.match(/^([a-z-]+)\((.*)\)$/i);
	if (!fnMatch) return null;
	fnMatch[1];
	const body = fnMatch[2].trim();
	{
		const slashIdx = body.lastIndexOf("/");
		if (slashIdx !== -1) {
			const a = parseAlphaComponent(body.slice(slashIdx + 1).trim());
			if (a != null) return clamp(a, 0, 1);
			return null;
		}
	}
	if (body.includes(",")) {
		const parts = body.split(",").map((s) => s.trim());
		if (parts.length >= 4) {
			const a = parseAlphaComponent(parts[3]);
			if (a != null) return clamp(a, 0, 1);
			return null;
		}
		return 1;
	}
	return 1;
}
function parseAlphaComponent(str) {
	if (!str) return null;
	if (str.endsWith("%")) {
		const n = parseFloat(str);
		if (Number.isNaN(n)) return null;
		return n / 100;
	}
	const n = parseFloat(str);
	if (Number.isNaN(n)) return null;
	return n;
}
function clamp(v, min, max) {
	return Math.min(max, Math.max(min, v));
}
var tacp = (color) => {
	if (!color || color == null) return 0;
	return (extractAlpha?.(color) || 0) > .1;
};
var setIdleInterval = (cb, timeout = 1e3, ...args) => {
	runWhenIdle(async () => {
		if (!cb || typeof cb != "function") return;
		while (true) {
			await Promise.try(cb, ...args);
			await new Promise((r) => setTimeout(r, timeout));
			await new Promise((r) => runWhenIdle(r, 100));
			await new Promise((r) => requestAnimationFrame(r));
		}
	}, 1e3);
};
/** Prefer real shell chrome (minimal nav / faint toolbar) for PWA title bar / WCO tint. */
var sampleShellToolbarBackgroundColor = () => {
	if (typeof document === "undefined") return null;
	try {
		const hosts = document.querySelectorAll("[data-shell]");
		for (const host of hosts) {
			const sr = host.shadowRoot;
			if (!sr) continue;
			const bar = sr.querySelector(".app-shell__nav, .app-shell__toolbar");
			if (!bar) continue;
			const bg = getComputedStyle(bar).backgroundColor;
			if (tacp(bg)) return bg;
		}
	} catch {}
	return null;
};
/** Under window-controls-overlay, sample inside env(titlebar-area-*) — not under OS control buttons. */
var sampleWcoTitlebarStripColor = () => {
	if (typeof document === "undefined") return null;
	if (!globalThis.matchMedia?.("(display-mode: window-controls-overlay)")?.matches) return null;
	const probe = document.createElement("div");
	probe.setAttribute("data-wco-theme-probe", "true");
	probe.style.cssText = [
		"position:fixed",
		"visibility:hidden",
		"pointer-events:none",
		"z-index:-2147483648",
		"left:env(titlebar-area-x,0px)",
		"top:env(titlebar-area-y,0px)",
		"width:env(titlebar-area-width,0px)",
		"height:env(titlebar-area-height,0px)"
	].join(";");
	document.documentElement.appendChild(probe);
	try {
		const r = probe.getBoundingClientRect();
		if (r.width < 1 || r.height < 1) return null;
		const c = pickBgColor(Math.floor(r.left + Math.min(40, r.width * .2)), Math.floor(r.top + r.height * .5));
		return tacp(c) ? c : null;
	} finally {
		probe.remove();
	}
};
var pickBgColor = (x, y, holder = null) => {
	const opaque = Array.from(document.elementsFromPoint(x, y))?.filter?.((el) => el instanceof HTMLElement && el != holder && (el?.dataset?.alpha != null ? parseFloat(el?.dataset?.alpha) > .01 : true) && el?.checkVisibility?.({
		contentVisibilityAuto: true,
		opacityProperty: true,
		visibilityProperty: true
	}) && el?.matches?.(":not([data-hidden])") && el?.style?.getPropertyValue("display") != "none").map((element) => {
		const computed = getComputedStyle?.(element);
		return {
			element,
			zIndex: parseInt(computed?.zIndex || "0", 10) || 0,
			color: computed?.backgroundColor || "transparent"
		};
	}).sort((a, b) => Math.sign(b.zIndex - a.zIndex)).filter(({ color }) => tacp(color));
	if (opaque?.[0]?.element instanceof HTMLElement) return opaque?.[0]?.color || "transparent";
	return "transparent";
};
var pickFromCenter = (holder) => {
	const box = holder?.getBoundingClientRect();
	if (box) {
		const Z = .5 * (fixedClientZoom?.() || 1);
		return pickBgColor(...[(box.left + box.right) * Z, (box.top + box.bottom) * Z], holder);
	}
};
var dynamicNativeFrame = (root = document.documentElement) => {
	let media = root?.querySelector?.("meta[data-theme-color]") ?? root?.querySelector?.("meta[name=\"theme-color\"]");
	if (!media && root == document.documentElement) {
		media = document.createElement("meta");
		media.setAttribute("name", "theme-color");
		media.setAttribute("data-theme-color", "");
		media.setAttribute("content", "transparent");
		document.head.appendChild(media);
	}
	const fromShell = sampleShellToolbarBackgroundColor();
	const fromWco = !fromShell ? sampleWcoTitlebarStripColor() : null;
	const fallbackX = Math.max(8, Math.floor(globalThis.innerWidth * .12));
	const picked = !fromShell && !fromWco ? pickBgColor(fallbackX, 20) : null;
	const color = fromShell || fromWco || (picked && tacp(picked) ? picked : null);
	if (color && color !== "transparent" && (media || window?.["electronBridge"]) && root == document.documentElement) media?.setAttribute?.("content", color);
};
var dynamicBgColors = (root = document.documentElement) => {
	root.querySelectorAll("body, body > *, body > * > *").forEach((target) => {
		if (target) pickFromCenter(target);
	});
};
var dynamicTheme = (ROOT = document.documentElement) => {
	const startedKey = "__LURE_DYNAMIC_THEME_STARTED__";
	if (globalThis?.[startedKey]) return;
	globalThis[startedKey] = true;
	matchMedia("(prefers-color-scheme: dark)").addEventListener("change", ({}) => dynamicBgColors(ROOT));
	const updater = () => {
		dynamicNativeFrame(ROOT);
		dynamicBgColors(ROOT);
	};
	addEvent(ROOT, "u2-appear", () => runWhenIdle(updater, 100));
	addEvent(ROOT, "u2-hidden", () => runWhenIdle(updater, 100));
	addEvent(ROOT, "u2-theme-change", () => runWhenIdle(updater, 100));
	addEvent(window, "load", () => runWhenIdle(updater, 100));
	addEvent(document, "visibilitychange", () => runWhenIdle(updater, 100));
	setIdleInterval(updater, 500);
};
//#endregion
//#region ../../modules/projects/lur.e/src/design/color/ThemeEngine.ts
var colorScheme = async () => {
	dynamicNativeFrame();
	dynamicBgColors();
};
/**
* Opt-in autostart only.
* This module is re-exported from `fest/lure` root, so unconditional side effects
* here can start a competing theme-color loop in host apps.
*/
var maybeStartThemeEngine = () => {
	if (typeof document === "undefined") return;
	if (globalThis?.__LURE_AUTO_THEME_ENGINE__ !== true) return;
	requestAnimationFrame(() => colorScheme?.());
	dynamicTheme?.();
};
maybeStartThemeEngine();
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/OPFS.uniform.worker.ts?worker
function WorkerWrapper(options) {
	return new Worker("" + new URL("../assets/OPFS.uniform.worker-DQViraMO.js", import.meta.url).href, {
		type: "module",
		name: options?.name
	});
}
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/OPFS.ts
var workerChannel = null;
var isServiceWorker = typeof ServiceWorkerGlobalScope !== "undefined" && self instanceof ServiceWorkerGlobalScope;
var SW_BRIDGE_CHANNEL_NAME = "opfs-sw-bridge-v1";
var observers = /* @__PURE__ */ new Map();
var workerInitPromise = null;
var swBridgeChannel = null;
var swBridgeRequestCounter = 0;
var ensureSwBridgeChannel = () => {
	if (!isServiceWorker) return null;
	if (swBridgeChannel) return swBridgeChannel;
	try {
		if (typeof BroadcastChannel === "undefined") return null;
		swBridgeChannel = new BroadcastChannel(SW_BRIDGE_CHANNEL_NAME);
		return swBridgeChannel;
	} catch {
		return null;
	}
};
var postViaSwBridge = (type, payload = {}, timeoutMs = 2500) => {
	const channel = ensureSwBridgeChannel();
	if (!channel) return Promise.reject(/* @__PURE__ */ new Error("SW OPFS bridge is unavailable"));
	const requestId = `sw-opfs-${Date.now()}-${++swBridgeRequestCounter}`;
	return new Promise((resolve, reject) => {
		let timeoutId = null;
		const onMessage = (event) => {
			const data = event?.data || {};
			if (!data || typeof data !== "object") return;
			if (data?.type !== "opfs-sw-response") return;
			if (String(data?.requestId || "") !== requestId) return;
			channel.removeEventListener("message", onMessage);
			if (timeoutId) clearTimeout(timeoutId);
			if (data?.ok) resolve(data?.result);
			else reject(new Error(String(data?.error || "Unknown bridge error")));
		};
		channel.addEventListener("message", onMessage);
		timeoutId = setTimeout(() => {
			channel.removeEventListener("message", onMessage);
			reject(/* @__PURE__ */ new Error("SW OPFS bridge timeout"));
		}, timeoutMs);
		channel.postMessage({
			type: "opfs-sw-request",
			requestId,
			action: type,
			payload
		});
	});
};
var ensureWorker = () => {
	if (workerInitPromise) return workerInitPromise;
	workerInitPromise = new Promise(async (resolve) => {
		if (typeof Worker !== "undefined" && !isServiceWorker) try {
			const baseChannel = await createWorkerChannel({
				name: "opfs-worker",
				script: WorkerWrapper
			});
			workerChannel = new QueuedWorkerChannel("opfs-worker", async () => baseChannel, {
				timeout: 3e4,
				retries: 3,
				batching: true,
				compression: false
			});
			resolve(workerChannel);
		} catch (e) {
			console.warn("OPFSUniformWorker instantiation failed, falling back to main thread...", e);
			workerChannel = null;
			resolve(null);
		}
		else {
			workerChannel = null;
			resolve(null);
		}
	});
	return workerInitPromise;
};
var directHandlers = {
	readDirectory: async ({ rootId, path, create }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			let current = root;
			for (const part of parts) current = await current.getDirectoryHandle(part, { create });
			const entries = [];
			for await (const [name, entry] of current.entries()) entries.push([name, entry]);
			return entries;
		} catch (e) {
			console.warn("Direct readDirectory error:", e);
			return [];
		}
	},
	readFile: async ({ rootId, path, type }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			const filename = parts.pop();
			let dir = root;
			for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: false });
			const file = await (await dir.getFileHandle(filename, { create: false })).getFile();
			if (type === "text") return await file.text();
			if (type === "arrayBuffer") return await file.arrayBuffer();
			return file;
		} catch (e) {
			console.warn("Direct readFile error:", e);
			return null;
		}
	},
	writeFile: async ({ rootId, path, data }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			const filename = parts.pop();
			let dir = root;
			for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: true });
			const writable = await (await dir.getFileHandle(filename, { create: true })).createWritable();
			await writable.write(data);
			await writable.close();
			return true;
		} catch (e) {
			console.warn("Direct writeFile error:", e);
			return false;
		}
	},
	remove: async ({ rootId, path, recursive }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			const name = parts.pop();
			let dir = root;
			for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: false });
			await dir.removeEntry(name, { recursive });
			return true;
		} catch {
			return false;
		}
	},
	copy: async ({ from, to }) => {
		try {
			const copyRecursive = async (source, dest) => {
				if (source.kind === "directory") for await (const [name, entry] of source.entries()) if (entry.kind === "directory") {
					const newDest = await dest.getDirectoryHandle(name, { create: true });
					await copyRecursive(entry, newDest);
				} else {
					const file = await entry.getFile();
					const writable = await (await dest.getFileHandle(name, { create: true })).createWritable();
					await writable.write(file);
					await writable.close();
				}
				else {
					const file = await source.getFile();
					const writable = await dest.createWritable();
					await writable.write(file);
					await writable.close();
				}
			};
			await copyRecursive(from, to);
			return true;
		} catch (e) {
			console.warn("Direct copy error:", e);
			return false;
		}
	},
	observe: async () => false,
	unobserve: async () => true,
	mount: async () => true,
	unmount: async () => true
};
var post = (type, payload = {}, transfer = []) => {
	if (isServiceWorker && directHandlers[type]) return postViaSwBridge(type, payload).catch(() => directHandlers[type](payload));
	return new Promise(async (resolve, reject) => {
		try {
			const channel = await ensureWorker();
			if (!channel) {
				if (directHandlers[type]) return resolve(directHandlers[type](payload));
				return reject(/* @__PURE__ */ new Error("No worker channel available"));
			}
			let result;
			try {
				result = await channel.request(type, payload);
			} catch (requestError) {
				if (directHandlers[type]) return resolve(directHandlers[type](payload));
				throw requestError;
			}
			if (result === false && (type === "writeFile" || type === "remove" || type === "copy")) {
				if (directHandlers[type]) return resolve(directHandlers[type](payload));
			}
			resolve(result);
		} catch (err) {
			if (directHandlers[type]) try {
				return resolve(directHandlers[type](payload));
			} catch (fallbackError) {
				return reject(fallbackError);
			}
			reject(err);
		}
	});
};
var getDir = (dest) => {
	if (typeof dest != "string") return dest;
	dest = dest?.trim?.() || dest;
	if (!dest?.endsWith?.("/")) dest = dest?.trim?.()?.split?.("/")?.slice(0, -1)?.join?.("/")?.trim?.() || dest;
	const p1 = !dest?.trim()?.endsWith("/") ? dest + "/" : dest;
	return !p1?.startsWith("/") ? "/" + p1 : p1;
};
var generalFileImportDesc = {
	startIn: "documents",
	multiple: false,
	types: [{
		description: "files",
		accept: { "application/*": [
			".txt",
			".md",
			".html",
			".htm",
			".css",
			".js",
			".json",
			".csv",
			".xml",
			".jpg",
			".jpeg",
			".png",
			".gif",
			".webp",
			".svg",
			".ico",
			".mp3",
			".wav",
			".mp4",
			".webm",
			".pdf",
			".zip",
			".rar",
			".7z"
		] }
	}]
};
var mappedRoots = /* @__PURE__ */ new Map([
	["/", async () => await navigator?.storage?.getDirectory?.()],
	["/user/", async () => await navigator?.storage?.getDirectory?.()],
	["/assets/", async () => {
		console.warn("Backend related API not implemented!");
		return null;
	}]
]);
var currentHandleMap = /* @__PURE__ */ new Map();
async function resolveRootHandle(rootHandle, relPath = "") {
	if (rootHandle == null || rootHandle == void 0 || rootHandle?.trim?.()?.length == 0) rootHandle = "/user/";
	const cleanId = typeof rootHandle == "string" ? rootHandle?.trim?.()?.replace?.(/^\//, "")?.trim?.()?.split?.("/")?.filter?.((p) => !!p?.trim?.())?.at?.(0) : null;
	if (cleanId) {
		if (typeof localStorage != "undefined" && JSON.parse(localStorage?.getItem?.("opfs.mounted") || "[]").includes(cleanId)) rootHandle = currentHandleMap?.get(cleanId);
		if (!rootHandle) rootHandle = await mappedRoots?.get?.(`/${cleanId}/`)?.() ?? await navigator.storage.getDirectory();
	}
	if (rootHandle instanceof FileSystemDirectoryHandle) return rootHandle;
	const normalizedPath = relPath?.trim?.() || "/";
	const pathForMatch = normalizedPath.startsWith("/") ? normalizedPath : "/" + normalizedPath;
	let bestMatch = null;
	let bestMatchLength = 0;
	for (const [rootPath, rootResolver] of mappedRoots.entries()) if (pathForMatch.startsWith(rootPath) && rootPath.length > bestMatchLength) {
		bestMatch = rootResolver;
		bestMatchLength = rootPath.length;
	}
	try {
		return (bestMatch ? await bestMatch() : null) || await navigator?.storage?.getDirectory?.();
	} catch (error) {
		console.warn("Failed to resolve root handle, falling back to OPFS root:", error);
		return await navigator?.storage?.getDirectory?.();
	}
}
function normalizePath(basePath = "", relPath) {
	if (!relPath?.trim()) return basePath;
	const cleanRelPath = relPath.trim();
	if (cleanRelPath.startsWith("/")) return cleanRelPath;
	const baseParts = basePath.split("/").filter((p) => p?.trim());
	const relParts = cleanRelPath.split("/").filter((p) => p?.trim());
	for (const part of relParts) if (part === ".") continue;
	else if (part === "..") {
		if (baseParts.length > 0) baseParts.pop();
	} else baseParts.push(part);
	return "/" + baseParts.join("/");
}
async function resolvePath(rootHandle, relPath, basePath = "") {
	const normalizedRelPath = normalizePath(basePath, relPath);
	return {
		rootHandle: await resolveRootHandle(rootHandle, normalizedRelPath),
		resolvedPath: normalizedRelPath
	};
}
function handleError(logger, status, message) {
	logger?.(status, message);
	return null;
}
function defaultLogger(status, message) {
	console.trace(`[${status}] ${message}`);
}
function detectTypeByRelPath(relPath) {
	if (relPath?.trim()?.endsWith?.("/")) return "directory";
	return "file";
}
function getMimeTypeByFilename(filename) {
	return {
		"txt": "text/plain",
		"md": "text/markdown",
		"html": "text/html",
		"htm": "text/html",
		"css": "text/css",
		"js": "application/javascript",
		"json": "application/json",
		"csv": "text/csv",
		"xml": "application/xml",
		"jpg": "image/jpeg",
		"jpeg": "image/jpeg",
		"png": "image/png",
		"gif": "image/gif",
		"webp": "image/webp",
		"svg": "image/svg+xml",
		"ico": "image/x-icon",
		"mp3": "audio/mpeg",
		"wav": "audio/wav",
		"mp4": "video/mp4",
		"webm": "video/webm",
		"pdf": "application/pdf",
		"zip": "application/zip",
		"rar": "application/vnd.rar",
		"7z": "application/x-7z-compressed"
	}[filename?.split?.(".")?.pop?.()?.toLowerCase?.()] || "application/octet-stream";
}
var hasFileExtension = (path) => {
	return path?.trim?.()?.split?.(".")?.[1]?.trim?.()?.length > 0;
};
async function getDirectoryHandle(rootHandle, relPath, { create = false, basePath = "" } = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, basePath);
		const parts = stripUserScopePrefix(resolvedPath).split("/").filter((p) => !!p?.trim?.());
		if (parts.length > 0 && hasFileExtension(parts[parts.length - 1]?.trim?.())) parts?.pop?.();
		let dir = resolvedRoot;
		if (parts?.length > 0) for (const part of parts) {
			dir = await dir?.getDirectoryHandle?.(part, { create });
			if (!dir) break;
		}
		return dir;
	} catch (e) {
		return handleError(logger, "error", `getDirectoryHandle: ${e.message}`);
	}
}
async function getFileHandle(rootHandle, relPath, { create = false, basePath = "" } = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, basePath);
		const cleanPath = stripUserScopePrefix(resolvedPath);
		const parts = cleanPath.split("/").filter((d) => !!d?.trim?.());
		if (parts?.length == 0) return null;
		const filePath = parts.length > 0 ? parts[parts.length - 1]?.trim?.()?.replace?.(/\s+/g, "-") : "";
		const dirName = parts.length > 1 ? parts?.slice(0, -1)?.join?.("/")?.trim?.()?.replace?.(/\s+/g, "-") : "";
		if (cleanPath?.trim?.()?.endsWith?.("/")) return null;
		return (await getDirectoryHandle(resolvedRoot, dirName, {
			create,
			basePath
		}, logger))?.getFileHandle?.(filePath, { create });
	} catch (e) {
		return handleError(logger, "error", `getFileHandle: ${e.message}`);
	}
}
async function getHandler(rootHandle, relPath, options = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRootHandle, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
		if (detectTypeByRelPath(resolvedPath) == "directory") {
			const dir = await getDirectoryHandle(resolvedRootHandle, resolvedPath?.trim?.()?.replace?.(/\/$/, ""), options, logger);
			if (dir) return {
				type: "directory",
				handle: dir
			};
		} else {
			const file = await getFileHandle(resolvedRootHandle, resolvedPath, options, logger);
			if (file) return {
				type: "file",
				handle: file
			};
		}
		return null;
	} catch (e) {
		return handleError(logger, "error", `getHandler: ${e.message}`);
	}
}
var directoryCacheMap = /* @__PURE__ */ new Map();
function openDirectory(rootHandle, relPath, options = { create: false }, logger = defaultLogger) {
	let cacheKey = "";
	let localMapCache = observe(/* @__PURE__ */ new Map());
	const statePromise = (async () => {
		try {
			const { rootHandle: resolvedRootHandle, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
			cacheKey = `${resolvedRootHandle?.name || "root"}:${resolvedPath}`;
			return {
				rootHandle: resolvedRootHandle,
				resolvedPath
			};
		} catch {
			return {
				rootHandle: null,
				resolvedPath: ""
			};
		}
	})().then(async ({ rootHandle, resolvedPath }) => {
		if (!resolvedPath) return null;
		const existing = directoryCacheMap.get(cacheKey);
		if (existing) {
			existing.refCount++;
			localMapCache = existing.mapCache;
			return existing;
		}
		const mapCache = observe(/* @__PURE__ */ new Map());
		localMapCache = mapCache;
		const observationId = UUIDv4();
		const dirHandlePromise = getDirectoryHandle(rootHandle, resolvedPath, options, logger);
		const updateCache = async () => {
			const entries = await post("readDirectory", {
				rootId: "",
				path: stripUserScopePrefix(resolvedPath),
				create: options.create
			}, rootHandle ? [rootHandle] : []);
			if (!entries) return mapCache;
			const entryMap = new Map(entries);
			for (const key of mapCache.keys()) if (!entryMap.has(key)) mapCache.delete(key);
			for (const [key, handle] of entryMap) if (!mapCache.has(key)) mapCache.set(key, handle);
			return mapCache;
		};
		const cleanup = () => {
			post("unobserve", { id: observationId });
			observers.delete(observationId);
			directoryCacheMap.delete(cacheKey);
		};
		observers.set(observationId, (changes) => {
			for (const change of changes) {
				if (!change?.name) continue;
				if (change.type === "modified" || change.type === "created" || change.type === "appeared") mapCache.set(change.name, change.handle);
				else if (change.type === "deleted" || change.type === "disappeared") mapCache.delete(change.name);
			}
		});
		post("observe", {
			rootId: "",
			path: stripUserScopePrefix(resolvedPath),
			id: observationId
		}, rootHandle ? [rootHandle] : []);
		updateCache();
		const newState = {
			mapCache,
			dirHandle: dirHandlePromise,
			resolvePath: resolvedPath,
			observationId,
			refCount: 1,
			cleanup,
			updateCache
		};
		directoryCacheMap.set(cacheKey, newState);
		const entries = await Promise.all(await Array.fromAsync((await dirHandlePromise)?.entries?.() ?? []));
		for (const [name, handle] of entries) if (!mapCache.has(name)) mapCache.set(name, handle);
		return {
			...newState,
			mapCache
		};
	});
	let disposed = false;
	const dispose = () => {
		if (disposed) return;
		disposed = true;
		statePromise.then((s) => {
			if (!s) return;
			s.refCount--;
			if (s.refCount <= 0) s.cleanup();
		}).catch(console.warn);
	};
	const handler = {
		get(_target, prop) {
			if (prop === Symbol.toStringTag || prop === Symbol.iterator || prop === "toString" || prop === "valueOf" || prop === "inspect" || prop === "constructor" || prop === "__proto__" || prop === "prototype") return;
			if (prop === "dispose") return dispose;
			if (prop === "getMap") return () => localMapCache;
			if (prop === "entries") return () => localMapCache.entries();
			if (prop === "keys") return () => localMapCache.keys();
			if (prop === "values") return () => localMapCache.values();
			if (prop === Symbol.iterator) return () => localMapCache[Symbol.iterator]();
			if (prop === "size") return localMapCache.size;
			if (prop === "has") return (k) => localMapCache.has(k);
			if (prop === "get") return (k) => localMapCache.get(k);
			if (prop === "entries") return () => localMapCache.entries();
			if (prop === "keys") return () => localMapCache.keys();
			if (prop === "values") return () => localMapCache.values();
			if (prop === "refresh") return () => statePromise.then((s) => s?.updateCache?.()).then(() => pxy);
			if (prop === "then" || prop === "catch" || prop === "finally") {
				const p = statePromise.then(() => true);
				return p[prop].bind(p);
			}
			return (...args) => statePromise.then(async (s) => {
				if (!s) return void 0;
				const dh = await s.dirHandle;
				const v = dh?.[prop];
				if (typeof v === "function") return v.apply(dh, args);
				return v;
			});
		},
		ownKeys() {
			return Array.from(localMapCache.keys());
		},
		getOwnPropertyDescriptor() {
			return {
				enumerable: true,
				configurable: true
			};
		}
	};
	const fx = function() {};
	const pxy = new Proxy(fx, handler);
	return pxy;
}
async function readFile(rootHandle, relPath, options = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
		return await post("readFile", {
			rootId: "",
			path: stripUserScopePrefix(resolvedPath),
			type: "blob"
		}, resolvedRoot ? [resolvedRoot] : []);
	} catch (e) {
		return handleError(logger, "error", `readFile: ${e.message}`);
	}
}
async function writeFile(rootHandle, relPath, data, logger = defaultLogger) {
	if (data instanceof FileSystemFileHandle) data = await data.getFile();
	if (data instanceof FileSystemDirectoryHandle) {
		const dstHandle = await getDirectoryHandle(await resolveRootHandle(rootHandle), relPath + (relPath?.trim?.()?.endsWith?.("/") ? "" : "/") + (data?.name || "")?.trim?.()?.replace?.(/\s+/g, "-"), { create: true });
		return await copyFromOneHandlerToAnother(data, dstHandle, {})?.catch?.(console.warn.bind(console));
	} else try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, "");
		return await post("writeFile", {
			rootId: "",
			path: stripUserScopePrefix(resolvedPath),
			data
		}, resolvedRoot ? [resolvedRoot] : []) !== false;
	} catch (e) {
		return handleError(logger, "error", `writeFile: ${e.message}`);
	}
}
async function removeFile(rootHandle, relPath, options = { recursive: true }, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
		const candidates = userPathCandidates(resolvedPath);
		let lastResult = false;
		for (const candidate of candidates) {
			lastResult = await post("remove", {
				rootId: "",
				path: candidate,
				recursive: options.recursive
			}, resolvedRoot ? [resolvedRoot] : []);
			if (lastResult !== false) return true;
		}
		return lastResult !== false;
	} catch (e) {
		return handleError(logger, "error", `removeFile: ${e.message}`);
	}
}
async function remove(rootHandle, relPath, options = {}, logger = defaultLogger) {
	try {
		return removeFile(rootHandle, relPath, {
			recursive: true,
			...options
		}, logger);
	} catch (e) {
		return handleError(logger, "error", `remove: ${e.message}`);
	}
}
var downloadFile = async (file, filename) => {
	if (file instanceof FileSystemFileHandle) file = await file.getFile();
	if (typeof file == "string") file = await provide(file);
	filename = filename ?? file?.name;
	if (!filename) return;
	if ("msSaveOrOpenBlob" in self.navigator) self.navigator.msSaveOrOpenBlob(file, filename);
	if (file instanceof FileSystemDirectoryHandle) {
		let dstHandle = await showDirectoryPicker?.({ mode: "readwrite" })?.catch?.(console.warn.bind(console));
		if (file && dstHandle) {
			dstHandle = await getDirectoryHandle(dstHandle, file?.name || "", { create: true })?.catch?.(console.warn.bind(console)) || dstHandle;
			return await copyFromOneHandlerToAnother(file, dstHandle, {})?.catch?.(console.warn.bind(console));
		}
		return;
	}
	const fx = await (self?.showOpenFilePicker ? new Promise((r) => r({
		showOpenFilePicker: self?.showOpenFilePicker?.bind?.(window),
		showSaveFilePicker: self?.showSaveFilePicker?.bind?.(window)
	})) : import(
		/* @vite-ignore */
		"../../../../../subsystem/fest/polyfill/showOpenFilePicker.mjs"
));
	if (window?.showSaveFilePicker) {
		const writableFileStream = await (await fx?.showSaveFilePicker?.({ suggestedName: filename })?.catch?.(console.warn.bind(console)))?.createWritable?.({ keepExistingData: true })?.catch?.(console.warn.bind(console));
		await writableFileStream?.write?.(file)?.catch?.(console.warn.bind(console));
		await writableFileStream?.close?.()?.catch?.(console.warn.bind(console));
	} else {
		const a = document.createElement("a");
		try {
			a.href = URL.createObjectURL(file);
		} catch (e) {
			console.warn(e);
		}
		a.download = filename;
		document.body.appendChild(a);
		a.click();
		setTimeout(function() {
			document.body.removeChild(a);
			globalThis.URL.revokeObjectURL(a.href);
		}, 0);
	}
};
var provide = async (req = "", rw = false) => {
	const requestUrl = (typeof req === "string" ? req : req?.url || "").trim();
	if (!requestUrl) return null;
	let pathname = requestUrl;
	try {
		pathname = new URL(requestUrl, location?.origin || self?.location?.origin || "http://localhost").pathname || requestUrl;
	} catch {}
	const cleanPath = pathname?.trim?.() || "/";
	if (cleanPath?.startsWith?.("/user")) {
		const path = stripUserScopePrefix(cleanPath);
		const root = await navigator?.storage?.getDirectory?.();
		if (!root) return null;
		const handle = await getFileHandle(root, path, { create: !!rw }).catch(() => null);
		if (!handle) return null;
		if (rw) return handle?.createWritable?.();
		return handle?.getFile?.();
	}
	if (rw) return null;
	try {
		const baseOrigin = String(location?.origin || self?.location?.origin || "").trim();
		const fetchTarget = cleanPath.startsWith("/") ? new URL(cleanPath, baseOrigin || "http://localhost").toString() : requestUrl;
		const r = await fetch(fetchTarget);
		const blob = await r?.blob()?.catch?.(console.warn.bind(console));
		const lastModifiedHeader = r?.headers?.get?.("Last-Modified");
		const lastModified = lastModifiedHeader ? Date.parse(lastModifiedHeader) : 0;
		if (blob) {
			const fallbackName = cleanPath?.substring?.(cleanPath?.lastIndexOf?.("/") + 1) || "resource";
			return new File([blob], fallbackName, {
				type: blob?.type,
				lastModified: isNaN(lastModified) ? 0 : lastModified
			});
		}
	} catch (e) {
		return handleError(defaultLogger, "error", `provide: ${e.message}`);
	}
	return null;
};
var dropFile = async (file, dest = "/user/".trim?.()?.replace?.(/\s+/g, "-"), current) => {
	const fs = await resolveRootHandle(null);
	const user = getDir(stripUserScopePrefix(dest))?.replace?.("/user", "")?.trim?.();
	file = file instanceof File ? file : new File([file], UUIDv4() + "." + (file?.type?.split?.("/")?.[1] || "tmp"));
	const fp = user + (file?.name || "wallpaper")?.trim?.()?.replace?.(/\s+/g, "-");
	await writeFile(fs, fp, file);
	current?.set?.("/user" + fp?.trim?.()?.replace?.(/\s+/g, "-"), file);
	return "/user" + fp?.trim?.();
};
var uploadFile = async (dest = "/user/".trim?.()?.replace?.(/\s+/g, "-"), current) => {
	const $e = "showOpenFilePicker";
	dest = stripUserScopePrefix(dest);
	return (window?.[$e]?.bind?.(window) ?? (await import("../chunks/showOpenFilePicker.js"))?.[$e])({
		...generalFileImportDesc,
		multiple: true
	})?.then?.(async (handles = []) => {
		for (const handle of handles) await dropFile(handle instanceof File ? handle : await handle?.getFile?.(), dest, current);
	});
};
var ghostImage = typeof Image != "undefined" ? new Image() : null;
if (ghostImage) {
	ghostImage.decoding = "async";
	ghostImage.width = 24;
	ghostImage.height = 24;
	try {
		ghostImage.src = URL.createObjectURL(new Blob([`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 384 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M0 64C0 28.7 28.7 0 64 0L224 0l0 128c0 17.7 14.3 32 32 32l128 0 0 288c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zm384 64l-128 0L256 0 384 128z"/></svg>`], { type: "image/svg+xml" }));
	} catch (e) {}
}
var copyFromOneHandlerToAnother = async (fromHandle, toHandle, options = {}, logger = defaultLogger) => {
	return post("copy", {
		from: fromHandle,
		to: toHandle
	}, [fromHandle, toHandle]);
};
var handleIncomingEntries = (data, destPath = "/user/", rootHandle = null, onItemHandled) => {
	const tasks = [];
	const items = Array.from(data?.items ?? []);
	const files = Array.from(data?.files ?? []);
	const dataArray = Array.isArray(data) ? data : [...data?.[Symbol.iterator] ? data : [data]];
	return Promise.try(async () => {
		const resolvedRoot = await resolveRootHandle(rootHandle);
		const processItem = async (item) => {
			let handle;
			if (item.kind === "file" || item.kind === "directory") try {
				handle = await item.getAsFileSystemHandle?.();
			} catch {}
			if (handle) {
				if (handle.kind === "directory") {
					const nwd = await getDirectoryHandle(resolvedRoot, destPath + (handle.name || "").trim().replace(/\s+/g, "-"), { create: true });
					if (nwd) tasks.push(copyFromOneHandlerToAnother(handle, nwd, { create: true }));
				} else {
					const file = await handle.getFile();
					const path = destPath + (file.name || handle.name).trim().replace(/\s+/g, "-");
					tasks.push(writeFile(resolvedRoot, path, file).then(() => onItemHandled?.(file, path)));
				}
				return;
			}
			if (item.kind === "file" || item instanceof File) {
				const file = item instanceof File ? item : item.getAsFile();
				if (file) {
					const path = destPath + file.name.trim().replace(/\s+/g, "-");
					tasks.push(writeFile(resolvedRoot, path, file).then(() => onItemHandled?.(file, path)));
				}
				return;
			}
		};
		if (items?.length > 0) for (const item of items) await processItem(item);
		if (files?.length > 0) for (const file of files) await processItem(file);
		if (dataArray?.length > 0) for (const item of dataArray) await processItem(item);
		const uriList = data?.getData?.("text/uri-list") || data?.getData?.("text/plain");
		if (uriList && typeof uriList === "string") {
			const urls = uriList.split(/\r?\n/).filter(Boolean);
			for (const url of urls) {
				if (url.startsWith("file://")) continue;
				if (url.startsWith("/user/")) {
					const src = url.trim();
					tasks.push(Promise.try(async () => {
						const srcHandle = await getHandler(resolvedRoot, src);
						if (srcHandle?.handle) {
							const name = src.split("/").filter(Boolean).pop();
							if (srcHandle.type === "directory") {
								const nwd = await getDirectoryHandle(resolvedRoot, destPath + name, { create: true });
								await copyFromOneHandlerToAnother(srcHandle.handle, nwd, { create: true });
							} else {
								const file = await srcHandle.handle.getFile();
								const path = destPath + name;
								await writeFile(resolvedRoot, path, file);
								onItemHandled?.(file, path);
							}
						}
					}));
				} else tasks.push(Promise.try(async () => {
					const file = await provide(url);
					if (file) {
						const path = destPath + file.name;
						await writeFile(resolvedRoot, path, file);
						onItemHandled?.(file, path);
					}
				}));
			}
		}
		if (dataArray?.[0] instanceof ClipboardItem) {
			for (const item of dataArray) for (const type of item.types) if (type.startsWith("image/") || type.startsWith("text/")) {
				const blob = await item.getType(type);
				const ext = type.split("/")[1].split("+")[0] || "txt";
				const file = new File([blob], `clipboard-${Date.now()}.${ext}`, { type });
				const path = destPath + file.name;
				tasks.push(writeFile(resolvedRoot, path, file).then(() => onItemHandled?.(file, path)));
			}
		}
		await Promise.allSettled(tasks).catch(console.warn.bind(console));
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/WriteFileSmart-v2.ts
var lureFsPromise = null;
var getLureFs = () => {
	if (!lureFsPromise) lureFsPromise = Promise.resolve().then(() => src_exports).then((m) => ({
		readFile: m.readFile,
		writeFile: m.writeFile
	}));
	return lureFsPromise;
};
var toSlug = (input, toLower = true) => {
	let s = String(input || "").trim();
	if (toLower) s = s.toLowerCase();
	s = s.replace(/\s+/g, "-");
	s = s.replace(/[^a-z0-9_.\-+#&]/g, "-");
	s = s.replace(/-+/g, "-");
	return s;
};
var inferExtFromMime = (mime = "") => {
	if (!mime) return "";
	if (mime.includes("json")) return "json";
	if (mime.includes("markdown")) return "md";
	if (mime.includes("plain")) return "txt";
	if (mime === "image/jpeg" || mime === "image/jpg") return "jpg";
	if (mime === "image/png") return "png";
	if (mime.startsWith("image/")) return mime.split("/").pop() || "";
	if (mime.includes("html")) return "html";
	return "";
};
var splitPath = (path) => String(path || "").split("/").filter(Boolean);
var ensureDir = (p) => p.endsWith("/") ? p : p + "/";
var joinPath = (parts, absolute = true) => (absolute ? "/" : "") + parts.filter(Boolean).join("/");
var sanitizePathSegments = (path) => {
	return joinPath(splitPath(path).map((p) => toSlug(p)));
};
var DEFAULT_ARRAY_KEYS = [
	"id",
	"_id",
	"key",
	"slug",
	"name"
];
var isPlainObject = (v) => Object.prototype.toString.call(v) === "[object Object]";
function dedupeArray(items, opts) {
	const keys = Array.isArray(opts.arrayKey) ? opts.arrayKey : opts.arrayKey ? [opts.arrayKey] : DEFAULT_ARRAY_KEYS;
	const result = [];
	const primitiveSet = /* @__PURE__ */ new Set();
	const objMap = /* @__PURE__ */ new Map();
	const stringifiedSet = /* @__PURE__ */ new Set();
	for (const it of items) {
		if (it == null) continue;
		if (isPlainObject(it)) {
			let dedupeKey;
			for (const k of keys) if (k in it && it[k] != null) {
				dedupeKey = String(it[k]);
				break;
			}
			if (dedupeKey != null) {
				if (!objMap.has(dedupeKey)) {
					objMap.set(dedupeKey, it);
					result.push(it);
				}
			} else {
				const sig = safeStableStringify(it);
				if (!stringifiedSet.has(sig)) {
					stringifiedSet.add(sig);
					result.push(it);
				}
			}
		} else if (Array.isArray(it)) {
			const sig = safeStableStringify(it);
			if (!stringifiedSet.has(sig)) {
				stringifiedSet.add(sig);
				result.push(it);
			}
		} else if (!primitiveSet.has(it)) {
			primitiveSet.add(it);
			result.push(it);
		}
	}
	return result;
}
function mergeDeepUnique(a, b, opts) {
	if (Array.isArray(a) && Array.isArray(b)) switch (opts.arrayStrategy) {
		case "replace": return b.slice();
		case "concat": return a.concat(b);
		default: return dedupeArray(a.concat(b), { arrayKey: opts.arrayKey });
	}
	if (isPlainObject(a) && isPlainObject(b)) {
		const out = { ...a };
		for (const k of Object.keys(b)) if (k in a) out[k] = mergeDeepUnique(a[k], b[k], opts);
		else out[k] = b[k];
		return out;
	}
	return b;
}
function safeStableStringify(obj) {
	if (!isPlainObject(obj)) return JSON.stringify(obj);
	const keys = Object.keys(obj).sort();
	const o = {};
	for (const k of keys) o[k] = obj[k];
	return JSON.stringify(o);
}
async function blobToText(blob) {
	return await blob.text();
}
async function readFileAsJson(root, fullPath) {
	try {
		const { readFile } = await getLureFs();
		const existing = await readFile(root, fullPath)?.catch?.(console.warn.bind(console));
		if (!existing) return null;
		const text = await blobToText(existing);
		if (!text?.trim()) return null;
		return JSOX.parse(text);
	} catch {
		return null;
	}
}
var writeFileSmart = async (root, dirOrPath, file, options = {}) => {
	const { writeFile } = await getLureFs();
	const { forceExt, ensureJson, toLower = true, sanitize = true, mergeJson, arrayStrategy = "union", arrayKey, jsonSpace = 2 } = options;
	let raw = String(dirOrPath || "").trim();
	const isDirHint = raw.endsWith("/");
	const hasFileToken = !isDirHint && splitPath(raw).length > 0 && raw.includes(".");
	let dirPath = isDirHint ? raw : hasFileToken ? raw.split("/").slice(0, -1).join("/") : raw;
	let desiredName = hasFileToken ? raw.split("/").pop() || "" : file?.name || "";
	dirPath = dirPath || "/";
	desiredName = desiredName || Date.now() + "";
	const lastDot = desiredName.lastIndexOf(".");
	let base = lastDot > 0 ? desiredName.slice(0, lastDot) : desiredName;
	let ext = forceExt || (ensureJson ? "json" : lastDot > 0 ? desiredName.slice(lastDot + 1) : inferExtFromMime(file?.type || "")) || "";
	if (sanitize) {
		dirPath = sanitizePathSegments(dirPath);
		base = toSlug(base, toLower);
	}
	const finalName = ext ? `${base}.${ext}` : base;
	const fullPath = ensureDir(dirPath) + finalName;
	if (mergeJson !== false && (ensureJson || ext.toLowerCase() === "json" || file?.type === "application/json")) try {
		let incomingJson;
		if (file instanceof File || file instanceof Blob) {
			const txt = await blobToText(file);
			incomingJson = txt?.trim() ? JSOX.parse(txt) : {};
		} else incomingJson = file;
		const existingJson = await readFileAsJson(root, fullPath)?.catch?.(console.warn.bind(console));
		let merged = existingJson != null ? mergeDeepUnique(existingJson, incomingJson, {
			arrayStrategy,
			arrayKey
		}) : incomingJson;
		const jsonString = JSON.stringify(merged, void 0, jsonSpace);
		const rs = await writeFile(root, fullPath, new File([jsonString], finalName, { type: "application/json" }))?.catch?.(console.warn.bind(console));
		if (typeof document !== "undefined") document?.dispatchEvent?.(new CustomEvent("rs-fs-changed", {
			detail: rs,
			bubbles: true,
			composed: true,
			cancelable: true
		}));
		return rs;
	} catch (err) {
		console.warn("writeFileSmart JSON merge failed, falling back to raw write:", err);
	}
	let toWrite;
	if (file instanceof File) if (file.name === finalName) toWrite = file;
	else {
		const type = file.type || (ext ? `application/${ext}` : "application/octet-stream");
		const buf = await file.arrayBuffer();
		toWrite = new File([buf], finalName, { type });
	}
	else {
		const type = file.type || (ext ? `application/${ext}` : "application/octet-stream");
		toWrite = new File([await file.arrayBuffer()], finalName, { type });
	}
	const rs = await writeFile(root, fullPath, toWrite)?.catch?.(console.warn.bind(console));
	if (typeof document !== "undefined") document?.dispatchEvent?.(new CustomEvent("rs-fs-changed", {
		detail: rs,
		bubbles: true,
		composed: true,
		cancelable: true
	}));
	return rs;
};
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/FsWatch.ts
var matchPath = (path = "", dir = "") => {
	const normalizedDir = dir.endsWith("/") ? dir : `${dir}/`;
	return path.startsWith(normalizedDir);
};
var channel = new BroadcastChannel("rs-fs");
var watchers = /* @__PURE__ */ new Map();
channel.addEventListener("close", () => watchers.clear());
channel.addEventListener("message", (event) => {
	const payload = event?.data;
	if (!payload || payload.type !== "commit-result" && payload.type !== "commit-to-clipboard") return;
	const results = payload?.results ?? [];
	if (!Array.isArray(results) || !results.length) return;
	for (const [dir, listeners] of watchers.entries()) {
		if (!listeners.size) continue;
		if (!results.some((item) => matchPath(item?.path, dir))) continue;
		for (const listener of listeners) try {
			listener();
		} catch (e) {
			console.warn(e);
		}
	}
});
//#endregion
//#region ../../modules/projects/lur.e/src/index.ts
var src_exports = /* @__PURE__ */ __exportAll({
	$behavior: () => $behavior,
	$createElement: () => $createElement,
	$mapped: () => $mapped,
	$observeAttribute: () => $observeAttribute,
	$observeInput: () => $observeInput,
	$virtual: () => $virtual,
	C: () => C,
	CSSCalc: () => CSSCalc,
	DESKTOP_DRAFT_KEY: () => DESKTOP_DRAFT_KEY,
	DESKTOP_MAIN_KEY: () => DESKTOP_MAIN_KEY,
	E: () => E,
	FileHandler: () => FileHandler,
	GLitElement: () => GLitElement,
	H: () => H,
	HistoryManager: () => HistoryManager,
	ITEM_COMPACT_KIND: () => ITEM_COMPACT_KIND,
	JUNCTION_DRAG_EVENTS: () => JUNCTION_DRAG_EVENTS,
	JUNCTION_RESIZE_EVENTS: () => JUNCTION_RESIZE_EVENTS,
	JUNCTION_SELECT_EVENTS: () => JUNCTION_SELECT_EVENTS,
	JunctionDragMixin: () => JunctionDragMixin,
	JunctionResizeMixin: () => JunctionResizeMixin,
	JunctionSelectMixin: () => JunctionSelectMixin,
	LongPressHandler: () => LongPressHandler,
	M: () => M,
	Q: () => Q,
	Qp: () => Qp,
	ReactiveViewport: () => ReactiveViewport,
	S: () => S,
	TemplateManager: () => TemplateManager,
	VoiceInputManager: () => VoiceInputManager,
	addProxiedEvent: () => addProxiedEvent,
	addToBank: () => addToBank,
	alives: () => alives,
	applyNormalizedInlineStyle: () => applyNormalizedInlineStyle,
	attrLink: () => attrLink,
	attrRef: () => attrRef,
	bindCtrl: () => bindCtrl,
	bindDraggable: () => bindDraggable,
	bindHandler: () => bindHandler,
	bindStyle: () => bindStyle,
	bindWith: () => bindWith,
	blobToBytes: () => blobToBytes,
	checkedLink: () => checkedLink,
	checkedRef: () => checkedRef,
	clampCell: () => clampCell,
	clickPrevention: () => clickPrevention,
	colorScheme: () => colorScheme,
	compactIconSrcForStorage: () => compactIconSrcForStorage,
	compileInlineStyleAttribute: () => compileInlineStyleAttribute,
	copy: () => copy,
	copyFromOneHandlerToAnother: () => copyFromOneHandlerToAnother,
	createFileHandler: () => createFileHandler,
	createHistoryManager: () => createHistoryManager,
	createTemplateManager: () => createTemplateManager,
	currentHandleMap: () => currentHandleMap,
	decodeBase64ToBytes: () => decodeBase64ToBytes,
	decodeDesktopState: () => decodeDesktopState,
	defaultLogger: () => defaultLogger,
	defineElement: () => defineElement,
	detectTypeByRelPath: () => detectTypeByRelPath,
	directHandlers: () => directHandlers,
	directoryCacheMap: () => directoryCacheMap,
	downloadFile: () => downloadFile,
	dropFile: () => dropFile,
	dynamicBgColors: () => dynamicBgColors,
	dynamicNativeFrame: () => dynamicNativeFrame,
	dynamicTheme: () => dynamicTheme,
	elMap: () => elMap,
	electronAPI: () => electronAPI,
	elementPointerMap: () => elementPointerMap,
	encodeDesktopState: () => encodeDesktopState,
	ensureWorker: () => ensureWorker,
	eventTrigger: () => eventTrigger,
	expandIconSrcForDom: () => expandIconSrcForDom,
	faviconUrlForHostname: () => faviconUrlForHostname,
	generalFileImportDesc: () => generalFileImportDesc,
	getCachedComponent: () => getCachedComponent,
	getDir: () => getDir,
	getDirectoryHandle: () => getDirectoryHandle,
	getFileHandle: () => getFileHandle,
	getHandler: () => getHandler,
	getMimeTypeByFilename: () => getMimeTypeByFilename,
	getSpeechPrompt: () => getSpeechPrompt,
	ghostImage: () => ghostImage,
	grabForDrag: () => grabForDrag,
	handleError: () => handleError,
	handleIncomingEntries: () => handleIncomingEntries,
	hasFileExtension: () => hasFileExtension,
	historyState: () => historyState,
	hostnameToFaviconRef: () => hostnameToFaviconRef,
	html: () => html,
	htmlBuilder: () => htmlBuilder,
	initClipboardReceiver: () => initClipboardReceiver,
	initGlobalClipboard: () => initGlobalClipboard,
	isBase64Like: () => isBase64Like,
	isEffectivelyEmptyStyleText: () => isEffectivelyEmptyStyleText,
	isNativeCSSStyleValue: () => isNativeCSSStyleValue,
	isNotExtended: () => isNotExtended,
	isReactiveStyleValue: () => isReactiveStyleValue,
	junctionToBox: () => junctionToBox,
	lazyAddEventListener: () => lazyAddEventListener,
	lazyLoadComponent: () => lazyLoadComponent,
	listenForClipboardRequests: () => listenForClipboardRequests,
	loadCachedStyles: () => loadCachedStyles,
	loadDesktopRaw: () => loadDesktopRaw,
	localStorageLink: () => localStorageLink,
	localStorageLinkMap: () => localStorageLinkMap,
	localStorageRef: () => localStorageRef,
	makeLinker: () => makeLinker,
	makeRef: () => makeRef,
	makeShiftTrigger: () => makeShiftTrigger,
	makeUIState: () => makeUIState,
	mappedRoots: () => mappedRoots,
	matchMediaLink: () => matchMediaLink,
	matchMediaRef: () => matchMediaRef,
	maybeStartThemeEngine: () => maybeStartThemeEngine,
	mergeByKey: () => mergeByKey,
	mutationTrigger: () => mutationTrigger,
	navigate: () => navigate,
	normalizeDataAsset: () => normalizeDataAsset,
	normalizeIconSrcFromPayload: () => normalizeIconSrcFromPayload,
	normalizePath: () => normalizePath,
	openDirectory: () => openDirectory,
	packHrefInline: () => packHrefInline,
	parseDataUrl: () => parseDataUrl,
	parseDesktopItemCompact: () => parseDesktopItemCompact,
	persistDesktopDraft: () => persistDesktopDraft,
	persistDesktopMain: () => persistDesktopMain,
	pickBgColor: () => pickBgColor,
	pickFromCenter: () => pickFromCenter,
	post: () => post,
	property: () => property,
	provide: () => provide,
	pruneEmptyStyleAttribute: () => pruneEmptyStyleAttribute,
	readFile: () => readFile,
	reflectControllers: () => reflectControllers,
	registerCloseable: () => registerCloseable,
	registerModal: () => registerModal,
	reloadInto: () => reloadInto,
	remove: () => remove,
	removeFile: () => removeFile,
	removeFromBank: () => removeFromBank,
	resolvePath: () => resolvePath,
	resolveRootHandle: () => resolveRootHandle,
	scrollLink: () => scrollLink,
	scrollRef: () => scrollRef,
	serializeDesktopItemCompact: () => serializeDesktopItemCompact,
	sizeLink: () => sizeLink,
	sizeRef: () => sizeRef,
	stringToBlob: () => stringToBlob,
	stringToBlobOrFile: () => stringToBlobOrFile,
	toText: () => toText,
	unpackHrefInline: () => unpackHrefInline,
	unregisterCloseable: () => unregisterCloseable,
	uploadFile: () => uploadFile,
	valueAsNumberLink: () => valueAsNumberLink,
	valueAsNumberRef: () => valueAsNumberRef,
	valueLink: () => valueLink,
	valueRef: () => valueRef,
	withProperties: () => withProperties,
	writeFile: () => writeFile,
	writeFileSmart: () => writeFileSmart,
	writeHTML: () => writeHTML,
	writeImage: () => writeImage,
	writeText: () => writeText
});
//#endregion
export { elementPointerMap as A, persistDesktopMain as C, writeText as D, initGlobalClipboard as E, GLitElement as M, defineElement as N, LongPressHandler as O, property as P, persistDesktopDraft as S, initClipboardReceiver as T, createTemplateManager as _, getDir as a, decodeDesktopState as b, getMimeTypeByFilename as c, provide as d, readFile as f, dynamicTheme as g, writeFile as h, downloadFile as i, makeShiftTrigger as j, bindDraggable as k, handleIncomingEntries as l, uploadFile as m, writeFileSmart as n, getDirectoryHandle as o, remove as p, copyFromOneHandlerToAnother as r, getFileHandle as s, src_exports as t, openDirectory as u, makeUIState as v, copy as w, loadDesktopRaw as x, JSOX as y };
