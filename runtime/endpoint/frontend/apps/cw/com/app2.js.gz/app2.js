import { n as __exportAll } from "../chunks/rolldown-runtime.js";
import { B as setIdleInterval$1, D as getBoundingOrientRect, E as fixedClientZoom, I as isValidParent, L as makeRAFCycle, P as isElement, R as setAttributesIfNull, _ as setProperty, a as handleStyleChange, f as getPadding, k as addEvent, m as loadInlineStyle, o as DOMMixin, p as loadAsAdopted, s as addRoot, t as handleAttribute, v as setStyleProperty, z as setChecked } from "../fest/dom.js";
import { a as WRef, n as stripUserScopePrefix, r as userPathCandidates } from "../fest/core.js";
import { C as inProxy, E as $getValue, K as normalizePrimitive, M as getValue, O as UUIDv4, T as $avoidTrigger, U as isValueRef, V as isPrimitive, _ as $triggerControl, a as booleanRef, b as bindEvent, f as addToCallChain, g as $trigger, l as ref, n as affected, o as numberRef, p as safe, s as observe, u as stringRef, v as $triggerLess, w as isNotEqual, x as contextify, z as isObject } from "../fest/object.js";
import { o as createWorkerChannel, s as QueuedWorkerChannel } from "../fest/uniform.js";
import { A as $mapped, B as bindSpring, C as isNativeCSSStyleValue, D as ANIMATABLE_BRAND, E as pruneEmptyStyleAttribute, F as alives, G as removeFromBank, H as bindWith, I as bindAnimated, L as bindCtrl, M as $observeInput, N as $virtual, O as isAnimatableValue, P as addToBank, R as bindHandler, S as isEffectivelyEmptyStyleText, T as isStyleBinding, U as elMap, V as bindTransition, W as reflectControllers, _ as C, a as html, b as bindStyle, c as E, d as EventHandler, f as Q, g as replaceOrSwap, h as removeChild, i as H, j as $observeAttribute, k as $behavior, l as Qp, m as getNode, o as htmlBuilder, p as appendFix, r as createHistoryManager, s as $createElement, t as HistoryManager, u as M, v as S, w as isReactiveStyleValue, x as compileInlineStyleAttribute, y as applyNormalizedInlineStyle, z as bindMorph } from "./app.js";
import { a as parseDataUrl, i as normalizeDataAsset, n as decodeBase64ToBytes, o as stringToBlob, r as isBase64Like, s as stringToBlobOrFile, t as blobToBytes } from "./app3.js";
import { a as VoiceInputManager, i as createFileHandler, n as lazyLoadComponent, o as getSpeechPrompt, r as FileHandler, t as getCachedComponent } from "./app9.js";
//#region ../../modules/projects/lur.e/src/lure/node/Switched.ts
var $getFromMapped = (mapped, value) => {
	if (typeof value == "number" && value < 0 || typeof value == "string" && !value || value == null) return { element: "" };
	if (mapped instanceof Map || typeof mapped?.get == "function") return mapped.get(value);
	if (mapped instanceof Set || typeof mapped?.has == "function") return mapped.has(value) ? value : null;
	return mapped?.[value] ?? { element: "" };
};
var getFromMapped = (mapped, value, requestor = null) => {
	return getNode($getFromMapped(mapped, value), null, -1, requestor);
};
var SwM = class {
	#stub = document.createComment("");
	current;
	mapped;
	boundParent = null;
	constructor(params, mapped) {
		this.#stub = document.createComment("");
		this.current = params?.current ?? { value: -1 };
		this.mapped = params?.mapped ?? mapped ?? [];
		const us = affected([params?.current, "value"], (newVal, prop, oldVal) => this._onUpdate(newVal, prop, oldVal));
		if (us) addToCallChain(this, Symbol.dispose, us);
	}
	get element() {
		const element = getFromMapped(this.mapped, this.current?.value ?? -1, this.boundParent) ?? this.#stub;
		const theirParent = isValidParent(element?.parentElement) ? element?.parentElement : this.boundParent;
		this.boundParent ??= isValidParent(theirParent) ?? this.boundParent;
		if (element != null && (element?.parentNode != this.boundParent || !element?.parentNode)) {
			if (this.boundParent) appendFix(this.boundParent, element);
		}
		queueMicrotask(() => {
			const theirParent = isValidParent(element?.parentElement) ? element?.parentElement : this.boundParent;
			this.boundParent ??= isValidParent(theirParent) ?? this.boundParent;
		});
		return element;
	}
	elementForPotentialParent(requestor) {
		if (isValidParent(requestor)) this.boundParent = requestor;
		this.current?.[$trigger]?.();
		return this.element;
	}
	_onUpdate(newVal, prop, oldVal) {
		const idx = newVal ?? this.current?.value;
		if (oldVal ? isNotEqual(idx, oldVal) : true) {
			const old = oldVal ?? this.current?.value;
			if (this.current) this.current.value = idx ?? -1;
			const parent = getFromMapped(this.mapped, old ?? idx ?? -1)?.parentNode ?? this.boundParent;
			this.boundParent = parent ?? this.boundParent;
			const newNode = getFromMapped(this.mapped, idx ?? -1, parent) ?? this.#stub;
			const oldNode = getFromMapped(this.mapped, old ?? -1, parent);
			if (isElement(parent)) {
				if (isElement(newNode)) {
					if (isElement(oldNode)) try {
						replaceOrSwap(parent, oldNode, newNode);
					} catch (e) {
						console.warn(e);
					}
					else appendFix(parent, newNode);
				} else if (oldNode && !newNode) removeChild(parent, oldNode);
			}
		}
	}
};
var SwHandler = class {
	constructor() {}
	set(params, name, val) {
		return Reflect.set(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, name, val);
	}
	has(params, name) {
		return Reflect.has(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, name);
	}
	get(params, name, ctx) {
		if (name == "elementForPotentialParent" && (name in params || params?.[name] != null)) return params?.elementForPotentialParent?.bind(params);
		if (name == "element" && (name in params || params?.[name] != null)) return params?.element;
		if (name == "_onUpdate" && (name in params || params?.[name] != null)) return params?._onUpdate?.bind(params);
		return contextify(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, name);
	}
	ownKeys(params) {
		return Reflect.ownKeys(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params);
	}
	apply(params, thisArg, args) {
		return Reflect.apply(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, thisArg, args);
	}
	deleteProperty(params, name) {
		return Reflect.deleteProperty(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, name);
	}
	setPrototypeOf(params, proto) {
		return Reflect.setPrototypeOf(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, proto);
	}
	getPrototypeOf(params) {
		return Reflect.getPrototypeOf(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params);
	}
	defineProperty(params, name, desc) {
		return Reflect.defineProperty(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, name, desc);
	}
	getOwnPropertyDescriptor(params, name) {
		return Reflect.getOwnPropertyDescriptor(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params, name);
	}
	preventExtensions(params) {
		return Reflect.preventExtensions(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params);
	}
	isExtensible(params) {
		return Reflect.isExtensible(getFromMapped(params?.mapped, params?.current?.value ?? -1) ?? params);
	}
};
var I = (params, mapped) => {
	return inProxy?.getOrInsertComputed?.(params, () => {
		return new Proxy(params instanceof SwM ? params : new SwM(params, mapped), new SwHandler());
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/lure/node/jsx-runtime/index.ts
/** INVARIANT: Symbol identity is shared via jsx-dev-runtime → jsx-runtime symlink. */
var Fragment = Symbol.for("fest.jsx.Fragment");
var createElement = (type, props = {}, children, ...others) => {
	let normalized = {}, ref;
	let attributes = {}, properties = {}, classList = {}, style = {}, ctrls = {}, on = {};
	for (const i in props) if (i == "ref") {
		if (typeof type != "function") ref = typeof props[i] != "function" ? props[i] : Q(props[i]);
	} else if (i == "classList") classList = props[i];
	else if (i == "style") style = props[i];
	else if (i?.startsWith?.("@")) {
		const name = i.replace("@", "").trim();
		if (name) bindEvent(on, name, props[i]);
		else on = props[i];
	} else if (i?.startsWith?.("on:")) {
		const name = i.replace("on:", "").trim();
		if (name) bindEvent(on, name, props[i]);
		else on = props[i];
	} else if (i?.startsWith?.("prop:")) {
		const name = i.replace("prop:", "").trim();
		if (name) properties[name] = props[i];
		else properties = props[i];
	} else if (i?.startsWith?.("attr:")) {
		const name = i.replace("attr:", "").trim();
		if (name) attributes[name] = props[i];
		else attributes = props[i];
	} else if (i?.startsWith?.("ctrl:")) {
		const name = i.replace("ctrl:", "").trim();
		if (name) ctrls.set(name, props[i]);
		else ctrls = props[i];
	} else if (i !== "children" && i !== "key") attributes[i.trim()] = props[i];
	Object.assign(normalized, {
		attributes,
		properties,
		classList,
		style,
		on
	});
	const fromProps = props?.children;
	const $children = Array.isArray(children) ? children : others?.length > 0 ? [children, ...others] : children != null ? (typeof children == "object" || typeof children == "function") && !(children instanceof Node) || children instanceof DocumentFragment ? children : [children] : fromProps != null ? fromProps : null;
	if (type == Fragment) return E(document.createDocumentFragment(), normalized, $children);
	if (typeof type == "function") return type(props, $children);
	if (type == "For") return M(props, $children);
	if (type == "Switch") return I(props, $children);
	const element = E(type, normalized, $children);
	if (!element) return element;
	Promise.try(() => {
		if (ref) {
			if (typeof ref == "function") ref?.(element);
			else ref.value = element;
		}
	})?.catch?.(console.warn.bind(console));
	return element;
};
globalThis["createElement"] = createElement;
globalThis["Fragment"] = Fragment;
globalThis["render"] = createElement;
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/tasking/History.ts
var STATE_KEY = "rs-nav-ctx";
var STACK_KEY = "rs-nav-stack";
var historyState = observe({
	index: 0,
	length: 0,
	action: "MANUAL",
	view: "",
	canBack: false,
	canForward: false,
	entries: []
});
var getCurrentState = () => {
	try {
		return history.state?.[STATE_KEY] || historyState?.entries?.[historyState?.index] || {};
	} catch (e) {
		return {};
	}
};
var saveStack = () => {
	try {
		sessionStorage.setItem(STACK_KEY, JSON.stringify(historyState?.entries));
	} catch (e) {}
};
var loadStack = () => {
	try {
		const stored = sessionStorage.getItem(STACK_KEY);
		return stored ? JSON.parse(stored) : [];
	} catch (e) {
		return [];
	}
};
var mergeState = (newState, existingData) => {
	try {
		const current = existingData !== void 0 ? existingData : history?.state || {};
		if (isPrimitive(current) && current !== null) return {
			value: current,
			[STATE_KEY]: newState
		};
		if (current === null) return { [STATE_KEY]: newState };
		return {
			...current,
			[STATE_KEY]: newState
		};
	} catch (e) {
		return { [STATE_KEY]: newState };
	}
};
var initialized$1 = false;
var originalPush = typeof history != "undefined" ? history.pushState.bind(history) : void 0;
var originalReplace = typeof history != "undefined" ? history.replaceState.bind(history) : void 0;
var originalGo = typeof history != "undefined" ? history.go.bind(history) : void 0;
var originalForward = typeof history != "undefined" ? history.forward.bind(history) : void 0;
typeof history != "undefined" && history.back.bind(history);
var initHistory = (initialView = "") => {
	if (initialized$1) return;
	initialized$1 = true;
	const current = getCurrentState();
	const view = initialView || location.hash || "#";
	let stack = loadStack();
	const idx = current.index || 0;
	if (stack && (stack?.length === 0 || idx >= stack?.length)) {
		if (stack.length <= idx) stack[idx] = {
			index: idx,
			depth: history.length,
			action: current?.action || "REPLACE",
			view,
			timestamp: Date.now()
		};
	}
	historyState.entries = stack;
	if (!current.timestamp) {
		const state = {
			index: idx,
			depth: history.length,
			action: "REPLACE",
			view,
			timestamp: Date.now()
		};
		history?.replaceState?.(mergeState(state), "", location.hash);
		if (historyState?.entries) historyState.entries[idx] = state;
		saveStack();
	} else {
		historyState.index = current.index || 0;
		historyState.view = current.view || view;
		if (!historyState?.entries?.[historyState?.index]) {
			historyState.entries[historyState.index] = current;
			saveStack();
		}
	}
	updateReactiveState(getCurrentState()?.action || "REPLACE", view);
	history.go = (delta = 0) => {
		const currentState = getCurrentState();
		currentState.index = Math.max(0, Math.min(historyState.length, (currentState.index || 0) + delta));
		const existsState = historyState.entries[currentState.index];
		Object.assign(currentState, existsState || {});
		setIgnoreNextPopState(true);
		const result = originalGo?.(delta);
		setTimeout(() => {
			setIgnoreNextPopState(false);
		}, 0);
		updateReactiveState(currentState?.action || "POP", currentState?.view);
		return result;
	};
	history.back = () => {
		return history.go(-1);
	};
	history.forward = () => {
		return history.go(1);
	};
	history.pushState = (data, unused, url) => {
		const currentState = getCurrentState();
		const nextIndex = (currentState.index || 0) + 1;
		const newState = {
			index: nextIndex,
			depth: history.length + 1,
			action: "PUSH",
			view: url ? String(url) : currentState.view || "",
			timestamp: Date.now()
		};
		const result = originalPush?.(mergeState(newState, data), unused, url);
		historyState.entries = historyState?.entries?.slice?.(0, nextIndex);
		historyState.entries?.push?.(newState);
		saveStack();
		updateReactiveState("PUSH", newState.view);
		return result;
	};
	history.replaceState = (data, unused, url) => {
		const currentState = getCurrentState();
		const index = currentState?.index || 0;
		const newState = {
			...currentState,
			index,
			depth: history.length,
			action: "REPLACE",
			view: url ? String(url) : currentState?.view || "",
			timestamp: Date.now()
		};
		const result = originalReplace?.(mergeState(newState, data), unused, url);
		if (historyState?.entries) {
			historyState.entries[index] = newState;
			historyState.entries[historyState.index].view = url ? String(url) : currentState?.view || "";
		}
		saveStack();
		updateReactiveState("REPLACE", newState.view);
		return result;
	};
	addEvent(window, "popstate", (ev) => {
		const state = ev.state?.[STATE_KEY];
		const currentIndex = historyState.index ?? 0;
		if (!state) {
			const newState = {
				index: currentIndex + 1,
				depth: history.length,
				action: "PUSH",
				view: location.hash || "#",
				timestamp: Date.now()
			};
			history.replaceState(mergeState(newState, ev.state), "", location.hash);
			historyState.entries = historyState?.entries?.slice?.(0, newState.index);
			historyState?.entries?.push?.(newState);
			saveStack();
			updateReactiveState("PUSH", newState.view);
			return;
		} else {
			const newIndex = state?.index ?? 0;
			let action = "POP";
			if (newIndex < currentIndex) action = "BACK";
			else if (newIndex > currentIndex) action = "FORWARD";
			updateReactiveState(action, state?.view || location.hash);
		}
	});
	addEvent(window, "hashchange", (ev) => {
		if (getIgnoreNextPopState()) return;
		const currentHash = location.hash || "#";
		if (historyState.view !== currentHash) updateReactiveState("PUSH", currentHash);
	});
};
var updateReactiveState = (action, view) => {
	const current = getCurrentState();
	historyState.index = current.index || 0;
	historyState.length = history.length;
	historyState.action = action || "POP";
	historyState.view = view || current.view || location.hash;
	historyState.canBack = historyState.index > 0;
};
var navigate = (view, replace = false) => {
	const hash = view.startsWith("#") ? view : `#${view}`;
	if (replace && historyState?.index > 0) {
		const prev = historyState?.entries?.[historyState?.index - 1];
		if (prev && prev.view === hash) {
			history.back();
			return;
		}
	}
	if (replace) {
		if (historyState?.entries?.[historyState.index]?.view !== hash || historyState?.entries?.[historyState.index]?.view) history?.replaceState?.(null, "", hash);
	} else history?.pushState?.(null, "", hash);
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/tasking/BackNavigation.ts
/**
* BackNavigation - Priority-based back gesture/button navigation manager
*
* Handles mobile/browser back gestures/buttons for closing:
* - Context menus (highest priority)
* - Modal dialogs
* - Sidebars/overlays
* - Tasks/views (lowest priority)
*
* Usage:
* 1. Register closable elements/callbacks with priority
* 2. On back navigation, closes the highest priority active element first
* 3. Supports custom close handlers and visibility checks
*/
var ClosePriority = /* @__PURE__ */ function(ClosePriority) {
	ClosePriority[ClosePriority["CONTEXT_MENU"] = 100] = "CONTEXT_MENU";
	ClosePriority[ClosePriority["DROPDOWN"] = 90] = "DROPDOWN";
	ClosePriority[ClosePriority["MODAL"] = 80] = "MODAL";
	ClosePriority[ClosePriority["DIALOG"] = 70] = "DIALOG";
	ClosePriority[ClosePriority["SIDEBAR"] = 60] = "SIDEBAR";
	ClosePriority[ClosePriority["OVERLAY"] = 50] = "OVERLAY";
	ClosePriority[ClosePriority["PANEL"] = 40] = "PANEL";
	ClosePriority[ClosePriority["TOAST"] = 30] = "TOAST";
	ClosePriority[ClosePriority["TASK"] = 20] = "TASK";
	ClosePriority[ClosePriority["VIEW"] = 10] = "VIEW";
	ClosePriority[ClosePriority["DEFAULT"] = 0] = "DEFAULT";
	return ClosePriority;
}({});
var registry = /* @__PURE__ */ new Map();
var navigationInitialized = false;
var processingBack = false;
var historyDepth = 0;
var options = {};
var ignoreNextPopState = false;
var setIgnoreNextPopState = (value) => {
	ignoreNextPopState = value;
};
var getIgnoreNextPopState = () => ignoreNextPopState;
var generateId = () => `closeable-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
/**
* Register a closeable element/callback with the back navigation system
*/
var registerCloseable = (entry) => {
	const id = entry.id || generateId();
	const fullEntry = Object.assign(entry, { id });
	if (fullEntry?.hashId == null) fullEntry.hashId = id;
	registry.set(id, fullEntry);
	if (options.debug) console.log("[BackNav] Registered:", id, "priority:", entry.priority);
	return () => unregisterCloseable(id);
};
/**
* Unregister a closeable by ID
*/
var unregisterCloseable = (id) => {
	const removed = registry.delete(id);
	if (options.debug && removed) console.log("[BackNav] Unregistered:", id);
	return removed;
};
/**
* Get all active closeables sorted by priority (highest first)
*/
var getActiveCloseables = (view) => {
	return Array.from(registry.values()).filter((entry) => {
		if (entry.element) {
			if (!entry.element.deref()) {
				registry.delete(entry.id);
				return false;
			}
		}
		return entry.isActive(view);
	}).sort((a, b) => b.priority - a.priority);
};
/**
* Get the highest priority active closeable
*/
var getActiveCloseable = (view) => {
	return getActiveCloseables(view)[0] || null;
};
/**
* Attempt to close the highest priority active closeable
* @returns true if something was closed, false otherwise
*/
var closeHighestPriority = (view) => {
	const entry = getActiveCloseable(view);
	if (!entry) return null;
	if (options.debug) console.log("[BackNav] Closing:", entry.id, "priority:", entry.priority);
	return entry?.close?.(view) != false ? entry : null;
};
/**
* Check if any closeable is currently active
*/
var hasActiveCloseable = (view) => {
	return getActiveCloseable(view) != null;
};
/**
* Handle back navigation (popstate event)
*/
var handleBackNavigation = (ev) => {
	if (processingBack) return false;
	if (ignoreNextPopState) {
		ignoreNextPopState = false;
		return false;
	}
	if (ev?.state?.action) return false;
	processingBack = true;
	try {
		ignoreNextPopState = true;
		let closingView;
		if (historyState.entries && (historyState.action === "BACK" || historyState.action === "POP")) {
			const prevEntry = historyState.entries[historyState.index + 1];
			if (prevEntry) closingView = prevEntry.view;
		}
		if (closeHighestPriority(closingView)) {
			ev.preventDefault?.();
			ignoreNextPopState = true;
			originalForward?.();
			setTimeout(() => {
				ignoreNextPopState = false;
			}, 0);
			return true;
		}
		ignoreNextPopState = false;
		return false;
	} finally {
		processingBack = false;
	}
};
/**
* Initialize back navigation handling
*/
var initBackNavigation = (opts = {}) => {
	if (navigationInitialized) {
		console.warn("[BackNav] Already initialized");
		return () => {};
	}
	options = { ...opts };
	navigationInitialized = true;
	initHistory(location.hash);
	if (opts.pushInitialState !== false && !opts.skipPopstateHandler) {
		historyDepth = 0;
		setIgnoreNextPopState(true);
		const newState = {
			...history.state || {},
			backNav: true,
			depth: historyDepth
		};
		history.pushState(newState, "", location.hash || "#");
		setIgnoreNextPopState(false);
	}
	let unbind;
	if (!opts.skipPopstateHandler) {
		const popstateHandler = (ev) => {
			if (!ev?.state?.action) {
				if (!handleBackNavigation(ev) && !opts.preventDefaultNavigation) {}
			}
		};
		unbind = addEvent(window, "popstate", popstateHandler);
	}
	if (options.debug) console.log("[BackNav] Initialized", opts.skipPopstateHandler ? "(external handler)" : "");
	return () => {
		unbind?.();
		navigationInitialized = false;
		registry.clear();
		if (options.debug) console.log("[BackNav] Destroyed");
	};
};
/**
* Register a modal dialog as closeable
*/
var registerModal = (element, isActiveCheck, onClose) => {
	return registerCloseable({
		id: `modal-${element.id || generateId()}`,
		priority: 80,
		element: new WeakRef(element),
		group: "modal",
		isActive: isActiveCheck ?? (() => {
			const el = element;
			return el?.isConnected && !el?.hasAttribute?.("data-hidden") && el?.checkVisibility?.({
				opacityProperty: true,
				visibilityProperty: true
			}) !== false;
		}),
		close: () => {
			onClose?.();
			element?.remove?.();
			return true;
		}
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/lure/core/Links.ts
var localStorageLinkMapSymbol = Symbol.for("lure@localStorageLinkMap");
globalThis[localStorageLinkMapSymbol] ??= /* @__PURE__ */ new Map();
var localStorageLinkMap = globalThis[localStorageLinkMapSymbol];
var cleanupOf = (cleanup) => {
	if (!cleanup) return;
	if (typeof cleanup == "function") return cleanup;
	const target = cleanup;
	if (typeof target?.disconnect == "function") return () => target.disconnect?.();
	if (typeof target?.unsubscribe == "function") return () => target.unsubscribe?.();
};
var runWithoutSetterTrigger = (target, cb) => {
	const control = target?.[$triggerControl];
	if (typeof control?.without == "function") return control.without(["setter", "set"], cb);
	return $avoidTrigger(target, cb);
};
var setRefValue = (target, value, forProp = "value") => {
	if (!target || !(typeof target == "object" || typeof target == "function")) return value;
	if (isNotEqual(target[forProp], value)) return runWithoutSetterTrigger(target, () => {
		target[forProp] = value;
	});
	return value;
};
var selectSourceInput = (source, event, selector = "input") => {
	const target = event?.target ?? source;
	if (target?.matches?.(selector)) return target;
	return target?.querySelector?.(selector) ?? source;
};
var eventTrigger = (events, options) => {
	const eventList = Array.isArray(events) ? events : [events];
	return ({ source, commit }) => {
		const target = source?.element ?? source?.self ?? source;
		if (!target?.addEventListener) return;
		const listener = (event) => commit(event);
		eventList.forEach((name) => target.addEventListener(name, listener, options));
		return () => eventList.forEach((name) => target.removeEventListener?.(name, listener, options));
	};
};
var mutationTrigger = (attribute) => {
	return ({ source, commit }) => {
		const target = source?.element ?? source?.self ?? source;
		if (!target || typeof MutationObserver == "undefined") return;
		const observer = new MutationObserver((records) => {
			if (!attribute || records.some((record) => record.type == "attributes" && record.attributeName == attribute)) commit(records);
		});
		observer.observe(target, {
			attributes: true,
			attributeFilter: attribute ? [attribute] : void 0
		});
		return () => observer.disconnect();
	};
};
var makeLinker = (options) => {
	const source = typeof options.source == "function" ? options.source() : options.source;
	const defaultForProp = options.forProp ?? "value";
	const linker = {
		source,
		ref: options.ref,
		forProp: defaultForProp,
		get(event, forProp = defaultForProp) {
			return options.getter?.({
				source,
				ref: linker.ref,
				linker,
				forProp,
				event,
				reason: event ? "source" : "manual"
			});
		},
		set(value, event, forProp = defaultForProp) {
			return options.setter?.(value, {
				source,
				ref: linker.ref,
				linker,
				forProp,
				event,
				reason: "ref"
			});
		},
		store(value, event, forProp = defaultForProp) {
			const ctx = {
				source,
				ref: linker.ref,
				linker,
				forProp,
				event,
				reason: "source"
			};
			return options.store ? options.store(value, ctx) : setRefValue(linker.ref, value, forProp);
		},
		trigger(event, forProp = defaultForProp) {
			const value = linker.get(event, forProp);
			return linker.store(value, event, forProp);
		},
		bind() {
			linker.unbind();
			if (options.bindImmediately) linker.trigger();
			const triggerCleanup = cleanupOf(options.trigger?.({
				source,
				ref: linker.ref,
				linker,
				forProp: defaultForProp,
				reason: "initial",
				commit: (event, forProp = defaultForProp) => linker.trigger(event, forProp)
			}));
			const setterCleanup = linker.ref && options.setter ? affected([linker.ref, defaultForProp], (value) => {
				linker.set(value, void 0, defaultForProp);
			}, {
				affectTypes: options.affectTypes ?? ["setter", "manual"],
				triggerImmediately: options.triggerImmediately ?? true
			}) : null;
			linker.__cleanup = () => {
				triggerCleanup?.();
				setterCleanup?.();
			};
			return linker;
		},
		unbind() {
			linker.__cleanup?.();
			linker.__cleanup = null;
		},
		[Symbol.dispose]() {
			linker.unbind();
		},
		__cleanup: null
	};
	return linker;
};
var localStorageLink = (existsStorage, exists, key, initial) => {
	if (key == null) return;
	if (localStorageLinkMap.has(key)) {
		localStorageLinkMap.get(key)?.[0]?.();
		localStorageLinkMap.delete(key);
	}
	return localStorageLinkMap.getOrInsertComputed?.(key, () => {
		const def = (existsStorage ?? localStorage).getItem(key) ?? initial?.value ?? initial;
		const ref = isValueRef(exists) ? exists : stringRef(def);
		ref.value ??= def;
		const $val = new WeakRef(ref);
		const unsb = affected([ref, "value"], (val) => {
			$avoidTrigger($val?.deref?.(), () => {
				(existsStorage ?? localStorage).setItem(key, val);
			});
		});
		const list = (ev) => {
			if (ev.storageArea == (existsStorage ?? localStorage) && ev.key == key) {
				if (isNotEqual(ref.value, ev.newValue)) ref.value = ev.newValue;
			}
		};
		addEventListener("storage", list);
		return [() => {
			unsb?.();
			removeEventListener("storage", list);
		}, ref];
	});
};
var matchMediaLink = (existsMedia, exists, condition) => {
	if (condition == null) return;
	const med = existsMedia ?? matchMedia(condition), def = med?.matches || false;
	const ref = isValueRef(exists) ? exists : booleanRef(def);
	ref.value ??= def;
	const evf = (ev) => ref.value = ev.matches;
	med?.addEventListener?.("change", evf);
	return () => {
		med?.removeEventListener?.("change", evf);
	};
};
var attrLink = (element, exists, attribute, initial) => {
	const def = element?.getAttribute?.(attribute) ?? (typeof initial == "boolean" ? initial ? "" : null : getValue(initial));
	if (!element) return;
	const val = isValueRef(exists) ? exists : stringRef(def);
	if (isObject(val) && !normalizePrimitive(val.value)) val.value = normalizePrimitive(def) ?? val.value ?? "";
	const linker = makeLinker({
		source: element,
		ref: val,
		getter: ({ source }) => source?.getAttribute?.(attribute),
		setter: (value, { source }) => handleAttribute(source, attribute, normalizePrimitive(value)),
		trigger: mutationTrigger(attribute)
	}).bind();
	return () => linker.unbind();
};
var sizeLink = (element, exists, axis, box) => {
	const def = box == "border-box" ? element?.[axis == "inline" ? "offsetWidth" : "offsetHeight"] : element?.[axis == "inline" ? "clientWidth" : "clientHeight"] - getPadding(element, axis);
	const val = isValueRef(exists) ? exists : numberRef(def);
	if (isObject(val)) val.value ||= (def ?? val.value) || 1;
	const obs = new ResizeObserver((entries) => {
		if (isObject(val)) {
			if (box == "border-box") val.value = axis == "inline" ? entries[0].borderBoxSize[0].inlineSize : entries[0].borderBoxSize[0].blockSize;
			if (box == "content-box") val.value = axis == "inline" ? entries[0].contentBoxSize[0].inlineSize : entries[0].contentBoxSize[0].blockSize;
			if (box == "device-pixel-content-box") val.value = axis == "inline" ? entries[0].devicePixelContentBoxSize[0].inlineSize : entries[0].devicePixelContentBoxSize[0].blockSize;
		}
	});
	if ((element?.element ?? element?.self ?? element) instanceof HTMLElement) obs?.observe?.(element?.element ?? element?.self ?? element, { box });
	return () => obs?.disconnect?.();
};
var scrollLink = (element, exists, axis, initial) => {
	if (initial != null && typeof (initial?.value ?? initial) == "number") element?.scrollTo?.({ [axis == "block" ? "top" : "left"]: initial?.value ?? initial });
	const def = element?.[axis == "block" ? "scrollTop" : "scrollLeft"];
	const val = isValueRef(exists) ? exists : numberRef(def || 0);
	if (isObject(val)) val.value ||= (def ?? val.value) || 1;
	val.value ||= (def ?? val.value) || 0;
	const prop = axis == "block" ? "scrollTop" : "scrollLeft";
	const scrollProp = axis == "block" ? "top" : "left";
	const linker = makeLinker({
		source: element,
		ref: val,
		getter: ({ source }) => source?.[prop] || 0,
		setter: (value, { source }) => {
			if (Math.abs((source?.[prop] || 0) - Number(value || 0)) > .001) source?.scrollTo?.({ [scrollProp]: Number(value || 0) });
		},
		trigger: eventTrigger("scroll", { passive: true })
	}).bind();
	return () => linker.unbind();
};
var checkedLink = (element, exists) => {
	const def = !!element?.checked || false;
	const val = isValueRef(exists) ? exists : booleanRef(def);
	if (isObject(val) && val.value !== def) val.value = def;
	const linker = makeLinker({
		source: (element?.type == "radio" ? element?.closest?.("input[type='radio']") : element) ?? element,
		ref: val,
		getter: ({ source, event }) => selectSourceInput(source, event, `input[type="checkbox"], input:checked`)?.checked ?? element?.checked ?? val?.value,
		setter: (value) => {
			if (element && element?.checked != value) setChecked(element, value);
		},
		trigger: eventTrigger([
			"click",
			"input",
			"change"
		])
	}).bind();
	return () => linker.unbind();
};
var valueLink = (element, exists) => {
	if (isPrimitive(element)) return;
	if (!element || !(element instanceof Node || element?.element instanceof Node)) return;
	const def = element?.value ?? "";
	const val = isValueRef(exists) ? exists : stringRef(def);
	if (isObject(val) && !normalizePrimitive(val.value)) val.value = normalizePrimitive(def) ?? val.value ?? "";
	const linker = makeLinker({
		source: element,
		ref: val,
		getter: ({ source, event }) => selectSourceInput(source, event)?.value ?? source?.value ?? val?.value ?? "",
		setter: (value, { source }) => {
			const next = $getValue(value);
			if (source && isNotEqual(source?.value, next)) {
				source.value = next ?? "";
				source?.dispatchEvent?.(new Event("change", { bubbles: true }));
			}
		},
		trigger: eventTrigger([
			"click",
			"input",
			"change"
		])
	}).bind();
	return () => linker.unbind();
};
var valueAsNumberLink = (element, exists) => {
	if (isPrimitive(element)) return;
	if (!element || !(element instanceof Node || element?.element instanceof Node)) return;
	const def = Number(element?.valueAsNumber) || 0;
	const val = isValueRef(exists) ? exists : numberRef(def);
	if (isObject(val) && !val.value && def) val.value = def;
	const linker = makeLinker({
		source: element,
		ref: val,
		getter: ({ source, event }) => Number(selectSourceInput(source, event)?.valueAsNumber || source?.valueAsNumber || 0) || 0,
		setter: (value, { source }) => {
			if (source && (source.type == "range" || source.type == "number") && typeof source?.valueAsNumber == "number" && isNotEqual(source?.valueAsNumber, value)) {
				source.valueAsNumber = Number(value);
				source?.dispatchEvent?.(new Event("change", { bubbles: true }));
			}
		},
		trigger: eventTrigger([
			"click",
			"input",
			"change"
		])
	}).bind();
	return () => linker.unbind();
};
//#endregion
//#region ../../modules/projects/lur.e/src/utils/math/Point2D.ts
var Vector2D = class Vector2D {
	_x;
	_y;
	constructor(x = 0, y = 0) {
		this._x = typeof x === "number" ? numberRef(x) : x;
		this._y = typeof y === "number" ? numberRef(y) : y;
	}
	get x() {
		return this._x;
	}
	set x(value) {
		if (typeof value === "number") this._x.value = value;
		else this._x = value;
	}
	get y() {
		return this._y;
	}
	set y(value) {
		if (typeof value === "number") this._y.value = value;
		else this._y = value;
	}
	get 0() {
		return this._x;
	}
	get 1() {
		return this._y;
	}
	toArray() {
		return [this._x, this._y];
	}
	clone() {
		return new Vector2D(this._x.value, this._y.value);
	}
	set(x, y) {
		this._x.value = x;
		this._y.value = y;
		return this;
	}
	copy(v) {
		this._x.value = v.x.value;
		this._y.value = v.y.value;
		return this;
	}
	add(v) {
		return new Vector2D(this._x.value + v.x.value, this._y.value + v.y.value);
	}
	subtract(v) {
		return new Vector2D(this._x.value - v.x.value, this._y.value - v.y.value);
	}
	multiply(scalar) {
		return new Vector2D(this._x.value * scalar, this._y.value * scalar);
	}
	divide(scalar) {
		if (scalar === 0) throw new Error("Division by zero");
		return new Vector2D(this._x.value / scalar, this._y.value / scalar);
	}
	dot(v) {
		return this._x.value * v.x.value + this._y.value * v.y.value;
	}
	cross(v) {
		return this._x.value * v.y.value - this._y.value * v.x.value;
	}
	magnitude() {
		return Math.sqrt(this._x.value * this._x.value + this._y.value * this._y.value);
	}
	magnitudeSquared() {
		return this._x.value * this._x.value + this._y.value * this._y.value;
	}
	distanceTo(v) {
		const dx = this._x.value - v.x.value;
		const dy = this._y.value - v.y.value;
		return Math.sqrt(dx * dx + dy * dy);
	}
	distanceToSquared(v) {
		const dx = this._x.value - v.x.value;
		const dy = this._y.value - v.y.value;
		return dx * dx + dy * dy;
	}
	normalize() {
		const mag = this.magnitude();
		if (mag === 0) return new Vector2D(0, 0);
		return new Vector2D(this._x.value / mag, this._y.value / mag);
	}
	equals(v, tolerance = 1e-6) {
		return Math.abs(this._x.value - v.x.value) < tolerance && Math.abs(this._y.value - v.y.value) < tolerance;
	}
	lerp(v, t) {
		const clampedT = Math.max(0, Math.min(1, t));
		return new Vector2D(this._x.value + (v.x.value - this._x.value) * clampedT, this._y.value + (v.y.value - this._y.value) * clampedT);
	}
	angleTo(v) {
		const dot = this.dot(v);
		const det = this.cross(v);
		return Math.atan2(det, dot);
	}
	rotate(angle) {
		const cos = Math.cos(angle);
		const sin = Math.sin(angle);
		return new Vector2D(this._x.value * cos - this._y.value * sin, this._x.value * sin + this._y.value * cos);
	}
	projectOnto(v) {
		const scalar = this.dot(v) / v.magnitudeSquared();
		return v.multiply(scalar);
	}
	reflect(normal) {
		const normalizedNormal = normal.normalize();
		const dotProduct = this.dot(normalizedNormal);
		return this.subtract(normalizedNormal.multiply(2 * dotProduct));
	}
	clamp(min, max) {
		return new Vector2D(Math.max(min.x.value, Math.min(max.x.value, this._x.value)), Math.max(min.y.value, Math.min(max.y.value, this._y.value)));
	}
	min() {
		return Math.min(this._x.value, this._y.value);
	}
	max() {
		return Math.max(this._x.value, this._y.value);
	}
	static zero() {
		return new Vector2D(0, 0);
	}
	static one() {
		return new Vector2D(1, 1);
	}
	static unitX() {
		return new Vector2D(1, 0);
	}
	static unitY() {
		return new Vector2D(0, 1);
	}
	static fromAngle(angle, length = 1) {
		return new Vector2D(Math.cos(angle) * length, Math.sin(angle) * length);
	}
	static fromPolar(angle, radius) {
		return Vector2D.fromAngle(angle, radius);
	}
};
var vector2Ref = (x = 0, y = 0) => {
	return new Vector2D(x, y);
};
//#endregion
//#region ../../modules/projects/lur.e/src/utils/math/Operations.ts
var rectCenter = (rect) => {
	return addVector2D(rect.position, multiplyVector2D(rect.size, numberRef(.5)));
};
var rectContainsPoint = (rect, point) => {
	return operated([
		rect.position.x,
		rect.position.y,
		rect.size.x,
		rect.size.y,
		point.x,
		point.y
	], () => {
		const inX = point.x.value >= rect.position.x.value && point.x.value <= rect.position.x.value + rect.size.x.value;
		const inY = point.y.value >= rect.position.y.value && point.y.value <= rect.position.y.value + rect.size.y.value;
		return inX && inY;
	});
};
var rectIntersects = (rectA, rectB) => {
	return operated([
		rectA.position.x,
		rectA.position.y,
		rectA.size.x,
		rectA.size.y,
		rectB.position.x,
		rectB.position.y,
		rectB.size.x,
		rectB.size.y
	], () => {
		const aRight = rectA.position.x.value + rectA.size.x.value;
		const aBottom = rectA.position.y.value + rectA.size.y.value;
		const bRight = rectB.position.x.value + rectB.size.x.value;
		const bBottom = rectB.position.y.value + rectB.size.y.value;
		return !(rectA.position.x.value > bRight || aRight < rectB.position.x.value || rectA.position.y.value > bBottom || aBottom < rectB.position.y.value);
	});
};
var clampPointToRect = (point, rect) => {
	return new Vector2D(operated([
		point.x,
		rect.position.x,
		rect.size.x
	], () => Math.max(rect.position.x.value, Math.min(point.x.value, rect.position.x.value + rect.size.x.value))), operated([
		point.y,
		rect.position.y,
		rect.size.y
	], () => Math.max(rect.position.y.value, Math.min(point.y.value, rect.position.y.value + rect.size.y.value))));
};
var pointToRectDistance = (point, rect) => {
	return magnitude2D(subtractVector2D(point, clampPointToRect(point, rect)));
};
var rectArea = (rect) => {
	return operated([rect.size.x, rect.size.y], () => rect.size.x.value * rect.size.y.value);
};
var flattenRefs = (input) => {
	const refs = [];
	const traverse = (item) => {
		if (item && typeof item === "object" && "value" in item) refs.push(item);
		else if (Array.isArray(item)) item.forEach(traverse);
		else if (item && typeof item === "object") Object.values(item).forEach(traverse);
	};
	traverse(input);
	return refs;
};
var operated = (args, fn) => {
	const getCurrentValues = () => args.map((arg) => {
		if (arg && typeof arg === "object" && "value" in arg) return arg.value;
		return arg;
	});
	const initialResult = fn(...getCurrentValues());
	if (typeof initialResult === "number") {
		const result = numberRef(initialResult);
		const updateResult = () => {
			result.value = fn(...getCurrentValues());
		};
		flattenRefs(args).forEach((ref) => affected(ref, updateResult));
		return result;
	}
	let currentResult = initialResult;
	const updateResult = () => {
		currentResult = fn(...getCurrentValues());
	};
	flattenRefs(args).forEach((ref) => affected(ref, updateResult));
	return currentResult;
};
var addVector2D = (a, b) => {
	return new Vector2D(operated([a.x, b.x], () => a.x.value + b.x.value), operated([a.y, b.y], () => a.y.value + b.y.value));
};
var subtractVector2D = (a, b) => {
	return new Vector2D(operated([a.x, b.x], () => a.x.value - b.x.value), operated([a.y, b.y], () => a.y.value - b.y.value));
};
var multiplyVector2D = (a, scalar) => {
	return new Vector2D(operated([a.x, scalar], () => a.x.value * scalar.value), operated([a.y, scalar], () => a.y.value * scalar.value));
};
var magnitude2D = (a) => {
	return operated([a.x, a.y], () => Math.sqrt(a.x.value * a.x.value + a.y.value * a.y.value));
};
//#endregion
//#region ../../modules/projects/lur.e/src/lure/core/Refs.ts
var makeRef = (host, type, link, ...args) => {
	if (link == attrLink || link == handleAttribute) {
		const exists = elMap?.get?.(host)?.get?.(handleAttribute)?.get?.(args[0])?.[0];
		if (exists) return exists;
	}
	const rf = (type ?? ref)?.(null), result = link?.(host, rf, ...args);
	const linker = result && typeof result == "object" && typeof result?.unbind == "function" ? result : null;
	const targetRef = linker?.ref ?? rf;
	const usub = linker ? () => linker.unbind() : result;
	if (usub && targetRef) addToCallChain(targetRef, Symbol.dispose, usub);
	return targetRef;
};
var attrRef = (host, ...args) => makeRef(host, stringRef, attrLink, ...args);
var valueRef = (host, ...args) => makeRef(host, stringRef, valueLink, ...args);
var valueAsNumberRef = (host, ...args) => makeRef(host, numberRef, valueAsNumberLink, ...args);
var localStorageRef = (...args) => {
	if (localStorageLinkMap.has(args[0])) return localStorageLinkMap.get(args[0])?.[1];
	const link = localStorageLink;
	const rf = (stringRef ?? ref)?.(null);
	const [usub, _] = link?.(null, rf, ...args);
	if (usub && rf) addToCallChain(rf, Symbol.dispose, usub);
	return rf;
};
var sizeRef = (host, ...args) => makeRef(host, numberRef, sizeLink, ...args);
var checkedRef = (host, ...args) => makeRef(host, booleanRef, checkedLink, ...args);
var scrollRef = (host, ...args) => makeRef(host, numberRef, scrollLink, ...args);
var matchMediaRef = (...args) => makeRef(null, booleanRef, matchMediaLink, ...args);
//#endregion
//#region ../../modules/projects/lur.e/src/lure/misc/Glit.ts
var styleCacheSymbol = Symbol.for("lur.e@styleCache");
globalThis[styleCacheSymbol] ??= /* @__PURE__ */ new Map();
var styleCache = globalThis[styleCacheSymbol];
var styleElementCacheSymbol = Symbol.for("lur.e@styleElementCache");
globalThis[styleElementCacheSymbol] ??= /* @__PURE__ */ new WeakMap();
var styleElementCache = globalThis[styleElementCacheSymbol];
var propStoreSymbol = Symbol.for("lur.e@propStore");
globalThis[propStoreSymbol] ??= /* @__PURE__ */ new WeakMap();
var propStore = globalThis[propStoreSymbol];
var CSM_symbol = Symbol.for("lur.e@CSM");
globalThis[CSM_symbol] ??= /* @__PURE__ */ new WeakMap();
var CSM = globalThis[CSM_symbol];
var camelToKebab = (str) => str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
var whenBoxValid = (name) => {
	const cb = camelToKebab(name);
	if ([
		"border-box",
		"content-box",
		"device-pixel-content-box"
	].indexOf(cb) >= 0) return cb;
	return null;
};
var whenAxisValid = (name) => {
	const cb = camelToKebab(name);
	if (cb?.startsWith?.("inline")) return "inline";
	if (cb?.startsWith?.("block")) return "block";
	return null;
};
var inRenderKey = Symbol.for("@render@");
var defKeys = Symbol.for("@defKeys@");
var defaultStyle = typeof document != "undefined" ? document?.createElement?.("style") : null;
var defineSource = (source, holder, name) => {
	if (source == "attr") return attrRef.bind(null, holder, name || "");
	if (source == "media") return matchMediaRef;
	if (source == "query") return (val) => Q?.(name || val || "", holder);
	if (source == "query-shadow") return (val) => Q?.(name || val || "", holder?.shadowRoot ?? holder);
	if (source == "localStorage") return localStorageRef;
	if (source == "inline-size") return sizeRef.bind(null, holder, "inline", whenBoxValid(name) || "border-box");
	if (source == "content-box") return sizeRef.bind(null, holder, whenAxisValid(name) || "inline", "content-box");
	if (source == "block-size") return sizeRef.bind(null, holder, "block", whenBoxValid(name) || "border-box");
	if (source == "border-box") return sizeRef.bind(null, holder, whenAxisValid(name) || "inline", "border-box");
	if (source == "scroll") return scrollRef.bind(null, holder, whenAxisValid(name) || "inline");
	if (source == "device-pixel-content-box") return sizeRef.bind(null, holder, whenAxisValid(name) || "inline", "device-pixel-content-box");
	if (source == "checked") return checkedRef.bind(null, holder);
	if (source == "value") return valueRef.bind(null, holder);
	if (source == "value-as-number") return valueAsNumberRef.bind(null, holder);
	return ref;
};
if (defaultStyle) typeof document != "undefined" && document.querySelector?.("head")?.appendChild?.(defaultStyle);
var getDef = (source) => {
	if (source == "query") return "input";
	if (source == "query-shadow") return "input";
	if (source == "media") return false;
	if (source == "localStorage") return null;
	if (source == "attr") return null;
	if (source == "inline-size") return 0;
	if (source == "block-size") return 0;
	if (source == "border-box") return 0;
	if (source == "content-box") return 0;
	if (source == "scroll") return 0;
	if (source == "device-pixel-content-box") return 0;
	if (source == "checked") return false;
	if (source == "value") return "";
	if (source == "value-as-number") return 0;
	return null;
};
if (defaultStyle) defaultStyle.innerHTML = `@layer ux-preload {
        :host { display: none; }
    }`;
function withProperties(ctr) {
	const proto = ctr.prototype ?? Object.getPrototypeOf(ctr) ?? ctr;
	const $prev = proto?.$init ?? ctr?.$init;
	proto.$init = function(...args) {
		$prev?.call?.(this, ...args);
		const allDefs = {};
		let p = Object.getPrototypeOf(this) ?? this;
		while (p) {
			if (Object.hasOwn(p, defKeys)) {
				const defs = Object.assign({}, Object.getOwnPropertyDescriptors(p), p[defKeys] ?? {});
				for (const k of Object.keys(defs)) if (!(k in allDefs)) allDefs[k] = defs[k];
			}
			p = Object.getPrototypeOf(p);
		}
		for (const [key, def] of Object.entries(allDefs)) {
			const attrLive = typeof key === "string" && typeof this.getAttribute === "function" ? this.getAttribute(key) : null;
			const exists = this[key];
			if (def != null) Object.defineProperty(this, key, def);
			try {
				const preferred = attrLive != null && String(attrLive).length > 0 ? attrLive : exists;
				if (preferred != null && preferred !== "") this[key] = preferred;
			} catch (e) {}
		}
		return this;
	};
	return ctr;
}
function defineElement(name, options) {
	return function(target, _key) {
		const registry = globalThis?.customElements;
		try {
			if (!registry || !name) return target;
			if (typeof registry.get !== "function" || typeof registry.define !== "function") return target;
			const existing = registry.get(name);
			if (existing) return existing;
			registry?.define?.(name, target, options);
		} catch (e) {
			if (e?.name === "NotSupportedError" || /has already been used|already been defined/i.test(e?.message || "")) return registry?.get?.(name) ?? target;
			throw e;
		}
		return target;
	};
}
function property(options = {}) {
	const { attribute, source, name, from } = options;
	return function(target, key) {
		const attrName = typeof attribute == "string" ? attribute : name ?? key;
		if (attribute !== false && attrName != null) {
			const ctor = target.constructor;
			if (!ctor.observedAttributes) ctor.observedAttributes = [];
			if (ctor.observedAttributes.indexOf(attrName) < 0) ctor.observedAttributes.push(attrName);
		}
		if (!Object.hasOwn(target, defKeys)) target[defKeys] = {};
		target[defKeys][key] = {
			get() {
				const ROOT = this;
				const inRender = ROOT[inRenderKey];
				const sourceTarget = !from ? ROOT : from instanceof HTMLElement ? from : typeof from == "string" ? Q?.(from, ROOT) : ROOT;
				let store = propStore.get(ROOT);
				let stored = store?.get?.(key);
				if (stored == null && source != null) {
					if (!store) propStore.set(ROOT, store = /* @__PURE__ */ new Map());
					if (!store?.has?.(key)) store?.set?.(key, stored = defineSource(source, sourceTarget, name || key)?.(getDef(source)));
				}
				if (inRender) return stored;
				if (stored?.element instanceof HTMLElement) return stored?.element;
				if (source == "query" || source == "query-shadow") return null;
				return (typeof stored == "object" || typeof stored == "function") && (stored?.value != null || "value" in stored) ? stored?.value : stored;
			},
			set(newValue) {
				const ROOT = this;
				const sourceTarget = !from ? ROOT : from instanceof HTMLElement ? from : typeof from == "string" ? Q?.(from, ROOT) : ROOT;
				let store = propStore.get(ROOT);
				let stored = store?.get?.(key);
				if (stored == null && source != null) {
					if (!store) propStore.set(ROOT, store = /* @__PURE__ */ new Map());
					if (!store?.has?.(key)) {
						const initialValue = (typeof newValue == "object" || typeof newValue == "function" ? newValue?.value : null) ?? newValue ?? getDef(source);
						store?.set?.(key, stored = defineSource(source, sourceTarget, name || key)?.(initialValue));
					}
				} else if (typeof stored == "object" || typeof stored == "function") try {
					if (typeof newValue == "object" && newValue != null && (newValue?.value == null && !("value" in newValue) || typeof newValue?.value == "object" || typeof newValue?.value == "function")) Object.assign(stored, newValue?.value ?? newValue);
					else stored.value = (typeof newValue == "object" || typeof newValue == "function" ? newValue?.value : null) ?? newValue;
				} catch (e) {
					console.warn("Error setting property value:", e);
				}
			},
			enumerable: true,
			configurable: true
		};
	};
}
var adoptedStyleSheetsCache = /* @__PURE__ */ new WeakMap();
var addAdoptedSheetToElement = (bTo, sheet) => {
	let adoptedSheets = adoptedStyleSheetsCache.get(bTo);
	if (!adoptedSheets) adoptedStyleSheetsCache.set(bTo, adoptedSheets = []);
	if (sheet && adoptedSheets.indexOf(sheet) < 0) adoptedSheets.push(sheet);
	if (bTo.shadowRoot) bTo.shadowRoot.adoptedStyleSheets = [...bTo.shadowRoot.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !bTo.shadowRoot.adoptedStyleSheets?.includes(s))];
};
var loadCachedStyles = (bTo, src) => {
	if (!src) return null;
	let resolvedSrc = src;
	if (typeof src == "function") try {
		const weak = new WeakRef(bTo);
		resolvedSrc = src.call(bTo, weak);
	} catch (e) {
		console.warn("Error calling styles function:", e);
		return null;
	}
	if (resolvedSrc && typeof CSSStyleSheet != "undefined" && resolvedSrc instanceof CSSStyleSheet) {
		addAdoptedSheetToElement(bTo, resolvedSrc);
		return null;
	}
	if (resolvedSrc instanceof Promise) {
		resolvedSrc.then((result) => {
			if (result instanceof CSSStyleSheet) addAdoptedSheetToElement(bTo, result);
			else if (result != null) loadCachedStyles(bTo, result);
		}).catch((e) => {
			console.warn("Error loading adopted stylesheet:", e);
		});
		return null;
	}
	if (typeof resolvedSrc == "string" || resolvedSrc instanceof Blob || resolvedSrc instanceof File) {
		const adopted = loadAsAdopted(resolvedSrc, "");
		if (adopted) {
			let adoptedSheets = adoptedStyleSheetsCache.get(bTo);
			if (!adoptedSheets) adoptedStyleSheetsCache.set(bTo, adoptedSheets = []);
			const addAdoptedSheet = (sheet) => {
				if (sheet && adoptedSheets.indexOf(sheet) < 0) adoptedSheets.push(sheet);
				if (bTo.shadowRoot) bTo.shadowRoot.adoptedStyleSheets = [...bTo.shadowRoot.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !bTo.shadowRoot.adoptedStyleSheets?.includes(s))];
			};
			if (adopted instanceof Promise) {
				adopted.then(addAdoptedSheet).catch((e) => {
					console.warn("Error loading adopted stylesheet:", e);
				});
				return null;
			} else {
				addAdoptedSheet(adopted);
				return null;
			}
		}
	}
	const source = typeof src == "function" || typeof src == "object" ? styleElementCache : styleCache;
	const cached = source.get(src);
	let styleElement = cached?.styleElement;
	let vars = cached?.vars;
	if (!cached) {
		let styles = ``;
		let props = [];
		if (typeof resolvedSrc == "string") styles = resolvedSrc || "";
		else if (typeof resolvedSrc == "object" && resolvedSrc != null) {
			if (resolvedSrc instanceof HTMLStyleElement) styleElement = resolvedSrc;
			else {
				styles = typeof resolvedSrc.css == "string" ? resolvedSrc.css : typeof resolvedSrc == "string" ? resolvedSrc : String(resolvedSrc);
				props = resolvedSrc?.props ?? props;
				vars = resolvedSrc?.vars ?? vars;
			}
		}
		if (!styleElement && styles) styleElement = loadInlineStyle(styles, bTo, "ux-layer");
		source.set(src, {
			css: styles,
			props,
			vars,
			styleElement
		});
	}
	return styleElement;
};
var isNotExtended = (el) => {
	return !(el instanceof HTMLDivElement || el instanceof HTMLImageElement || el instanceof HTMLVideoElement || el instanceof HTMLCanvasElement) && !(el?.hasAttribute?.("is") || el?.getAttribute?.("is") != null);
};
/**
* GLitElement: Создаёт базовый класс для кастомных элементов с расширенными возможностями.
* Поддерживает все lifecycle callbacks Web Components.
* 
* @param derivate - Базовый класс для расширения (по умолчанию HTMLElement).
* @returns Конструктор расширенного класса с полной поддержкой lifecycle.
* 
* @example
* ```typescript
* // Базовое использование
* class MyElement extends GLitElement() {
*     connectedCallback() {
*         super.connectedCallback();
*         console.log('Connected!');
*     }
*     
*     render() {
*         return H`<div>Hello</div>`;
*     }
* }
* 
* // С наследованием от другого элемента
* class MyButton extends GLitElement(HTMLButtonElement) {
*     static observedAttributes = ['disabled'];
*     
*     attributeChangedCallback(name, oldVal, newVal) {
*         console.log(`${name} changed from ${oldVal} to ${newVal}`);
*     }
* }
* 
* // С декоратором
* @defineElement('my-element')
* class MyElement extends GLitElement() {
*     @property({ source: 'attr', name: 'value' })
*     value: string = '';
*     
*     disconnectedCallback() {
*         console.log('Disconnected!');
*     }
* }
* ```
*/
function GLitElement(derivate) {
	const fallbackBase = globalThis.HTMLElement ?? class {};
	const Base = derivate ?? fallbackBase;
	const cached = CSM.get(Base);
	if (cached) return cached;
	/**
	* Внутренний класс с полной реализацией lifecycle
	*/
	class GLitElementImpl extends Base {
		#shadowDOM;
		#styleElement;
		#defaultStyle;
		#initialized = false;
		styleLibs = [];
		adoptedStyleSheets = [];
		get styles() {}
		get initialAttributes() {}
		styleLayers() {
			return [];
		}
		render(_weak) {
			return document.createElement("slot");
		}
		constructor(...args) {
			super(...args);
			if (isNotExtended(this)) {
				const shadowRoot = addRoot(this.shadowRoot ?? this.createShadowRoot?.() ?? this.attachShadow({ mode: "open" }));
				const defStyle = this.#defaultStyle ??= defaultStyle?.cloneNode?.(true);
				const layersStyle = shadowRoot.querySelector(`style[data-type="ux-layer"]`);
				if (layersStyle) layersStyle.after(defStyle);
				else shadowRoot.prepend(defStyle);
			}
			this.styleLibs ??= [];
		}
		$makeLayers() {
			return `@layer ${[
				"ux-preload",
				"ux-layer",
				...this.styleLayers?.() ?? []
			].join?.(",") ?? ""};`;
		}
		onInitialize(_weak) {
			return this;
		}
		onRender(_weak) {
			return this;
		}
		getProperty(key) {
			const current = this[inRenderKey];
			this[inRenderKey] = true;
			const cp = this[key];
			this[inRenderKey] = current;
			if (!current) delete this[inRenderKey];
			return cp;
		}
		loadStyleLibrary($module) {
			const root = this.shadowRoot;
			const module = typeof $module == "function" ? $module?.(root) : $module;
			if (module instanceof HTMLStyleElement) {
				this.styleLibs?.push?.(module);
				if (this.#styleElement?.isConnected) this.#styleElement?.before?.(module);
				else this.shadowRoot?.prepend?.(module);
			} else if (module instanceof CSSStyleSheet) {
				let adoptedSheets = adoptedStyleSheetsCache.get(this);
				if (!adoptedSheets) adoptedStyleSheetsCache.set(this, adoptedSheets = []);
				if (adoptedSheets.indexOf(module) < 0) adoptedSheets.push(module);
				if (root) root.adoptedStyleSheets = [...root.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !root.adoptedStyleSheets?.includes(s))];
			} else {
				const adopted = loadAsAdopted(module, "ux-layer");
				let adoptedSheets = adoptedStyleSheetsCache.get(this);
				if (!adoptedSheets) adoptedStyleSheetsCache.set(this, adoptedSheets = []);
				const addAdoptedSheet = (sheet) => {
					if (sheet && adoptedSheets.indexOf(sheet) < 0) adoptedSheets.push(sheet);
					if (root) root.adoptedStyleSheets = [...root.adoptedStyleSheets || [], ...adoptedSheets.filter((s) => !root.adoptedStyleSheets?.includes(s))];
				};
				if (adopted instanceof Promise) adopted.then(addAdoptedSheet).catch(() => {});
				else if (adopted) addAdoptedSheet(adopted);
			}
			return this;
		}
		createShadowRoot() {
			return this.shadowRoot ?? this.attachShadow({ mode: "open" });
		}
		/**
		* Вызывается когда элемент добавлен в DOM
		*/
		connectedCallback() {
			if (super.connectedCallback) super.connectedCallback();
			const weak = new WeakRef(this);
			if (!this.#initialized) {
				this.#initialized = true;
				const shadowRoot = isNotExtended(this) ? this.createShadowRoot?.() ?? this.shadowRoot ?? this.attachShadow({ mode: "open" }) : this.shadowRoot;
				const ctor = this.constructor;
				const init = this.$init ?? ctor.prototype?.$init;
				if (typeof init === "function") init.call(this);
				const attrs = typeof this.initialAttributes == "function" ? this.initialAttributes() : this.initialAttributes;
				setAttributesIfNull(this, attrs);
				this.onInitialize?.call(this, weak);
				this[inRenderKey] = true;
				if (isNotExtended(this) && shadowRoot) {
					const rendered = this.render?.call?.(this, weak) ?? document.createElement("slot");
					const styleElement = loadCachedStyles(this, this.styles);
					if (styleElement instanceof HTMLStyleElement) this.#styleElement = styleElement;
					const elements = [
						H`<style data-type="ux-layer" prop:innerHTML=${this.$makeLayers()}></style>`,
						this.#defaultStyle,
						...this.styleLibs.map((x) => x.cloneNode?.(true)) || [],
						styleElement,
						rendered
					].filter((x) => x != null && isElement(x));
					shadowRoot.append(...elements);
					const adoptedSheets = adoptedStyleSheetsCache.get(this) || [];
					if (adoptedSheets.length > 0) shadowRoot.adoptedStyleSheets = [...adoptedSheets.filter((s) => !shadowRoot.adoptedStyleSheets?.includes(s)), .../* @__PURE__ */ new Set([...shadowRoot.adoptedStyleSheets || []])];
				}
				this.onRender?.call?.(this, weak);
				delete this[inRenderKey];
				if (shadowRoot) addRoot(shadowRoot);
			}
		}
		/**
		* Вызывается когда элемент удалён из DOM
		*/
		disconnectedCallback() {
			if (super.disconnectedCallback) super.disconnectedCallback();
		}
		/**
		* Вызывается когда элемент перемещён в новый документ
		*/
		adoptedCallback() {
			if (super.adoptedCallback) super.adoptedCallback();
		}
		/**
		* Вызывается когда наблюдаемый атрибут изменился
		*/
		attributeChangedCallback(name, oldValue, newValue) {
			if (super.attributeChangedCallback) super.attributeChangedCallback(name, oldValue, newValue);
		}
	}
	const result = withProperties(GLitElementImpl);
	CSM.set(Base, result);
	console.log("result", result);
	return result;
}
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/tasking/Manager.ts
var getBy = (tasks = [], taskId) => {
	return tasks.find((t) => taskId == t || typeof t.taskId == "string" && t.taskId?.replace?.(/^#/, "") == (typeof taskId == "string" ? taskId?.replace?.(/^#/, "") : null));
};
var taskHashUrl$1 = (taskIdOrHash) => {
	const raw = String(taskIdOrHash || "").trim();
	const hash = !raw ? "" : raw.startsWith("#") ? raw : `#${raw.replace(/^#/, "")}`;
	try {
		return `${location.pathname}${location.search}${hash}`;
	} catch {
		return hash || "#";
	}
};
var getFocused = (tasks = [], includeHash = true) => {
	return tasks.findLast((t) => t.active) ?? (includeHash ? tasks?.find?.((t) => t.taskId?.replace?.(/^#/, "") == location.hash?.replace?.(/^#/, "")) : null);
};
/**
* Register a task with the back navigation system
* Tasks have lower priority than modals/menus and can be closed via back gesture
*/
var registerTask = (task, onClose) => {
	return registerCloseable({
		id: `task-${task.taskId?.replace?.(/^#/, "") ?? task.taskId}`,
		priority: ClosePriority.TASK,
		group: "task",
		isActive: () => task.active === true,
		close: (view) => {
			task.active = false;
			return onClose?.() ?? false;
		}
	});
};
var navigationEnable = (tasks, taskEnvAction) => {
	let processingHashChange = false;
	initBackNavigation({
		preventDefaultNavigation: false,
		pushInitialState: false
	});
	if (taskEnvAction) registerCloseable({
		id: "task-env-manager",
		priority: ClosePriority.VIEW,
		isActive: () => !!getFocused(tasks, true),
		close: () => {
			const focused = getFocused(tasks, true);
			if (focused && taskEnvAction(focused)) return true;
			return false;
		}
	});
	addEvent(window, "hashchange", (ev) => {
		if (processingHashChange || getIgnoreNextPopState()) return;
		processingHashChange = true;
		try {
			const fc = getBy(tasks, location.hash);
			if (fc) fc.focus = true;
			else {
				const hash = getFocused(tasks, false)?.taskId || location.hash || "";
				if (location.hash?.trim?.()?.replace?.(/^#/, "")?.trim?.() != hash?.trim?.()?.replace?.(/^#/, "")?.trim?.()) {
					setIgnoreNextPopState(true);
					const state = history.state || {};
					history?.replaceState?.(state, "", taskHashUrl$1(hash));
				}
			}
		} finally {
			processingHashChange = false;
		}
	});
	if (!history.state?.backNav) {
		setIgnoreNextPopState(true);
		const state = history.state || {};
		history?.replaceState?.({
			...state,
			backNav: true,
			depth: history.length
		}, "", taskHashUrl$1(location.hash || ""));
		setIgnoreNextPopState(false);
	}
	return tasks;
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/tasking/Tasks.ts
/**
* Apply a task hash without dropping pathname/search.
* WHY: `history.replaceState("", "", "#env-viewer")` is fine, but bare `#…` after a
* prior root rewrite made mono Settings look like `/?view=…#env-viewer`.
*/
var taskHashUrl = (taskIdOrHash) => {
	const raw = String(taskIdOrHash || "").trim();
	const hash = !raw ? "" : raw.startsWith("#") ? raw : `#${raw.replace(/^#/, "")}`;
	try {
		return `${location.pathname}${location.search}${hash}`;
	} catch {
		return hash || "#";
	}
};
var Task = class {
	$active = false;
	$action;
	payload;
	taskId;
	list;
	_unregisterBack;
	constructor(taskId, list, state = null, payload = {}, action) {
		this.taskId = taskId;
		this.list = list;
		this.payload = payload;
		Object.assign(this, state);
		this.$action = action ?? (() => {
			if (location.hash != this.taskId && this.taskId) {
				setIgnoreNextPopState(true);
				history.replaceState("", "", taskHashUrl(this.taskId || location.hash));
				setIgnoreNextPopState(false);
				return;
			}
		});
		this.addSelfToList(list, false);
	}
	addSelfToList(list, doFocus = false) {
		if (list == null) return this;
		const has = getBy(list, this);
		if (has != this) {
			if (!has) list?.push(makeTask(this));
			else Object.assign(has, this);
		}
		this.list = list;
		if (doFocus) {
			this.focus = true;
			setIgnoreNextPopState(true);
			const focusHash = getFocused(list, false)?.taskId || this.taskId || location.hash || "";
			history.pushState({ backNav: true }, "", taskHashUrl(focusHash));
			setIgnoreNextPopState(false);
			document.dispatchEvent(new CustomEvent("task-focus", {
				detail: this,
				bubbles: true,
				composed: true,
				cancelable: true
			}));
		}
		return this;
	}
	get active() {
		return !!this.$active;
	}
	get order() {
		return this.list?.findIndex?.((t) => t == this || typeof t.taskId == "string" && t.taskId == this.taskId) ?? -1;
	}
	get focus() {
		if (!this.taskId) return false;
		const task = this.list?.findLast?.((t) => t.active) ?? null;
		if (!task) return false;
		if (task?.taskId && task?.taskId == this.taskId) return true;
		return false;
	}
	set active(activeStatus) {
		if (this != null && this?.$active != activeStatus) {
			this.$active = activeStatus;
			if (activeStatus) this._unregisterBack = registerTask(this);
			else {
				this._unregisterBack?.();
				this._unregisterBack = void 0;
			}
			document.dispatchEvent(new CustomEvent("task-focus", {
				detail: getFocused(this.list ?? [], false),
				bubbles: true,
				composed: true,
				cancelable: true
			}));
		}
	}
	set focus(activeStatus) {
		if (activeStatus && activeStatus != this.focus) {
			const index = this.order;
			if (!this.focus && index >= 0) {
				const last = this.list?.findLastIndex?.((t) => t.focus) ?? -1;
				if (index < last || last < 0) {
					if (this.list) {
						for (const task of this.list) if (task != this && task?.taskId != this.taskId) task.focus = false;
					}
					this.list?.[$triggerLess]?.(() => {
						this.list?.splice?.(index, 1);
						this.list?.push?.(makeTask(this));
					});
					document.dispatchEvent(new CustomEvent("task-focus", {
						detail: getFocused(this.list ?? [], false),
						bubbles: true,
						composed: true,
						cancelable: true
					}));
				}
				this.takeAction();
			}
		}
	}
	takeAction() {
		return this.$action?.call?.(this);
	}
	removeFromList() {
		if (!this.list) return this;
		const index = this.list.indexOf(getBy(this.list, this) ?? makeTask(this)) ?? -1;
		if (index >= 0) this.list.splice(index, 1);
		const list = this.list;
		this.list = null;
		document.dispatchEvent(new CustomEvent("task-focus", {
			detail: getFocused(list ?? [], false),
			bubbles: true,
			composed: true,
			cancelable: true
		}));
		return this;
	}
};
var makeTask = (taskId, list, state = null, payload = {}, action) => {
	if (taskId instanceof Task) return observe(taskId);
	const task = new Task(taskId, list, state, payload, action);
	return observe(task);
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/LazyEvents.ts
var hubsByTarget = /* @__PURE__ */ new WeakMap();
var keyOf = (type, options) => {
	return `${type}|c:${options?.capture ? "1" : "0"}|p:${options?.passive ? "1" : "0"}`;
};
var lazyAddEventListener = (target, type, handler, options = {}) => {
	if (!target || typeof target.addEventListener !== "function") return () => {};
	const normalized = {
		capture: Boolean(options.capture),
		passive: Boolean(options.passive)
	};
	const key = keyOf(type, normalized);
	let hubs = hubsByTarget.get(target);
	if (!hubs) {
		hubs = /* @__PURE__ */ new Map();
		hubsByTarget.set(target, hubs);
	}
	let hub = hubs.get(key);
	if (!hub) {
		const handlers = /* @__PURE__ */ new Set();
		const listener = (ev) => {
			for (const cb of Array.from(handlers)) try {
				cb(ev);
			} catch (e) {
				console.warn(e);
			}
		};
		hubs.set(key, hub = {
			handlers,
			listener,
			options: normalized
		});
		target.addEventListener(type, listener, normalized);
	}
	hub.handlers.add(handler);
	return () => {
		const hubsNow = hubsByTarget.get(target);
		const hubNow = hubsNow?.get(key);
		if (!hubNow) return;
		hubNow.handlers.delete(handler);
		if (hubNow.handlers.size > 0) return;
		target.removeEventListener(type, hubNow.listener, hubNow.options);
		hubsNow?.delete(key);
		if (hubsNow && hubsNow.size === 0) hubsByTarget.delete(target);
	};
};
var proxiedByRoot = /* @__PURE__ */ new WeakMap();
var resolveHTMLElement = (el) => {
	const resolved = el?.element ?? el;
	return resolved instanceof HTMLElement ? resolved : null;
};
var shouldApply = (when, hadMatch, hadHandled) => {
	if (!when) return false;
	if (when === "handled") return hadHandled;
	return hadMatch;
};
/**
* Proxied events:
* - Installs **one** real DOM listener on `root` (per event/options/config), but only after the first element handler registers.
* - Routes events to registered element handlers based on the composed path.
* - Can conditionally call preventDefault/stop* only when a trigger matches (or when handled).
*/
var addProxiedEvent = (root, type, options = {
	capture: true,
	passive: false
}, config = {}) => {
	const target = root;
	if (!target || typeof target.addEventListener !== "function") return (_element, _handler) => () => {};
	const normalized = {
		capture: Boolean(options.capture),
		passive: Boolean(options.passive)
	};
	const strategy = config.strategy ?? "closest";
	const key = `${type}|c:${normalized.capture ? "1" : "0"}|p:${normalized.passive ? "1" : "0"}|s:${strategy}|pd:${String(config.preventDefault ?? "")}|sp:${String(config.stopPropagation ?? "")}|sip:${String(config.stopImmediatePropagation ?? "")}`;
	let hubs = proxiedByRoot.get(target);
	if (!hubs) {
		hubs = /* @__PURE__ */ new Map();
		proxiedByRoot.set(target, hubs);
	}
	let hub = hubs.get(key);
	if (!hub) {
		const targets = /* @__PURE__ */ new Map();
		const dispatch = (ev) => {
			let hadMatch = false;
			let hadHandled = false;
			const callSet = (set) => {
				if (!set || set.size === 0) return;
				hadMatch = true;
				for (const cb of Array.from(set)) if (cb(ev)) hadHandled = true;
			};
			const path = ev?.composedPath?.();
			if (Array.isArray(path)) {
				if (strategy === "closest") for (const n of path) {
					const el = resolveHTMLElement(n);
					if (!el) continue;
					const set = targets.get(el);
					if (!set) continue;
					callSet(set);
					break;
				}
				else for (const n of path) {
					const el = resolveHTMLElement(n);
					if (!el) continue;
					callSet(targets.get(el));
				}
			} else {
				let cur = resolveHTMLElement(ev?.target);
				while (cur) {
					const set = targets.get(cur);
					if (set) {
						callSet(set);
						if (strategy === "closest") break;
					}
					const r = cur.getRootNode?.();
					cur = cur.parentElement || (r instanceof ShadowRoot ? r.host : null);
				}
			}
			if (shouldApply(config.preventDefault, hadMatch, hadHandled)) ev?.preventDefault?.();
			if (shouldApply(config.stopImmediatePropagation, hadMatch, hadHandled)) ev?.stopImmediatePropagation?.();
			if (shouldApply(config.stopPropagation, hadMatch, hadHandled)) ev?.stopPropagation?.();
		};
		hub = {
			targets,
			unbindGlobal: null,
			options: normalized,
			strategy,
			config,
			dispatch
		};
		hubs.set(key, hub);
	}
	return (element, handler) => {
		const el = resolveHTMLElement(element);
		if (!el) return () => {};
		if (hub.targets.size === 0 && !hub.unbindGlobal) hub.unbindGlobal = lazyAddEventListener(target, type, hub.dispatch, hub.options);
		let set = hub.targets.get(el);
		if (!set) {
			set = /* @__PURE__ */ new Set();
			hub.targets.set(el, set);
		}
		set.add(handler);
		return () => {
			const hubsNow = proxiedByRoot.get(target);
			const h = hubsNow?.get(key);
			if (!h) return;
			const resolved = resolveHTMLElement(element);
			if (!resolved) return;
			const s = h.targets.get(resolved);
			if (!s) return;
			s.delete(handler);
			if (s.size === 0) h.targets.delete(resolved);
			if (h.targets.size === 0) {
				h.unbindGlobal?.();
				h.unbindGlobal = null;
				hubsNow?.delete(key);
				if (hubsNow && hubsNow.size === 0) proxiedByRoot.delete(target);
			}
		};
	};
};
typeof document != "undefined" && document?.documentElement;
//#endregion
//#region ../../modules/projects/lur.e/src/design/anchor/CSSAdapter.ts
var CSSTransform = class {
	static translate2D(vector) {
		return operated([vector.x, vector.y], () => `translate(${vector.x.value}px, ${vector.y.value}px)`);
	}
	static translate3D(vector, z = numberRef(0)) {
		return operated([
			vector.x,
			vector.y,
			z
		], () => `translate3d(${vector.x.value}px, ${vector.y.value}px, ${z.value}px)`);
	}
	static scale2D(vector) {
		return operated([vector.x, vector.y], () => `scale(${vector.x.value}, ${vector.y.value})`);
	}
	static rotate(angle) {
		return operated([angle], () => `rotate(${angle.value}deg)`);
	}
	static combine(transforms) {
		return operated(transforms, () => transforms.map((t) => t.value).join(" "));
	}
	static matrix2D(matrix) {
		return operated(matrix.elements, () => `matrix(${matrix.elements.map((e) => e.value).join(", ")})`);
	}
	static matrix3D(matrix) {
		return operated(matrix.elements, () => `matrix3d(${matrix.elements.map((e) => e.value).join(", ")})`);
	}
};
var CSSPosition = class {
	static leftTop(vector) {
		return {
			left: operated([vector.x], () => `${vector.x.value}px`),
			top: operated([vector.y], () => `${vector.y.value}px`)
		};
	}
	static inset(vector) {
		return { inset: operated([vector.x, vector.y], () => `${vector.y.value}px ${vector.x.value}px`) };
	}
	static size(vector) {
		return {
			width: operated([vector.x], () => `${vector.x.value}px`),
			height: operated([vector.y], () => `${vector.y.value}px`)
		};
	}
};
var CSSBinder = class {
	static bindTransform(element, vector, animationType = "instant", options) {
		const transformValue = CSSTransform.translate2D(vector);
		return (animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring)(element, "transform", transformValue, options) ?? (() => {});
	}
	static bindPosition(element, vector, animationType = "instant", options) {
		const position = CSSPosition.leftTop(vector);
		const binder = animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring;
		const unsubLeft = binder(element, "left", position.left, options) ?? (() => {});
		const unsubTop = binder(element, "top", position.top, options) ?? (() => {});
		return () => {
			unsubLeft?.();
			unsubTop?.();
		};
	}
	static bindSize(element, vector, animationType = "instant", options) {
		const size = CSSPosition.size(vector);
		const binder = animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring;
		const unsubWidth = binder(element, "width", size.width, options) ?? (() => {});
		const unsubHeight = binder(element, "height", size.height, options) ?? (() => {});
		return () => {
			unsubWidth?.();
			unsubHeight?.();
		};
	}
	static bindWithUnit(element, property, value, unit = "px", animationType = "instant", options) {
		const cssValue = operated([value], () => `${value.value}${unit}`);
		return (animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring)(element, property, cssValue, options) ?? (() => {});
	}
	static bindVectorWithUnit(element, vector, unit = "px", animationType = "instant", options) {
		const cssValue = operated([vector.x, vector.y], () => `${vector.x.value}${unit} ${vector.y.value}${unit}`);
		return (animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring)(element, "transform", cssValue, {
			...options,
			handler: animationType === "instant" ? void 0 : (el, val) => {
				el.style.setProperty("transform", `translate(${val})`);
			}
		}) ?? (() => {});
	}
	static bindTransformMorph(element, transformProps, options = {}) {
		const transforms = {};
		if (transformProps.translate) transforms.transform = operated([transformProps.translate.x, transformProps.translate.y], () => `translate(${transformProps.translate.x.value}px, ${transformProps.translate.y.value}px)`);
		if (transformProps.scale) {
			const scaleStr = transformProps.scale instanceof Vector2D ? operated([transformProps.scale.x, transformProps.scale.y], () => `scale(${transformProps.scale.x.value}, ${transformProps.scale.y.value})`) : operated([transformProps.scale], () => `scale(${transformProps.scale.value})`);
			transforms.transform = transforms.transform ? operated([transforms.transform, scaleStr], (t, s) => `${t} ${s}`) : scaleStr;
		}
		if (transformProps.rotate) {
			const rotateStr = operated([transformProps.rotate], () => `rotate(${transformProps.rotate.value}deg)`);
			transforms.transform = transforms.transform ? operated([transforms.transform, rotateStr], (t, r) => `${t} ${r}`) : rotateStr;
		}
		if (transformProps.skew) {
			const skewStr = operated([transformProps.skew.x, transformProps.skew.y], () => `skew(${transformProps.skew.x.value}deg, ${transformProps.skew.y.value}deg)`);
			transforms.transform = transforms.transform ? operated([transforms.transform, skewStr], (t, s) => `${t} ${s}`) : skewStr;
		}
		return bindMorph(element, transforms, options);
	}
	static bindColor(element, property, color, animationType = "transition", options = {
		duration: 300,
		easing: "ease-in-out"
	}) {
		return (animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : bindTransition)(element, property, typeof color === "string" ? color : operated([color], () => `hsl(${color.value}, 70%, 50%)`), options) ?? (() => {});
	}
	static bindOpacity(element, opacity, animationType = "transition", options = {
		duration: 200,
		easing: "ease-in-out"
	}) {
		return (animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring)(element, "opacity", opacity, options) ?? (() => {});
	}
	static bindBorderRadius(element, radius, animationType = "animate", options = {
		duration: 300,
		easing: "ease-out"
	}) {
		return (animationType === "instant" ? bindWith : animationType === "animate" ? bindAnimated : animationType === "transition" ? bindTransition : bindSpring)(element, "border-radius", radius instanceof Vector2D ? operated([radius.x, radius.y], () => `${radius.x.value}px ${radius.y.value}px`) : operated([radius], () => `${radius.value}px`), options) ?? (() => {});
	}
};
var CSSCalc = class {
	static add(a, b, unit = "px") {
		return operated([a, b], () => `calc(${a.value}${unit} + ${b.value}${unit})`);
	}
	static subtract(a, b, unit = "px") {
		return operated([a, b], () => `calc(${a.value}${unit} - ${b.value}${unit})`);
	}
	static multiply(a, b) {
		return operated([a, b], () => `calc(${a.value} * ${b.value})`);
	}
	static divide(a, b) {
		return operated([a, b], () => `calc(${a.value} / ${b.value})`);
	}
	static clamp(value, min, max, unit = "px") {
		return operated([
			value,
			min,
			max
		], () => `clamp(${min.value}${unit}, ${value.value}${unit}, ${max.value}${unit})`);
	}
	static min(a, b, unit = "px") {
		return operated([a, b], () => `min(${a.value}${unit}, ${b.value}${unit})`);
	}
	static max(a, b, unit = "px") {
		return operated([a, b], () => `max(${a.value}${unit}, ${b.value}${unit})`);
	}
};
var CSSUnitUtils = class {
	static asPx(value) {
		if (typeof value === "number") return `${value || 0}px`;
		if (typeof value === "string") return value || "0px";
		return operated([value], (v) => `${v || 0}px`);
	}
	static asPercent(value) {
		if (typeof value === "number") return `${value || 0}%`;
		if (typeof value === "string") return value || "0%";
		return operated([value], (v) => `${v || 0}%`);
	}
	static asEm(value) {
		if (typeof value === "number") return `${value || 0}em`;
		if (typeof value === "string") return value || "0em";
		return operated([value], (v) => `${v || 0}em`);
	}
	static asRem(value) {
		if (typeof value === "number") return `${value || 0}rem`;
		if (typeof value === "string") return value || "0rem";
		return operated([value], (v) => `${v || 0}rem`);
	}
	static asVw(value) {
		if (typeof value === "number") return `${value || 0}vw`;
		if (typeof value === "string") return value || "0vw";
		return operated([value], (v) => `${v || 0}vw`);
	}
	static asVh(value) {
		if (typeof value === "number") return `${value || 0}vh`;
		if (typeof value === "string") return value || "0vh";
		return operated([value], (v) => `${v || 0}vh`);
	}
	static asUnit(value, unit, fallbackValue = 0) {
		if (typeof value === "number") return `${value || fallbackValue}${unit}`;
		if (typeof value === "string") return value || `${fallbackValue}${unit}`;
		return operated([value], (v) => `${v || fallbackValue}${unit}`);
	}
	static calc(expression) {
		return `calc(${expression})`;
	}
	static reactiveCalc(operands, operator) {
		return operated(operands, (...values) => {
			return `calc(${values.join(` ${operator} `)})`;
		});
	}
	static clamp(min, value, max) {
		return operated([
			typeof min === "number" || typeof min === "string" ? min : operated([min], (v) => v),
			typeof value === "number" || typeof value === "string" ? value : operated([value], (v) => v),
			typeof max === "number" || typeof max === "string" ? max : operated([max], (v) => v)
		].filter((v) => typeof v !== "string"), () => {
			return `clamp(${typeof min === "number" ? min : typeof min === "string" ? min : min.value}, ${typeof value === "number" ? value : typeof value === "string" ? value : value.value}, ${typeof max === "number" ? max : typeof max === "string" ? max : max.value})`;
		});
	}
	static max(values) {
		return operated(values.filter((v) => typeof v !== "string"), (...nums) => {
			return `max(${values.map((v) => typeof v === "number" ? v : typeof v === "string" ? v : v.value).join(", ")})`;
		});
	}
	static min(values) {
		return operated(values.filter((v) => typeof v !== "string"), (...nums) => {
			return `min(${values.map((v) => typeof v === "number" ? v : typeof v === "string" ? v : v.value).join(", ")})`;
		});
	}
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/PointerAPI.ts
var elementPointerMap = /* @__PURE__ */ new WeakMap();
if (typeof PointerEvent != "undefined");
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/controllers/Handler.ts
var handleByPointer = (cb, root = typeof document != "undefined" ? document?.documentElement : null) => {
	if (!root) return () => {};
	let pointerId = -1;
	const rst = (ev) => {
		pointerId = -1;
	};
	const tgi = (ev) => {
		if (pointerId < 0) pointerId = ev.pointerId;
		if (pointerId == ev.pointerId) cb?.(ev);
	};
	const listening = [
		addEvent(root, "pointerup", rst),
		addEvent(root, "pointercancel", rst),
		addEvent(root, "pointermove", tgi)
	];
	return () => {
		listening.forEach((ub) => ub?.());
	};
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/mixins/types.ts
function junctionToBox(a, b) {
	const left = Math.min(a.x, b.x);
	const top = Math.min(a.y, b.y);
	const right = Math.max(a.x, b.x);
	const bottom = Math.max(a.y, b.y);
	return {
		left,
		top,
		right,
		bottom,
		width: right - left,
		height: bottom - top
	};
}
var JUNCTION_SELECT_EVENTS = {
	start: "junction-select:start",
	move: "junction-select:move",
	end: "junction-select:end",
	cancel: "junction-select:cancel"
};
var JUNCTION_DRAG_EVENTS = {
	start: "junction-drag:start",
	move: "junction-drag:move",
	end: "junction-drag:end"
};
var JUNCTION_RESIZE_EVENTS = {
	start: "junction-resize:start",
	move: "junction-resize:move",
	end: "junction-resize:end"
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/mixins/Junction.ts
/**
* Junction-based DOM mixins: selection (A/B), drag, resize.
*/
var mixinDisposersSymbol = Symbol.for("dom.ts@mixinDisposers");
var mixinDisposers = globalThis[mixinDisposersSymbol] ??= /* @__PURE__ */ new WeakMap();
var pushDisposable = (host, mixinName, fn) => {
	const map = mixinDisposers.get(host) ?? /* @__PURE__ */ new Map();
	const list = map.get(mixinName) ?? [];
	list.push(fn);
	map.set(mixinName, list);
	mixinDisposers.set(host, map);
};
var runDisposers = (host, mixinName) => {
	const map = mixinDisposers.get(host);
	const list = map?.get(mixinName);
	if (!list) return;
	for (const fn of list) try {
		fn();
	} catch {}
	map.delete(mixinName);
	if (map.size === 0) mixinDisposers.delete(host);
};
var parsePxVar = (host, name) => {
	const raw = globalThis.getComputedStyle?.(host)?.getPropertyValue?.(name)?.trim?.() ?? "";
	const n = parseFloat(raw);
	return Number.isFinite(n) ? n : 0;
};
var queryHandle = (host, attr, fallback) => {
	const sel = host.getAttribute(attr)?.trim();
	if (!sel) return fallback;
	const found = host.querySelector(sel);
	return found instanceof HTMLElement ? found : fallback;
};
var JunctionSelectMixin = class extends DOMMixin {
	constructor() {
		super("ui-junction-select");
	}
	connect(wEl) {
		const host = wEl?.deref?.();
		if (!host) return this;
		const overlay = document.createElement("div");
		overlay.className = "ui-junction-select-overlay";
		overlay.setAttribute("data-junction-overlay", "");
		overlay.style.cssText = "position:absolute;pointer-events:none;z-index:9999;box-sizing:border-box;border:1px dashed color-mix(in oklab, #3794ff 70%, transparent);background:color-mix(in oklab, #3794ff 14%, transparent);display:none;inset:auto;min-width:0;min-height:0;";
		const ensurePositioned = () => {
			if ((globalThis.getComputedStyle?.(host))?.position === "static") host.style.position = "relative";
		};
		ensurePositioned();
		host.appendChild(overlay);
		let active = false;
		let a = {
			x: 0,
			y: 0
		};
		let b = {
			x: 0,
			y: 0
		};
		const localPoint = (ev) => {
			const r = host.getBoundingClientRect();
			return {
				x: ev.clientX - r.left,
				y: ev.clientY - r.top
			};
		};
		const applyOverlay = () => {
			const box = junctionToBox(a, b);
			if (box.width < 1 && box.height < 1) {
				overlay.style.display = "none";
				return;
			}
			overlay.style.display = "block";
			overlay.style.left = `${box.left}px`;
			overlay.style.top = `${box.top}px`;
			overlay.style.width = `${box.width}px`;
			overlay.style.height = `${box.height}px`;
		};
		const onDown = (ev) => {
			if (ev.button !== 0) return;
			if (ev.target?.closest?.("[data-junction-ignore-select], [data-junction-drag-handle], [data-junction-resize-handle], button, a, input, textarea, select")) return;
			if (!(ev.target === host || host.contains(ev.target))) return;
			active = true;
			a = localPoint(ev);
			b = { ...a };
			host.setPointerCapture(ev.pointerId);
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.start, {
				bubbles: true,
				detail: {
					a: { ...a },
					b: { ...b },
					host
				}
			}));
			applyOverlay();
		};
		const onMove = (ev) => {
			if (!active) return;
			b = localPoint(ev);
			applyOverlay();
			const box = junctionToBox(a, b);
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.move, {
				bubbles: true,
				detail: {
					a: { ...a },
					b: { ...b },
					box,
					host
				}
			}));
		};
		const end = (ev) => {
			if (!active) return;
			active = false;
			try {
				host.releasePointerCapture(ev.pointerId);
			} catch {}
			const box = junctionToBox(a, b);
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.end, {
				bubbles: true,
				detail: {
					a: { ...a },
					b: { ...b },
					box,
					host
				}
			}));
		};
		const onUp = (ev) => {
			if (!active) return;
			end(ev);
		};
		const onCancel = (ev) => {
			if (!active) return;
			active = false;
			overlay.style.display = "none";
			try {
				host.releasePointerCapture(ev.pointerId);
			} catch {}
			host.dispatchEvent(new CustomEvent(JUNCTION_SELECT_EVENTS.cancel, {
				bubbles: true,
				detail: { host }
			}));
		};
		pushDisposable(host, "ui-junction-select", () => {
			overlay.remove();
		});
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointerdown", onDown));
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointermove", onMove));
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointerup", onUp));
		pushDisposable(host, "ui-junction-select", addEvent(host, "pointercancel", onCancel));
		return this;
	}
	disconnect(wEl) {
		const host = wEl?.deref?.();
		if (host) runDisposers(host, "ui-junction-select");
		return this;
	}
};
var JunctionDragMixin = class extends DOMMixin {
	constructor() {
		super("ui-junction-drag");
	}
	connect(wEl) {
		const host = wEl?.deref?.();
		if (!host) return this;
		setStyleProperty(host, "--jx-drag-x", parsePxVar(host, "--jx-drag-x"));
		setStyleProperty(host, "--jx-drag-y", parsePxVar(host, "--jx-drag-y"));
		const previousTransform = host.style.transform;
		if (!host.style.transform || host.style.transform === "none") host.style.transform = "translate3d(calc(var(--jx-drag-x, 0) * 1px), calc(var(--jx-drag-y, 0) * 1px), 0)";
		const handle = queryHandle(host, "data-junction-drag-handle", host);
		let dragging = false;
		let startX = 0;
		let startY = 0;
		let baseX = 0;
		let baseY = 0;
		const onDown = (ev) => {
			if (ev.button !== 0) return;
			if (ev.target !== handle && !handle.contains(ev.target)) return;
			dragging = true;
			startX = ev.clientX;
			startY = ev.clientY;
			baseX = parsePxVar(host, "--jx-drag-x");
			baseY = parsePxVar(host, "--jx-drag-y");
			handle.setPointerCapture(ev.pointerId);
			host.dispatchEvent(new CustomEvent(JUNCTION_DRAG_EVENTS.start, {
				bubbles: true,
				detail: {
					host,
					clientX: ev.clientX,
					clientY: ev.clientY,
					baseX,
					baseY
				}
			}));
		};
		const onMove = (ev) => {
			if (!dragging) return;
			const dx = ev.clientX - startX;
			const dy = ev.clientY - startY;
			const nx = baseX + dx;
			const ny = baseY + dy;
			setStyleProperty(host, "--jx-drag-x", nx);
			setStyleProperty(host, "--jx-drag-y", ny);
			host.dispatchEvent(new CustomEvent(JUNCTION_DRAG_EVENTS.move, {
				bubbles: true,
				detail: {
					host,
					dx,
					dy,
					x: nx,
					y: ny
				}
			}));
		};
		const onUp = (ev) => {
			if (!dragging) return;
			dragging = false;
			try {
				handle.releasePointerCapture(ev.pointerId);
			} catch {}
			host.dispatchEvent(new CustomEvent(JUNCTION_DRAG_EVENTS.end, {
				bubbles: true,
				detail: {
					host,
					x: parsePxVar(host, "--jx-drag-x"),
					y: parsePxVar(host, "--jx-drag-y")
				}
			}));
		};
		pushDisposable(host, "ui-junction-drag", () => {
			host.style.transform = previousTransform;
		});
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointerdown", onDown));
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointermove", onMove));
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointerup", onUp));
		pushDisposable(host, "ui-junction-drag", addEvent(handle, "pointercancel", onUp));
		return this;
	}
	disconnect(wEl) {
		const host = wEl?.deref?.();
		if (host) runDisposers(host, "ui-junction-drag");
		return this;
	}
};
var JunctionResizeMixin = class extends DOMMixin {
	constructor() {
		super("ui-junction-resize");
	}
	connect(wEl) {
		const host = wEl?.deref?.();
		if (!host) return this;
		const handle = queryHandle(host, "data-junction-resize-handle", host);
		let resizing = false;
		let sx = 0;
		let sy = 0;
		let sw = 0;
		let sh = 0;
		const minW = Math.max(120, parseFloat(host.getAttribute("data-junction-resize-min-w") || "") || 120);
		const minH = Math.max(80, parseFloat(host.getAttribute("data-junction-resize-min-h") || "") || 80);
		const onDown = (ev) => {
			if (ev.button !== 0) return;
			if (ev.target !== handle && !handle.contains(ev.target)) return;
			resizing = true;
			sx = ev.clientX;
			sy = ev.clientY;
			sw = host.offsetWidth;
			sh = host.offsetHeight;
			handle.setPointerCapture(ev.pointerId);
			host.dispatchEvent(new CustomEvent(JUNCTION_RESIZE_EVENTS.start, {
				bubbles: true,
				detail: {
					host,
					width: sw,
					height: sh
				}
			}));
		};
		const onMove = (ev) => {
			if (!resizing) return;
			const nw = Math.max(minW, sw + (ev.clientX - sx));
			const nh = Math.max(minH, sh + (ev.clientY - sy));
			host.style.width = `${nw}px`;
			host.style.height = `${nh}px`;
			host.dispatchEvent(new CustomEvent(JUNCTION_RESIZE_EVENTS.move, {
				bubbles: true,
				detail: {
					host,
					width: nw,
					height: nh
				}
			}));
		};
		const onUp = (ev) => {
			if (!resizing) return;
			resizing = false;
			try {
				handle.releasePointerCapture(ev.pointerId);
			} catch {}
			host.dispatchEvent(new CustomEvent(JUNCTION_RESIZE_EVENTS.end, {
				bubbles: true,
				detail: {
					host,
					width: host.offsetWidth,
					height: host.offsetHeight
				}
			}));
		};
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointerdown", onDown));
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointermove", onMove));
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointerup", onUp));
		pushDisposable(host, "ui-junction-resize", addEvent(handle, "pointercancel", onUp));
		return this;
	}
	disconnect(wEl) {
		const host = wEl?.deref?.();
		if (host) runDisposers(host, "ui-junction-resize");
		return this;
	}
};
new JunctionSelectMixin();
new JunctionDragMixin();
new JunctionResizeMixin();
//#endregion
//#region ../../modules/projects/lur.e/src/design/anchor/Utils.ts
var generateAnchorId = () => {
	return "--" + Math.random().toString(36).substring(2, 15).replace(/[0-9]/g, "");
};
var getComputedZIndex = (element) => {
	if (element?.computedStyleMap) return Number(element.computedStyleMap().get("z-index")?.toString() || 0) || 0;
	else return Number(getComputedStyle(element?.element ?? element).getPropertyValue("z-index") || 0) || 0;
};
var getExistsZIndex = (element) => {
	if (!element) return 0;
	if (element?.attributeStyleMap && element.attributeStyleMap.get("z-index") != null) return Number(element.attributeStyleMap.get("z-index")?.value ?? 0) || 0;
	if (element?.style && "zIndex" in element.style && element.style.zIndex != null) return Number(element.style.zIndex || 0) || 0;
	return getComputedZIndex(element);
};
var ReactiveViewport = class {
	static width = numberRef(typeof window != "undefined" ? window?.innerWidth : 0);
	static height = numberRef(typeof window != "undefined" ? window?.innerHeight : 0);
	static init() {
		const updateSize = () => {
			this.width.value = window?.innerWidth;
			this.height.value = window?.innerHeight;
		};
		if (typeof window != "undefined") window?.addEventListener?.("resize", updateSize);
	}
	static center() {
		return {
			x: CSSCalc.divide(this.width, numberRef(2)),
			y: CSSCalc.divide(this.height, numberRef(2))
		};
	}
};
ReactiveViewport.init();
var ReactiveElementSize = class {
	element;
	size;
	observer;
	constructor(element) {
		this.element = element;
		this.size = {
			width: numberRef(element.offsetWidth),
			height: numberRef(element.offsetHeight)
		};
		this.observer = new ResizeObserver((entries) => {
			for (const entry of entries) if (entry.target === element) {
				this.size.width.value = entry.contentRect.width;
				this.size.height.value = entry.contentRect.height;
			}
		});
		this.observer.observe(element);
	}
	get width() {
		return this.size.width;
	}
	get height() {
		return this.size.height;
	}
	center() {
		return {
			x: CSSCalc.divide(this.size.width, numberRef(2)),
			y: CSSCalc.divide(this.size.height, numberRef(2))
		};
	}
	destroy() {
		this.observer.disconnect();
	}
};
//#endregion
//#region ../../modules/projects/lur.e/src/design/layers/stacking.ts
var defaultZIndexShift = (role) => role === "underlying" ? -1 : 1;
/**
* Returns numeric z-index to apply, or null to leave unset
* (order-equal when main has no explicit z-index — DOM paint order wins).
*/
function resolveLayerZIndex(main, options) {
	const role = options.role;
	const stackMode = options.stackMode ?? "shift";
	const mainZ = getExistsZIndex(main);
	const mainStyleZ = (main.style?.zIndex ?? "").trim();
	const mainIsAuto = !mainStyleZ || mainStyleZ === "auto";
	if (stackMode === "order-equal") {
		if (mainIsAuto) return null;
		return mainZ;
	}
	const shift = options.zIndexShift ?? defaultZIndexShift(role);
	return Math.max(mainIsAuto ? 0 : mainZ + shift, 0);
}
//#endregion
//#region ../../modules/projects/lur.e/src/design/anchor/CSSAnchor.ts
var registeredAnchorIds = /* @__PURE__ */ new WeakMap();
var registeredAnchors = /* @__PURE__ */ new WeakMap();
var CSSAnchor = class {
	source;
	anchorId;
	constructor(source) {
		this.source = source;
		registeredAnchors.set(source, this);
		this.anchorId = registeredAnchorIds.getOrInsert(source, generateAnchorId());
		this.source.style.setProperty("anchor-name", this.anchorId);
		this.source.style.setProperty("position-visibility", `always`);
	}
	connectElement(connect, { placement = "fill", zIndexShift = 1, inset = 0, size = "100%", transformOrigin = "50% 50%" }) {
		if (placement == "fill") {
			connect.style.setProperty("inset-block-start", `anchor(start, ${inset}px)`);
			connect.style.setProperty("inset-inline-start", `anchor(start, ${inset}px)`);
			connect.style.setProperty("inset-block-end", `anchor(end, ${inset}px)`);
			connect.style.setProperty("inset-inline-end", `anchor(end, ${inset}px)`);
			connect.style.setProperty("inline-size", `anchor-size(inline, ${size})`);
			connect.style.setProperty("block-size", `anchor-size(block, ${size})`);
			connect.style.setProperty("transform-origin", transformOrigin);
		} else if (placement == "bottom") {
			connect.style.setProperty("inset-block-start", `anchor(end, ${inset}px)`);
			connect.style.setProperty("inset-inline-start", `anchor(start, ${inset}px)`);
			connect.style.setProperty("inline-size", `anchor-size(self-inline, ${size})`);
			connect.style.setProperty("transform-origin", transformOrigin);
		} else if (placement == "top") {
			connect.style.setProperty("inset-block-end", `anchor(start, ${inset}px)`);
			connect.style.setProperty("inset-inline-start", `anchor(start, ${inset}px)`);
			connect.style.setProperty("inline-size", `anchor-size(self-inline, ${size})`);
			connect.style.setProperty("transform-origin", transformOrigin);
		} else if (placement == "left") {
			connect.style.setProperty("inset-inline-start", `anchor(end, ${inset}px)`);
			connect.style.setProperty("inset-block-start", `anchor(start, ${inset}px)`);
			connect.style.setProperty("block-size", `anchor-size(self-block, ${size})`);
			connect.style.setProperty("transform-origin", transformOrigin);
		} else if (placement == "right") {
			connect.style.setProperty("inset-inline-end", `anchor(start, ${inset}px)`);
			connect.style.setProperty("inset-block-start", `anchor(start, ${inset}px)`);
			connect.style.setProperty("block-size", `anchor-size(self-block, ${size})`);
			connect.style.setProperty("transform-origin", transformOrigin);
		} else if (placement == "center") {
			connect.style.setProperty("inset-inline-start", `anchor(center, ${inset}px)`);
			connect.style.setProperty("inset-block-start", `anchor(center, ${inset}px)`);
			connect.style.setProperty("inline-size", `anchor-size(self-inline, ${size})`);
			connect.style.setProperty("block-size", `anchor-size(self-block, ${size})`);
			connect.style.setProperty("transform-origin", transformOrigin);
		}
		connect.style.setProperty("position-visibility", `always`);
		connect.style.setProperty("position-anchor", this.anchorId);
		connect.style.setProperty("position", `absolute`);
		connect.style.setProperty("position-area", `span-all`);
		connect.style.setProperty("z-index", String(getExistsZIndex(this.source ?? connect) + zIndexShift));
		return this;
	}
	connectWithContainerQuery(connect, { placement = "fill", containerQuery = "(min-width: 768px)", fallbackPlacement = "bottom", zIndexShift = 1, inset = 0, size = "100%" }) {
		const mediaQuery = globalThis.matchMedia ? globalThis.matchMedia(containerQuery) : null;
		const updatePosition = () => {
			if (CSS.supports && CSS.supports("anchor-name", this.anchorId) && mediaQuery?.matches) this.connectElement(connect, {
				placement,
				zIndexShift,
				inset,
				size
			});
			else {
				connect.style.removeProperty("position-anchor");
				connect.style.removeProperty("anchor-name");
				connect.style.setProperty("position", "absolute");
				connect.style.setProperty("z-index", String(getExistsZIndex(this.source ?? connect) + zIndexShift));
				const sourceRect = this.source.getBoundingClientRect();
				if (fallbackPlacement === "bottom") {
					connect.style.setProperty("top", `${sourceRect.bottom + inset}px`);
					connect.style.setProperty("left", `${sourceRect.left + inset}px`);
					connect.style.setProperty("width", size);
				} else if (fallbackPlacement === "top") {
					connect.style.setProperty("bottom", `${globalThis.innerHeight - sourceRect.top + inset}px`);
					connect.style.setProperty("left", `${sourceRect.left + inset}px`);
					connect.style.setProperty("width", size);
				} else if (fallbackPlacement === "right") {
					connect.style.setProperty("top", `${sourceRect.top + inset}px`);
					connect.style.setProperty("left", `${sourceRect.right + inset}px`);
					connect.style.setProperty("height", size);
				} else if (fallbackPlacement === "left") {
					connect.style.setProperty("top", `${sourceRect.top + inset}px`);
					connect.style.setProperty("right", `${globalThis.innerWidth - sourceRect.left + inset}px`);
					connect.style.setProperty("height", size);
				}
			}
		};
		if (mediaQuery) {
			mediaQuery.addEventListener("change", updatePosition);
			updatePosition();
		}
		return () => mediaQuery?.removeEventListener("change", updatePosition);
	}
};
var makeAnchorElement = (anchorElement) => {
	return registeredAnchors.getOrInsert(anchorElement, new CSSAnchor(anchorElement));
};
//#endregion
//#region ../../modules/projects/lur.e/src/design/anchor/BBoxAnchor.ts
function boundingBoxAnchorRef(anchor, options) {
	if (!anchor) return () => {};
	const position = vector2Ref(0, 0);
	const size = vector2Ref(0, 0);
	const area = [
		position.x,
		position.y,
		size.x,
		size.y,
		numberRef(0),
		numberRef(0)
	];
	const rect = {
		position,
		size
	};
	const center = rectCenter(rect);
	const reactiveArea = rectArea(rect);
	const { root = anchor?.offsetParent ?? document.documentElement, observeResize = true, observeMutations = false } = options || {};
	const elementSize = new ReactiveElementSize(anchor);
	function updateArea() {
		const rect = anchor?.getBoundingClientRect?.() ?? {};
		position.x.value = rect?.left;
		position.y.value = rect?.top;
		size.x.value = rect?.right - rect?.left;
		size.y.value = rect?.bottom - rect?.top;
		area[4].value = rect?.right;
		area[5].value = rect?.bottom;
	}
	const listening = [
		addEvent(root, "scroll", updateArea, { capture: true }),
		addEvent(window, "resize", updateArea),
		addEvent(window, "scroll", updateArea, { capture: true })
	];
	let resizeObs;
	if (observeResize && "ResizeObserver" in window && typeof ResizeObserver != "undefined") {
		resizeObs = typeof ResizeObserver != "undefined" ? new ResizeObserver(updateArea) : void 0;
		resizeObs?.observe(anchor);
	}
	let mutationObs;
	if (observeMutations) {
		mutationObs = typeof MutationObserver != "undefined" ? new MutationObserver(updateArea) : void 0;
		mutationObs?.observe(anchor, {
			attributes: true,
			childList: true,
			subtree: true
		});
	}
	updateArea();
	function destroy() {
		listening.forEach((ub) => ub?.());
		resizeObs?.disconnect?.();
		mutationObs?.disconnect?.();
	}
	if (destroy) area.forEach((ub) => addToCallChain(ub, Symbol.dispose, destroy));
	return Object.assign(area, {
		position,
		size,
		rect,
		center,
		area: reactiveArea,
		elementSize,
		containsPoint: (point) => rectContainsPoint(rect, point),
		intersects: (otherRect) => rectIntersects(rect, otherRect),
		clampPoint: (point) => clampPointToRect(point, rect),
		distanceToPoint: (point) => pointToRectDistance(point, rect),
		bindPosition: (element) => CSSBinder.bindPosition(element, position),
		bindSize: (element) => CSSBinder.bindSize(element, size),
		bindCenter: (element) => CSSBinder.bindPosition(element, center),
		destroy: () => {
			elementSize.destroy();
			destroy();
		}
	});
}
//#endregion
//#region ../../modules/projects/lur.e/src/design/anchor/IntersectionAnchor.ts
var computeIntersectionRect = (anchor, root = document.documentElement, includeExtendedInfo = false) => {
	const rootRect = getBoundingOrientRect(root) ?? root?.getBoundingClientRect?.();
	const anchorRect = getBoundingOrientRect(anchor) ?? anchor?.getBoundingClientRect?.();
	if (!anchorRect) return includeExtendedInfo ? {
		intersection: {
			left: 0,
			top: 0,
			right: 0,
			bottom: 0,
			width: 0,
			height: 0
		},
		anchor: {
			left: 0,
			top: 0,
			width: 0,
			height: 0
		},
		root: rootRect
	} : {
		left: 0,
		top: 0,
		right: 0,
		bottom: 0,
		width: 0,
		height: 0
	};
	const intersectionLeft = Math.max(rootRect.left, anchorRect.left);
	const intersectionTop = Math.max(rootRect.top, anchorRect.top);
	const intersectionRight = Math.min(rootRect.right, anchorRect.right);
	const intersectionBottom = Math.min(rootRect.bottom, anchorRect.bottom);
	const intersection = intersectionRight > intersectionLeft && intersectionBottom > intersectionTop ? {
		left: intersectionLeft,
		top: intersectionTop,
		right: intersectionRight,
		bottom: intersectionBottom,
		width: intersectionRight - intersectionLeft,
		height: intersectionBottom - intersectionTop
	} : {
		left: 0,
		top: 0,
		right: 0,
		bottom: 0,
		width: 0,
		height: 0
	};
	if (includeExtendedInfo) return {
		intersection,
		anchor: anchorRect,
		root: rootRect,
		anchorLeft: anchorRect.left,
		anchorTop: anchorRect.top,
		anchorRight: anchorRect.right,
		anchorBottom: anchorRect.bottom,
		anchorWidth: anchorRect.width,
		anchorHeight: anchorRect.height,
		rootLeft: rootRect.left,
		rootTop: rootRect.top,
		rootWidth: rootRect.width,
		rootHeight: rootRect.height
	};
	return intersection;
};
function enhancedIntersectionBoxAnchorRef(anchor, options) {
	if (!anchor) return () => {};
	const area = [
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0),
		numberRef(0)
	];
	const { root = anchor?.offsetParent ?? document.documentElement, iterateResize = true, iterateMutations = true, iterateIntersection = true } = options || {};
	function updateArea(intersectionRect) {
		const data = intersectionRect ? {
			intersection: {
				left: intersectionRect.left,
				top: intersectionRect.top,
				right: intersectionRect.right,
				bottom: intersectionRect.bottom,
				width: intersectionRect.width,
				height: intersectionRect.height
			},
			anchor: getBoundingOrientRect(anchor) ?? anchor?.getBoundingClientRect?.(),
			root: (root instanceof HTMLElement ? getBoundingOrientRect(root) ?? root?.getBoundingClientRect?.() : null) ?? {
				left: 0,
				top: 0,
				right: globalThis.innerWidth,
				bottom: globalThis.innerHeight,
				width: globalThis.innerWidth,
				height: globalThis.innerHeight
			}
		} : computeIntersectionRect(anchor, root, true);
		if (!data.anchor) return;
		area[0].value = data.intersection.left ?? 0;
		area[1].value = data.intersection.top ?? 0;
		area[2].value = data.intersection.width ?? 0;
		area[3].value = data.intersection.height ?? 0;
		area[4].value = data.intersection.right ?? 0;
		area[5].value = data.intersection.bottom ?? 0;
		area[6].value = data.anchor.left ?? 0;
		area[7].value = data.anchor.top ?? 0;
		area[8].value = data.anchor.width ?? 0;
		area[9].value = data.anchor.height ?? 0;
		area[10].value = data.root.left ?? 0;
		area[11].value = data.root.top ?? 0;
		area[12].value = data.root.width ?? 0;
		area[13].value = data.root.height ?? 0;
	}
	let resizeObs;
	if (observeResize && "ResizeObserver" in window && typeof ResizeObserver != "undefined") {
		resizeObs = typeof ResizeObserver != "undefined" ? new ResizeObserver((entries) => {
			for (const entry of entries) updateArea(entry.contentRect);
		}) : void 0;
		resizeObs?.observe(anchor);
	}
	let mutationObs;
	if (observeMutations) {
		mutationObs = typeof MutationObserver != "undefined" ? new MutationObserver((mutations) => {
			for (const mutation of mutations) updateArea(computeIntersectionRect(anchor, root, true).intersection);
		}) : void 0;
		mutationObs?.observe(anchor, {
			attributes: true,
			childList: true,
			subtree: true
		});
	}
	let intersectionObs;
	if (observeIntersection) {
		intersectionObs = typeof IntersectionObserver != "undefined" ? new IntersectionObserver((entries) => {
			for (const entry of entries) updateArea(entry.intersectionRect);
		}, {
			root: root instanceof HTMLElement ? root : null,
			threshold: [
				0,
				.1,
				.2,
				.3,
				.4,
				.5,
				.6,
				.7,
				.8,
				.9,
				1
			],
			rootMargin: "0px"
		}) : void 0;
		intersectionObs?.observe(anchor);
	}
	const listening = [
		addEvent(root, "scroll", () => updateArea(computeIntersectionRect(anchor, root, true).intersection), { capture: true }),
		addEvent(window, "resize", () => updateArea(computeIntersectionRect(anchor, root, true).intersection)),
		addEvent(window, "scroll", () => updateArea(computeIntersectionRect(anchor, root, true).intersection), { capture: true })
	];
	updateArea(computeIntersectionRect(anchor, root, true).intersection);
	function destroy() {
		listening.forEach((ub) => ub?.());
		resizeObs?.disconnect?.();
		mutationObs?.disconnect?.();
		intersectionObs?.disconnect?.();
	}
	if (destroy) area.forEach((ub) => addToCallChain(ub, Symbol.dispose, destroy));
	return area;
}
//#endregion
//#region ../../modules/projects/lur.e/src/design/layers/AnchorOverlay.ts
var getParentOrShadowRoot = (element) => {
	if (element?.parentElement) return !(element?.parentElement instanceof DocumentFragment) ? element?.parentElement : void 0;
	return element?.host?.shadowRoot;
};
var observeDisconnect = (element, handleMutation) => {
	if (!element?.isConnected) return handleMutation();
	const observer = new MutationObserver((mutationList, observer) => {
		for (const mutation of mutationList) if (mutation.type == "childList") {
			if (Array.from(mutation?.removedNodes || []).some((node) => node === element || node?.contains?.(element))) {
				queueMicrotask(() => handleMutation(mutation));
				observer?.disconnect?.();
			}
		}
	});
	const parent = getParentOrShadowRoot(element) ?? document.documentElement;
	const observed = (parent instanceof HTMLElement ? parent : parent?.host) ?? parent;
	queueMicrotask(() => observer.observe(observed, {
		subtree: true,
		childList: true
	}));
};
var observeConnect = (element, handleMutation) => {
	if (element?.isConnected) return handleMutation();
	const observer = new MutationObserver((_mutationList, obs) => {
		if (!element?.isConnected) return;
		queueMicrotask(() => handleMutation());
		obs?.disconnect?.();
	});
	const parent = getParentOrShadowRoot(element);
	const observed = (parent instanceof HTMLElement && parent.isConnected ? parent : null) ?? document.documentElement;
	queueMicrotask(() => {
		if (element?.isConnected) {
			handleMutation();
			observer.disconnect();
			return;
		}
		observer.observe(observed, {
			subtree: true,
			childList: true
		});
	});
};
var connectWithPlacement = (anchorBinder, layer, placement, zIndexShift, inset, size, transformOrigin) => {
	if (placement === "scrollbar-x") anchorBinder.connectElement(layer, {
		placement: "bottom",
		zIndexShift,
		inset,
		size,
		transformOrigin
	});
	else if (placement === "scrollbar-y") anchorBinder.connectElement(layer, {
		placement: "right",
		zIndexShift,
		inset,
		size,
		transformOrigin
	});
	else anchorBinder.connectElement(layer, {
		placement,
		zIndexShift,
		inset,
		size,
		transformOrigin
	});
};
/**
* Insert `layer` as a sibling of `anchor` (before = underlying, after = overlaying),
* bind CSS anchor placement, and apply hybrid stacking.
*/
var appendAsLayer = (anchor, layer, self, options) => {
	const role = options?.role ?? "overlaying";
	const stackMode = options?.stackMode ?? "shift";
	const zIndexShift = options?.zIndexShift ?? defaultZIndexShift(role);
	const placement = options?.placement ?? "fill";
	const positioning = options?.positioning ?? "anchor";
	const inset = options?.inset ?? 0;
	const size = options?.size ?? "100%";
	const transformOrigin = options?.transformOrigin ?? "50% 50%";
	anchor ??= self?.children?.[0] ?? anchor;
	if (!anchor && (self?.children?.length ?? 0) < 1) {
		const fillAnchorBox = document.createElement("div");
		fillAnchorBox.classList.add("ui-window-frame-anchor-box");
		fillAnchorBox.style.position = "relative";
		fillAnchorBox.style.inlineSize = "stretch";
		fillAnchorBox.style.blockSize = "stretch";
		fillAnchorBox.style.zIndex = String(Math.max(zIndexShift - 0, 0));
		fillAnchorBox.style.pointerEvents = "none";
		fillAnchorBox.style.opacity = "1";
		fillAnchorBox.style.visibility = "visible";
		fillAnchorBox.style.backgroundColor = "transparent";
		self?.append?.(anchor = fillAnchorBox);
	}
	if (anchor == null || layer == null) return;
	const resolvedZ = resolveLayerZIndex(anchor, {
		role,
		stackMode,
		zIndexShift
	});
	if (resolvedZ == null) layer.style.removeProperty("z-index");
	else layer.style.setProperty("z-index", String(resolvedZ));
	if (role === "underlying") {
		if (!layer.style.pointerEvents) layer.style.pointerEvents = "none";
	}
	if (positioning === "contain") {
		const host = (self instanceof HTMLElement ? self : null) ?? getParentOrShadowRoot(anchor) ?? anchor.parentElement;
		if (host instanceof HTMLElement) {
			if (getComputedStyle(host).position === "static") host.style.position = "relative";
		}
		layer.style.position = "absolute";
		layer.style.inset = inset ? `${inset}px` : "0";
		layer.style.inlineSize = "auto";
		layer.style.blockSize = "auto";
		layer.style.removeProperty("position-anchor");
		layer.style.removeProperty("position-area");
		layer.style.removeProperty("anchor-name");
		observeConnect(anchor, () => {
			const parent = (self instanceof HTMLElement ? self : null) ?? getParentOrShadowRoot(anchor) ?? anchor.parentElement;
			if (role === "underlying") anchor?.before?.(layer);
			else anchor?.after?.(layer);
			observeDisconnect(parent ?? anchor, () => layer?.remove?.());
		});
		return anchor;
	}
	const anchorBinder = makeAnchorElement(anchor);
	connectWithPlacement(anchorBinder, layer, placement, zIndexShift, inset, size, transformOrigin);
	if (resolvedZ == null) layer.style.removeProperty("z-index");
	else layer.style.setProperty("z-index", String(resolvedZ));
	observeConnect(anchor, () => {
		const parent = getParentOrShadowRoot(anchor) ?? self;
		(parent instanceof HTMLElement ? parent : parent?.host)?.style?.setProperty?.("anchor-scope", anchorBinder.anchorId);
		if (role === "underlying") anchor?.before?.(layer);
		else anchor?.after?.(layer);
		observeDisconnect(parent, () => layer?.remove?.());
	});
	return anchor;
};
var appendAsUnderlying = (main, layer, options, maybeOptions) => {
	let self = null;
	let opts;
	if (options && typeof options.nodeType === "number") {
		self = options;
		opts = maybeOptions;
	} else opts = options;
	return appendAsLayer(main, layer, self, {
		placement: "fill",
		...opts,
		role: "underlying"
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/design/layers/UnderlyingShadow.ts
var UnderlyingShadow = class {
	shadowContainer;
	shadowElement;
	geometryClone;
	target;
	options;
	anchorBox;
	cleanupFunctions = [];
	constructor(options) {
		this.target = options.target;
		this.options = {
			shadowType: "drop-shadow",
			shadowColor: "rgba(0, 0, 0, 0.25)",
			shadowBlur: 8,
			shadowOffsetX: 0,
			shadowOffsetY: 4,
			spreadRadius: 0,
			opacity: 1,
			inset: 0,
			zIndexShift: -1,
			useIntersection: false,
			cloneGeometry: true,
			updateOnScroll: true,
			updateOnResize: true,
			positioning: "contain",
			...options
		};
		this.createShadowElements();
		this.setupPositioning();
		this.setupGeometryCloning();
		this.applyShadowStyle();
		this.attachToDOM();
	}
	get positioningMode() {
		return this.options.positioning ?? "contain";
	}
	get geometryHost() {
		return this.options.geometrySource ?? this.target;
	}
	createShadowElements() {
		this.shadowContainer = document.createElement("div");
		this.shadowContainer.className = ["underlying-shadow-container", this.options.className || ""].filter(Boolean).join(" ");
		this.shadowContainer.setAttribute("aria-hidden", "true");
		this.shadowContainer.style.pointerEvents = "none";
		this.shadowContainer.style.overflow = "visible";
		this.shadowContainer.style.isolation = "isolate";
		this.shadowContainer.style.contentVisibility = "visible";
		if (this.options.cloneGeometry) {
			this.geometryClone = document.createElement("div");
			this.geometryClone.className = "underlying-shadow-geometry underlying-shadow-element";
			this.geometryClone.style.width = "100%";
			this.geometryClone.style.height = "100%";
			this.geometryClone.style.position = "relative";
			this.geometryClone.style.overflow = "hidden";
			this.geometryClone.style.contentVisibility = "visible";
			this.geometryClone.style.visibility = "visible";
			this.shadowContainer.appendChild(this.geometryClone);
			this.shadowElement = this.geometryClone;
		} else {
			this.shadowElement = document.createElement("div");
			this.shadowElement.className = "underlying-shadow-element";
			this.shadowElement.style.width = "100%";
			this.shadowElement.style.height = "100%";
			this.shadowElement.style.position = "relative";
			this.shadowElement.style.overflow = "hidden";
			this.shadowElement.style.contentVisibility = "visible";
			this.shadowElement.style.visibility = "visible";
			this.shadowContainer.appendChild(this.shadowElement);
		}
	}
	setupPositioning() {
		const mode = this.positioningMode;
		if (mode === "contain") {
			this.shadowContainer.style.position = "absolute";
			return;
		}
		if (mode === "anchor") return;
		if (mode === "fixed") this.shadowContainer.style.position = "fixed";
		else this.shadowContainer.style.position = "absolute";
		if (this.options.useIntersection) {
			this.anchorBox = enhancedIntersectionBoxAnchorRef(this.target, {
				root: window,
				observeResize: this.options.updateOnResize,
				observeMutations: true,
				observeIntersection: true
			});
			bindWith(this.shadowContainer, "left", CSSUnitUtils.asPx(this.anchorBox?.[6]), handleStyleChange);
			bindWith(this.shadowContainer, "top", CSSUnitUtils.asPx(this.anchorBox?.[7]), handleStyleChange);
			bindWith(this.shadowContainer, "width", CSSUnitUtils.asPx(this.anchorBox?.[8]), handleStyleChange);
			bindWith(this.shadowContainer, "height", CSSUnitUtils.asPx(this.anchorBox?.[9]), handleStyleChange);
		} else {
			this.anchorBox = boundingBoxAnchorRef(this.target, {
				observeResize: this.options.updateOnResize,
				observeMutations: true
			});
			bindWith(this.shadowContainer, "left", CSSUnitUtils.asPx(this.anchorBox?.[0]), handleStyleChange);
			bindWith(this.shadowContainer, "top", CSSUnitUtils.asPx(this.anchorBox?.[1]), handleStyleChange);
			bindWith(this.shadowContainer, "width", CSSUnitUtils.asPx(this.anchorBox?.[2]), handleStyleChange);
			bindWith(this.shadowContainer, "height", CSSUnitUtils.asPx(this.anchorBox?.[3]), handleStyleChange);
		}
		if (this.options.inset !== 0) {
			const insetPx = CSSUnitUtils.asPx(this.options.inset);
			setProperty(this.shadowContainer, "left", `calc(var(--left) + ${insetPx})`);
			setProperty(this.shadowContainer, "top", `calc(var(--top) + ${insetPx})`);
			setProperty(this.shadowContainer, "width", `calc(var(--width) - ${2 * insetPx})`);
			setProperty(this.shadowContainer, "height", `calc(var(--height) - ${2 * insetPx})`);
		}
	}
	setupGeometryCloning() {
		if (!this.geometryClone) return;
		const cloneGeometry = () => {
			const host = this.geometryHost;
			const computedStyle = getComputedStyle(host);
			const borderRadius = computedStyle.borderRadius;
			if (borderRadius && borderRadius !== "0px") this.geometryClone.style.borderRadius = borderRadius;
			const clipPath = computedStyle.clipPath;
			if (clipPath && clipPath !== "none") this.geometryClone.style.clipPath = clipPath;
			if (computedStyle.borderShape && computedStyle.borderShape !== "none") this.geometryClone.style.borderShape = computedStyle.borderShape;
			if (computedStyle.cornerShape && computedStyle.cornerShape !== "none") this.geometryClone.style.cornerShape = computedStyle.cornerShape;
			const maskImage = computedStyle.maskImage || computedStyle.webkitMaskImage;
			if (maskImage && maskImage !== "none") {
				this.geometryClone.style.maskImage = maskImage;
				this.geometryClone.style.webkitMaskImage = maskImage;
			}
			const shape = host.getAttribute("data-shape");
			if (shape) this.geometryClone.setAttribute("data-shape", shape);
			const borderWidth = computedStyle.borderWidth;
			const borderStyle = computedStyle.borderStyle;
			if (borderWidth && borderWidth !== "0px" && borderStyle !== "none") this.geometryClone.style.border = `${borderWidth} ${borderStyle} transparent`;
			if (this.options.shadowType !== "box-shadow") this.geometryClone.style.background = "#000000";
			this.geometryClone.style.opacity = "1";
		};
		cloneGeometry();
		const observer = new MutationObserver(cloneGeometry);
		observer.observe(this.geometryHost, {
			attributes: true,
			attributeFilter: [
				"style",
				"class",
				"data-shape"
			]
		});
		this.cleanupFunctions.push(() => observer.disconnect());
	}
	applyShadowStyle() {
		const { shadowType, shadowColor, shadowBlur, shadowOffsetX, shadowOffsetY, spreadRadius, opacity } = this.options;
		if (shadowType === "drop-shadow") {
			const filterValue = `drop-shadow(${CSSUnitUtils.asPx(shadowOffsetX || 0)} ${CSSUnitUtils.asPx(shadowOffsetY || 0)} ${CSSUnitUtils.asPx(shadowBlur || 0)} ${shadowColor})`;
			this.shadowContainer.style.filter = filterValue;
			this.shadowContainer.style.opacity = opacity.toString() || "1";
			this.shadowContainer.style.boxShadow = "none";
		} else if (shadowType === "blur") {
			const filterValue = `blur(${CSSUnitUtils.asPx(shadowBlur || 0)})`;
			this.shadowContainer.style.filter = filterValue;
			this.shadowContainer.style.opacity = opacity.toString() || "1";
			if (this.geometryClone) this.geometryClone.style.backgroundColor = shadowColor;
		} else if (shadowType === "box-shadow") {
			const boxShadowValue = `${CSSUnitUtils.asPx(shadowOffsetX || 0)} ${CSSUnitUtils.asPx(shadowOffsetY || 0)} ${CSSUnitUtils.asPx(shadowBlur || 0)} ${CSSUnitUtils.asPx(spreadRadius || 0)} ${shadowColor}`;
			if (this.geometryClone) {
				this.shadowContainer.style.background = "transparent";
				this.shadowContainer.style.boxShadow = boxShadowValue;
			} else this.shadowContainer.style.boxShadow = boxShadowValue;
			this.shadowContainer.style.filter = "none";
			this.shadowContainer.style.opacity = opacity.toString() || "1";
		}
	}
	attachToDOM() {
		if (!this.shadowContainer) return;
		const mode = this.positioningMode;
		if (mode === "fixed") {
			const layer = this.shadowContainer;
			layer.style.position = "fixed";
			layer.style.pointerEvents = "none";
			const shift = this.options.zIndexShift ?? -1;
			const mainZ = Number.parseInt(getComputedStyle(this.target).zIndex || "0", 10);
			if (Number.isFinite(mainZ)) layer.style.zIndex = String(Math.max(mainZ + shift, 0));
			else layer.style.zIndex = String(Math.max(shift, 0));
			const insert = () => {
				if (!this.target.isConnected) return;
				this.target.before(layer);
			};
			observeConnect(this.target, insert);
			if (this.target.isConnected) insert();
		} else appendAsUnderlying(this.target, this.shadowContainer, {
			stackMode: "shift",
			zIndexShift: this.options.zIndexShift ?? -1,
			placement: "fill",
			positioning: mode === "contain" ? "contain" : "anchor",
			useIntersection: this.options.useIntersection
		});
		const parent = this.target.parentElement ?? document.body;
		const disconnectObserver = new MutationObserver((mutations) => {
			mutations.forEach((mutation) => {
				mutation.removedNodes.forEach((node) => {
					if (node === this.target || node.contains?.(this.target)) this.destroy();
				});
			});
		});
		if (parent) {
			disconnectObserver.observe(parent, {
				childList: true,
				subtree: true
			});
			this.cleanupFunctions.push(() => disconnectObserver.disconnect());
		}
	}
	updateOptions(newOptions) {
		Object.assign(this.options, newOptions);
		this.applyShadowStyle();
		if (newOptions.cloneGeometry !== void 0) this.setupGeometryCloning();
	}
	setVisible(visible) {
		this.shadowContainer.style.display = visible ? "block" : "none";
	}
	getShadowElement() {
		return this.shadowContainer;
	}
	destroy() {
		this.cleanupFunctions.forEach((cleanup) => cleanup());
		if (this.shadowContainer?.parentNode) this.shadowContainer.parentNode.removeChild(this.shadowContainer);
		if (this.anchorBox) this.anchorBox.forEach((anchor) => {
			if (anchor && typeof anchor[Symbol.dispose] === "function") anchor[Symbol.dispose]();
		});
	}
};
function createUnderlyingShadow(options) {
	return new UnderlyingShadow(options);
}
function createBoxShadow(target, options) {
	return createUnderlyingShadow({
		target,
		shadowType: "box-shadow",
		shadowColor: "rgba(0, 0, 0, 0.2)",
		shadowBlur: 8,
		shadowOffsetX: 0,
		shadowOffsetY: 4,
		spreadRadius: 0,
		positioning: "contain",
		...options
	});
}
/**
* Shaped under-glow for glass tiles (`backdrop-filter` on main).
* INVARIANT: `target` is the grid `.ui-ws-item` (under is a preceding sibling in the grid);
* shape/radius clones from `geometrySource` (usually `.ui-ws-item-icon`).
*/
function createShapedTileShadow(target, options) {
	return createBoxShadow(target, {
		shadowType: "blur",
		className: "ui-ws-item-icon-under",
		shadowColor: "rgba(0, 0, 0, 0.6)",
		shadowBlur: 24,
		shadowOffsetY: 6,
		shadowOffsetX: 0,
		spreadRadius: -8,
		opacity: 1,
		cloneGeometry: true,
		positioning: "anchor",
		geometrySource: options?.geometrySource ?? target.querySelector(".ui-ws-item-icon") ?? target,
		...options
	});
}
/**
* Under-shadow for fixed chrome panels (context menus) that may use backdrop-filter.
*/
function createPanelUnderShadow(target, options) {
	return createBoxShadow(target, {
		className: "cw-context-menu-under",
		shadowColor: "rgba(0, 0, 0, 0.45)",
		shadowBlur: 36,
		shadowOffsetY: 14,
		shadowOffsetX: 0,
		spreadRadius: 0,
		cloneGeometry: true,
		positioning: "fixed",
		updateOnScroll: true,
		updateOnResize: true,
		...options
	});
}
typeof document !== "undefined" && document?.documentElement && addProxiedEvent(document.documentElement, "contextmenu", {
	capture: true,
	passive: false
}, {
	strategy: "closest",
	preventDefault: "handled",
	stopImmediatePropagation: "handled"
});
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/Clipboard.ts
var CLIPBOARD_CHANNEL = "rs-clipboard";
/** Beyond this, legacy execCommand + textarea.select() can freeze the tab for seconds. */
var CLIPBOARD_LEGACY_MAX_CHARS = 256e3;
/** Hard cap — clipboard APIs and string work degrade badly above this. */
var CLIPBOARD_TEXT_MAX_CHARS = 2e6;
/** Failsafe if the browser never settles clipboard read/write. */
var CLIPBOARD_OPERATION_TIMEOUT_MS = 12e3;
var scheduleClipboardFrame = (cb) => {
	if (typeof globalThis.requestAnimationFrame === "function") {
		globalThis.requestAnimationFrame(cb);
		return;
	}
	if (typeof MessageChannel !== "undefined") {
		const channel = new MessageChannel();
		channel.port1.onmessage = () => cb();
		channel.port2.postMessage(void 0);
		return;
	}
	if (typeof setTimeout === "function") {
		setTimeout(() => cb(), 16);
		return;
	}
	if (typeof queueMicrotask === "function") {
		queueMicrotask(() => cb());
		return;
	}
	cb();
};
/**
* Convert data to string safely
*/
var toText = (data) => {
	if (data == null) return "";
	if (typeof data === "string") return data;
	try {
		return JSON.stringify(data, null, 2);
	} catch {
		return String(data);
	}
};
var raceClipboardWrite = (write, ms) => Promise.race([write.then(() => "ok").catch(() => "error"), new Promise((res) => {
	globalThis.setTimeout(() => res("timeout"), ms);
})]);
/**
* Write text to clipboard using modern API
*/
var writeText = async (text) => {
	const raw = toText(text);
	if (!raw.trim()) return {
		ok: false,
		error: "Empty content"
	};
	if (raw.length > CLIPBOARD_TEXT_MAX_CHARS) return {
		ok: false,
		error: "Content too large to copy safely"
	};
	const trimmed = raw.trim();
	return new Promise((resolve) => {
		scheduleClipboardFrame(() => {
			if (typeof document !== "undefined" && document.hasFocus && !document.hasFocus()) globalThis?.focus?.();
			const tryClipboardAPI = async () => {
				const tryWriteText = async () => {
					if (typeof navigator === "undefined" || !navigator.clipboard?.writeText) return false;
					const outcome = await raceClipboardWrite(navigator.clipboard.writeText(trimmed), CLIPBOARD_OPERATION_TIMEOUT_MS);
					if (outcome === "ok") return true;
					if (outcome === "timeout") console.warn("[Clipboard] writeText timed out");
					return false;
				};
				try {
					if (await tryWriteText()) {
						resolve({
							ok: true,
							data: trimmed,
							method: "clipboard-api"
						});
						return;
					}
				} catch (err) {
					console.warn("[Clipboard] Direct write failed:", err);
				}
				if (trimmed.length > CLIPBOARD_LEGACY_MAX_CHARS) {
					resolve({
						ok: false,
						error: "Content too large for fallback copy"
					});
					return;
				}
				try {
					if (typeof document !== "undefined") {
						const textarea = document.createElement("textarea");
						textarea.value = trimmed;
						textarea.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0;pointer-events:none;";
						document.body.appendChild(textarea);
						textarea.select();
						textarea.remove();
					}
				} catch (err) {
					console.warn("[Clipboard] Legacy execCommand failed:", err);
				}
				resolve({
					ok: false,
					error: "All clipboard methods failed"
				});
			};
			tryClipboardAPI();
		});
	});
};
/**
* Write HTML content to clipboard (with text fallback)
*/
var writeHTML = async (html, plainText) => {
	const htmlContent = html.trim();
	const textContent = (plainText ?? htmlContent).trim();
	if (!htmlContent) return {
		ok: false,
		error: "Empty content"
	};
	return new Promise((resolve) => {
		scheduleClipboardFrame(() => {
			if (typeof document !== "undefined" && document.hasFocus && !document.hasFocus()) globalThis?.focus?.();
			const tryHTMLClipboard = async () => {
				try {
					if (typeof navigator !== "undefined" && navigator.clipboard?.write) {
						const htmlBlob = new Blob([htmlContent], { type: "text/html" });
						const textBlob = new Blob([textContent], { type: "text/plain" });
						await navigator.clipboard.write([new ClipboardItem({
							"text/html": htmlBlob,
							"text/plain": textBlob
						})]);
						return resolve({
							ok: true,
							data: htmlContent,
							method: "clipboard-api"
						});
					}
				} catch (err) {
					console.warn("[Clipboard] HTML write failed:", err);
				}
				resolve(await writeText(textContent));
			};
			tryHTMLClipboard();
		});
	});
};
/**
* Write image to clipboard
*/
var writeImage = async (blob) => {
	return new Promise((resolve) => {
		scheduleClipboardFrame(async () => {
			if (typeof document !== "undefined" && document.hasFocus && !document.hasFocus()) globalThis?.focus?.();
			try {
				let imageBlob;
				if (typeof blob === "string") {
					if (blob.startsWith("data:")) imageBlob = await (await fetch(blob)).blob();
					else imageBlob = await (await fetch(blob)).blob();
				} else imageBlob = blob;
				if (typeof navigator !== "undefined" && navigator.clipboard?.write) {
					const pngBlob = imageBlob.type === "image/png" ? imageBlob : await convertToPng(imageBlob);
					await navigator.clipboard.write([new ClipboardItem({ [pngBlob.type]: pngBlob })]);
					resolve({
						ok: true,
						method: "clipboard-api"
					});
					return;
				}
			} catch (err) {
				console.warn("[Clipboard] Image write failed:", err);
			}
			resolve({
				ok: false,
				error: "Image clipboard not supported"
			});
		});
	});
};
/**
* Convert image blob to PNG
*/
var convertToPng = async (blob) => {
	return new Promise((resolve, reject) => {
		if (typeof document === "undefined") {
			reject(/* @__PURE__ */ new Error("No document context"));
			return;
		}
		const img = new Image();
		const url = URL.createObjectURL(blob);
		img.onload = () => {
			const canvas = document.createElement("canvas");
			canvas.width = img.naturalWidth;
			canvas.height = img.naturalHeight;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Canvas context failed"));
				return;
			}
			ctx.drawImage(img, 0, 0);
			canvas.toBlob((pngBlob) => {
				URL.revokeObjectURL(url);
				if (pngBlob) resolve(pngBlob);
				else reject(/* @__PURE__ */ new Error("PNG conversion failed"));
			}, "image/png");
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Image load failed"));
		};
		img.src = url;
	});
};
/**
* Unified copy function with automatic type detection
*/
var copy = async (data, options = {}) => {
	const { type, showFeedback = false, silentOnError = false } = options;
	return new Promise((resolve) => {
		scheduleClipboardFrame(async () => {
			let result;
			if (data instanceof Blob) {
				if (data.type.startsWith("image/")) result = await writeImage(data);
				else result = await writeText(await data.text());
			} else if (type === "html" || typeof data === "string" && data.trim().startsWith("<")) result = await writeHTML(String(data));
			else if (type === "image") result = await writeImage(data);
			else result = await writeText(toText(data));
			if (showFeedback && (result.ok || !silentOnError)) broadcastClipboardFeedback(result);
			resolve(result);
		});
	});
};
/**
* Broadcast clipboard feedback for toast display
*/
var broadcastClipboardFeedback = (result) => {
	try {
		const channel = new BroadcastChannel("rs-toast");
		channel.postMessage({
			type: "show-toast",
			options: {
				message: result.ok ? "Copied to clipboard" : result.error || "Copy failed",
				kind: result.ok ? "success" : "error",
				duration: 2e3
			}
		});
		channel.close();
	} catch (e) {
		console.warn("[Clipboard] Feedback broadcast failed:", e);
	}
};
/** One logical listener for rs-clipboard — multiple initClipboardReceiver calls must not stack handlers (duplicate copy() freezes UI). */
var _clipboardBroadcastChannel = null;
var _clipboardBroadcastRefCount = 0;
var _clipboardBroadcastHandler = null;
/** Serialize SW/client broadcast copies so overlapping clipboard API work does not wedge the main thread. */
var _clipboardBroadcastQueue = Promise.resolve();
/**
* Listen for clipboard operation requests
*/
var listenForClipboardRequests = () => {
	if (typeof BroadcastChannel === "undefined") return () => {};
	if (_clipboardBroadcastRefCount === 0) {
		const channel = new BroadcastChannel(CLIPBOARD_CHANNEL);
		const handler = (event) => {
			if (event.data?.type !== "copy") return;
			const opts = event.data.options || {};
			const data = event.data.data;
			_clipboardBroadcastQueue = _clipboardBroadcastQueue.then(async () => {
				try {
					await copy(data, {
						...opts,
						showFeedback: opts.showFeedback !== false,
						silentOnError: opts.silentOnError === true
					});
				} catch (err) {
					console.warn("[Clipboard] Broadcast copy failed:", err);
				}
			});
		};
		channel.addEventListener("message", handler);
		_clipboardBroadcastChannel = channel;
		_clipboardBroadcastHandler = handler;
	}
	_clipboardBroadcastRefCount++;
	return () => {
		_clipboardBroadcastRefCount--;
		if (_clipboardBroadcastRefCount <= 0) {
			const ch = _clipboardBroadcastChannel;
			const h = _clipboardBroadcastHandler;
			if (ch && h) {
				ch.removeEventListener("message", h);
				ch.close();
			}
			_clipboardBroadcastChannel = null;
			_clipboardBroadcastHandler = null;
			_clipboardBroadcastRefCount = 0;
		}
	};
};
/**
* Initialize clipboard listener for receiving copy requests
*/
var initClipboardReceiver = () => {
	return listenForClipboardRequests();
};
var collectProviders = (ev, action) => {
	const providers = /* @__PURE__ */ new Set();
	let el = ev?.target || document.activeElement || document.body;
	if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el.isContentEditable) return [];
	let current = el;
	const visited = /* @__PURE__ */ new Set();
	while (current && !visited.has(current)) {
		visited.add(current);
		if (typeof current[action] === "function") providers.add(current);
		if (current.operativeInstance && typeof current.operativeInstance[action] === "function") providers.add(current.operativeInstance);
		const shadowHost = current.shadowRoot?.host;
		if (shadowHost && shadowHost !== current) current = shadowHost;
		else {
			const rootHost = (current.getRootNode?.())?.host;
			const next = current.parentElement || rootHost;
			current = next && next !== current ? next : null;
		}
	}
	if (ev.currentTarget instanceof Node || typeof document !== "undefined") {
		const root = ev.currentTarget instanceof Node ? ev.currentTarget instanceof Document ? ev.currentTarget.body : ev.currentTarget : document.body;
		if (root) {
			const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, { acceptNode(node) {
				if (typeof node[action] === "function" || node.operativeInstance && typeof node.operativeInstance[action] === "function") return NodeFilter.FILTER_ACCEPT;
				return NodeFilter.FILTER_SKIP;
			} });
			while (walker.nextNode()) {
				const node = walker.currentNode;
				if (typeof node[action] === "function") providers.add(node);
				if (node.operativeInstance && typeof node.operativeInstance[action] === "function") providers.add(node.operativeInstance);
			}
		}
	}
	return Array.from(providers);
};
var handleClipboardEvent = (ev, type) => {
	const providers = collectProviders(ev, type);
	const handled = /* @__PURE__ */ new Set();
	for (const provider of providers) {
		if (handled.has(provider)) continue;
		const operative = provider?.operativeInstance;
		if (operative && handled.has(operative)) continue;
		handled.add(provider);
		if (operative) handled.add(operative);
		provider[type]?.(ev);
	}
};
var initialized = false;
var initGlobalClipboard = () => {
	if (typeof window === "undefined" || initialized) return;
	initialized = true;
	lazyAddEventListener(window, "copy", (ev) => handleClipboardEvent(ev, "onCopy"), {
		capture: false,
		passive: true
	});
	lazyAddEventListener(window, "cut", (ev) => handleClipboardEvent(ev, "onCut"), {
		capture: false,
		passive: true
	});
	lazyAddEventListener(window, "paste", (ev) => handleClipboardEvent(ev, "onPaste"), {
		capture: false,
		passive: false
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/DesktopStateStorage.ts
/**
* Versioned JSON persistence for the orient-layer speed dial / desktop grid.
* - Main key: canonical layout + items
* - Draft key: debounced snapshot while dragging (crash recovery if main never flushed)
*/
var DESKTOP_MAIN_KEY = "cw-oriented-desktop-layout-v1";
var DESKTOP_DRAFT_KEY = `${DESKTOP_MAIN_KEY}.draft`;
var safeGet = (key) => {
	try {
		return localStorage.getItem(key);
	} catch {
		return null;
	}
};
/**
* Decode persisted JSON. Accepts v2 envelope or legacy flat `{ columns, rows, items }`.
*/
function decodeDesktopState(raw) {
	try {
		const p = JSON.parse(raw);
		if (!p || typeof p !== "object") return null;
		const items = p.items;
		if (!Array.isArray(items)) return null;
		const columns = Math.max(0, Number(p.columns));
		const rows = Math.max(0, Number(p.rows));
		if (p.v === 2 && Number.isFinite(columns) && Number.isFinite(rows)) return {
			v: 2,
			updatedAt: String(p.updatedAt || (/* @__PURE__ */ new Date()).toISOString()),
			columns: columns || 6,
			rows: rows || 8,
			items
		};
		return {
			v: 2,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			columns: Number.isFinite(columns) && columns > 0 ? columns : 6,
			rows: Number.isFinite(rows) && rows > 0 ? rows : 8,
			items
		};
	} catch {
		return null;
	}
}
function loadDesktopRaw() {
	const main = safeGet(DESKTOP_MAIN_KEY);
	const draft = safeGet(DESKTOP_DRAFT_KEY);
	if (!main) return draft;
	if (!draft) return main;
	const mainDec = decodeDesktopState(main);
	const draftDec = decodeDesktopState(draft);
	if (!mainDec) return draft;
	if (!draftDec) return main;
	const mainT = Date.parse(mainDec.updatedAt || "");
	const draftT = Date.parse(draftDec.updatedAt || "");
	if (Number.isFinite(draftT) && Number.isFinite(mainT) && draftT > mainT) return draft;
	return main;
}
//#endregion
//#region ../../node_modules/jsox/lib/jsox.mjs
var _JSON = JSON;
/**
* JSOX container for all JSOX methods.
* @namespace
*/
var JSOX = {};
JSOX.JSOX = JSOX;
JSOX.version = "1.2.125";
var hasBigInt = typeof BigInt === "function";
var VALUE_UNDEFINED = -1;
var VALUE_UNSET = 0;
var VALUE_NULL = 1;
var VALUE_TRUE = 2;
var VALUE_FALSE = 3;
var VALUE_STRING = 4;
var VALUE_NUMBER = 5;
var VALUE_OBJECT = 6;
var VALUE_NEG_NAN = 7;
var VALUE_NAN = 8;
var VALUE_NEG_INFINITY = 9;
var VALUE_INFINITY = 10;
var VALUE_EMPTY = 12;
var VALUE_ARRAY = 13;
var knownArrayTypeNames = [
	"ab",
	"u8",
	"cu8",
	"s8",
	"u16",
	"s16",
	"u32",
	"s32",
	"u64",
	"s64",
	"f32",
	"f64"
];
var arrayToJSOX = null;
var mapToJSOX = null;
var knownArrayTypes = [
	ArrayBuffer,
	Uint8Array,
	Uint8ClampedArray,
	Int8Array,
	Uint16Array,
	Int16Array,
	Uint32Array,
	Int32Array,
	null,
	null,
	Float32Array,
	Float64Array
];
var WORD_POS_RESET = 0;
var WORD_POS_TRUE_1 = 1;
var WORD_POS_TRUE_2 = 2;
var WORD_POS_TRUE_3 = 3;
var WORD_POS_FALSE_1 = 5;
var WORD_POS_FALSE_2 = 6;
var WORD_POS_FALSE_3 = 7;
var WORD_POS_FALSE_4 = 8;
var WORD_POS_NULL_1 = 9;
var WORD_POS_NULL_2 = 10;
var WORD_POS_NULL_3 = 11;
var WORD_POS_UNDEFINED_1 = 12;
var WORD_POS_UNDEFINED_2 = 13;
var WORD_POS_UNDEFINED_3 = 14;
var WORD_POS_UNDEFINED_4 = 15;
var WORD_POS_UNDEFINED_5 = 16;
var WORD_POS_UNDEFINED_6 = 17;
var WORD_POS_UNDEFINED_7 = 18;
var WORD_POS_UNDEFINED_8 = 19;
var WORD_POS_NAN_1 = 20;
var WORD_POS_NAN_2 = 21;
var WORD_POS_INFINITY_1 = 22;
var WORD_POS_INFINITY_2 = 23;
var WORD_POS_INFINITY_3 = 24;
var WORD_POS_INFINITY_4 = 25;
var WORD_POS_INFINITY_5 = 26;
var WORD_POS_INFINITY_6 = 27;
var WORD_POS_INFINITY_7 = 28;
var WORD_POS_FIELD = 29;
var WORD_POS_AFTER_FIELD = 30;
var WORD_POS_END = 31;
var WORD_POS_AFTER_FIELD_VALUE = 32;
var CONTEXT_UNKNOWN = 0;
var CONTEXT_IN_ARRAY = 1;
var CONTEXT_OBJECT_FIELD = 2;
var CONTEXT_OBJECT_FIELD_VALUE = 3;
var CONTEXT_CLASS_FIELD = 4;
var CONTEXT_CLASS_VALUE = 5;
var CONTEXT_CLASS_FIELD_VALUE = 6;
var keywords = {
	["true"]: true,
	["false"]: false,
	["null"]: null,
	["NaN"]: NaN,
	["Infinity"]: Infinity,
	["undefined"]: void 0
};
/**
* Extend Date type with a nanosecond field.
* @constructor
* @param {Date} original_date
* @param {Number} nanoseconds in milli-seconds of Date ( 0 to 1_000_000 )
*/
var DateNS = class extends Date {
	constructor(a, b) {
		super(a);
		this.ns = b || 0;
	}
};
JSOX.DateNS = DateNS;
var contexts = [];
/**
* get a context from stack (reuse contexts)
* @internal
*/
function getContext() {
	let ctx = contexts.pop();
	if (!ctx) ctx = {
		context: CONTEXT_UNKNOWN,
		current_proto: null,
		current_class: null,
		current_class_field: 0,
		arrayType: -1,
		valueType: VALUE_UNSET,
		elements: null
	};
	return ctx;
}
/**
* return a context to the stack (reuse contexts)
* @internal
*/
function dropContext(ctx) {
	contexts.push(ctx);
}
/**
* SACK jsox compatibility; hands maps to internal C++ code in other case.
* @internal
*/
JSOX.updateContext = function() {};
var buffers = [];
function getBuffer() {
	let buf = buffers.pop();
	if (!buf) buf = {
		buf: null,
		n: 0
	};
	else buf.n = 0;
	return buf;
}
function dropBuffer(buf) {
	buffers.push(buf);
}
/**
* Provide minimal escapes for a string to be encapsulated as a JSOX string in quotes.
*
* @param {string} string 
* @returns {string}
*/
JSOX.escape = function(string) {
	let n;
	let output = "";
	if (!string) return string;
	for (n = 0; n < string.length; n++) {
		if (string[n] == "\"" || string[n] == "\\" || string[n] == "`" || string[n] == "'") output += "\\";
		output += string[n];
	}
	return output;
};
var toProtoTypes = /* @__PURE__ */ new WeakMap();
var toObjectTypes = /* @__PURE__ */ new Map();
var fromProtoTypes = /* @__PURE__ */ new Map();
var commonClasses = [];
/**
* reset JSOX parser entirely; clears all type mappings
*
* @returns {void}
*/
JSOX.reset = function() {
	toProtoTypes = /* @__PURE__ */ new WeakMap();
	toObjectTypes = /* @__PURE__ */ new Map();
	fromProtoTypes = /* @__PURE__ */ new Map();
	commonClasses = [];
};
/**
* Create a streaming parser.  Add data with parser.write(data); values that
* are found are dispatched to the callback.
*
* @param {(value:any) => void} [cb]
* @param {(this: any, key: string, value: any) => any} [reviver] 
* @returns {JSOXParser}
*/
JSOX.begin = function(cb, reviver) {
	const val = {
		name: null,
		value_type: VALUE_UNSET,
		string: "",
		contains: null,
		className: null
	};
	const pos = {
		line: 1,
		col: 1
	};
	let n = 0;
	let str;
	let localFromProtoTypes = /* @__PURE__ */ new Map();
	let word = WORD_POS_RESET, status = true, redefineClass = false, negative = false, result = null, rootObject = null, elements = void 0, context_stack = {
		first: null,
		last: null,
		saved: null,
		push(node) {
			let recover = this.saved;
			if (recover) {
				this.saved = recover.next;
				recover.node = node;
				recover.next = null;
				recover.prior = this.last;
			} else recover = {
				node,
				next: null,
				prior: this.last
			};
			if (!this.last) this.first = recover;
			else this.last.next = recover;
			this.last = recover;
			this.length++;
		},
		pop() {
			let result = this.last;
			if (!(this.last = result.prior)) this.first = null;
			result.next = this.saved;
			if (this.last) this.last.next = null;
			if (!result.next) result.first = null;
			this.saved = result;
			this.length--;
			return result.node;
		},
		length: 0
	}, classes = [], protoTypes = {}, current_proto = null, current_class = null, current_class_field = 0, arrayType = -1, parse_context = CONTEXT_UNKNOWN, comment = 0, fromHex = false, decimal = false, exponent = false, exponent_sign = false, exponent_digit = false, inQueue = {
		first: null,
		last: null,
		saved: null,
		push(node) {
			let recover = this.saved;
			if (recover) {
				this.saved = recover.next;
				recover.node = node;
				recover.next = null;
				recover.prior = this.last;
			} else recover = {
				node,
				next: null,
				prior: this.last
			};
			if (!this.last) this.first = recover;
			else this.last.next = recover;
			this.last = recover;
		},
		shift() {
			let result = this.first;
			if (!result) return null;
			if (!(this.first = result.next)) this.last = null;
			result.next = this.saved;
			this.saved = result;
			return result.node;
		},
		unshift(node) {
			let recover = this.saved;
			this.saved = recover.next;
			recover.node = node;
			recover.next = this.first;
			recover.prior = null;
			if (!this.first) this.last = recover;
			this.first = recover;
		}
	}, gatheringStringFirstChar = null, gatheringString = false, gatheringNumber = false, stringEscape = false, cr_escaped = false, unicodeWide = false, stringUnicode = false, stringHex = false, hex_char = 0, hex_char_len = 0, completed = false, date_format = false, isBigInt = false;
	function throwEndError(leader) {
		throw new Error(`${leader} at ${n} [${pos.line}:${pos.col}]`);
	}
	return {
		/**
		* Define a class that can be used to deserialize objects of this type.
		* @param {string} prototypeName 
		* @param {new ():any} o 
		* @param {(any)=>any} f 
		*/
		fromJSOX(prototypeName, o, f) {
			if (localFromProtoTypes.get(prototypeName)) throw new Error("Existing fromJSOX has been registered for prototype");
			function privateProto() {}
			if (!o) o = privateProto;
			if (o && !("constructor" in o)) throw new Error("Please pass a prototype like thing...");
			localFromProtoTypes.set(prototypeName, {
				protoCon: o.prototype.constructor,
				cb: f
			});
		},
		registerFromJSOX(prototypeName, o) {
			throw new Error("registerFromJSOX is deprecated, please update to use fromJSOX instead:" + prototypeName + o.toString());
		},
		finalError() {
			if (comment !== 0) {
				if (comment === 1) throwEndError("Comment began at end of document");
				if (comment === 2);
				if (comment === 3) throwEndError("Open comment '/*' is missing close at end of document");
				if (comment === 4) throwEndError("Incomplete '/* *' close at end of document");
			}
			if (gatheringString) throwEndError("Incomplete string");
		},
		value() {
			this.finalError();
			let r = result;
			result = void 0;
			return r;
		},
		/**
		* Reset the parser to a blank state.
		*/
		reset() {
			word = WORD_POS_RESET;
			status = true;
			if (inQueue.last) inQueue.last.next = inQueue.save;
			inQueue.save = inQueue.first;
			inQueue.first = inQueue.last = null;
			if (context_stack.last) context_stack.last.next = context_stack.save;
			context_stack.length = 0;
			context_stack.save = inQueue.first;
			context_stack.first = context_stack.last = null;
			elements = void 0;
			parse_context = CONTEXT_UNKNOWN;
			classes = [];
			protoTypes = {};
			current_proto = null;
			current_class = null;
			current_class_field = 0;
			val.value_type = VALUE_UNSET;
			val.name = null;
			val.string = "";
			val.className = null;
			pos.line = 1;
			pos.col = 1;
			negative = false;
			comment = 0;
			completed = false;
			gatheringString = false;
			stringEscape = false;
			cr_escaped = false;
			date_format = false;
		},
		usePrototype(className, protoType) {
			protoTypes[className] = protoType;
		},
		/**
		* Add input to the parser to get parsed.
		* @param {string} msg 
		*/
		write(msg) {
			let retcode;
			if (typeof msg !== "string" && typeof msg !== "undefined") msg = String(msg);
			if (!status) throw new Error("Parser is still in an error state, please reset before resuming");
			for (retcode = this._write(msg, false); retcode > 0; retcode = this._write()) {
				if (typeof reviver === "function") (function walk(holder, key) {
					let k, v, value = holder[key];
					if (value && typeof value === "object") {
						for (k in value) if (Object.prototype.hasOwnProperty.call(value, k)) {
							v = walk(value, k);
							if (v !== void 0) value[k] = v;
							else delete value[k];
						}
					}
					return reviver.call(holder, key, value);
				})({ "": result }, "");
				result = cb(result);
				if (retcode < 2) break;
			}
		},
		/**
		* Parse a string and return the result.
		* @template T
		* @param {string} msg
		* @param {(key:string,value:any)=>any} [reviver]
		* @returns {T}
		*/
		parse(msg, reviver) {
			if (typeof msg !== "string") msg = String(msg);
			this.reset();
			const writeResult = this._write(msg, true);
			if (writeResult > 0) {
				if (writeResult > 1) {}
				let result = this.value();
				if ("undefined" === typeof result && writeResult > 1) throw new Error("Pending value could not complete");
				result = typeof reviver === "function" ? function walk(holder, key) {
					let k, v, value = holder[key];
					if (value && typeof value === "object") {
						for (k in value) if (Object.prototype.hasOwnProperty.call(value, k)) {
							v = walk(value, k);
							if (v !== void 0) value[k] = v;
							else delete value[k];
						}
					}
					return reviver.call(holder, key, value);
				}({ "": result }, "") : result;
				return result;
			}
			this.finalError();
		},
		_write(msg, complete_at_end) {
			let cInt;
			let input;
			let buf;
			let retval = 0;
			function throwError(leader, c) {
				throw new Error(`${leader} '${String.fromCodePoint(c)}' unexpected at ${n} (near '${buf.substr(n > 4 ? n - 4 : 0, n > 4 ? 3 : n - 1)}[${String.fromCodePoint(c)}]${buf.substr(n, 10)}') [${pos.line}:${pos.col}]`);
			}
			function RESET_VAL() {
				val.value_type = VALUE_UNSET;
				val.string = "";
				val.contains = null;
			}
			function convertValue() {
				let fp = null;
				switch (val.value_type) {
					case VALUE_NUMBER:
						if ((val.string.length > 13 || val.string.length == 13 && val[0] > "2") && !date_format && !exponent_digit && !exponent_sign && !decimal) isBigInt = true;
						if (isBigInt) {
							if (hasBigInt) return BigInt(val.string);
							else throw new Error("no builtin BigInt()", 0);
						}
						if (date_format) {
							const r = val.string.match(/\.(\d\d\d\d*)/);
							const frac = r ? r[1] : null;
							if (!frac || frac.length < 4) {
								const r = new Date(val.string);
								if (isNaN(r.getTime())) throwError("Bad Date format", cInt);
								return r;
							} else {
								let ns = frac.substr(3);
								while (ns.length < 6) ns = ns + "0";
								const r = new DateNS(val.string, Number(ns));
								if (isNaN(r.getTime())) throwError("Bad DateNS format" + r + r.getTime(), cInt);
								return r;
							}
						}
						return (negative ? -1 : 1) * Number(val.string);
					case VALUE_STRING:
						if (val.className) {
							fp = localFromProtoTypes.get(val.className);
							if (!fp) fp = fromProtoTypes.get(val.className);
							if (fp && fp.cb) {
								val.className = null;
								return fp.cb.call(val.string);
							} else throw new Error("Double string error, no constructor for: new " + val.className + "(" + val.string + ")");
						}
						return val.string;
					case VALUE_TRUE: return true;
					case VALUE_FALSE: return false;
					case VALUE_NEG_NAN: return NaN;
					case VALUE_NAN: return NaN;
					case VALUE_NEG_INFINITY: return -Infinity;
					case VALUE_INFINITY: return Infinity;
					case VALUE_NULL: return null;
					case VALUE_UNDEFINED: return;
					case VALUE_EMPTY: return;
					case VALUE_OBJECT:
						if (val.className) {
							fp = localFromProtoTypes.get(val.className);
							if (!fp) fp = fromProtoTypes.get(val.className);
							val.className = null;
							if (fp && fp.cb) return val.contains = fp.cb.call(val.contains);
						}
						return val.contains;
					case VALUE_ARRAY:
						if (arrayType >= 0) {
							let ab;
							if (val.contains.length) ab = DecodeBase64(val.contains[0]);
							else ab = DecodeBase64(val.string);
							if (arrayType === 0) {
								arrayType = -1;
								return ab;
							} else {
								const newab = new knownArrayTypes[arrayType](ab);
								arrayType = -1;
								return newab;
							}
						} else if (arrayType === -2) {
							let obj = rootObject;
							let lvl;
							const pathlen = val.contains.length;
							for (lvl = 0; lvl < pathlen; lvl++) {
								const idx = val.contains[lvl];
								let nextObj = obj[idx];
								if (!nextObj) {
									let ctx = context_stack.first;
									let p = 0;
									while (ctx && p < pathlen && p < context_stack.length) {
										const thisKey = val.contains[p];
										if (!ctx.next || thisKey !== ctx.next.node.name) break;
										if (ctx.next) {
											if ("number" === typeof thisKey) {
												const actualObject = ctx.next.node.elements;
												if (actualObject && thisKey >= actualObject.length) {
													if (p === context_stack.length - 1) {
														console.log("This is actually at the current object so use that", p, val.contains, elements);
														nextObj = elements;
														p++;
														ctx = ctx.next;
														break;
													} else {
														if (ctx.next.next && thisKey === actualObject.length) {
															nextObj = ctx.next.next.node.elements;
															ctx = ctx.next;
															p++;
															obj = nextObj;
															continue;
														}
														nextObj = elements;
														p++;
														break;
													}
												}
											} else if (thisKey !== ctx.next.node.name) {
												nextObj = ctx.next.node.elements[thisKey];
												lvl = p;
												break;
											} else if (ctx.next.next) nextObj = ctx.next.next.node.elements;
											else nextObj = elements;
										} else nextObj = nextObj[thisKey];
										ctx = ctx.next;
										p++;
									}
									if (p < pathlen) lvl = p - 1;
									else lvl = p;
								}
								if ("object" === typeof nextObj && !nextObj) throw new Error("Path did not resolve properly:" + val.contains + " at " + idx + "(" + lvl + ")");
								obj = nextObj;
							}
							arrayType = -3;
							return obj;
						}
						if (val.className) {
							fp = localFromProtoTypes.get(val.className);
							if (!fp) fp = fromProtoTypes.get(val.className);
							val.className = null;
							if (fp && fp.cb) return fp.cb.call(val.contains);
						}
						return val.contains;
					default: console.log("Unhandled value conversion.", val);
				}
			}
			function arrayPush() {
				if (arrayType == -3) {
					if (val.value_type === VALUE_OBJECT) elements.push(val.contains);
					arrayType = -1;
					return;
				}
				switch (val.value_type) {
					case VALUE_EMPTY:
						elements.push(void 0);
						delete elements[elements.length - 1];
						break;
					default: elements.push(convertValue());
				}
				RESET_VAL();
			}
			function objectPush() {
				if (arrayType === -3 && val.value_type === VALUE_ARRAY) {
					RESET_VAL();
					arrayType = -1;
					return;
				}
				if (val.value_type === VALUE_EMPTY) return;
				if (!val.name && current_class) val.name = current_class.fields[current_class_field++];
				let value = convertValue();
				if (current_proto && current_proto.protoDef && current_proto.protoDef.cb) {
					value = current_proto.protoDef.cb.call(elements, val.name, value);
					if (value) elements[val.name] = value;
				} else elements[val.name] = value;
				RESET_VAL();
			}
			function recoverIdent(cInt) {
				if (word !== WORD_POS_RESET) {
					if (negative) throwError("Negative outside of quotes, being converted to a string (would lose count of leading '-' characters)", cInt);
					switch (word) {
						case WORD_POS_END:
							switch (val.value_type) {
								case VALUE_TRUE:
									val.string += "true";
									break;
								case VALUE_FALSE:
									val.string += "false";
									break;
								case VALUE_NULL:
									val.string += "null";
									break;
								case VALUE_INFINITY:
									val.string += "Infinity";
									break;
								case VALUE_NEG_INFINITY:
									val.string += "-Infinity";
									throwError("Negative outside of quotes, being converted to a string", cInt);
									break;
								case VALUE_NAN:
									val.string += "NaN";
									break;
								case VALUE_NEG_NAN:
									val.string += "-NaN";
									throwError("Negative outside of quotes, being converted to a string", cInt);
									break;
								case VALUE_UNDEFINED:
									val.string += "undefined";
									break;
								case VALUE_STRING: break;
								case VALUE_UNSET: break;
								default: console.log("Value of type " + val.value_type + " is not restored...");
							}
							break;
						case WORD_POS_TRUE_1:
							val.string += "t";
							break;
						case WORD_POS_TRUE_2:
							val.string += "tr";
							break;
						case WORD_POS_TRUE_3:
							val.string += "tru";
							break;
						case WORD_POS_FALSE_1:
							val.string += "f";
							break;
						case WORD_POS_FALSE_2:
							val.string += "fa";
							break;
						case WORD_POS_FALSE_3:
							val.string += "fal";
							break;
						case WORD_POS_FALSE_4:
							val.string += "fals";
							break;
						case WORD_POS_NULL_1:
							val.string += "n";
							break;
						case WORD_POS_NULL_2:
							val.string += "nu";
							break;
						case WORD_POS_NULL_3:
							val.string += "nul";
							break;
						case WORD_POS_UNDEFINED_1:
							val.string += "u";
							break;
						case WORD_POS_UNDEFINED_2:
							val.string += "un";
							break;
						case WORD_POS_UNDEFINED_3:
							val.string += "und";
							break;
						case WORD_POS_UNDEFINED_4:
							val.string += "unde";
							break;
						case WORD_POS_UNDEFINED_5:
							val.string += "undef";
							break;
						case WORD_POS_UNDEFINED_6:
							val.string += "undefi";
							break;
						case WORD_POS_UNDEFINED_7:
							val.string += "undefin";
							break;
						case WORD_POS_UNDEFINED_8:
							val.string += "undefine";
							break;
						case WORD_POS_NAN_1:
							val.string += "N";
							break;
						case WORD_POS_NAN_2:
							val.string += "Na";
							break;
						case WORD_POS_INFINITY_1:
							val.string += "I";
							break;
						case WORD_POS_INFINITY_2:
							val.string += "In";
							break;
						case WORD_POS_INFINITY_3:
							val.string += "Inf";
							break;
						case WORD_POS_INFINITY_4:
							val.string += "Infi";
							break;
						case WORD_POS_INFINITY_5:
							val.string += "Infin";
							break;
						case WORD_POS_INFINITY_6:
							val.string += "Infini";
							break;
						case WORD_POS_INFINITY_7:
							val.string += "Infinit";
							break;
						case WORD_POS_RESET: break;
						case WORD_POS_FIELD: break;
						case WORD_POS_AFTER_FIELD: break;
						case WORD_POS_AFTER_FIELD_VALUE: throwError("String-keyword recovery fail (after whitespace)", cInt);
					}
					val.value_type = VALUE_STRING;
					if (word < WORD_POS_FIELD) word = WORD_POS_END;
				} else {
					word = WORD_POS_END;
					val.value_type = VALUE_STRING;
				}
				if (cInt == 123) openObject();
				else if (cInt == 91) openArray();
				else if (cInt == 44) {} else {
					if (cInt == 32 || cInt == 13 || cInt == 10 || cInt == 9 || cInt == 65279 || cInt == 8232 || cInt == 8233) return;
					if (cInt == 44 || cInt == 125 || cInt == 93 || cInt == 58);
					else val.string += str;
				}
			}
			function gatherString(start_c) {
				let retval = 0;
				while (retval == 0 && n < buf.length) {
					str = buf.charAt(n);
					let cInt = buf.codePointAt(n++);
					if (cInt >= 65536) {
						str += buf.charAt(n);
						n++;
					}
					pos.col++;
					if (cInt == start_c) {
						if (stringEscape) {
							if (stringHex) throwError("Incomplete hexidecimal sequence", cInt);
							else if (stringUnicode) throwError("Incomplete long unicode sequence", cInt);
							else if (unicodeWide) throwError("Incomplete unicode sequence", cInt);
							if (cr_escaped) {
								cr_escaped = false;
								retval = 1;
							} else val.string += str;
							stringEscape = false;
						} else retval = 1;
					} else if (stringEscape) {
						if (unicodeWide) {
							if (cInt == 125) {
								val.string += String.fromCodePoint(hex_char);
								unicodeWide = false;
								stringUnicode = false;
								stringEscape = false;
								continue;
							}
							hex_char *= 16;
							if (cInt >= 48 && cInt <= 57) hex_char += cInt - 48;
							else if (cInt >= 65 && cInt <= 70) hex_char += cInt - 65 + 10;
							else if (cInt >= 97 && cInt <= 102) hex_char += cInt - 97 + 10;
							else {
								throwError("(escaped character, parsing hex of \\u)", cInt);
								retval = -1;
								unicodeWide = false;
								stringEscape = false;
								continue;
							}
							continue;
						} else if (stringHex || stringUnicode) {
							if (hex_char_len === 0 && cInt === 123) {
								unicodeWide = true;
								continue;
							}
							if (hex_char_len < 2 || stringUnicode && hex_char_len < 4) {
								hex_char *= 16;
								if (cInt >= 48 && cInt <= 57) hex_char += cInt - 48;
								else if (cInt >= 65 && cInt <= 70) hex_char += cInt - 65 + 10;
								else if (cInt >= 97 && cInt <= 102) hex_char += cInt - 97 + 10;
								else {
									throwError(stringUnicode ? "(escaped character, parsing hex of \\u)" : "(escaped character, parsing hex of \\x)", cInt);
									retval = -1;
									stringHex = false;
									stringEscape = false;
									continue;
								}
								hex_char_len++;
								if (stringUnicode) {
									if (hex_char_len == 4) {
										val.string += String.fromCodePoint(hex_char);
										stringUnicode = false;
										stringEscape = false;
									}
								} else if (hex_char_len == 2) {
									val.string += String.fromCodePoint(hex_char);
									stringHex = false;
									stringEscape = false;
								}
								continue;
							}
						}
						switch (cInt) {
							case 13:
								cr_escaped = true;
								pos.col = 1;
								continue;
							case 8232:
							case 8233: pos.col = 1;
							case 10:
								if (!cr_escaped) pos.col = 1;
								else cr_escaped = false;
								pos.line++;
								break;
							case 116:
								val.string += "	";
								break;
							case 98:
								val.string += "\b";
								break;
							case 110:
								val.string += "\n";
								break;
							case 114:
								val.string += "\r";
								break;
							case 102:
								val.string += "\f";
								break;
							case 118:
								val.string += "\v";
								break;
							case 48:
								val.string += "\0";
								break;
							case 120:
								stringHex = true;
								hex_char_len = 0;
								hex_char = 0;
								continue;
							case 117:
								stringUnicode = true;
								hex_char_len = 0;
								hex_char = 0;
								continue;
							default: val.string += str;
						}
						stringEscape = false;
					} else if (cInt === 92) {
						if (stringEscape) {
							val.string += "\\";
							stringEscape = false;
						} else {
							stringEscape = true;
							hex_char = 0;
							hex_char_len = 0;
						}
					} else {
						if (cr_escaped) {
							cr_escaped = false;
							pos.line++;
							pos.col = 2;
						}
						val.string += str;
					}
				}
				return retval;
			}
			function collectNumber() {
				let _n;
				while ((_n = n) < buf.length) {
					str = buf.charAt(_n);
					let cInt = buf.codePointAt(n++);
					if (cInt >= 256) {
						pos.col -= n - _n;
						n = _n;
						break;
					} else {
						if (cInt == 95) continue;
						pos.col++;
						if (cInt >= 48 && cInt <= 57) {
							if (exponent) exponent_digit = true;
							val.string += str;
						} else if (cInt == 45 || cInt == 43) {
							if (val.string.length == 0 || exponent && !exponent_sign && !exponent_digit) {
								if (cInt == 45 && !exponent) negative = !negative;
								val.string += str;
								exponent_sign = true;
							} else {
								if (negative) {
									val.string = "-" + val.string;
									negative = false;
								}
								val.string += str;
								date_format = true;
							}
						} else if (cInt == 78) {
							if (word == WORD_POS_RESET) {
								gatheringNumber = false;
								word = WORD_POS_NAN_1;
								return;
							}
							throwError("fault while parsing number;", cInt);
							break;
						} else if (cInt == 73) {
							if (word == WORD_POS_RESET) {
								gatheringNumber = false;
								word = WORD_POS_INFINITY_1;
								return;
							}
							throwError("fault while parsing number;", cInt);
							break;
						} else if (cInt == 58 && date_format) {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						} else if (cInt == 84 && date_format) {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						} else if (cInt == 90 && date_format) {
							if (negative) {
								val.string = "-" + val.string;
								negative = false;
							}
							val.string += str;
							date_format = true;
						} else if (cInt == 46) {
							if (!decimal && !fromHex && !exponent) {
								val.string += str;
								decimal = true;
							} else {
								status = false;
								throwError("fault while parsing number;", cInt);
								break;
							}
						} else if (cInt == 110) {
							isBigInt = true;
							break;
						} else if (fromHex && (cInt >= 95 && cInt <= 102 || cInt >= 65 && cInt <= 70)) val.string += str;
						else if (cInt == 120 || cInt == 98 || cInt == 111 || cInt == 88 || cInt == 66 || cInt == 79) {
							if (!fromHex && val.string == "0") {
								fromHex = true;
								val.string += str;
							} else {
								status = false;
								throwError("fault while parsing number;", cInt);
								break;
							}
						} else if (cInt == 101 || cInt == 69) {
							if (!exponent) {
								val.string += str;
								exponent = true;
							} else {
								status = false;
								throwError("fault while parsing number;", cInt);
								break;
							}
						} else if (cInt == 32 || cInt == 13 || cInt == 10 || cInt == 9 || cInt == 47 || cInt == 35 || cInt == 44 || cInt == 125 || cInt == 93 || cInt == 123 || cInt == 91 || cInt == 34 || cInt == 39 || cInt == 96 || cInt == 58) {
							pos.col -= n - _n;
							n = _n;
							break;
						} else {
							if (complete_at_end) {
								status = false;
								throwError("fault while parsing number;", cInt);
							}
							break;
						}
					}
				}
				if (!complete_at_end && n == buf.length) gatheringNumber = true;
				else {
					gatheringNumber = false;
					val.value_type = VALUE_NUMBER;
					if (parse_context == CONTEXT_UNKNOWN) completed = true;
				}
			}
			function openObject() {
				let nextMode = CONTEXT_OBJECT_FIELD;
				let cls = null;
				let tmpobj = {};
				if (word > WORD_POS_RESET && word < WORD_POS_FIELD) recoverIdent(123);
				let protoDef;
				protoDef = getProto();
				if (parse_context == CONTEXT_UNKNOWN) {
					if (word == WORD_POS_FIELD || word == WORD_POS_END && (protoDef || val.string.length)) {
						if (protoDef && protoDef.protoDef && protoDef.protoDef.protoCon) tmpobj = new protoDef.protoDef.protoCon();
						if (!protoDef || !protoDef.protoDef && val.string) {
							cls = classes.find((cls) => cls.name === val.string);
							if (!cls) {
								function privateProto() {}
								classes.push(cls = {
									name: val.string,
									protoCon: protoDef && protoDef.protoDef && protoDef.protoDef.protoCon || privateProto.constructor,
									fields: []
								});
								nextMode = CONTEXT_CLASS_FIELD;
							} else if (redefineClass) {
								cls.fields.length = 0;
								nextMode = CONTEXT_CLASS_FIELD;
							} else {
								tmpobj = new cls.protoCon();
								nextMode = CONTEXT_CLASS_VALUE;
							}
							redefineClass = false;
						}
						current_class = cls;
						word = WORD_POS_RESET;
					} else word = WORD_POS_FIELD;
				} else if (word == WORD_POS_FIELD || parse_context === CONTEXT_IN_ARRAY || parse_context === CONTEXT_OBJECT_FIELD_VALUE || parse_context == CONTEXT_CLASS_VALUE) {
					if (word != WORD_POS_RESET || val.value_type == VALUE_STRING) {
						if (protoDef && protoDef.protoDef) tmpobj = new protoDef.protoDef.protoCon();
						else {
							cls = classes.find((cls) => cls.name === val.string);
							if (!cls) {
								function privateProto() {}
								localFromProtoTypes.set(val.string, {
									protoCon: privateProto.prototype.constructor,
									cb: null
								});
								tmpobj = new privateProto();
							} else {
								nextMode = CONTEXT_CLASS_VALUE;
								tmpobj = {};
							}
						}
						word = WORD_POS_RESET;
					} else word = WORD_POS_RESET;
				} else if (parse_context == CONTEXT_OBJECT_FIELD && word == WORD_POS_RESET) {
					throwError("fault while parsing; getting field name unexpected ", cInt);
					status = false;
					return false;
				}
				let old_context = getContext();
				val.value_type = VALUE_OBJECT;
				if (parse_context === CONTEXT_UNKNOWN) elements = tmpobj;
				else if (parse_context == CONTEXT_IN_ARRAY) {
					if (arrayType == -1) {}
					val.name = elements.length;
				} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE || parse_context == CONTEXT_CLASS_VALUE) {
					if (!val.name && current_class) val.name = current_class.fields[current_class_field++];
					elements[val.name] = tmpobj;
				}
				old_context.context = parse_context;
				old_context.elements = elements;
				old_context.name = val.name;
				old_context.current_proto = current_proto;
				old_context.current_class = current_class;
				old_context.current_class_field = current_class_field;
				old_context.valueType = val.value_type;
				old_context.arrayType = arrayType;
				old_context.className = val.className;
				val.className = null;
				val.name = null;
				current_proto = protoDef;
				current_class = cls;
				current_class_field = 0;
				elements = tmpobj;
				if (!rootObject) rootObject = elements;
				context_stack.push(old_context);
				RESET_VAL();
				parse_context = nextMode;
				return true;
			}
			function openArray() {
				if (word > WORD_POS_RESET && word < WORD_POS_FIELD) recoverIdent(91);
				if (word == WORD_POS_END && val.string.length) {
					let typeIndex = knownArrayTypeNames.findIndex((type) => type === val.string);
					word = WORD_POS_RESET;
					if (typeIndex >= 0) {
						arrayType = typeIndex;
						val.className = val.string;
						val.string = null;
					} else if (val.string === "ref") {
						val.className = null;
						arrayType = -2;
					} else if (localFromProtoTypes.get(val.string)) val.className = val.string;
					else if (fromProtoTypes.get(val.string)) val.className = val.string;
					else throwError(`Unknown type '${val.string}' specified for array`, cInt);
				} else if (parse_context == CONTEXT_OBJECT_FIELD || word == WORD_POS_FIELD || word == WORD_POS_AFTER_FIELD) {
					throwError("Fault while parsing; while getting field name unexpected", cInt);
					status = false;
					return false;
				}
				{
					let old_context = getContext();
					val.value_type = VALUE_ARRAY;
					let tmparr = [];
					if (parse_context == CONTEXT_UNKNOWN) elements = tmparr;
					else if (parse_context == CONTEXT_IN_ARRAY) {
						if (arrayType == -1) elements.push(tmparr);
						val.name = elements.length;
					} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
						if (!val.name) {
							console.log("This says it's resolved.......");
							arrayType = -3;
						}
						if (current_proto && current_proto.protoDef) {
							if (current_proto.protoDef.cb) {
								const newarr = current_proto.protoDef.cb.call(elements, val.name, tmparr);
								if (newarr !== void 0) tmparr = elements[val.name] = newarr;
							} else elements[val.name] = tmparr;
						} else elements[val.name] = tmparr;
					}
					old_context.context = parse_context;
					old_context.elements = elements;
					old_context.name = val.name;
					old_context.current_proto = current_proto;
					old_context.current_class = current_class;
					old_context.current_class_field = current_class_field;
					old_context.valueType = val.value_type;
					old_context.arrayType = arrayType == -1 ? -3 : arrayType;
					old_context.className = val.className;
					arrayType = -1;
					val.className = null;
					val.name = null;
					current_proto = null;
					current_class = null;
					current_class_field = 0;
					elements = tmparr;
					if (!rootObject) rootObject = tmparr;
					context_stack.push(old_context);
					RESET_VAL();
					parse_context = CONTEXT_IN_ARRAY;
				}
				return true;
			}
			function getProto() {
				const result = {
					protoDef: null,
					cls: null
				};
				if (result.protoDef = localFromProtoTypes.get(val.string)) {
					if (!val.className) {
						val.className = val.string;
						val.string = null;
					}
				} else if (result.protoDef = fromProtoTypes.get(val.string)) {
					if (!val.className) {
						val.className = val.string;
						val.string = null;
					}
				}
				if (val.string) {
					result.cls = classes.find((cls) => cls.name === val.string);
					if (!result.protoDef && !result.cls) {}
				}
				return result.protoDef || result.cls ? result : null;
			}
			if (!status) return -1;
			if (msg && msg.length) {
				input = getBuffer();
				input.buf = msg;
				inQueue.push(input);
			} else {
				if (gatheringNumber) {
					gatheringNumber = false;
					val.value_type = VALUE_NUMBER;
					if (parse_context == CONTEXT_UNKNOWN) completed = true;
					retval = 1;
				}
				if (parse_context !== CONTEXT_UNKNOWN) throwError("Unclosed object at end of stream.", cInt);
			}
			while (status && (input = inQueue.shift())) {
				n = input.n;
				buf = input.buf;
				if (gatheringString) {
					let string_status = gatherString(gatheringStringFirstChar);
					if (string_status < 0) status = false;
					else if (string_status > 0) {
						gatheringString = false;
						if (status) val.value_type = VALUE_STRING;
					}
				}
				if (gatheringNumber) collectNumber();
				while (!completed && status && n < buf.length) {
					str = buf.charAt(n);
					cInt = buf.codePointAt(n++);
					if (cInt >= 65536) {
						str += buf.charAt(n);
						n++;
					}
					pos.col++;
					if (comment) {
						if (comment == 1) {
							if (cInt == 42) comment = 3;
							else if (cInt != 47) return throwError("fault while parsing;", cInt);
							else comment = 2;
						} else if (comment == 2) {
							if (cInt == 10 || cInt == 13) comment = 0;
						} else if (comment == 3) {
							if (cInt == 42) comment = 4;
						} else if (cInt == 47) comment = 0;
						else comment = 3;
						continue;
					}
					switch (cInt) {
						case 35:
							comment = 2;
							break;
						case 47:
							comment = 1;
							break;
						case 123:
							openObject();
							break;
						case 91:
							openArray();
							break;
						case 58:
							if (parse_context == CONTEXT_CLASS_VALUE) {
								word = WORD_POS_RESET;
								val.name = val.string;
								val.string = "";
								val.value_type = VALUE_UNSET;
							} else if (parse_context == CONTEXT_OBJECT_FIELD || parse_context == CONTEXT_CLASS_FIELD) {
								if (parse_context == CONTEXT_CLASS_FIELD) {
									if (!Object.keys(elements).length) {
										console.log("This is a full object, not a class def...", val.className);
										const privateProto = () => {};
										localFromProtoTypes.set(context_stack.last.node.current_class.name, {
											protoCon: privateProto.prototype.constructor,
											cb: null
										});
										elements = new privateProto();
										parse_context = CONTEXT_OBJECT_FIELD_VALUE;
										val.name = val.string;
										word = WORD_POS_RESET;
										val.string = "";
										val.value_type = VALUE_UNSET;
										console.log("don't do default;s do a revive...");
									}
								} else {
									if (word != WORD_POS_RESET && word != WORD_POS_END && word != WORD_POS_FIELD && word != WORD_POS_AFTER_FIELD) recoverIdent(32);
									word = WORD_POS_RESET;
									val.name = val.string;
									val.string = "";
									parse_context = parse_context === CONTEXT_OBJECT_FIELD ? CONTEXT_OBJECT_FIELD_VALUE : CONTEXT_CLASS_FIELD_VALUE;
									val.value_type = VALUE_UNSET;
								}
							} else if (parse_context == CONTEXT_UNKNOWN) {
								console.log("Override colon found, allow class redefinition", parse_context);
								redefineClass = true;
								break;
							} else {
								if (parse_context == CONTEXT_IN_ARRAY) throwError("(in array, got colon out of string):parsing fault;", cInt);
								else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) throwError("String unexpected", cInt);
								else throwError("(outside any object, got colon out of string):parsing fault;", cInt);
								status = false;
							}
							break;
						case 125:
							if (word == WORD_POS_END) word = WORD_POS_RESET;
							if (parse_context == CONTEXT_CLASS_FIELD) {
								if (current_class) {
									if (val.string) current_class.fields.push(val.string);
									RESET_VAL();
									let old_context = context_stack.pop();
									parse_context = CONTEXT_UNKNOWN;
									word = WORD_POS_RESET;
									val.name = old_context.name;
									elements = old_context.elements;
									current_class = old_context.current_class;
									current_class_field = old_context.current_class_field;
									arrayType = old_context.arrayType;
									val.value_type = old_context.valueType;
									val.className = old_context.className;
									rootObject = null;
									dropContext(old_context);
								} else throwError("State error; gathering class fields, and lost the class", cInt);
							} else if (parse_context == CONTEXT_OBJECT_FIELD || parse_context == CONTEXT_CLASS_VALUE) {
								if (val.value_type != VALUE_UNSET) {
									if (current_class) val.name = current_class.fields[current_class_field++];
									objectPush();
								}
								val.value_type = VALUE_OBJECT;
								if (current_proto && current_proto.protoDef) {
									console.log("SOMETHING SHOULD AHVE BEEN REPLACED HERE??", current_proto);
									console.log("The other version only revives on init");
									elements = new current_proto.protoDef.cb(elements, void 0, void 0);
								}
								val.contains = elements;
								val.string = "";
								let old_context = context_stack.pop();
								parse_context = old_context.context;
								val.name = old_context.name;
								elements = old_context.elements;
								current_class = old_context.current_class;
								current_proto = old_context.current_proto;
								current_class_field = old_context.current_class_field;
								arrayType = old_context.arrayType;
								val.value_type = old_context.valueType;
								val.className = old_context.className;
								dropContext(old_context);
								if (parse_context == CONTEXT_UNKNOWN) completed = true;
							} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
								if (val.value_type === VALUE_UNSET) {
									if (word == WORD_POS_RESET) throwError("Fault while parsing; unexpected", cInt);
									else recoverIdent(cInt);
								}
								objectPush();
								val.value_type = VALUE_OBJECT;
								val.contains = elements;
								word = WORD_POS_RESET;
								let old_context = context_stack.pop();
								parse_context = old_context.context;
								val.name = old_context.name;
								elements = old_context.elements;
								current_proto = old_context.current_proto;
								current_class = old_context.current_class;
								current_class_field = old_context.current_class_field;
								arrayType = old_context.arrayType;
								val.value_type = old_context.valueType;
								val.className = old_context.className;
								dropContext(old_context);
								if (parse_context == CONTEXT_UNKNOWN) completed = true;
							} else {
								throwError("Fault while parsing; unexpected", cInt);
								status = false;
							}
							negative = false;
							break;
						case 93:
							if (word >= WORD_POS_AFTER_FIELD) word = WORD_POS_RESET;
							if (parse_context == CONTEXT_IN_ARRAY) {
								if (val.value_type != VALUE_UNSET) arrayPush();
								else if (word !== WORD_POS_RESET) {
									recoverIdent(cInt);
									arrayPush();
								}
								val.contains = elements;
								{
									let old_context = context_stack.pop();
									val.name = old_context.name;
									val.className = old_context.className;
									parse_context = old_context.context;
									elements = old_context.elements;
									current_proto = old_context.current_proto;
									current_class = old_context.current_class;
									current_class_field = old_context.current_class_field;
									arrayType = old_context.arrayType;
									val.value_type = old_context.valueType;
									dropContext(old_context);
								}
								val.value_type = VALUE_ARRAY;
								if (parse_context == CONTEXT_UNKNOWN) completed = true;
							} else {
								throwError(`bad context ${parse_context}; fault while parsing`, cInt);
								status = false;
							}
							negative = false;
							break;
						case 44:
							if (word < WORD_POS_AFTER_FIELD && word != WORD_POS_RESET) recoverIdent(cInt);
							if (word == WORD_POS_END || word == WORD_POS_FIELD) word = WORD_POS_RESET;
							if (parse_context == CONTEXT_CLASS_FIELD) {
								if (current_class) {
									current_class.fields.push(val.string);
									val.string = "";
									word = WORD_POS_FIELD;
								} else throwError("State error; gathering class fields, and lost the class", cInt);
							} else if (parse_context == CONTEXT_OBJECT_FIELD) {
								if (current_class) {
									val.name = current_class.fields[current_class_field++];
									if (val.value_type != VALUE_UNSET) {
										objectPush();
										RESET_VAL();
									}
								} else if (val.string || val.value_type) throwError("State error; comma in field name and/or lost the class", cInt);
							} else if (parse_context == CONTEXT_CLASS_VALUE) {
								if (current_class) {
									if (arrayType != -3 && !val.name) val.name = current_class.fields[current_class_field++];
									if (val.value_type != VALUE_UNSET) {
										if (arrayType != -3) objectPush();
										RESET_VAL();
									}
								} else if (val.value_type != VALUE_UNSET) {
									objectPush();
									RESET_VAL();
								}
								val.name = null;
							} else if (parse_context == CONTEXT_IN_ARRAY) {
								if (val.value_type == VALUE_UNSET) val.value_type = VALUE_EMPTY;
								arrayPush();
								RESET_VAL();
								word = WORD_POS_RESET;
							} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE && val.value_type != VALUE_UNSET) {
								parse_context = CONTEXT_OBJECT_FIELD;
								if (val.value_type != VALUE_UNSET) {
									objectPush();
									RESET_VAL();
								}
								word = WORD_POS_RESET;
							} else {
								status = false;
								throwError("bad context; excessive commas while parsing;", cInt);
							}
							negative = false;
							break;
						default: switch (cInt) {
							default:
								if (parse_context == CONTEXT_UNKNOWN || parse_context == CONTEXT_OBJECT_FIELD_VALUE && word == WORD_POS_FIELD || parse_context == CONTEXT_OBJECT_FIELD || word == WORD_POS_FIELD || parse_context == CONTEXT_CLASS_FIELD) switch (cInt) {
									case 96:
									case 34:
									case 39:
										if (word == WORD_POS_RESET || word == WORD_POS_FIELD) {
											if (val.string.length) {
												console.log("IN ARRAY AND FIXING?");
												val.className = val.string;
												val.string = "";
											}
											if (gatherString(cInt)) val.value_type = VALUE_STRING;
											else {
												gatheringStringFirstChar = cInt;
												gatheringString = true;
											}
										} else throwError("fault while parsing; quote not at start of field name", cInt);
										break;
									case 10:
										pos.line++;
										pos.col = 1;
									case 13:
									case 32:
									case 8232:
									case 8233:
									case 9:
									case 65279:
										if (parse_context === CONTEXT_UNKNOWN && word === WORD_POS_END) {
											word = WORD_POS_RESET;
											if (parse_context === CONTEXT_UNKNOWN) completed = true;
											break;
										}
										if (word === WORD_POS_RESET || word === WORD_POS_AFTER_FIELD) {
											if (parse_context == CONTEXT_UNKNOWN && val.value_type) completed = true;
											break;
										} else if (word === WORD_POS_FIELD) {
											if (parse_context === CONTEXT_UNKNOWN) {
												word = WORD_POS_RESET;
												completed = true;
												break;
											}
											if (val.string.length) console.log("STEP TO NEXT TOKEN.");
											word = WORD_POS_AFTER_FIELD;
										} else {
											status = false;
											throwError("fault while parsing; whitepsace unexpected", cInt);
										}
										break;
									default:
										if (word == WORD_POS_RESET && (cInt >= 48 && cInt <= 57 || cInt == 43 || cInt == 46 || cInt == 45)) {
											fromHex = false;
											exponent = false;
											date_format = false;
											isBigInt = false;
											exponent_sign = false;
											exponent_digit = false;
											decimal = false;
											val.string = str;
											input.n = n;
											collectNumber();
											break;
										}
										if (word === WORD_POS_AFTER_FIELD) {
											status = false;
											throwError("fault while parsing; character unexpected", cInt);
										}
										if (word === WORD_POS_RESET) {
											word = WORD_POS_FIELD;
											val.value_type = VALUE_STRING;
											val.string += str;
											break;
										}
										if (val.value_type == VALUE_UNSET) {
											if (word !== WORD_POS_RESET && word !== WORD_POS_END) recoverIdent(cInt);
										} else {
											if (word === WORD_POS_END || word === WORD_POS_FIELD) {
												val.string += str;
												break;
											}
											if (parse_context == CONTEXT_OBJECT_FIELD) {
												if (word == WORD_POS_FIELD) {
													val.string += str;
													break;
												}
												throwError("Multiple values found in field name", cInt);
											}
											if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) throwError("String unexpected", cInt);
										}
								}
								else {
									if (word == WORD_POS_RESET && (cInt >= 48 && cInt <= 57 || cInt == 43 || cInt == 46 || cInt == 45)) {
										fromHex = false;
										exponent = false;
										date_format = false;
										isBigInt = false;
										exponent_sign = false;
										exponent_digit = false;
										decimal = false;
										val.string = str;
										input.n = n;
										collectNumber();
									} else if (val.value_type == VALUE_UNSET) {
										if (word != WORD_POS_RESET) recoverIdent(cInt);
										else {
											word = WORD_POS_END;
											val.string += str;
											val.value_type = VALUE_STRING;
										}
									} else if (parse_context == CONTEXT_OBJECT_FIELD) throwError("Multiple values found in field name", cInt);
									else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
										if (val.value_type != VALUE_STRING) {
											if (val.value_type == VALUE_OBJECT || val.value_type == VALUE_ARRAY) throwError("String unexpected", cInt);
											recoverIdent(cInt);
										}
										if (word == WORD_POS_AFTER_FIELD) {
											if (getProto()) val.string = str;
											else throwError("String unexpected", cInt);
										} else if (word == WORD_POS_END) val.string += str;
										else throwError("String unexpected", cInt);
									} else if (parse_context == CONTEXT_IN_ARRAY) {
										if (word == WORD_POS_AFTER_FIELD) {
											if (!val.className) {
												val.className = val.string;
												val.string = "";
											}
											val.string += str;
											break;
										} else if (word == WORD_POS_END) val.string += str;
									}
									break;
								}
								break;
							case 96:
							case 34:
							case 39:
								if (val.string) val.className = val.string;
								val.string = "";
								if (gatherString(cInt)) {
									val.value_type = VALUE_STRING;
									word = WORD_POS_END;
								} else {
									gatheringStringFirstChar = cInt;
									gatheringString = true;
								}
								break;
							case 10:
								pos.line++;
								pos.col = 1;
							case 32:
							case 9:
							case 13:
							case 8232:
							case 8233:
							case 65279:
								if (word == WORD_POS_END) {
									if (parse_context == CONTEXT_UNKNOWN) {
										word = WORD_POS_RESET;
										completed = true;
										break;
									} else if (parse_context == CONTEXT_OBJECT_FIELD_VALUE) {
										word = WORD_POS_AFTER_FIELD_VALUE;
										break;
									} else if (parse_context == CONTEXT_OBJECT_FIELD) {
										word = WORD_POS_AFTER_FIELD;
										break;
									} else if (parse_context == CONTEXT_IN_ARRAY) {
										word = WORD_POS_AFTER_FIELD;
										break;
									}
								}
								if (word == WORD_POS_RESET || word == WORD_POS_AFTER_FIELD) break;
								else if (word == WORD_POS_FIELD) {
									if (val.string.length) word = WORD_POS_AFTER_FIELD;
								} else if (word < WORD_POS_END) recoverIdent(cInt);
								break;
							case 116:
								if (word == WORD_POS_RESET) word = WORD_POS_TRUE_1;
								else if (word == WORD_POS_INFINITY_6) word = WORD_POS_INFINITY_7;
								else recoverIdent(cInt);
								break;
							case 114:
								if (word == WORD_POS_TRUE_1) word = WORD_POS_TRUE_2;
								else recoverIdent(cInt);
								break;
							case 117:
								if (word == WORD_POS_TRUE_2) word = WORD_POS_TRUE_3;
								else if (word == WORD_POS_NULL_1) word = WORD_POS_NULL_2;
								else if (word == WORD_POS_RESET) word = WORD_POS_UNDEFINED_1;
								else recoverIdent(cInt);
								break;
							case 101:
								if (word == WORD_POS_TRUE_3) {
									val.value_type = VALUE_TRUE;
									word = WORD_POS_END;
								} else if (word == WORD_POS_FALSE_4) {
									val.value_type = VALUE_FALSE;
									word = WORD_POS_END;
								} else if (word == WORD_POS_UNDEFINED_3) word = WORD_POS_UNDEFINED_4;
								else if (word == WORD_POS_UNDEFINED_7) word = WORD_POS_UNDEFINED_8;
								else recoverIdent(cInt);
								break;
							case 110:
								if (word == WORD_POS_RESET) word = WORD_POS_NULL_1;
								else if (word == WORD_POS_UNDEFINED_1) word = WORD_POS_UNDEFINED_2;
								else if (word == WORD_POS_UNDEFINED_6) word = WORD_POS_UNDEFINED_7;
								else if (word == WORD_POS_INFINITY_1) word = WORD_POS_INFINITY_2;
								else if (word == WORD_POS_INFINITY_4) word = WORD_POS_INFINITY_5;
								else recoverIdent(cInt);
								break;
							case 100:
								if (word == WORD_POS_UNDEFINED_2) word = WORD_POS_UNDEFINED_3;
								else if (word == WORD_POS_UNDEFINED_8) {
									val.value_type = VALUE_UNDEFINED;
									word = WORD_POS_END;
								} else recoverIdent(cInt);
								break;
							case 105:
								if (word == WORD_POS_UNDEFINED_5) word = WORD_POS_UNDEFINED_6;
								else if (word == WORD_POS_INFINITY_3) word = WORD_POS_INFINITY_4;
								else if (word == WORD_POS_INFINITY_5) word = WORD_POS_INFINITY_6;
								else recoverIdent(cInt);
								break;
							case 108:
								if (word == WORD_POS_NULL_2) word = WORD_POS_NULL_3;
								else if (word == WORD_POS_NULL_3) {
									val.value_type = VALUE_NULL;
									word = WORD_POS_END;
								} else if (word == WORD_POS_FALSE_2) word = WORD_POS_FALSE_3;
								else recoverIdent(cInt);
								break;
							case 102:
								if (word == WORD_POS_RESET) word = WORD_POS_FALSE_1;
								else if (word == WORD_POS_UNDEFINED_4) word = WORD_POS_UNDEFINED_5;
								else if (word == WORD_POS_INFINITY_2) word = WORD_POS_INFINITY_3;
								else recoverIdent(cInt);
								break;
							case 97:
								if (word == WORD_POS_FALSE_1) word = WORD_POS_FALSE_2;
								else if (word == WORD_POS_NAN_1) word = WORD_POS_NAN_2;
								else recoverIdent(cInt);
								break;
							case 115:
								if (word == WORD_POS_FALSE_3) word = WORD_POS_FALSE_4;
								else recoverIdent(cInt);
								break;
							case 73:
								if (word == WORD_POS_RESET) word = WORD_POS_INFINITY_1;
								else recoverIdent(cInt);
								break;
							case 78:
								if (word == WORD_POS_RESET) word = WORD_POS_NAN_1;
								else if (word == WORD_POS_NAN_2) {
									val.value_type = negative ? VALUE_NEG_NAN : VALUE_NAN;
									negative = false;
									word = WORD_POS_END;
								} else recoverIdent(cInt);
								break;
							case 121:
								if (word == WORD_POS_INFINITY_7) {
									val.value_type = negative ? VALUE_NEG_INFINITY : VALUE_INFINITY;
									negative = false;
									word = WORD_POS_END;
								} else recoverIdent(cInt);
								break;
							case 45:
								if (word == WORD_POS_RESET) negative = !negative;
								else recoverIdent(cInt);
								break;
							case 43: if (word !== WORD_POS_RESET) recoverIdent(cInt);
						}
					}
					if (completed) {
						if (word == WORD_POS_END) word = WORD_POS_RESET;
						break;
					}
				}
				if (n == buf.length) {
					dropBuffer(input);
					if (val.value_type == VALUE_UNSET && complete_at_end && word != WORD_POS_RESET) recoverIdent(32);
					if (gatheringString || gatheringNumber || parse_context == CONTEXT_OBJECT_FIELD) retval = 0;
					else if (parse_context == CONTEXT_UNKNOWN && (val.value_type != VALUE_UNSET || result)) {
						completed = true;
						retval = 1;
					}
				} else {
					input.n = n;
					inQueue.unshift(input);
					retval = 2;
				}
				if (completed) {
					rootObject = null;
					break;
				}
			}
			if (!status) return -1;
			if (completed && val.value_type != VALUE_UNSET) {
				word = WORD_POS_RESET;
				result = convertValue();
				negative = false;
				val.string = "";
				val.value_type = VALUE_UNSET;
			}
			completed = false;
			return retval;
		}
	};
};
var _parser = [Object.freeze(JSOX.begin())];
var _parse_level = 0;
/**
* parse a string resulting with one value from it.
*
* @template T
* @param {string} msg 
* @param {(this: any, key: string, value: any) => any} [reviver] 
* @returns {T}
*/
JSOX.parse = function(msg, reviver) {
	let parse_level = _parse_level++;
	let parser;
	if (_parser.length <= parse_level) _parser.push(Object.freeze(JSOX.begin()));
	parser = _parser[parse_level];
	if (typeof msg !== "string") msg = String(msg);
	parser.reset();
	const writeResult = parser._write(msg, true);
	if (writeResult > 0) {
		if (writeResult > 1) {}
		let result = parser.value();
		if ("undefined" === typeof result && writeResult > 1) throw new Error("Pending value could not complete");
		result = typeof reviver === "function" ? function walk(holder, key) {
			let k, v, value = holder[key];
			if (value && typeof value === "object") {
				for (k in value) if (Object.prototype.hasOwnProperty.call(value, k)) {
					v = walk(value, k);
					if (v !== void 0) value[k] = v;
					else delete value[k];
				}
			}
			return reviver.call(holder, key, value);
		}({ "": result }, "") : result;
		_parse_level--;
		return result;
	}
	parser.finalError();
};
function this_value() {
	return this && this.valueOf();
}
/**
* Define a class to be used for serialization; the class allows emitting the class fields ahead of time, and just provide values later.
* @param {string} name 
* @param {object} obj 
*/
JSOX.defineClass = function(name, obj) {
	let cls;
	let denormKeys = Object.keys(obj);
	for (let i = 1; i < denormKeys.length; i++) {
		let a, b;
		if ((a = denormKeys[i - 1]) > (b = denormKeys[i])) {
			denormKeys[i - 1] = b;
			denormKeys[i] = a;
			if (i) i -= 2;
			else i--;
		}
	}
	commonClasses.push(cls = {
		name,
		tag: denormKeys.toString(),
		proto: Object.getPrototypeOf(obj),
		fields: Object.keys(obj)
	});
	for (let n = 1; n < cls.fields.length; n++) if (cls.fields[n] < cls.fields[n - 1]) {
		let tmp = cls.fields[n - 1];
		cls.fields[n - 1] = cls.fields[n];
		cls.fields[n] = tmp;
		if (n > 1) n -= 2;
	}
	if (cls.proto === Object.getPrototypeOf({})) cls.proto = null;
};
/**
* deprecated; define a class to be used for serialization
*
* @param {string} named
* @param {class} ptype
* @param {(any)=>any} f
*/
JSOX.registerToJSOX = function(name, ptype, f) {
	throw new Error("registerToJSOX deprecated; please use toJSOX:" + prototypeName + prototype.toString());
};
/**
* define a class with special serialization rules.
*
* @param {string} named
* @param {class} ptype
* @param {(any)=>any} f
*/
JSOX.toJSOX = function(name, ptype, f) {
	if (!ptype.prototype || ptype.prototype !== Object.prototype) {
		if (toProtoTypes.get(ptype.prototype)) throw new Error("Existing toJSOX has been registered for prototype");
		toProtoTypes.set(ptype.prototype, {
			external: true,
			name: name || f.constructor.name,
			cb: f
		});
	} else {
		let key = Object.keys(ptype).toString();
		if (toObjectTypes.get(key)) throw new Error("Existing toJSOX has been registered for object type");
		toObjectTypes.set(key, {
			external: true,
			name,
			cb: f
		});
	}
};
/**
* define a class to be used for deserialization
* @param {string} prototypeName 
* @param {class} o 
* @param {(any)=>any} f 
*/
JSOX.fromJSOX = function(prototypeName, o, f) {
	function privateProto() {}
	if (!o) o = privateProto.prototype;
	if (fromProtoTypes.get(prototypeName)) throw new Error("Existing fromJSOX has been registered for prototype");
	if (o && !("constructor" in o)) throw new Error("Please pass a prototype like thing...");
	fromProtoTypes.set(prototypeName, {
		protoCon: o.prototype.constructor,
		cb: f
	});
};
/**
* deprecated; use fromJSOX instead
*/
JSOX.registerFromJSOX = function(prototypeName, o) {
	throw new Error("deprecated; please adjust code to use fromJSOX:" + prototypeName + o.toString());
};
/**
* Define serialization and deserialization methods for a class.
* This is the same as registering separately with toJSOX and fromJSOX methods.
* 
* @param {string} name - Name used to prefix objects of this type encoded in JSOX
* @param {class} prototype - prototype to match when serializing, and to create instaces of when deserializing.
* @param {(stringifier:JSOXStringifier)=>{string}} to - `this` is the value to convert; function to call to encode JSOX from an object
* @param {(field:string,val:any)=>{any}} from - handle storing revived value in class
*/
JSOX.addType = function(prototypeName, prototype, to, from) {
	JSOX.toJSOX(prototypeName, prototype, to);
	JSOX.fromJSOX(prototypeName, prototype, from);
};
JSOX.registerToFrom = function(prototypeName, prototype) {
	throw new Error("registerToFrom deprecated; please use addType:" + prototypeName + prototype.toString());
};
/**
* Create a stringifier to convert objects to JSOX text.  Allows defining custom serialization for objects.
* @returns {JSOXStringifier}
*/
JSOX.stringifier = function() {
	let classes = [];
	let useQuote = "\"";
	let fieldMap = /* @__PURE__ */ new WeakMap();
	const path = [];
	let encoding = [];
	const localToProtoTypes = /* @__PURE__ */ new WeakMap();
	const localToObjectTypes = /* @__PURE__ */ new Map();
	let objectToJSOX = null;
	const stringifying = [];
	let ignoreNonEnumerable = false;
	function getIdentifier(s) {
		if ("string" === typeof s && s === "") return "\"\"";
		if ("number" === typeof s && !isNaN(s)) return [
			"'",
			s.toString(),
			"'"
		].join("");
		if (s.includes("﻿")) return useQuote + JSOX.escape(s) + useQuote;
		return s in keywords || /[0-9\-]/.test(s[0]) || /[\n\r\t #\[\]{}()<>\~!+*/.:,\-"'`]/.test(s) ? useQuote + JSOX.escape(s) + useQuote : s;
	}
	if (!toProtoTypes.get(Object.prototype)) {
		toProtoTypes.set(Object.prototype, {
			external: false,
			name: Object.prototype.constructor.name,
			cb: null
		});
		toProtoTypes.set(Date.prototype, {
			external: false,
			name: "Date",
			cb: function() {
				if (this.getTime() === -621672192e5) return "0000-01-01T00:00:00.000Z";
				let tzo = -this.getTimezoneOffset(), dif = tzo >= 0 ? "+" : "-", pad = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 10 ? "0" : "") + norm;
				}, pad3 = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 100 ? "0" : "") + (norm < 10 ? "0" : "") + norm;
				};
				return [
					this.getFullYear(),
					"-",
					pad(this.getMonth() + 1),
					"-",
					pad(this.getDate()),
					"T",
					pad(this.getHours()),
					":",
					pad(this.getMinutes()),
					":",
					pad(this.getSeconds()),
					"." + pad3(this.getMilliseconds()) + dif,
					pad(tzo / 60),
					":",
					pad(tzo % 60)
				].join("");
			}
		});
		toProtoTypes.set(DateNS.prototype, {
			external: false,
			name: "DateNS",
			cb: function() {
				let tzo = -this.getTimezoneOffset(), dif = tzo >= 0 ? "+" : "-", pad = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 10 ? "0" : "") + norm;
				}, pad3 = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 100 ? "0" : "") + (norm < 10 ? "0" : "") + norm;
				}, pad6 = function(num) {
					let norm = Math.floor(Math.abs(num));
					return (norm < 1e5 ? "0" : "") + (norm < 1e4 ? "0" : "") + (norm < 1e3 ? "0" : "") + (norm < 100 ? "0" : "") + (norm < 10 ? "0" : "") + norm;
				};
				return [
					this.getFullYear(),
					"-",
					pad(this.getMonth() + 1),
					"-",
					pad(this.getDate()),
					"T",
					pad(this.getHours()),
					":",
					pad(this.getMinutes()),
					":",
					pad(this.getSeconds()),
					"." + pad3(this.getMilliseconds()) + pad6(this.ns) + dif,
					pad(tzo / 60),
					":",
					pad(tzo % 60)
				].join("");
			}
		});
		toProtoTypes.set(Boolean.prototype, {
			external: false,
			name: "Boolean",
			cb: this_value
		});
		toProtoTypes.set(Number.prototype, {
			external: false,
			name: "Number",
			cb: function() {
				if (isNaN(this)) return "NaN";
				return isFinite(this) ? String(this) : this < 0 ? "-Infinity" : "Infinity";
			}
		});
		toProtoTypes.set(String.prototype, {
			external: false,
			name: "String",
			cb: function() {
				return "\"" + JSOX.escape(this_value.apply(this)) + "\"";
			}
		});
		if (typeof BigInt === "function") toProtoTypes.set(BigInt.prototype, {
			external: false,
			name: "BigInt",
			cb: function() {
				return this + "n";
			}
		});
		toProtoTypes.set(ArrayBuffer.prototype, {
			external: true,
			name: "ab",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this)) + "]";
			}
		});
		toProtoTypes.set(Uint8Array.prototype, {
			external: true,
			name: "u8",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Uint8ClampedArray.prototype, {
			external: true,
			name: "uc8",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Int8Array.prototype, {
			external: true,
			name: "s8",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Uint16Array.prototype, {
			external: true,
			name: "u16",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Int16Array.prototype, {
			external: true,
			name: "s16",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Uint32Array.prototype, {
			external: true,
			name: "u32",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Int32Array.prototype, {
			external: true,
			name: "s32",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Float32Array.prototype, {
			external: true,
			name: "f32",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Float64Array.prototype, {
			external: true,
			name: "f64",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(Float64Array.prototype, {
			external: true,
			name: "f64",
			cb: function() {
				return "[" + getIdentifier(base64ArrayBuffer(this.buffer)) + "]";
			}
		});
		toProtoTypes.set(RegExp.prototype, mapToJSOX = {
			external: true,
			name: "regex",
			cb: function(o, stringifier) {
				return "'" + escape(this.source) + "'";
			}
		});
		fromProtoTypes.set("regex", {
			protoCon: RegExp,
			cb: function(field, val) {
				return new RegExp(this);
			}
		});
		toProtoTypes.set(Map.prototype, mapToJSOX = {
			external: true,
			name: "map",
			cb: null
		});
		fromProtoTypes.set("map", {
			protoCon: Map,
			cb: function(field, val) {
				if (field) {
					this.set(field, val);
					return;
				}
				return this;
			}
		});
		toProtoTypes.set(Array.prototype, arrayToJSOX = {
			external: false,
			name: Array.prototype.constructor.name,
			cb: null
		});
	}
	const stringifier = {
		defineClass(name, obj) {
			let cls;
			let denormKeys = Object.keys(obj);
			for (let i = 1; i < denormKeys.length; i++) {
				let a, b;
				if ((a = denormKeys[i - 1]) > (b = denormKeys[i])) {
					denormKeys[i - 1] = b;
					denormKeys[i] = a;
					if (i) i -= 2;
					else i--;
				}
			}
			classes.push(cls = {
				name,
				tag: denormKeys.toString(),
				proto: Object.getPrototypeOf(obj),
				fields: Object.keys(obj)
			});
			for (let n = 1; n < cls.fields.length; n++) if (cls.fields[n] < cls.fields[n - 1]) {
				let tmp = cls.fields[n - 1];
				cls.fields[n - 1] = cls.fields[n];
				cls.fields[n] = tmp;
				if (n > 1) n -= 2;
			}
			if (cls.proto === Object.getPrototypeOf({})) cls.proto = null;
		},
		setDefaultObjectToJSOX(cb) {
			objectToJSOX = cb;
		},
		isEncoding(o) {
			return !!encoding.find((eo, i) => eo === o && i < encoding.length - 1);
		},
		encodeObject(o) {
			if (objectToJSOX) return objectToJSOX.apply(o, [this]);
			return o;
		},
		stringify(o, r, s) {
			return stringify(o, r, s);
		},
		setQuote(q) {
			useQuote = q;
		},
		registerToJSOX(n, p, f) {
			return this.toJSOX(n, p, f);
		},
		toJSOX(name, ptype, f) {
			if (ptype.prototype && ptype.prototype !== Object.prototype) {
				if (localToProtoTypes.get(ptype.prototype)) throw new Error("Existing toJSOX has been registered for prototype");
				localToProtoTypes.set(ptype.prototype, {
					external: true,
					name: name || f.constructor.name,
					cb: f
				});
			} else {
				let key = Object.keys(ptype).toString();
				if (localToObjectTypes.get(key)) throw new Error("Existing toJSOX has been registered for object type");
				localToObjectTypes.set(key, {
					external: true,
					name,
					cb: f
				});
			}
		},
		get ignoreNonEnumerable() {
			return ignoreNonEnumerable;
		},
		set ignoreNonEnumerable(val) {
			ignoreNonEnumerable = val;
		}
	};
	return stringifier;
	/**
	* get a reference to a previously seen object
	* @param {any} here 
	* @returns reference to existing object, or undefined if not found.
	*/
	function getReference(here) {
		if (here === null) return void 0;
		let field = fieldMap.get(here);
		if (!field) {
			fieldMap.set(here, _JSON.stringify(path));
			return;
		}
		return "ref" + field;
	}
	/**
	* find the prototype definition for a class
	* @param {object} o 
	* @param {map} useK 
	* @returns object
	*/
	function matchObject(o, useK) {
		let k;
		let cls;
		let prt = Object.getPrototypeOf(o);
		cls = classes.find((cls) => {
			if (cls.proto && cls.proto === prt) return true;
		});
		if (cls) return cls;
		if (classes.length || commonClasses.length) {
			if (useK) {
				useK = useK.map((v) => {
					if (typeof v === "string") return v;
					else return void 0;
				});
				k = useK.toString();
			} else {
				let denormKeys = Object.keys(o);
				for (let i = 1; i < denormKeys.length; i++) {
					let a, b;
					if ((a = denormKeys[i - 1]) > (b = denormKeys[i])) {
						denormKeys[i - 1] = b;
						denormKeys[i] = a;
						if (i) i -= 2;
						else i--;
					}
				}
				k = denormKeys.toString();
			}
			cls = classes.find((cls) => {
				if (cls.tag === k) return true;
			});
			if (!cls) cls = commonClasses.find((cls) => {
				if (cls.tag === k) return true;
			});
		}
		return cls;
	}
	/**
	* Serialize an object to JSOX text.
	* @param {any} object 
	* @param {(key:string,value:any)=>string} replacer 
	* @param {string|number} space 
	* @returns 
	*/
	function stringify(object, replacer, space) {
		if (object === void 0) return "undefined";
		if (object === null) return;
		let gap;
		let indent;
		let rep;
		let i;
		const spaceType = typeof space;
		const repType = typeof replacer;
		gap = "";
		indent = "";
		if (spaceType === "number") for (i = 0; i < space; i += 1) indent += " ";
		else if (spaceType === "string") indent = space;
		rep = replacer;
		if (replacer && repType !== "function" && (repType !== "object" || typeof replacer.length !== "number")) throw new Error("JSOX.stringify");
		path.length = 0;
		fieldMap = /* @__PURE__ */ new WeakMap();
		const finalResult = str("", { "": object });
		commonClasses.length = 0;
		return finalResult;
		function str(key, holder) {
			var mind = gap;
			const doArrayToJSOX_ = arrayToJSOX.cb;
			const mapToObject_ = mapToJSOX.cb;
			arrayToJSOX.cb = doArrayToJSOX;
			mapToJSOX.cb = mapToObject;
			const v = str_(key, holder);
			arrayToJSOX.cb = doArrayToJSOX_;
			mapToJSOX.cb = mapToObject_;
			return v;
			function doArrayToJSOX() {
				let v;
				let partial = [];
				let thisNodeNameIndex = path.length;
				for (let i = 0; i < this.length; i += 1) {
					path[thisNodeNameIndex] = i;
					partial[i] = str(i, this) || "null";
				}
				path.length = thisNodeNameIndex;
				encoding.length = thisNodeNameIndex;
				v = partial.length === 0 ? "[]" : gap ? [
					"[\n",
					gap,
					partial.join(",\n" + gap),
					"\n",
					mind,
					"]"
				].join("") : "[" + partial.join(",") + "]";
				return v;
			}
			function mapToObject() {
				let tmp = { tmp: null };
				let out = "{";
				let first = true;
				for (let [key, value] of this) {
					tmp.tmp = value;
					let thisNodeNameIndex = path.length;
					path[thisNodeNameIndex] = key;
					out += (first ? "" : ",") + getIdentifier(key) + ":" + str("tmp", tmp);
					path.length = thisNodeNameIndex;
					first = false;
				}
				out += "}";
				return out;
			}
			function str_(key, holder) {
				let i;
				let k;
				let v;
				let length;
				let partialClass;
				let partial;
				let thisNodeNameIndex = path.length;
				let isValue = true;
				let value = holder[key];
				let isObject = typeof value === "object";
				let c;
				if (isObject && value !== null) {
					if (objectToJSOX) {
						if (!stringifying.find((val) => val === value)) {
							stringifying.push(value);
							encoding[thisNodeNameIndex] = value;
							isValue = false;
							value = objectToJSOX.apply(value, [stringifier]);
							isObject = typeof value === "object";
							stringifying.pop();
							encoding.length = thisNodeNameIndex;
							isObject = typeof value === "object";
						}
					}
				}
				const objType = value !== void 0 && value !== null && Object.getPrototypeOf(value);
				let protoConverter = objType && (localToProtoTypes.get(objType) || toProtoTypes.get(objType) || null);
				let objectConverter = !protoConverter && value !== void 0 && value !== null && (localToObjectTypes.get(Object.keys(value).toString()) || toObjectTypes.get(Object.keys(value).toString()) || null);
				if (typeof rep === "function") {
					isValue = false;
					value = rep.call(holder, key, value);
				}
				let toJSOX = protoConverter && protoConverter.cb || objectConverter && objectConverter.cb;
				if (value !== void 0 && value !== null && typeof value === "object" && typeof toJSOX === "function") {
					if (!stringifying.find((val) => val === value)) {
						if (typeof value === "object") {
							v = getReference(value);
							if (v) return v;
						}
						stringifying.push(value);
						encoding[thisNodeNameIndex] = value;
						value = toJSOX.call(value, stringifier);
						isValue = false;
						stringifying.pop();
						if (protoConverter && protoConverter.name) {
							if ("string" === typeof value && value[0] !== "-" && (value[0] < "0" || value[0] > "9") && value[0] !== "\"" && value[0] !== "'" && value[0] !== "`" && value[0] !== "[" && value[0] !== "{") value = " " + value;
						}
						encoding.length = thisNodeNameIndex;
					} else v = getReference(value);
				} else if (typeof value === "object") {
					v = getReference(value);
					if (v) return v;
				}
				switch (typeof value) {
					case "bigint": return value + "n";
					case "string": {
						value = isValue ? getIdentifier(value) : value;
						let c = "";
						if (key === "") c = classes.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "") + commonClasses.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "") + (gap ? "\n" : "");
						if (protoConverter && protoConverter.external) return c + protoConverter.name + value;
						if (objectConverter && objectConverter.external) return c + objectConverter.name + value;
						return c + value;
					}
					case "number":
					case "boolean":
					case "null": return String(value);
					case "object":
						if (v) return v;
						if (!value) return "null";
						gap += indent;
						partialClass = null;
						partial = [];
						if (rep && typeof rep === "object") {
							length = rep.length;
							partialClass = matchObject(value, rep);
							for (i = 0; i < length; i += 1) if (typeof rep[i] === "string") {
								k = rep[i];
								path[thisNodeNameIndex] = k;
								v = str(k, value);
								if (v !== void 0) {
									if (partialClass) partial.push(v);
									else partial.push(getIdentifier(k) + (gap ? ": " : ":") + v);
								}
							}
							path.splice(thisNodeNameIndex, 1);
						} else {
							partialClass = matchObject(value);
							let keys = [];
							for (k in value) {
								if (ignoreNonEnumerable) {
									if (!Object.prototype.propertyIsEnumerable.call(value, k)) continue;
								}
								if (Object.prototype.hasOwnProperty.call(value, k)) {
									let n;
									for (n = 0; n < keys.length; n++) if (keys[n] > k) {
										keys.splice(n, 0, k);
										break;
									}
									if (n == keys.length) keys.push(k);
								}
							}
							for (let n = 0; n < keys.length; n++) {
								k = keys[n];
								if (Object.prototype.hasOwnProperty.call(value, k)) {
									path[thisNodeNameIndex] = k;
									v = str(k, value);
									if (v !== void 0) {
										if (partialClass) partial.push(v);
										else partial.push(getIdentifier(k) + (gap ? ": " : ":") + v);
									}
								}
							}
							path.splice(thisNodeNameIndex, 1);
						}
						if (key === "") c = (classes.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "") || commonClasses.map((cls) => cls.name + "{" + cls.fields.join(",") + "}").join(gap ? "\n" : "")) + (gap ? "\n" : "");
						else c = "";
						if (protoConverter && protoConverter.external) c = c + getIdentifier(protoConverter.name);
						let ident = null;
						if (partialClass) ident = getIdentifier(partialClass.name);
						v = c + (partial.length === 0 ? "{}" : gap ? (partialClass ? ident : "") + "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : (partialClass ? ident : "") + "{" + partial.join(",") + "}");
						gap = mind;
						return v;
				}
			}
		}
	}
};
var encodings = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789$_";
var decodings = {
	"~": -1,
	"=": -1,
	"$": 62,
	"_": 63,
	"+": 62,
	"-": 62,
	".": 62,
	"/": 63,
	",": 63
};
for (let x = 0; x < 64; x++) decodings[encodings[x]] = x;
Object.freeze(decodings);
function base64ArrayBuffer(arrayBuffer) {
	let base64 = "";
	let bytes = new Uint8Array(arrayBuffer);
	let byteLength = bytes.byteLength;
	let byteRemainder = byteLength % 3;
	let mainLength = byteLength - byteRemainder;
	let a, b, c, d;
	let chunk;
	for (let i = 0; i < mainLength; i = i + 3) {
		chunk = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
		a = (chunk & 16515072) >> 18;
		b = (chunk & 258048) >> 12;
		c = (chunk & 4032) >> 6;
		d = chunk & 63;
		base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d];
	}
	if (byteRemainder == 1) {
		chunk = bytes[mainLength];
		a = (chunk & 252) >> 2;
		b = (chunk & 3) << 4;
		base64 += encodings[a] + encodings[b] + "==";
	} else if (byteRemainder == 2) {
		chunk = bytes[mainLength] << 8 | bytes[mainLength + 1];
		a = (chunk & 64512) >> 10;
		b = (chunk & 1008) >> 4;
		c = (chunk & 15) << 2;
		base64 += encodings[a] + encodings[b] + encodings[c] + "=";
	}
	return base64;
}
function DecodeBase64(buf) {
	let outsize;
	if (buf.length % 4 == 1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 3;
	else if (buf.length % 4 == 2) outsize = ((buf.length + 3) / 4 | 0) * 3 - 2;
	else if (buf.length % 4 == 3) outsize = ((buf.length + 3) / 4 | 0) * 3 - 1;
	else if (decodings[buf[buf.length - 3]] == -1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 3;
	else if (decodings[buf[buf.length - 2]] == -1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 2;
	else if (decodings[buf[buf.length - 1]] == -1) outsize = ((buf.length + 3) / 4 | 0) * 3 - 1;
	else outsize = ((buf.length + 3) / 4 | 0) * 3;
	let ab = new ArrayBuffer(outsize);
	let out = new Uint8Array(ab);
	let n;
	let l = buf.length + 3 >> 2;
	for (n = 0; n < l; n++) {
		let index0 = decodings[buf[n * 4]];
		let index1 = n * 4 + 1 < buf.length ? decodings[buf[n * 4 + 1]] : -1;
		let index2 = index1 >= 0 && n * 4 + 2 < buf.length ? decodings[buf[n * 4 + 2]] : -1;
		let index3 = index2 >= 0 && n * 4 + 3 < buf.length ? decodings[buf[n * 4 + 3]] : -1;
		if (index1 >= 0) out[n * 3 + 0] = index0 << 2 | index1 >> 4;
		if (index2 >= 0) out[n * 3 + 1] = index1 << 4 | index2 >> 2 & 15;
		if (index3 >= 0) out[n * 3 + 2] = index2 << 6 | index3 & 63;
	}
	return ab;
}
/**
* @param {unknown} object 
* @param {(this: unknown, key: string, value: unknown)} [replacer] 
* @param {string | number} [space] 
* @returns {string}
*/
JSOX.stringify = function(object, replacer, space) {
	return JSOX.stringifier().stringify(object, replacer, space);
};
[[
	0,
	256,
	[
		16767487,
		16739071,
		130048,
		3670016,
		0,
		16777208,
		16777215,
		8388607
	]
]].map((row) => {
	return {
		firstChar: row[0],
		lastChar: row[1],
		bits: row[2]
	};
});
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/UIState.ts
var mapEntriesFrom = (source) => {
	if (!source) return [];
	if (source instanceof Map) return Array.from(source.entries());
	if (Array.isArray(source)) return source.map((value, index) => {
		if (Array.isArray(value) && value.length === 2) return value;
		return [index, value];
	});
	if (source instanceof Set) return Array.from(source.values()).map((value, index) => [index, value]);
	if (typeof source === "object") return Object.entries(source);
	return [];
};
var ownProp = Object.prototype.hasOwnProperty;
var isPlainObject$1 = (value) => {
	if (!value || typeof value !== "object") return false;
	if (Array.isArray(value)) return false;
	return !(value instanceof Map) && !(value instanceof Set);
};
var identityOf = (value, fallback) => {
	if (value && typeof value === "object") {
		if ("id" in value && value.id != null) return value.id;
		if ("key" in value && value.key != null) return value.key;
	}
	return fallback;
};
var resolveEntryKey = (entryKey, value, fallback) => {
	if (entryKey != null) return entryKey;
	const identity = identityOf(value);
	if (identity != null) return identity;
	return fallback;
};
var mergePlainObject = (target, source) => {
	for (const key of Object.keys(source)) {
		const nextValue = source[key];
		const currentValue = target[key];
		if (isPlainObject$1(currentValue) && isPlainObject$1(nextValue)) {
			mergePlainObject(currentValue, nextValue);
			continue;
		}
		const merged = mergeValue(currentValue, nextValue);
		if (target[key] !== merged) target[key] = merged;
	}
	return target;
};
var mergeValue = (target, source) => {
	if (target === source) return target;
	const sourceIsObject = source && typeof source === "object";
	if (target instanceof Map && sourceIsObject) {
		reloadInto(target, source);
		return target;
	}
	if (target instanceof Set && sourceIsObject) {
		reloadInto(target, source);
		return target;
	}
	if (Array.isArray(target) && sourceIsObject) {
		reloadInto(target, source);
		return target;
	}
	if (isPlainObject$1(target) && isPlainObject$1(source)) {
		mergePlainObject(target, source);
		return target;
	}
	return source;
};
var reloadInto = (items, map) => {
	if (!items || !map) return items;
	const entries = mapEntriesFrom(map);
	if (!entries.length) return items;
	if (items instanceof Set) {
		const existingByKey = /* @__PURE__ */ new Map();
		for (const value of items.values()) {
			const key = identityOf(value);
			if (key != null) existingByKey.set(key, value);
		}
		const usedKeys = /* @__PURE__ */ new Set();
		for (const [entryKey, incoming] of entries) {
			const key = resolveEntryKey(entryKey, incoming);
			if (key == null) {
				if (!items.has(incoming)) items.add(incoming);
				continue;
			}
			const hasCurrent = existingByKey.has(key);
			const current = hasCurrent ? existingByKey.get(key) : void 0;
			if (hasCurrent) {
				const merged = mergeValue(current, incoming);
				if (merged !== current) {
					items.delete(current);
					items.add(merged);
					existingByKey.set(key, merged);
				}
			} else {
				items.add(incoming);
				existingByKey.set(key, incoming);
			}
			usedKeys.add(key);
		}
		if (usedKeys.size) for (const value of Array.from(items.values())) {
			const key = identityOf(value);
			if (key != null && !usedKeys.has(key)) items.delete(value);
		}
		return items;
	}
	if (items instanceof Map) {
		const nextMap = new Map(entries);
		for (const key of Array.from(items.keys())) if (!nextMap.has(key)) items.delete(key);
		for (const [key, incoming] of nextMap.entries()) if (items.has(key)) {
			const current = items.get(key);
			const merged = mergeValue(current, incoming);
			if (merged !== current) items.set(key, merged);
		} else items.set(key, incoming);
		return items;
	}
	if (Array.isArray(items)) {
		const availableIndexes = /* @__PURE__ */ new Set();
		const existingByKey = /* @__PURE__ */ new Map();
		const existingByObject = /* @__PURE__ */ new WeakMap();
		items.forEach((value, index) => {
			availableIndexes.add(index);
			const key = identityOf(value, index);
			if (key != null && !existingByKey.has(key)) existingByKey.set(key, index);
			if (value && typeof value === "object") existingByObject.set(value, index);
		});
		const takeIndex = (index) => {
			if (index == null) return void 0;
			if (!availableIndexes.has(index)) return void 0;
			availableIndexes.delete(index);
			return index;
		};
		const takeNextAvailable = () => {
			const iterator = availableIndexes.values().next();
			if (iterator.done) return void 0;
			const index = iterator.value;
			availableIndexes.delete(index);
			return index;
		};
		let writeIndex = 0;
		let fallbackIndex = 0;
		for (const [entryKey, incoming] of entries) {
			const key = resolveEntryKey(entryKey, incoming, fallbackIndex++);
			let claimedIndex = takeIndex(key != null ? existingByKey.get(key) : void 0);
			if (claimedIndex == null && incoming && typeof incoming === "object") claimedIndex = takeIndex(existingByObject.get(incoming));
			if (claimedIndex == null) claimedIndex = takeNextAvailable();
			const current = claimedIndex != null ? items[claimedIndex] : void 0;
			const merged = current !== void 0 ? mergeValue(current, incoming) : incoming;
			if (writeIndex < items.length) {
				if (items[writeIndex] !== merged) items[writeIndex] = merged;
			} else items.push(merged);
			writeIndex++;
		}
		while (items.length > writeIndex) items.pop();
		return items;
	}
	if (typeof items === "object") {
		const nextKeys = new Set(entries.map(([key]) => String(key)));
		for (const prop of Object.keys(items)) if (!nextKeys.has(prop)) delete items[prop];
		for (const [entryKey, incoming] of entries) {
			const prop = String(entryKey);
			if (ownProp.call(items, prop)) {
				const current = items[prop];
				const merged = mergeValue(current, incoming);
				if (merged !== current) items[prop] = merged;
			} else items[prop] = incoming;
		}
		return items;
	}
	return items;
};
var mergeByKey = (items, key = "id") => {
	if (items && (items instanceof Set || Array.isArray(items))) {
		const entries = Array.from(items?.values?.() || []).map((I) => [I?.[key], I]).filter((I) => I?.[0] != null);
		return reloadInto(items, new Map(entries));
	}
	return items;
};
var hasChromeStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
/**
* WHY: Vite symlink graphs can load lur.e twice. A module-local Map would leave
* the second copy's saveUIState() looking at an empty registry while the live
* state (and real saver) live in the first copy — silent no-op persists.
*/
var UI_STATE_SAVE_BOOT = "__CWSP_UI_STATE_SAVE_BY_KEY_V1__";
var uiStateSaveByKey = () => {
	const g = globalThis;
	if (!(g[UI_STATE_SAVE_BOOT] instanceof Map)) g[UI_STATE_SAVE_BOOT] = /* @__PURE__ */ new Map();
	return g[UI_STATE_SAVE_BOOT];
};
/** Call the registered saver for a makeUIState storage key (preferred over `(state).$save`). */
var saveUIState = (storageKey, ev) => {
	const save = uiStateSaveByKey().get(storageKey);
	if (typeof save === "function") save(ev);
};
var makeUIState = (storageKey, initialCb, unpackCb, packCb = (items) => safe(items), key = "id", saveInterval = 6e3) => {
	let state = null;
	state = mergeByKey(initialCb?.() || {}, key);
	let hydrated = !hasChromeStorage();
	if (hasChromeStorage()) chrome.storage.local.get([storageKey], (result) => {
		try {
			if (result[storageKey]) {
				const unpacked = unpackCb(JSOX.parse(result?.[storageKey] || "{}"));
				reloadInto(state, unpacked);
				mergeByKey(state, key);
			}
		} finally {
			hydrated = true;
		}
	});
	else if (typeof localStorage !== "undefined") {
		if (localStorage.getItem(storageKey)) {
			const unpacked = unpackCb(JSOX.parse(localStorage.getItem(storageKey) || "{}"));
			reloadInto(state, unpacked);
			mergeByKey(state, key);
		} else localStorage.setItem(storageKey, JSOX.stringify(packCb(state)));
		hydrated = true;
	}
	let lastPackedEcho = "";
	const saveInStorage = (ev) => {
		if (!hydrated) return;
		const packed = JSOX.stringify(packCb(mergeByKey(state, key)));
		lastPackedEcho = packed;
		if (hasChromeStorage()) chrome.storage.local.set({ [storageKey]: packed });
		else if (typeof localStorage !== "undefined") localStorage.setItem(storageKey, packed);
	};
	uiStateSaveByKey().set(storageKey, saveInStorage);
	setIdleInterval$1(saveInStorage, saveInterval);
	if (typeof window !== "undefined" && typeof document !== "undefined") {
		const listening = [
			addEvent(document, "visibilitychange", (ev) => {
				if (document.visibilityState === "hidden") saveInStorage(ev);
			}),
			addEvent(window, "beforeunload", (ev) => saveInStorage(ev)),
			addEvent(window, "pagehide", (ev) => saveInStorage(ev)),
			addEvent(window, "storage", (ev) => {
				if (ev.storageArea == localStorage && ev.key == storageKey) reloadInto(state, unpackCb(JSOX.parse(ev?.newValue || JSOX.stringify(packCb(mergeByKey(state, key))))));
			})
		];
		addToCallChain(state, Symbol.dispose, () => listening.forEach((ub) => ub?.()));
	}
	if (hasChromeStorage()) {
		const listener = (changes, area) => {
			if (area === "local" && changes[storageKey]) {
				const newValue = changes[storageKey].newValue;
				if (!newValue || newValue === lastPackedEcho) return;
				lastPackedEcho = typeof newValue === "string" ? newValue : JSOX.stringify(newValue);
				reloadInto(state, unpackCb(typeof newValue === "string" ? JSOX.parse(newValue) : newValue));
			}
		};
		chrome.storage.onChanged.addListener(listener);
	}
	if (state && typeof state === "object") try {
		Object.defineProperty(state, "$save", {
			value: saveInStorage,
			configurable: true,
			enumerable: false,
			writable: true
		});
	} catch (e) {
		state.$save = saveInStorage;
	}
	return state;
};
//#endregion
//#region ../../modules/projects/lur.e/src/design/anchor/PointerAnchor.ts
/** INVARIANT: use interactive/controllers (not legacy md-2025 path). */
var pointerAnchorRef = (root = typeof document != "undefined" ? document?.documentElement : null) => {
	if (!root) return () => {};
	const coordinate = [numberRef(0), numberRef(0)];
	coordinate.push(WRef(handleByPointer((ev) => {
		coordinate[0].value = ev.clientX;
		coordinate[1].value = ev.clientY;
	}, root)));
	if (coordinate[2]?.deref?.() ?? coordinate[2]) addToCallChain(coordinate, Symbol.dispose, coordinate[2]?.deref?.() ?? coordinate[2]);
	return coordinate;
};
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/ScrollBar.ts
makeRAFCycle();
try {
	CSS.registerProperty({
		name: "--percent-x",
		syntax: "<number>",
		inherits: true,
		initialValue: "0"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--percent-y",
		syntax: "<number>",
		inherits: true,
		initialValue: "0"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--scroll-coef",
		syntax: "<number>",
		inherits: true,
		initialValue: "1"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--determinant",
		syntax: "<number>",
		inherits: true,
		initialValue: "0"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--scroll-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--content-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--clamped-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--thumb-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--max-offset",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
try {
	CSS.registerProperty({
		name: "--max-size",
		syntax: "<length-percentage>",
		inherits: true,
		initialValue: "0px"
	});
} catch (e) {}
//#endregion
//#region ../../modules/projects/lur.e/src/interactive/modules/TemplateManager.ts
var TemplateManager = class {
	storageKey;
	templates = [];
	defaultTemplates;
	constructor(options = {}) {
		this.storageKey = options.storageKey || "rs-prompt-templates";
		this.defaultTemplates = options.defaultTemplates || this.getDefaultTemplates();
		this.loadTemplates();
	}
	/**
	* Get all templates
	*/
	getAllTemplates() {
		return [...this.templates];
	}
	/**
	* Get template by ID
	*/
	getTemplateById(id) {
		return this.templates.find((t) => t.id === id);
	}
	/**
	* Add a new template
	*/
	addTemplate(template) {
		const newTemplate = {
			...template,
			id: this.generateId(),
			createdAt: Date.now(),
			updatedAt: Date.now(),
			usageCount: 0
		};
		this.templates.push(newTemplate);
		this.saveTemplates();
		return newTemplate;
	}
	/**
	* Update an existing template
	*/
	updateTemplate(id, updates) {
		const index = this.templates.findIndex((t) => t.id === id);
		if (index === -1) return false;
		this.templates[index] = {
			...this.templates[index],
			...updates,
			updatedAt: Date.now()
		};
		this.saveTemplates();
		return true;
	}
	/**
	* Remove a template
	*/
	removeTemplate(id) {
		const index = this.templates.findIndex((t) => t.id === id);
		if (index === -1) return false;
		this.templates.splice(index, 1);
		this.saveTemplates();
		return true;
	}
	/**
	* Increment usage count for a template
	*/
	incrementUsageCount(id) {
		const template = this.templates.find((t) => t.id === id);
		if (template) {
			template.usageCount = (template.usageCount || 0) + 1;
			this.saveTemplates();
		}
	}
	/**
	* Search templates by name or content
	*/
	searchTemplates(query) {
		const lowercaseQuery = query.toLowerCase();
		return this.templates.filter((template) => template.name.toLowerCase().includes(lowercaseQuery) || template.prompt.toLowerCase().includes(lowercaseQuery) || template.tags?.some((tag) => tag.toLowerCase().includes(lowercaseQuery)));
	}
	/**
	* Get templates by category
	*/
	getTemplatesByCategory(category) {
		return this.templates.filter((template) => template.category === category);
	}
	/**
	* Get most used templates
	*/
	getMostUsedTemplates(limit = 5) {
		return this.templates.sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0)).slice(0, limit);
	}
	/**
	* Export templates as JSON
	*/
	exportTemplates() {
		return JSON.stringify(this.templates, null, 2);
	}
	/**
	* Import templates from JSON
	*/
	importTemplates(jsonData) {
		try {
			const importedTemplates = JSON.parse(jsonData);
			if (!Array.isArray(importedTemplates)) throw new Error("Invalid template data: not an array");
			for (const template of importedTemplates) if (!template.name || !template.prompt) throw new Error("Invalid template: missing name or prompt");
			const templatesWithIds = importedTemplates.map((template) => ({
				...template,
				id: this.generateId(),
				createdAt: template.createdAt || Date.now(),
				updatedAt: Date.now()
			}));
			this.templates.push(...templatesWithIds);
			this.saveTemplates();
			return true;
		} catch (error) {
			console.error("Failed to import templates:", error);
			return false;
		}
	}
	/**
	* Reset to default templates
	*/
	resetToDefaults() {
		this.templates = this.defaultTemplates.map((template) => ({
			...template,
			id: this.generateId(),
			createdAt: Date.now(),
			updatedAt: Date.now(),
			usageCount: 0
		}));
		this.saveTemplates();
	}
	/**
	* Create template editor modal
	*/
	createTemplateEditor(container, onSave) {
		const modal = H`<div class="template-editor-modal">
      <div class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>Prompt Templates</h3>
          </div>

          <div class="template-list">
            ${this.templates.map((template, index) => H`<div class="template-item">
                <div class="template-header">
                  <input type="text" class="template-name" value="${template.name}" data-index="${index}" placeholder="Template name">
                  <button class="btn small remove-template" data-index="${index}" title="Remove template">✕</button>
                </div>
                <textarea class="template-prompt" data-index="${index}" placeholder="Enter your prompt template...">${template.prompt}</textarea>
                <div class="template-meta">
                  ${template.usageCount ? H`<span class="usage-count">Used ${template.usageCount} times</span>` : ""}
                  ${template.category ? H`<span class="category">${template.category}</span>` : ""}
                </div>
              </div>`)}
          </div>

          <div class="modal-actions">
            <button class="btn" data-action="add-template">Add Template</button>
            <button class="btn" data-action="reset-defaults">Reset to Defaults</button>
            <button class="btn primary" data-action="save-templates">Save Changes</button>
            <button class="btn" data-action="close-editor">Close</button>
          </div>
        </div>
      </div>
    </div>`;
		modal.addEventListener("click", (e) => {
			const target = e.target;
			const action = target.getAttribute("data-action");
			const index = target.getAttribute("data-index");
			if (action === "add-template") {
				this.addTemplate({
					name: "New Template",
					prompt: "Enter your prompt template here...",
					category: "Custom"
				});
				modal.remove();
				this.createTemplateEditor(container, onSave);
			} else if (action === "reset-defaults") {
				if (confirm("Are you sure you want to reset all templates to defaults? This will remove all custom templates.")) {
					this.resetToDefaults();
					modal.remove();
					this.createTemplateEditor(container, onSave);
				}
			} else if (action === "save-templates") {
				const nameInputs = modal.querySelectorAll(".template-name");
				const promptInputs = modal.querySelectorAll(".template-prompt");
				this.templates = Array.from(nameInputs).map((input, i) => {
					const index = parseInt(input.getAttribute("data-index") || "0");
					return {
						...this.templates[index],
						name: input.value.trim() || "Untitled Template",
						prompt: promptInputs[i].value.trim() || "Enter your prompt...",
						updatedAt: Date.now()
					};
				});
				this.saveTemplates();
				modal.remove();
				onSave?.();
			} else if (action === "close-editor") modal.remove();
			else if (target.classList.contains("remove-template") && index !== null) {
				const templateIndex = parseInt(index);
				const template = this.templates[templateIndex];
				if (confirm(`Remove template "${template.name}"?`)) {
					this.removeTemplate(template.id);
					modal.remove();
					this.createTemplateEditor(container, onSave);
				}
			}
		});
		container.append(modal);
	}
	/**
	* Create template selector dropdown
	*/
	createTemplateSelect(selectedPrompt) {
		const select = document.createElement("select");
		select.className = "template-select";
		const defaultOption = document.createElement("option");
		defaultOption.value = "";
		defaultOption.textContent = "Select Template...";
		select.append(defaultOption);
		this.templates.forEach((template) => {
			const option = document.createElement("option");
			option.value = template.prompt;
			option.textContent = template.name;
			if (template.category) option.textContent += ` (${template.category})`;
			select.append(option);
		});
		if (selectedPrompt) select.value = selectedPrompt;
		return select;
	}
	getDefaultTemplates() {
		return [].map((template) => ({
			...template,
			id: this.generateId(),
			createdAt: Date.now(),
			updatedAt: Date.now(),
			usageCount: 0
		}));
	}
	generateId() {
		return `template_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
	}
	loadTemplates() {
		try {
			const stored = localStorage.getItem(this.storageKey);
			if (stored) {
				const parsedTemplates = JSON.parse(stored);
				this.templates = parsedTemplates.map((template) => ({
					...template,
					id: template.id || this.generateId(),
					createdAt: template.createdAt || Date.now(),
					updatedAt: template.updatedAt || Date.now(),
					usageCount: template.usageCount || 0
				}));
			} else this.resetToDefaults();
		} catch (error) {
			console.warn("Failed to load templates from storage:", error);
			this.resetToDefaults();
		}
	}
	saveTemplates() {
		try {
			localStorage.setItem(this.storageKey, JSON.stringify(this.templates));
		} catch (error) {
			console.warn("Failed to save templates to storage:", error);
		}
	}
};
/**
* Utility function to create a template manager
*/
function createTemplateManager(options) {
	return new TemplateManager(options);
}
//#endregion
//#region ../../modules/projects/lur.e/src/design/color/DynamicEngine.ts
var runWhenIdle = (cb, timeout = 100) => {
	if (typeof globalThis.requestIdleCallback === "function") return globalThis.requestIdleCallback(cb, { timeout });
	return setTimeout(() => cb({
		didTimeout: false,
		timeRemaining: () => 0
	}), 0);
};
var electronAPI = "electronBridge";
function extractAlpha(input) {
	if (typeof input !== "string") return null;
	let color = input.trim().toLowerCase();
	if (color === "transparent") return 0;
	if (color.startsWith("#")) {
		const hex = color;
		if (hex.length === 4) return 1;
		if (hex.length === 7) return 1;
		if (hex.length === 5) {
			const a = hex[4];
			const aa = a + a;
			return clamp(parseInt(aa, 16) / 255, 0, 1);
		}
		if (hex.length === 9) {
			const aa = hex.slice(7, 9);
			return clamp(parseInt(aa, 16) / 255, 0, 1);
		}
		return null;
	}
	const fnMatch = color.match(/^([a-z-]+)\((.*)\)$/i);
	if (!fnMatch) return null;
	fnMatch[1];
	const body = fnMatch[2].trim();
	{
		const slashIdx = body.lastIndexOf("/");
		if (slashIdx !== -1) {
			const a = parseAlphaComponent(body.slice(slashIdx + 1).trim());
			if (a != null) return clamp(a, 0, 1);
			return null;
		}
	}
	if (body.includes(",")) {
		const parts = body.split(",").map((s) => s.trim());
		if (parts.length >= 4) {
			const a = parseAlphaComponent(parts[3]);
			if (a != null) return clamp(a, 0, 1);
			return null;
		}
		return 1;
	}
	return 1;
}
function parseAlphaComponent(str) {
	if (!str) return null;
	if (str.endsWith("%")) {
		const n = parseFloat(str);
		if (Number.isNaN(n)) return null;
		return n / 100;
	}
	const n = parseFloat(str);
	if (Number.isNaN(n)) return null;
	return n;
}
function clamp(v, min, max) {
	return Math.min(max, Math.max(min, v));
}
var tacp = (color) => {
	if (!color || color == null) return 0;
	return (extractAlpha?.(color) || 0) > .1;
};
var setIdleInterval = (cb, timeout = 1e3, ...args) => {
	runWhenIdle(async () => {
		if (!cb || typeof cb != "function") return;
		while (true) {
			await Promise.try(cb, ...args);
			await new Promise((r) => setTimeout(r, timeout));
			await new Promise((r) => runWhenIdle(r, 100));
			await new Promise((r) => requestAnimationFrame(r));
		}
	}, 1e3);
};
/** Prefer real shell chrome (minimal nav / faint toolbar) for PWA title bar / WCO tint. */
var sampleShellToolbarBackgroundColor = () => {
	if (typeof document === "undefined") return null;
	try {
		const hosts = document.querySelectorAll("[data-shell]");
		for (const host of hosts) {
			const sr = host.shadowRoot;
			if (!sr) continue;
			const bar = sr.querySelector(".app-shell__nav, .app-shell__toolbar");
			if (!bar) continue;
			const bg = getComputedStyle(bar).backgroundColor;
			if (tacp(bg)) return bg;
		}
	} catch {}
	return null;
};
/** Under window-controls-overlay, sample inside env(titlebar-area-*) — not under OS control buttons. */
var sampleWcoTitlebarStripColor = () => {
	if (typeof document === "undefined") return null;
	if (!globalThis.matchMedia?.("(display-mode: window-controls-overlay)")?.matches) return null;
	const probe = document.createElement("div");
	probe.setAttribute("data-wco-theme-probe", "true");
	probe.style.cssText = [
		"position:fixed",
		"visibility:hidden",
		"pointer-events:none",
		"z-index:-2147483648",
		"left:env(titlebar-area-x,0px)",
		"top:env(titlebar-area-y,0px)",
		"width:env(titlebar-area-width,0px)",
		"height:env(titlebar-area-height,0px)"
	].join(";");
	document.documentElement.appendChild(probe);
	try {
		const r = probe.getBoundingClientRect();
		if (r.width < 1 || r.height < 1) return null;
		const c = pickBgColor(Math.floor(r.left + Math.min(40, r.width * .2)), Math.floor(r.top + r.height * .5));
		return tacp(c) ? c : null;
	} finally {
		probe.remove();
	}
};
var pickBgColor = (x, y, holder = null) => {
	const opaque = Array.from(document.elementsFromPoint(x, y))?.filter?.((el) => el instanceof HTMLElement && el != holder && (el?.dataset?.alpha != null ? parseFloat(el?.dataset?.alpha) > .01 : true) && el?.checkVisibility?.({
		contentVisibilityAuto: true,
		opacityProperty: true,
		visibilityProperty: true
	}) && el?.matches?.(":not([data-hidden])") && el?.style?.getPropertyValue("display") != "none").map((element) => {
		const computed = getComputedStyle?.(element);
		return {
			element,
			zIndex: parseInt(computed?.zIndex || "0", 10) || 0,
			color: computed?.backgroundColor || "transparent"
		};
	}).sort((a, b) => Math.sign(b.zIndex - a.zIndex)).filter(({ color }) => tacp(color));
	if (opaque?.[0]?.element instanceof HTMLElement) return opaque?.[0]?.color || "transparent";
	return "transparent";
};
var pickFromCenter = (holder) => {
	const box = holder?.getBoundingClientRect();
	if (box) {
		const Z = .5 * (fixedClientZoom?.() || 1);
		return pickBgColor(...[(box.left + box.right) * Z, (box.top + box.bottom) * Z], holder);
	}
};
var dynamicNativeFrame = (root = document.documentElement) => {
	let media = root?.querySelector?.("meta[data-theme-color]") ?? root?.querySelector?.("meta[name=\"theme-color\"]");
	if (!media && root == document.documentElement) {
		media = document.createElement("meta");
		media.setAttribute("name", "theme-color");
		media.setAttribute("data-theme-color", "");
		media.setAttribute("content", "transparent");
		document.head.appendChild(media);
	}
	try {
		const nativeOwned = Boolean(globalThis?.__CWSP_NATIVE_THEME_COLOR_OWNED__);
		const coveringWin = document.querySelector("ui-window[native-mode]:not([minimized])") || document.querySelector("ui-window[data-desk-max]:not([minimized]), ui-window[maximized]:not([minimized]), ui-window[data-mobile-max]:not([minimized])");
		if (nativeOwned || coveringWin) {
			if (nativeOwned) return;
			if (coveringWin?.shadowRoot && root == document.documentElement) {
				const title = coveringWin.shadowRoot.querySelector(".title-handler");
				const token = title && getComputedStyle(title).getPropertyValue("--ui-win-titlebar-bg").trim() || getComputedStyle(coveringWin).getPropertyValue("--ui-win-titlebar-bg").trim() || getComputedStyle(document.documentElement).getPropertyValue("--color-surface-container").trim();
				const bg = title ? getComputedStyle(title).backgroundColor : "";
				const candidate = (bg && tacp(bg) ? bg : null) || (token && tacp(token) ? token : null);
				if (candidate) {
					const low = String(candidate).toLowerCase();
					if (!/#007acc\b/.test(low) && !/rgba?\(\s*0\s*,\s*122\s*,\s*204/.test(low)) media?.setAttribute?.("content", candidate);
					return;
				}
			}
			return;
		}
	} catch {}
	const fromShell = sampleShellToolbarBackgroundColor();
	const fromWco = !fromShell ? sampleWcoTitlebarStripColor() : null;
	const fromSurface = !fromShell && !fromWco ? (() => {
		try {
			const raw = getComputedStyle(document.documentElement).getPropertyValue("--color-surface-container").trim();
			return raw && tacp(raw) ? raw : null;
		} catch {
			return null;
		}
	})() : null;
	const color = fromShell || fromWco || fromSurface;
	if (color && color !== "transparent" && (media || window?.["electronBridge"]) && root == document.documentElement) media?.setAttribute?.("content", color);
};
var dynamicBgColors = (root = document.documentElement) => {
	root.querySelectorAll("body, body > *, body > * > *").forEach((target) => {
		if (target) pickFromCenter(target);
	});
};
var dynamicTheme = (ROOT = document.documentElement) => {
	const startedKey = "__LURE_DYNAMIC_THEME_STARTED__";
	if (globalThis?.[startedKey]) return;
	globalThis[startedKey] = true;
	matchMedia("(prefers-color-scheme: dark)").addEventListener("change", ({}) => dynamicBgColors(ROOT));
	const updater = () => {
		dynamicNativeFrame(ROOT);
		dynamicBgColors(ROOT);
	};
	addEvent(ROOT, "u2-appear", () => runWhenIdle(updater, 100));
	addEvent(ROOT, "u2-hidden", () => runWhenIdle(updater, 100));
	addEvent(ROOT, "u2-theme-change", () => runWhenIdle(updater, 100));
	addEvent(window, "load", () => runWhenIdle(updater, 100));
	addEvent(document, "visibilitychange", () => runWhenIdle(updater, 100));
	setIdleInterval(updater, 500);
};
//#endregion
//#region ../../modules/projects/lur.e/src/design/color/ThemeEngine.ts
var colorScheme = async () => {
	dynamicNativeFrame();
	dynamicBgColors();
};
/**
* Opt-in autostart only.
* This module is re-exported from `fest/lure` root, so unconditional side effects
* here can start a competing theme-color loop in host apps.
*/
var maybeStartThemeEngine = () => {
	if (typeof document === "undefined") return;
	if (globalThis?.__LURE_AUTO_THEME_ENGINE__ !== true) return;
	requestAnimationFrame(() => colorScheme?.());
	dynamicTheme?.();
};
maybeStartThemeEngine();
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/OPFS.uniform.worker.ts?worker
function WorkerWrapper(options) {
	return new Worker("" + new URL("../assets/OPFS.uniform.worker-DBpDQLE5.js", import.meta.url).href, {
		type: "module",
		name: options?.name
	});
}
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/OPFS.ts
var workerChannel = null;
var isServiceWorker = typeof ServiceWorkerGlobalScope !== "undefined" && self instanceof ServiceWorkerGlobalScope;
var SW_BRIDGE_CHANNEL_NAME = "opfs-sw-bridge-v1";
var observers = /* @__PURE__ */ new Map();
var workerInitPromise = null;
var swBridgeChannel = null;
var swBridgeRequestCounter = 0;
var ensureSwBridgeChannel = () => {
	if (!isServiceWorker) return null;
	if (swBridgeChannel) return swBridgeChannel;
	try {
		if (typeof BroadcastChannel === "undefined") return null;
		swBridgeChannel = new BroadcastChannel(SW_BRIDGE_CHANNEL_NAME);
		return swBridgeChannel;
	} catch {
		return null;
	}
};
var postViaSwBridge = (type, payload = {}, timeoutMs = 2500) => {
	const channel = ensureSwBridgeChannel();
	if (!channel) return Promise.reject(/* @__PURE__ */ new Error("SW OPFS bridge is unavailable"));
	const requestId = `sw-opfs-${Date.now()}-${++swBridgeRequestCounter}`;
	return new Promise((resolve, reject) => {
		let timeoutId = null;
		const onMessage = (event) => {
			const data = event?.data || {};
			if (!data || typeof data !== "object") return;
			if (data?.type !== "opfs-sw-response") return;
			if (String(data?.requestId || "") !== requestId) return;
			channel.removeEventListener("message", onMessage);
			if (timeoutId) clearTimeout(timeoutId);
			if (data?.ok) resolve(data?.result);
			else reject(new Error(String(data?.error || "Unknown bridge error")));
		};
		channel.addEventListener("message", onMessage);
		timeoutId = setTimeout(() => {
			channel.removeEventListener("message", onMessage);
			reject(/* @__PURE__ */ new Error("SW OPFS bridge timeout"));
		}, timeoutMs);
		channel.postMessage({
			type: "opfs-sw-request",
			requestId,
			action: type,
			payload
		});
	});
};
var ensureWorker = () => {
	if (workerInitPromise) return workerInitPromise;
	workerInitPromise = new Promise(async (resolve) => {
		if (typeof Worker !== "undefined" && !isServiceWorker) try {
			const baseChannel = await createWorkerChannel({
				name: "opfs-worker",
				script: WorkerWrapper
			});
			workerChannel = new QueuedWorkerChannel("opfs-worker", async () => baseChannel, {
				timeout: 3e4,
				retries: 3,
				batching: true,
				compression: false
			});
			resolve(workerChannel);
		} catch (e) {
			console.warn("OPFSUniformWorker instantiation failed, falling back to main thread...", e);
			workerChannel = null;
			resolve(null);
		}
		else {
			workerChannel = null;
			resolve(null);
		}
	});
	return workerInitPromise;
};
var directHandlers = {
	readDirectory: async ({ rootId, path, create }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			let current = root;
			for (const part of parts) current = await current.getDirectoryHandle(part, { create });
			const entries = [];
			for await (const [name, entry] of current.entries()) entries.push([name, entry]);
			return entries;
		} catch (e) {
			console.warn("Direct readDirectory error:", e);
			return [];
		}
	},
	readFile: async ({ rootId, path, type }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			const filename = parts.pop();
			let dir = root;
			for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: false });
			const file = await (await dir.getFileHandle(filename, { create: false })).getFile();
			if (type === "text") return await file.text();
			if (type === "arrayBuffer") return await file.arrayBuffer();
			return file;
		} catch (e) {
			console.warn("Direct readFile error:", e);
			return null;
		}
	},
	writeFile: async ({ rootId, path, data }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			const filename = parts.pop();
			let dir = root;
			for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: true });
			const writable = await (await dir.getFileHandle(filename, { create: true })).createWritable();
			await writable.write(data);
			await writable.close();
			return true;
		} catch (e) {
			console.warn("Direct writeFile error:", e);
			return false;
		}
	},
	remove: async ({ rootId, path, recursive }) => {
		try {
			const root = await navigator.storage.getDirectory();
			const parts = (path || "").trim().replace(/\/+/g, "/").split("/").filter((p) => p);
			const name = parts.pop();
			let dir = root;
			for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: false });
			await dir.removeEntry(name, { recursive });
			return true;
		} catch {
			return false;
		}
	},
	copy: async ({ from, to }) => {
		try {
			const copyRecursive = async (source, dest) => {
				if (source.kind === "directory") for await (const [name, entry] of source.entries()) if (entry.kind === "directory") {
					const newDest = await dest.getDirectoryHandle(name, { create: true });
					await copyRecursive(entry, newDest);
				} else {
					const file = await entry.getFile();
					const writable = await (await dest.getFileHandle(name, { create: true })).createWritable();
					await writable.write(file);
					await writable.close();
				}
				else {
					const file = await source.getFile();
					const writable = await dest.createWritable();
					await writable.write(file);
					await writable.close();
				}
			};
			await copyRecursive(from, to);
			return true;
		} catch (e) {
			console.warn("Direct copy error:", e);
			return false;
		}
	},
	observe: async () => false,
	unobserve: async () => true,
	mount: async () => true,
	unmount: async () => true
};
var post = (type, payload = {}, transfer = []) => {
	if (isServiceWorker && directHandlers[type]) return postViaSwBridge(type, payload).catch(() => directHandlers[type](payload));
	return new Promise(async (resolve, reject) => {
		try {
			const channel = await ensureWorker();
			if (!channel) {
				if (directHandlers[type]) return resolve(directHandlers[type](payload));
				return reject(/* @__PURE__ */ new Error("No worker channel available"));
			}
			let result;
			try {
				result = await channel.request(type, payload);
			} catch (requestError) {
				if (directHandlers[type]) return resolve(directHandlers[type](payload));
				throw requestError;
			}
			if (result === false && (type === "writeFile" || type === "remove" || type === "copy")) {
				if (directHandlers[type]) return resolve(directHandlers[type](payload));
			}
			resolve(result);
		} catch (err) {
			if (directHandlers[type]) try {
				return resolve(directHandlers[type](payload));
			} catch (fallbackError) {
				return reject(fallbackError);
			}
			reject(err);
		}
	});
};
var getDir = (dest) => {
	if (typeof dest != "string") return dest;
	dest = dest?.trim?.() || dest;
	if (!dest?.endsWith?.("/")) dest = dest?.trim?.()?.split?.("/")?.slice(0, -1)?.join?.("/")?.trim?.() || dest;
	const p1 = !dest?.trim()?.endsWith("/") ? dest + "/" : dest;
	return !p1?.startsWith("/") ? "/" + p1 : p1;
};
var generalFileImportDesc = {
	startIn: "documents",
	multiple: false,
	types: [{
		description: "files",
		accept: { "application/*": [
			".txt",
			".md",
			".html",
			".htm",
			".css",
			".js",
			".json",
			".csv",
			".xml",
			".jpg",
			".jpeg",
			".png",
			".gif",
			".webp",
			".svg",
			".ico",
			".mp3",
			".wav",
			".mp4",
			".webm",
			".pdf",
			".zip",
			".rar",
			".7z"
		] }
	}]
};
var mappedRoots = /* @__PURE__ */ new Map([
	["/", async () => await navigator?.storage?.getDirectory?.()],
	["/user/", async () => await navigator?.storage?.getDirectory?.()],
	["/assets/", async () => {
		console.warn("Backend related API not implemented!");
		return null;
	}]
]);
var currentHandleMap = /* @__PURE__ */ new Map();
/** Virtual Explorer / OPFS roots that `provide()` can read without HTTP. */
var isVirtualFsPath = (path) => {
	const raw = String(path || "").trim();
	if (!raw) return false;
	let p = raw;
	try {
		if (/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(raw)) p = new URL(raw).pathname;
	} catch {}
	if (!p.startsWith("/")) p = `/${p}`;
	if (p === "/user" || p.startsWith("/user/") || p === "/mounts" || p.startsWith("/mounts/") || p === "/sdcard" || p.startsWith("/sdcard/") || p === "/saf" || p.startsWith("/saf/")) return true;
	for (const root of mappedRoots.keys()) if (p === root || p.startsWith(root) || `${p}/` === root) return true;
	return false;
};
var matchMappedRoot = (path) => {
	let p = String(path || "").trim() || "/";
	try {
		if (/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(p)) p = new URL(p).pathname || p;
	} catch {}
	if (!p.startsWith("/")) p = `/${p}`;
	let best = null;
	let bestLen = -1;
	for (const [root, resolver] of mappedRoots.entries()) if (p === root || p.startsWith(root) || `${p}/` === root) {
		if (root.length > bestLen) {
			best = {
				root,
				resolver
			};
			bestLen = root.length;
		}
	}
	return best;
};
/**
* WHY: `getFileHandle` hyphen-rewrites OPFS `/user/` names. Local
* `showDirectoryPicker` trees must keep exact filenames (`My Image.png`).
*/
var walkExactFile = async (root, rel) => {
	const parts = String(rel || "").split("/").filter(Boolean);
	if (!parts.length) return null;
	let dir = root;
	for (const seg of parts.slice(0, -1)) try {
		dir = await dir.getDirectoryHandle(seg, { create: false });
	} catch {
		return null;
	}
	try {
		return await dir.getFileHandle(parts[parts.length - 1], { create: false });
	} catch {
		return null;
	}
};
/** Register a directory handle as a virtual root (`/mounts/<id>/`, etc.). */
var registerDirectoryRoot = (root, handle) => {
	if (!handle) return;
	const key = String(root || "").endsWith("/") ? String(root) : `${root}/`;
	if (!key.startsWith("/")) return;
	mappedRoots.set(key, async () => handle);
	const segs = key.split("/").filter(Boolean);
	if (segs[0] === "mounts" && segs[1]) currentHandleMap.set(segs[1], handle);
	currentHandleMap.set(key, handle);
};
var unregisterDirectoryRoot = (root) => {
	const key = String(root || "").endsWith("/") ? String(root) : `${root}/`;
	mappedRoots.delete(key);
	currentHandleMap.delete(key);
	const segs = key.split("/").filter(Boolean);
	if (segs[0] === "mounts" && segs[1]) currentHandleMap.delete(segs[1]);
};
async function resolveRootHandle(rootHandle, relPath = "") {
	if (rootHandle == null || rootHandle == void 0 || rootHandle?.trim?.()?.length == 0) rootHandle = "/user/";
	const cleanId = typeof rootHandle == "string" ? rootHandle?.trim?.()?.replace?.(/^\//, "")?.trim?.()?.split?.("/")?.filter?.((p) => !!p?.trim?.())?.at?.(0) : null;
	if (cleanId) {
		if (typeof localStorage != "undefined" && JSON.parse(localStorage?.getItem?.("opfs.mounted") || "[]").includes(cleanId)) rootHandle = currentHandleMap?.get(cleanId);
		if (!rootHandle) rootHandle = await mappedRoots?.get?.(`/${cleanId}/`)?.() ?? await navigator.storage.getDirectory();
	}
	if (rootHandle instanceof FileSystemDirectoryHandle) return rootHandle;
	const normalizedPath = relPath?.trim?.() || "/";
	const pathForMatch = normalizedPath.startsWith("/") ? normalizedPath : "/" + normalizedPath;
	let bestMatch = null;
	let bestMatchLength = 0;
	for (const [rootPath, rootResolver] of mappedRoots.entries()) if (pathForMatch.startsWith(rootPath) && rootPath.length > bestMatchLength) {
		bestMatch = rootResolver;
		bestMatchLength = rootPath.length;
	}
	try {
		return (bestMatch ? await bestMatch() : null) || await navigator?.storage?.getDirectory?.();
	} catch (error) {
		console.warn("Failed to resolve root handle, falling back to OPFS root:", error);
		return await navigator?.storage?.getDirectory?.();
	}
}
function normalizePath(basePath = "", relPath) {
	if (!relPath?.trim()) return basePath;
	const cleanRelPath = relPath.trim();
	if (cleanRelPath.startsWith("/")) return cleanRelPath;
	const baseParts = basePath.split("/").filter((p) => p?.trim());
	const relParts = cleanRelPath.split("/").filter((p) => p?.trim());
	for (const part of relParts) if (part === ".") continue;
	else if (part === "..") {
		if (baseParts.length > 0) baseParts.pop();
	} else baseParts.push(part);
	return "/" + baseParts.join("/");
}
async function resolvePath(rootHandle, relPath, basePath = "") {
	const normalizedRelPath = normalizePath(basePath, relPath);
	return {
		rootHandle: await resolveRootHandle(rootHandle, normalizedRelPath),
		resolvedPath: normalizedRelPath
	};
}
function handleError(logger, status, message) {
	logger?.(status, message);
	return null;
}
function defaultLogger(status, message) {
	console.trace(`[${status}] ${message}`);
}
function detectTypeByRelPath(relPath) {
	if (relPath?.trim()?.endsWith?.("/")) return "directory";
	return "file";
}
function getMimeTypeByFilename(filename) {
	return {
		"txt": "text/plain",
		"md": "text/markdown",
		"html": "text/html",
		"htm": "text/html",
		"css": "text/css",
		"js": "application/javascript",
		"json": "application/json",
		"csv": "text/csv",
		"xml": "application/xml",
		"jpg": "image/jpeg",
		"jpeg": "image/jpeg",
		"png": "image/png",
		"gif": "image/gif",
		"webp": "image/webp",
		"svg": "image/svg+xml",
		"ico": "image/x-icon",
		"mp3": "audio/mpeg",
		"wav": "audio/wav",
		"mp4": "video/mp4",
		"webm": "video/webm",
		"pdf": "application/pdf",
		"zip": "application/zip",
		"rar": "application/vnd.rar",
		"7z": "application/x-7z-compressed"
	}[filename?.split?.(".")?.pop?.()?.toLowerCase?.()] || "application/octet-stream";
}
var hasFileExtension = (path) => {
	return path?.trim?.()?.split?.(".")?.[1]?.trim?.()?.length > 0;
};
async function getDirectoryHandle(rootHandle, relPath, { create = false, basePath = "" } = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, basePath);
		const parts = stripUserScopePrefix(resolvedPath).split("/").filter((p) => !!p?.trim?.());
		if (parts.length > 0 && hasFileExtension(parts[parts.length - 1]?.trim?.())) parts?.pop?.();
		let dir = resolvedRoot;
		if (parts?.length > 0) for (const part of parts) {
			dir = await dir?.getDirectoryHandle?.(part, { create });
			if (!dir) break;
		}
		return dir;
	} catch (e) {
		return handleError(logger, "error", `getDirectoryHandle: ${e.message}`);
	}
}
async function getFileHandle(rootHandle, relPath, { create = false, basePath = "" } = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, basePath);
		const cleanPath = stripUserScopePrefix(resolvedPath);
		const parts = cleanPath.split("/").filter((d) => !!d?.trim?.());
		if (parts?.length == 0) return null;
		const filePath = parts.length > 0 ? parts[parts.length - 1]?.trim?.()?.replace?.(/\s+/g, "-") : "";
		const dirName = parts.length > 1 ? parts?.slice(0, -1)?.join?.("/")?.trim?.()?.replace?.(/\s+/g, "-") : "";
		if (cleanPath?.trim?.()?.endsWith?.("/")) return null;
		return (await getDirectoryHandle(resolvedRoot, dirName, {
			create,
			basePath
		}, logger))?.getFileHandle?.(filePath, { create });
	} catch (e) {
		return handleError(logger, "error", `getFileHandle: ${e.message}`);
	}
}
async function getHandler(rootHandle, relPath, options = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRootHandle, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
		if (detectTypeByRelPath(resolvedPath) == "directory") {
			const dir = await getDirectoryHandle(resolvedRootHandle, resolvedPath?.trim?.()?.replace?.(/\/$/, ""), options, logger);
			if (dir) return {
				type: "directory",
				handle: dir
			};
		} else {
			const file = await getFileHandle(resolvedRootHandle, resolvedPath, options, logger);
			if (file) return {
				type: "file",
				handle: file
			};
		}
		return null;
	} catch (e) {
		return handleError(logger, "error", `getHandler: ${e.message}`);
	}
}
var directoryCacheMap = /* @__PURE__ */ new Map();
function openDirectory(rootHandle, relPath, options = { create: false }, logger = defaultLogger) {
	let cacheKey = "";
	let localMapCache = observe(/* @__PURE__ */ new Map());
	const statePromise = (async () => {
		try {
			const { rootHandle: resolvedRootHandle, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
			cacheKey = `${resolvedRootHandle?.name || "root"}:${resolvedPath}`;
			return {
				rootHandle: resolvedRootHandle,
				resolvedPath
			};
		} catch {
			return {
				rootHandle: null,
				resolvedPath: ""
			};
		}
	})().then(async ({ rootHandle, resolvedPath }) => {
		if (!resolvedPath) return null;
		const existing = directoryCacheMap.get(cacheKey);
		if (existing) {
			existing.refCount++;
			localMapCache = existing.mapCache;
			return existing;
		}
		const mapCache = observe(/* @__PURE__ */ new Map());
		localMapCache = mapCache;
		const observationId = UUIDv4();
		const dirHandlePromise = getDirectoryHandle(rootHandle, resolvedPath, options, logger);
		const updateCache = async () => {
			const entries = await post("readDirectory", {
				rootId: "",
				path: stripUserScopePrefix(resolvedPath),
				create: options.create
			}, rootHandle ? [rootHandle] : []);
			if (!entries) return mapCache;
			const entryMap = new Map(entries);
			for (const key of mapCache.keys()) if (!entryMap.has(key)) mapCache.delete(key);
			for (const [key, handle] of entryMap) if (!mapCache.has(key)) mapCache.set(key, handle);
			return mapCache;
		};
		const cleanup = () => {
			post("unobserve", { id: observationId });
			observers.delete(observationId);
			directoryCacheMap.delete(cacheKey);
		};
		observers.set(observationId, (changes) => {
			for (const change of changes) {
				if (!change?.name) continue;
				if (change.type === "modified" || change.type === "created" || change.type === "appeared") mapCache.set(change.name, change.handle);
				else if (change.type === "deleted" || change.type === "disappeared") mapCache.delete(change.name);
			}
		});
		post("observe", {
			rootId: "",
			path: stripUserScopePrefix(resolvedPath),
			id: observationId
		}, rootHandle ? [rootHandle] : []);
		updateCache();
		const newState = {
			mapCache,
			dirHandle: dirHandlePromise,
			resolvePath: resolvedPath,
			observationId,
			refCount: 1,
			cleanup,
			updateCache
		};
		directoryCacheMap.set(cacheKey, newState);
		const entries = await Promise.all(await Array.fromAsync((await dirHandlePromise)?.entries?.() ?? []));
		for (const [name, handle] of entries) if (!mapCache.has(name)) mapCache.set(name, handle);
		return {
			...newState,
			mapCache
		};
	});
	let disposed = false;
	const dispose = () => {
		if (disposed) return;
		disposed = true;
		statePromise.then((s) => {
			if (!s) return;
			s.refCount--;
			if (s.refCount <= 0) s.cleanup();
		}).catch(console.warn);
	};
	const handler = {
		get(_target, prop) {
			if (prop === Symbol.toStringTag || prop === Symbol.iterator || prop === "toString" || prop === "valueOf" || prop === "inspect" || prop === "constructor" || prop === "__proto__" || prop === "prototype") return;
			if (prop === "dispose") return dispose;
			if (prop === "getMap") return () => localMapCache;
			if (prop === "entries") return () => localMapCache.entries();
			if (prop === "keys") return () => localMapCache.keys();
			if (prop === "values") return () => localMapCache.values();
			if (prop === Symbol.iterator) return () => localMapCache[Symbol.iterator]();
			if (prop === "size") return localMapCache.size;
			if (prop === "has") return (k) => localMapCache.has(k);
			if (prop === "get") return (k) => localMapCache.get(k);
			if (prop === "entries") return () => localMapCache.entries();
			if (prop === "keys") return () => localMapCache.keys();
			if (prop === "values") return () => localMapCache.values();
			if (prop === "refresh") return () => statePromise.then((s) => s?.updateCache?.()).then(() => pxy);
			if (prop === "then" || prop === "catch" || prop === "finally") {
				const p = statePromise.then(() => true);
				return p[prop].bind(p);
			}
			return (...args) => statePromise.then(async (s) => {
				if (!s) return void 0;
				const dh = await s.dirHandle;
				const v = dh?.[prop];
				if (typeof v === "function") return v.apply(dh, args);
				return v;
			});
		},
		ownKeys() {
			return Array.from(localMapCache.keys());
		},
		getOwnPropertyDescriptor() {
			return {
				enumerable: true,
				configurable: true
			};
		}
	};
	const fx = function() {};
	const pxy = new Proxy(fx, handler);
	return pxy;
}
async function readFile(rootHandle, relPath, options = {}, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
		return await post("readFile", {
			rootId: "",
			path: stripUserScopePrefix(resolvedPath),
			type: "blob"
		}, resolvedRoot ? [resolvedRoot] : []);
	} catch (e) {
		return handleError(logger, "error", `readFile: ${e.message}`);
	}
}
async function writeFile(rootHandle, relPath, data, logger = defaultLogger) {
	if (data instanceof FileSystemFileHandle) data = await data.getFile();
	if (data instanceof FileSystemDirectoryHandle) {
		const dstHandle = await getDirectoryHandle(await resolveRootHandle(rootHandle), relPath + (relPath?.trim?.()?.endsWith?.("/") ? "" : "/") + (data?.name || "")?.trim?.()?.replace?.(/\s+/g, "-"), { create: true });
		return await copyFromOneHandlerToAnother(data, dstHandle, {})?.catch?.(console.warn.bind(console));
	} else try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, "");
		return await post("writeFile", {
			rootId: "",
			path: stripUserScopePrefix(resolvedPath),
			data
		}, resolvedRoot ? [resolvedRoot] : []) !== false;
	} catch (e) {
		return handleError(logger, "error", `writeFile: ${e.message}`);
	}
}
async function removeFile(rootHandle, relPath, options = { recursive: true }, logger = defaultLogger) {
	try {
		const { rootHandle: resolvedRoot, resolvedPath } = await resolvePath(rootHandle, relPath, options?.basePath || "");
		const candidates = userPathCandidates(resolvedPath);
		let lastResult = false;
		for (const candidate of candidates) {
			lastResult = await post("remove", {
				rootId: "",
				path: candidate,
				recursive: options.recursive
			}, resolvedRoot ? [resolvedRoot] : []);
			if (lastResult !== false) return true;
		}
		return lastResult !== false;
	} catch (e) {
		return handleError(logger, "error", `removeFile: ${e.message}`);
	}
}
async function remove(rootHandle, relPath, options = {}, logger = defaultLogger) {
	try {
		return removeFile(rootHandle, relPath, {
			recursive: true,
			...options
		}, logger);
	} catch (e) {
		return handleError(logger, "error", `remove: ${e.message}`);
	}
}
var downloadFile = async (file, filename) => {
	if (file instanceof FileSystemFileHandle) file = await file.getFile();
	if (typeof file == "string") file = await provide(file);
	filename = filename ?? file?.name;
	if (!filename) return;
	if ("msSaveOrOpenBlob" in self.navigator) self.navigator.msSaveOrOpenBlob(file, filename);
	if (file instanceof FileSystemDirectoryHandle) {
		let dstHandle = await showDirectoryPicker?.({ mode: "readwrite" })?.catch?.(console.warn.bind(console));
		if (file && dstHandle) {
			dstHandle = await getDirectoryHandle(dstHandle, file?.name || "", { create: true })?.catch?.(console.warn.bind(console)) || dstHandle;
			return await copyFromOneHandlerToAnother(file, dstHandle, {})?.catch?.(console.warn.bind(console));
		}
		return;
	}
	const fx = await (self?.showOpenFilePicker ? new Promise((r) => r({
		showOpenFilePicker: self?.showOpenFilePicker?.bind?.(window),
		showSaveFilePicker: self?.showSaveFilePicker?.bind?.(window)
	})) : import("./app11.js"));
	if (window?.showSaveFilePicker) {
		const writableFileStream = await (await fx?.showSaveFilePicker?.({ suggestedName: filename })?.catch?.(console.warn.bind(console)))?.createWritable?.({ keepExistingData: true })?.catch?.(console.warn.bind(console));
		await writableFileStream?.write?.(file)?.catch?.(console.warn.bind(console));
		await writableFileStream?.close?.()?.catch?.(console.warn.bind(console));
	} else {
		const a = document.createElement("a");
		try {
			a.href = URL.createObjectURL(file);
		} catch (e) {
			console.warn(e);
		}
		a.download = filename;
		document.body.appendChild(a);
		a.click();
		setTimeout(function() {
			document.body.removeChild(a);
			globalThis.URL.revokeObjectURL(a.href);
		}, 0);
	}
};
var provide = async (req = "", rw = false) => {
	const requestUrl = (typeof req === "string" ? req : req?.url || "").trim();
	if (!requestUrl) return null;
	let pathname = requestUrl;
	try {
		pathname = new URL(requestUrl, location?.origin || self?.location?.origin || "http://localhost").pathname || requestUrl;
	} catch {}
	const cleanPath = pathname?.trim?.() || "/";
	if (cleanPath?.startsWith?.("/user")) {
		const path = stripUserScopePrefix(cleanPath);
		const root = await navigator?.storage?.getDirectory?.();
		if (!root) return null;
		const handle = await getFileHandle(root, path, { create: !!rw }).catch(() => null);
		if (!handle) return null;
		if (rw) return handle?.createWritable?.();
		return handle?.getFile?.();
	}
	const mapped = matchMappedRoot(cleanPath);
	if (mapped && mapped.root !== "/user/" && mapped.root !== "/") {
		const dir = await mapped.resolver().catch(() => null);
		if (dir instanceof FileSystemDirectoryHandle) {
			const fileHandle = await walkExactFile(dir, cleanPath.startsWith(mapped.root) ? cleanPath.slice(mapped.root.length) : cleanPath.replace(/^\/+/, ""));
			if (!fileHandle) return null;
			if (rw) return fileHandle.createWritable?.();
			return fileHandle.getFile?.();
		}
		return null;
	}
	if (rw) return null;
	if (isVirtualFsPath(cleanPath)) return null;
	try {
		const baseOrigin = String(location?.origin || self?.location?.origin || "").trim();
		const fetchTarget = cleanPath.startsWith("/") ? new URL(cleanPath, baseOrigin || "http://localhost").toString() : requestUrl;
		const r = await fetch(fetchTarget);
		const blob = await r?.blob()?.catch?.(console.warn.bind(console));
		const lastModifiedHeader = r?.headers?.get?.("Last-Modified");
		const lastModified = lastModifiedHeader ? Date.parse(lastModifiedHeader) : 0;
		if (blob) {
			const fallbackName = cleanPath?.substring?.(cleanPath?.lastIndexOf?.("/") + 1) || "resource";
			return new File([blob], fallbackName, {
				type: blob?.type,
				lastModified: isNaN(lastModified) ? 0 : lastModified
			});
		}
	} catch (e) {
		return handleError(defaultLogger, "error", `provide: ${e.message}`);
	}
	return null;
};
var dropFile = async (file, dest = "/user/".trim?.()?.replace?.(/\s+/g, "-"), current) => {
	const fs = await resolveRootHandle(null);
	const user = getDir(stripUserScopePrefix(dest))?.replace?.("/user", "")?.trim?.();
	file = file instanceof File ? file : new File([file], UUIDv4() + "." + (file?.type?.split?.("/")?.[1] || "tmp"));
	const fp = user + (file?.name || "wallpaper")?.trim?.()?.replace?.(/\s+/g, "-");
	await writeFile(fs, fp, file);
	current?.set?.("/user" + fp?.trim?.()?.replace?.(/\s+/g, "-"), file);
	return "/user" + fp?.trim?.();
};
var uploadFile = async (dest = "/user/".trim?.()?.replace?.(/\s+/g, "-"), current) => {
	const $e = "showOpenFilePicker";
	dest = stripUserScopePrefix(dest);
	return (window?.[$e]?.bind?.(window) ?? (await import("./app11.js"))?.[$e])({
		...generalFileImportDesc,
		multiple: true
	})?.then?.(async (handles = []) => {
		for (const handle of handles) await dropFile(handle instanceof File ? handle : await handle?.getFile?.(), dest, current);
	});
};
var ghostImage = typeof Image != "undefined" ? new Image() : null;
if (ghostImage) {
	ghostImage.decoding = "async";
	ghostImage.width = 24;
	ghostImage.height = 24;
	try {
		ghostImage.src = URL.createObjectURL(new Blob([`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 384 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M0 64C0 28.7 28.7 0 64 0L224 0l0 128c0 17.7 14.3 32 32 32l128 0 0 288c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zm384 64l-128 0L256 0 384 128z"/></svg>`], { type: "image/svg+xml" }));
	} catch (e) {}
}
var copyFromOneHandlerToAnother = async (fromHandle, toHandle, options = {}, logger = defaultLogger) => {
	return post("copy", {
		from: fromHandle,
		to: toHandle
	}, [fromHandle, toHandle]);
};
var handleIncomingEntries = (data, destPath = "/user/", rootHandle = null, onItemHandled) => {
	const tasks = [];
	const items = Array.from(data?.items ?? []);
	const files = Array.from(data?.files ?? []);
	const dataArray = Array.isArray(data) ? data : [...data?.[Symbol.iterator] ? data : [data]];
	return Promise.try(async () => {
		const resolvedRoot = await resolveRootHandle(rootHandle);
		const processItem = async (item) => {
			let handle;
			if (item.kind === "file" || item.kind === "directory") try {
				handle = await item.getAsFileSystemHandle?.();
			} catch {}
			if (handle) {
				if (handle.kind === "directory") {
					const nwd = await getDirectoryHandle(resolvedRoot, destPath + (handle.name || "").trim().replace(/\s+/g, "-"), { create: true });
					if (nwd) tasks.push(copyFromOneHandlerToAnother(handle, nwd, { create: true }));
				} else {
					const file = await handle.getFile();
					const path = destPath + (file.name || handle.name).trim().replace(/\s+/g, "-");
					tasks.push(writeFile(resolvedRoot, path, file).then(() => onItemHandled?.(file, path)));
				}
				return;
			}
			if (item.kind === "file" || item instanceof File) {
				const file = item instanceof File ? item : item.getAsFile();
				if (file) {
					const path = destPath + file.name.trim().replace(/\s+/g, "-");
					tasks.push(writeFile(resolvedRoot, path, file).then(() => onItemHandled?.(file, path)));
				}
				return;
			}
		};
		if (items?.length > 0) for (const item of items) await processItem(item);
		if (files?.length > 0) for (const file of files) await processItem(file);
		if (dataArray?.length > 0) for (const item of dataArray) await processItem(item);
		const uriList = data?.getData?.("text/uri-list") || data?.getData?.("text/plain");
		if (uriList && typeof uriList === "string") {
			const urls = uriList.split(/\r?\n/).filter(Boolean);
			for (const url of urls) {
				if (url.startsWith("file://")) continue;
				if (url.startsWith("/user/")) {
					const src = url.trim();
					tasks.push(Promise.try(async () => {
						const srcHandle = await getHandler(resolvedRoot, src);
						if (srcHandle?.handle) {
							const name = src.split("/").filter(Boolean).pop();
							if (srcHandle.type === "directory") {
								const nwd = await getDirectoryHandle(resolvedRoot, destPath + name, { create: true });
								await copyFromOneHandlerToAnother(srcHandle.handle, nwd, { create: true });
							} else {
								const file = await srcHandle.handle.getFile();
								const path = destPath + name;
								await writeFile(resolvedRoot, path, file);
								onItemHandled?.(file, path);
							}
						}
					}));
				} else tasks.push(Promise.try(async () => {
					const file = await provide(url);
					if (file) {
						const path = destPath + file.name;
						await writeFile(resolvedRoot, path, file);
						onItemHandled?.(file, path);
					}
				}));
			}
		}
		if (dataArray?.[0] instanceof ClipboardItem) {
			for (const item of dataArray) for (const type of item.types) if (type.startsWith("image/") || type.startsWith("text/")) {
				const blob = await item.getType(type);
				const ext = type.split("/")[1].split("+")[0] || "txt";
				const file = new File([blob], `clipboard-${Date.now()}.${ext}`, { type });
				const path = destPath + file.name;
				tasks.push(writeFile(resolvedRoot, path, file).then(() => onItemHandled?.(file, path)));
			}
		}
		await Promise.allSettled(tasks).catch(console.warn.bind(console));
	});
};
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/WriteFileSmart-v2.ts
var lureFsPromise = null;
var getLureFs = () => {
	if (!lureFsPromise) lureFsPromise = Promise.resolve().then(() => src_exports).then((m) => ({
		readFile: m.readFile,
		writeFile: m.writeFile
	}));
	return lureFsPromise;
};
var toSlug = (input, toLower = true) => {
	let s = String(input || "").trim();
	if (toLower) s = s.toLowerCase();
	s = s.replace(/\s+/g, "-");
	s = s.replace(/[^a-z0-9_.\-+#&]/g, "-");
	s = s.replace(/-+/g, "-");
	return s;
};
var inferExtFromMime = (mime = "") => {
	if (!mime) return "";
	if (mime.includes("json")) return "json";
	if (mime.includes("markdown")) return "md";
	if (mime.includes("plain")) return "txt";
	if (mime === "image/jpeg" || mime === "image/jpg") return "jpg";
	if (mime === "image/png") return "png";
	if (mime.startsWith("image/")) return mime.split("/").pop() || "";
	if (mime.includes("html")) return "html";
	return "";
};
var splitPath = (path) => String(path || "").split("/").filter(Boolean);
var ensureDir = (p) => p.endsWith("/") ? p : p + "/";
var joinPath = (parts, absolute = true) => (absolute ? "/" : "") + parts.filter(Boolean).join("/");
var sanitizePathSegments = (path) => {
	return joinPath(splitPath(path).map((p) => toSlug(p)));
};
var DEFAULT_ARRAY_KEYS = [
	"id",
	"_id",
	"key",
	"slug",
	"name"
];
var isPlainObject = (v) => Object.prototype.toString.call(v) === "[object Object]";
function dedupeArray(items, opts) {
	const keys = Array.isArray(opts.arrayKey) ? opts.arrayKey : opts.arrayKey ? [opts.arrayKey] : DEFAULT_ARRAY_KEYS;
	const result = [];
	const primitiveSet = /* @__PURE__ */ new Set();
	const objMap = /* @__PURE__ */ new Map();
	const stringifiedSet = /* @__PURE__ */ new Set();
	for (const it of items) {
		if (it == null) continue;
		if (isPlainObject(it)) {
			let dedupeKey;
			for (const k of keys) if (k in it && it[k] != null) {
				dedupeKey = String(it[k]);
				break;
			}
			if (dedupeKey != null) {
				if (!objMap.has(dedupeKey)) {
					objMap.set(dedupeKey, it);
					result.push(it);
				}
			} else {
				const sig = safeStableStringify(it);
				if (!stringifiedSet.has(sig)) {
					stringifiedSet.add(sig);
					result.push(it);
				}
			}
		} else if (Array.isArray(it)) {
			const sig = safeStableStringify(it);
			if (!stringifiedSet.has(sig)) {
				stringifiedSet.add(sig);
				result.push(it);
			}
		} else if (!primitiveSet.has(it)) {
			primitiveSet.add(it);
			result.push(it);
		}
	}
	return result;
}
function mergeDeepUnique(a, b, opts) {
	if (Array.isArray(a) && Array.isArray(b)) switch (opts.arrayStrategy) {
		case "replace": return b.slice();
		case "concat": return a.concat(b);
		default: return dedupeArray(a.concat(b), { arrayKey: opts.arrayKey });
	}
	if (isPlainObject(a) && isPlainObject(b)) {
		const out = { ...a };
		for (const k of Object.keys(b)) if (k in a) out[k] = mergeDeepUnique(a[k], b[k], opts);
		else out[k] = b[k];
		return out;
	}
	return b;
}
function safeStableStringify(obj) {
	if (!isPlainObject(obj)) return JSON.stringify(obj);
	const keys = Object.keys(obj).sort();
	const o = {};
	for (const k of keys) o[k] = obj[k];
	return JSON.stringify(o);
}
async function blobToText(blob) {
	return await blob.text();
}
async function readFileAsJson(root, fullPath) {
	try {
		const { readFile } = await getLureFs();
		const existing = await readFile(root, fullPath)?.catch?.(console.warn.bind(console));
		if (!existing) return null;
		const text = await blobToText(existing);
		if (!text?.trim()) return null;
		return JSOX.parse(text);
	} catch {
		return null;
	}
}
var writeFileSmart = async (root, dirOrPath, file, options = {}) => {
	const { writeFile } = await getLureFs();
	const { forceExt, ensureJson, toLower = true, sanitize = true, mergeJson, arrayStrategy = "union", arrayKey, jsonSpace = 2 } = options;
	let raw = String(dirOrPath || "").trim();
	const isDirHint = raw.endsWith("/");
	const hasFileToken = !isDirHint && splitPath(raw).length > 0 && raw.includes(".");
	let dirPath = isDirHint ? raw : hasFileToken ? raw.split("/").slice(0, -1).join("/") : raw;
	let desiredName = hasFileToken ? raw.split("/").pop() || "" : file?.name || "";
	dirPath = dirPath || "/";
	desiredName = desiredName || Date.now() + "";
	const lastDot = desiredName.lastIndexOf(".");
	let base = lastDot > 0 ? desiredName.slice(0, lastDot) : desiredName;
	let ext = forceExt || (ensureJson ? "json" : lastDot > 0 ? desiredName.slice(lastDot + 1) : inferExtFromMime(file?.type || "")) || "";
	if (sanitize) {
		dirPath = sanitizePathSegments(dirPath);
		base = toSlug(base, toLower);
	}
	const finalName = ext ? `${base}.${ext}` : base;
	const fullPath = ensureDir(dirPath) + finalName;
	if (mergeJson !== false && (ensureJson || ext.toLowerCase() === "json" || file?.type === "application/json")) try {
		let incomingJson;
		if (file instanceof File || file instanceof Blob) {
			const txt = await blobToText(file);
			incomingJson = txt?.trim() ? JSOX.parse(txt) : {};
		} else incomingJson = file;
		const existingJson = await readFileAsJson(root, fullPath)?.catch?.(console.warn.bind(console));
		let merged = existingJson != null ? mergeDeepUnique(existingJson, incomingJson, {
			arrayStrategy,
			arrayKey
		}) : incomingJson;
		const jsonString = JSON.stringify(merged, void 0, jsonSpace);
		const rs = await writeFile(root, fullPath, new File([jsonString], finalName, { type: "application/json" }))?.catch?.(console.warn.bind(console));
		if (typeof document !== "undefined") document?.dispatchEvent?.(new CustomEvent("rs-fs-changed", {
			detail: rs,
			bubbles: true,
			composed: true,
			cancelable: true
		}));
		return rs;
	} catch (err) {
		console.warn("writeFileSmart JSON merge failed, falling back to raw write:", err);
	}
	let toWrite;
	if (file instanceof File) {
		if (file.name === finalName) toWrite = file;
		else {
			const type = file.type || (ext ? `application/${ext}` : "application/octet-stream");
			const buf = await file.arrayBuffer();
			toWrite = new File([buf], finalName, { type });
		}
	} else {
		const type = file.type || (ext ? `application/${ext}` : "application/octet-stream");
		toWrite = new File([await file.arrayBuffer()], finalName, { type });
	}
	const rs = await writeFile(root, fullPath, toWrite)?.catch?.(console.warn.bind(console));
	if (typeof document !== "undefined") document?.dispatchEvent?.(new CustomEvent("rs-fs-changed", {
		detail: rs,
		bubbles: true,
		composed: true,
		cancelable: true
	}));
	return rs;
};
//#endregion
//#region ../../modules/projects/lur.e/src/utils/opfs/FsWatch.ts
var matchPath = (path = "", dir = "") => {
	const normalizedDir = dir.endsWith("/") ? dir : `${dir}/`;
	return path.startsWith(normalizedDir);
};
var channel = new BroadcastChannel("rs-fs");
var watchers = /* @__PURE__ */ new Map();
channel.addEventListener("close", () => watchers.clear());
channel.addEventListener("message", (event) => {
	const payload = event?.data;
	if (!payload || payload.type !== "commit-result" && payload.type !== "commit-to-clipboard") return;
	const results = payload?.results ?? [];
	if (!Array.isArray(results) || !results.length) return;
	for (const [dir, listeners] of watchers.entries()) {
		if (!listeners.size) continue;
		if (!results.some((item) => matchPath(item?.path, dir))) continue;
		for (const listener of listeners) try {
			listener();
		} catch (e) {
			console.warn(e);
		}
	}
});
//#endregion
//#region ../../modules/projects/lur.e/src/index.ts
var src_exports = /* @__PURE__ */ __exportAll({
	$behavior: () => $behavior,
	$createElement: () => $createElement,
	$mapped: () => $mapped,
	$observeAttribute: () => $observeAttribute,
	$observeInput: () => $observeInput,
	$virtual: () => $virtual,
	ANIMATABLE_BRAND: () => ANIMATABLE_BRAND,
	C: () => C,
	CSM: () => CSM,
	CSSAnchor: () => CSSAnchor,
	CSSBinder: () => CSSBinder,
	CSSCalc: () => CSSCalc,
	CSSPosition: () => CSSPosition,
	CSSTransform: () => CSSTransform,
	CSSUnitUtils: () => CSSUnitUtils,
	ClosePriority: () => ClosePriority,
	DESKTOP_DRAFT_KEY: () => DESKTOP_DRAFT_KEY,
	DESKTOP_MAIN_KEY: () => DESKTOP_MAIN_KEY,
	E: () => E,
	EventHandler: () => EventHandler,
	FileHandler: () => FileHandler,
	Fragment: () => Fragment,
	GLitElement: () => GLitElement,
	H: () => H,
	HistoryManager: () => HistoryManager,
	I: () => I,
	ITEM_COMPACT_KIND: () => ITEM_COMPACT_KIND,
	JUNCTION_DRAG_EVENTS: () => JUNCTION_DRAG_EVENTS,
	JUNCTION_RESIZE_EVENTS: () => JUNCTION_RESIZE_EVENTS,
	JUNCTION_SELECT_EVENTS: () => JUNCTION_SELECT_EVENTS,
	JunctionDragMixin: () => JunctionDragMixin,
	JunctionResizeMixin: () => JunctionResizeMixin,
	JunctionSelectMixin: () => JunctionSelectMixin,
	M: () => M,
	Q: () => Q,
	Qp: () => Qp,
	ReactiveElementSize: () => ReactiveElementSize,
	ReactiveViewport: () => ReactiveViewport,
	S: () => S,
	SwM: () => SwM,
	Task: () => Task,
	TemplateManager: () => TemplateManager,
	UnderlyingShadow: () => UnderlyingShadow,
	VoiceInputManager: () => VoiceInputManager,
	addProxiedEvent: () => addProxiedEvent,
	addToBank: () => addToBank,
	addVector2D: () => addVector2D,
	alives: () => alives,
	appendAsLayer: () => appendAsLayer,
	appendAsUnderlying: () => appendAsUnderlying,
	applyNormalizedInlineStyle: () => applyNormalizedInlineStyle,
	attrLink: () => attrLink,
	attrRef: () => attrRef,
	bindAnimated: () => bindAnimated,
	bindCtrl: () => bindCtrl,
	bindHandler: () => bindHandler,
	bindMorph: () => bindMorph,
	bindSpring: () => bindSpring,
	bindStyle: () => bindStyle,
	bindTransition: () => bindTransition,
	bindWith: () => bindWith,
	blobToBytes: () => blobToBytes,
	boundingBoxAnchorRef: () => boundingBoxAnchorRef,
	checkedLink: () => checkedLink,
	checkedRef: () => checkedRef,
	clampPointToRect: () => clampPointToRect,
	closeHighestPriority: () => closeHighestPriority,
	colorScheme: () => colorScheme,
	compileInlineStyleAttribute: () => compileInlineStyleAttribute,
	copy: () => copy,
	copyFromOneHandlerToAnother: () => copyFromOneHandlerToAnother,
	createBoxShadow: () => createBoxShadow,
	createElement: () => createElement,
	createFileHandler: () => createFileHandler,
	createHistoryManager: () => createHistoryManager,
	createPanelUnderShadow: () => createPanelUnderShadow,
	createShapedTileShadow: () => createShapedTileShadow,
	createTemplateManager: () => createTemplateManager,
	createUnderlyingShadow: () => createUnderlyingShadow,
	currentHandleMap: () => currentHandleMap,
	decodeBase64ToBytes: () => decodeBase64ToBytes,
	decodeDesktopState: () => decodeDesktopState,
	defaultLogger: () => defaultLogger,
	defaultZIndexShift: () => defaultZIndexShift,
	defineElement: () => defineElement,
	detectTypeByRelPath: () => detectTypeByRelPath,
	directHandlers: () => directHandlers,
	directoryCacheMap: () => directoryCacheMap,
	downloadFile: () => downloadFile,
	dropFile: () => dropFile,
	dynamicBgColors: () => dynamicBgColors,
	dynamicNativeFrame: () => dynamicNativeFrame,
	dynamicTheme: () => dynamicTheme,
	elMap: () => elMap,
	electronAPI: () => electronAPI,
	elementPointerMap: () => elementPointerMap,
	enhancedIntersectionBoxAnchorRef: () => enhancedIntersectionBoxAnchorRef,
	ensureWorker: () => ensureWorker,
	eventTrigger: () => eventTrigger,
	generalFileImportDesc: () => generalFileImportDesc,
	generateAnchorId: () => generateAnchorId,
	getActiveCloseable: () => getActiveCloseable,
	getActiveCloseables: () => getActiveCloseables,
	getBy: () => getBy,
	getCachedComponent: () => getCachedComponent,
	getComputedZIndex: () => getComputedZIndex,
	getDir: () => getDir,
	getDirectoryHandle: () => getDirectoryHandle,
	getExistsZIndex: () => getExistsZIndex,
	getFileHandle: () => getFileHandle,
	getFocused: () => getFocused,
	getHandler: () => getHandler,
	getIgnoreNextPopState: () => getIgnoreNextPopState,
	getMimeTypeByFilename: () => getMimeTypeByFilename,
	getParentOrShadowRoot: () => getParentOrShadowRoot,
	getSpeechPrompt: () => getSpeechPrompt,
	ghostImage: () => ghostImage,
	handleByPointer: () => handleByPointer,
	handleError: () => handleError,
	handleIncomingEntries: () => handleIncomingEntries,
	hasActiveCloseable: () => hasActiveCloseable,
	hasFileExtension: () => hasFileExtension,
	historyState: () => historyState,
	html: () => html,
	htmlBuilder: () => htmlBuilder,
	ignoreNextPopState: () => ignoreNextPopState,
	initBackNavigation: () => initBackNavigation,
	initClipboardReceiver: () => initClipboardReceiver,
	initGlobalClipboard: () => initGlobalClipboard,
	initHistory: () => initHistory,
	isAnimatableValue: () => isAnimatableValue,
	isBase64Like: () => isBase64Like,
	isEffectivelyEmptyStyleText: () => isEffectivelyEmptyStyleText,
	isNativeCSSStyleValue: () => isNativeCSSStyleValue,
	isNotExtended: () => isNotExtended,
	isReactiveStyleValue: () => isReactiveStyleValue,
	isStyleBinding: () => isStyleBinding,
	isVirtualFsPath: () => isVirtualFsPath,
	junctionToBox: () => junctionToBox,
	lazyAddEventListener: () => lazyAddEventListener,
	lazyLoadComponent: () => lazyLoadComponent,
	listenForClipboardRequests: () => listenForClipboardRequests,
	loadCachedStyles: () => loadCachedStyles,
	loadDesktopRaw: () => loadDesktopRaw,
	localStorageLink: () => localStorageLink,
	localStorageLinkMap: () => localStorageLinkMap,
	localStorageRef: () => localStorageRef,
	magnitude2D: () => magnitude2D,
	makeAnchorElement: () => makeAnchorElement,
	makeLinker: () => makeLinker,
	makeRef: () => makeRef,
	makeTask: () => makeTask,
	makeUIState: () => makeUIState,
	mappedRoots: () => mappedRoots,
	matchMappedRoot: () => matchMappedRoot,
	matchMediaLink: () => matchMediaLink,
	matchMediaRef: () => matchMediaRef,
	maybeStartThemeEngine: () => maybeStartThemeEngine,
	mergeByKey: () => mergeByKey,
	mixinDisposers: () => mixinDisposers,
	multiplyVector2D: () => multiplyVector2D,
	mutationTrigger: () => mutationTrigger,
	navigate: () => navigate,
	navigationEnable: () => navigationEnable,
	normalizeDataAsset: () => normalizeDataAsset,
	normalizePath: () => normalizePath,
	observeConnect: () => observeConnect,
	observeDisconnect: () => observeDisconnect,
	openDirectory: () => openDirectory,
	originalForward: () => originalForward,
	originalGo: () => originalGo,
	originalPush: () => originalPush,
	originalReplace: () => originalReplace,
	parseDataUrl: () => parseDataUrl,
	pickBgColor: () => pickBgColor,
	pickFromCenter: () => pickFromCenter,
	pointToRectDistance: () => pointToRectDistance,
	pointerAnchorRef: () => pointerAnchorRef,
	post: () => post,
	propStore: () => propStore,
	property: () => property,
	provide: () => provide,
	pruneEmptyStyleAttribute: () => pruneEmptyStyleAttribute,
	readFile: () => readFile,
	rectArea: () => rectArea,
	rectCenter: () => rectCenter,
	rectContainsPoint: () => rectContainsPoint,
	rectIntersects: () => rectIntersects,
	reflectControllers: () => reflectControllers,
	registerCloseable: () => registerCloseable,
	registerDirectoryRoot: () => registerDirectoryRoot,
	registerModal: () => registerModal,
	registerTask: () => registerTask,
	reloadInto: () => reloadInto,
	remove: () => remove,
	removeFile: () => removeFile,
	removeFromBank: () => removeFromBank,
	resolveLayerZIndex: () => resolveLayerZIndex,
	resolvePath: () => resolvePath,
	resolveRootHandle: () => resolveRootHandle,
	saveUIState: () => saveUIState,
	scrollLink: () => scrollLink,
	scrollRef: () => scrollRef,
	setIgnoreNextPopState: () => setIgnoreNextPopState,
	sizeLink: () => sizeLink,
	sizeRef: () => sizeRef,
	stringToBlob: () => stringToBlob,
	stringToBlobOrFile: () => stringToBlobOrFile,
	styleCache: () => styleCache,
	styleElementCache: () => styleElementCache,
	subtractVector2D: () => subtractVector2D,
	toText: () => toText,
	unregisterCloseable: () => unregisterCloseable,
	unregisterDirectoryRoot: () => unregisterDirectoryRoot,
	uploadFile: () => uploadFile,
	valueAsNumberLink: () => valueAsNumberLink,
	valueAsNumberRef: () => valueAsNumberRef,
	valueLink: () => valueLink,
	valueRef: () => valueRef,
	walkExactFile: () => walkExactFile,
	withProperties: () => withProperties,
	writeFile: () => writeFile,
	writeFileSmart: () => writeFileSmart,
	writeHTML: () => writeHTML,
	writeImage: () => writeImage,
	writeText: () => writeText
});
//#endregion
export { initClipboardReceiver as A, defineElement as B, pointerAnchorRef as C, decodeDesktopState as D, JSOX as E, elementPointerMap as F, hasActiveCloseable as G, vector2Ref as H, makeTask as I, registerModal as J, initBackNavigation as K, getBy as L, writeText as M, createPanelUnderShadow as N, loadDesktopRaw as O, createShapedTileShadow as P, navigationEnable as R, createTemplateManager as S, saveUIState as T, ClosePriority as U, property as V, closeHighestPriority as W, navigate as Y, remove as _, getDir as a, writeFile as b, getMimeTypeByFilename as c, matchMappedRoot as d, normalizePath as f, registerDirectoryRoot as g, readFile as h, downloadFile as i, initGlobalClipboard as j, copy as k, handleIncomingEntries as l, provide as m, writeFileSmart as n, getDirectoryHandle as o, openDirectory as p, registerCloseable as q, copyFromOneHandlerToAnother as r, getFileHandle as s, src_exports as t, isVirtualFsPath as u, unregisterDirectoryRoot as v, makeUIState as w, dynamicTheme as x, uploadFile as y, GLitElement as z };
