//#region ../../modules/projects/core.ts/src/utils/Primitive.ts
var $fxy = Symbol.for("@fix");
var isObservable$1 = (observable) => {
	return Array.isArray(observable) || observable instanceof Set || observable instanceof Map;
};
/**
* Check if a value is a primitive type (null, string, number, boolean, bigint, or undefined).
* @param obj - The value to check
* @returns True if the value is a primitive type, false otherwise
*/
var isPrimitive = (obj) => {
	return typeof obj == "string" || typeof obj == "number" || typeof obj == "boolean" || typeof obj == "bigint" || typeof obj == "undefined" || obj == null;
};
var tryParseByHint = (value, hint) => {
	if (!isPrimitive(value)) return null;
	if (hint == "number") return Number(value) || 0;
	if (hint == "string") return String(value) || "";
	if (hint == "boolean") return !!value;
	return value;
};
var hasProperty = (v, prop = "value") => {
	return (typeof v == "object" || typeof v == "function") && v != null && (prop in v || v?.[prop] != null);
};
var hasValue = (v) => {
	return hasProperty(v, "value");
};
var $getValue = ($objOrPlain) => {
	if (isPrimitive($objOrPlain)) return $objOrPlain;
	return hasValue($objOrPlain) ? $objOrPlain?.value : $objOrPlain;
};
var unwrap$1 = (obj, fallback) => {
	return obj?.[$fxy] ?? (obj != null ? obj : fallback) ?? fallback;
};
var deref$1 = (obj) => {
	if (obj != null && (typeof obj == "object" || typeof obj == "function") && (obj instanceof WeakRef || typeof obj?.deref == "function")) return deref$1(obj?.deref?.());
	return obj;
};
var fixFx = (obj) => {
	if (typeof obj == "function" || obj == null) return obj;
	const fx = function() {};
	fx[$fxy] = obj;
	return fx;
};
var $set = (rv, key, val) => {
	rv = deref$1(rv);
	if (rv != null && (typeof rv == "object" || typeof rv == "function")) return rv[key] = $getValue(val = deref$1(val));
	return rv;
};
var getRandomValues = (array) => {
	return crypto?.getRandomValues ? crypto?.getRandomValues?.(array) : (() => {
		const values = new Uint8Array(array.length);
		for (let i = 0; i < array.length; i++) values[i] = Math.floor(Math.random() * 256);
		return values;
	})();
};
var UUIDv4 = () => crypto?.randomUUID ? crypto?.randomUUID?.() : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) => (+c ^ getRandomValues?.(/* @__PURE__ */ new Uint8Array(1))?.[0] & 15 >> +c / 4).toString(16));
var camelToKebab = (str) => {
	if (!str) return str;
	return str?.replace?.(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
};
var kebabToCamel = (str) => {
	if (!str) return str;
	return str?.replace?.(/-([a-z])/g, (_, char) => char.toUpperCase());
};
var isValueUnit = (val) => typeof CSSStyleValue !== "undefined" && val instanceof CSSStyleValue;
var isVal = (v) => v != null && (typeof v == "boolean" ? v !== false : true) && typeof v != "object" && typeof v != "function";
var normalizePrimitive = (val) => {
	return typeof val == "boolean" ? val ? "" : null : typeof val == "number" ? String(val) : val;
};
var $triggerLock$1 = Symbol.for("@trigger-lock");
var $avoidTrigger = (ref, cb, $prop = "value") => {
	if (hasProperty(ref, $prop)) ref[$triggerLock$1] = true;
	let result;
	try {
		result = cb?.();
	} finally {
		if (hasProperty(ref, $prop)) delete ref[$triggerLock$1];
	}
	return result;
};
var tryStringAsNumber = (val) => {
	if (typeof val != "string") return null;
	const matches = [...val?.matchAll?.(/^\d+(\.\d+)?$/g)];
	if (matches?.length != 1) return null;
	const triedToParse = parseFloat(matches[0][0]);
	if (!Number.isNaN(triedToParse) && Number.isFinite(triedToParse)) return triedToParse;
	return null;
};
var INTEGER_REGEXP = /^\d+$/g;
var tryStringAsInteger = (val) => {
	if (typeof val != "string") return null;
	val = val?.trim?.();
	if (val == "" || val == null) return null;
	const matches = [...val?.matchAll?.(INTEGER_REGEXP)];
	if (matches?.length != 1) return null;
	const triedToParse = parseInt(matches[0][0]);
	if (!Number.isNaN(triedToParse) && Number.isInteger(triedToParse)) return triedToParse;
	return null;
};
var canBeInteger = (value) => {
	if (typeof value == "string") return tryStringAsInteger(value) != null;
	else return typeof value == "number" && Number.isInteger(value) && value >= 0;
};
var isArrayOrIterable = (obj) => Array.isArray(obj) || obj != null && typeof obj == "object" && typeof obj[Symbol.iterator] == "function";
var handleListeners = (root, fn, handlers) => {
	root = root instanceof WeakRef ? root.deref() : root;
	const usubs = [...Object.entries(handlers)].map?.(([name, cb]) => root?.[fn]?.call?.(root, name, cb));
	return () => {
		usubs?.forEach?.((unsub) => unsub?.());
	};
};
var isRef = (ref) => {
	return ref instanceof WeakRef || typeof ref?.deref == "function";
};
var toRef = (ref) => {
	return ref != null ? isRef(ref) ? ref : typeof ref == "function" || typeof ref == "object" ? new WeakRef(ref) : ref : ref;
};
var isValueRef = (exists) => {
	return (typeof exists == "object" || typeof exists == "function") && (exists?.value != null || exists != null && "value" in exists);
};
var isObject = (exists) => {
	return exists != null && (typeof exists == "object" || typeof exists == "function");
};
/**
* Get the value from a value reference or return the value itself.
* @param val - The value or value reference to extract from
* @returns The extracted value
*/
var getValue = (val) => {
	return hasValue(val) ? val?.value : val;
};
var potentiallyAsync = (promise, cb) => {
	if (promise instanceof Promise || typeof promise?.then == "function") return promise?.then?.(cb);
	else return cb?.(promise);
	return promise;
};
var potentiallyAsyncMap = (promise, cb) => {
	if (promise instanceof Promise || typeof promise?.then == "function") return promise?.then?.(cb);
	else return cb?.(promise);
	return promise;
};
var makeTriggerLess = function(self) {
	return (cb) => {
		self[$triggerLock$1] = true;
		let result;
		try {
			result = cb?.();
		} finally {
			self[$triggerLock$1] = false;
		}
		return result;
	};
};
var unwrapArray = (arr) => {
	if (Array.isArray(arr)) return arr?.flatMap?.((el) => {
		if (Array.isArray(el)) return unwrapArray(el);
		return el;
	});
	else return arr;
};
var isNotComplexArray = (arr) => {
	return unwrapArray(arr)?.every?.(isCanJustReturn);
};
var isCanJustReturn = (obj) => {
	return isPrimitive(obj) || typeof SharedArrayBuffer == "function" && obj instanceof SharedArrayBuffer || isTypedArray(obj) || Array.isArray(obj) && isNotComplexArray(obj);
};
var isTypedArray = (value) => {
	return ArrayBuffer.isView(value) && !(value instanceof DataView);
};
var isCanTransfer = (obj) => {
	return isPrimitive(obj) || typeof ArrayBuffer == "function" && obj instanceof ArrayBuffer || typeof MessagePort == "function" && obj instanceof MessagePort || typeof ReadableStream == "function" && obj instanceof ReadableStream || typeof WritableStream == "function" && obj instanceof WritableStream || typeof TransformStream == "function" && obj instanceof TransformStream || typeof ImageBitmap == "function" && obj instanceof ImageBitmap || typeof VideoFrame == "function" && obj instanceof VideoFrame || typeof OffscreenCanvas == "function" && obj instanceof OffscreenCanvas || typeof RTCDataChannel == "function" && obj instanceof RTCDataChannel || typeof AudioData == "function" && obj instanceof AudioData || typeof WebTransportReceiveStream == "function" && obj instanceof WebTransportReceiveStream || typeof WebTransportSendStream == "function" && obj instanceof WebTransportSendStream || typeof WebTransportReceiveStream == "function" && obj instanceof WebTransportReceiveStream;
};
var defaultByType = (a) => {
	switch (typeof a) {
		case "number": return 0;
		case "string": return "";
		case "boolean": return false;
		case "object": return null;
		case "function": return null;
		case "symbol": return null;
		case "bigint": return 0n;
	}
};
//#endregion
//#region ../../modules/projects/core.ts/src/utils/Object.ts
var isIterable = (obj) => typeof obj?.[Symbol.iterator] == "function";
var isKeyType = (prop) => [
	"symbol",
	"string",
	"number"
].indexOf(typeof prop) >= 0;
var removeExtra = (target, value, name = null) => {
	const exists = name != null && (typeof target == "object" || typeof target == "function") ? target?.[name] ?? target : target;
	let entries = [];
	if (value instanceof Set || value instanceof Map || Array.isArray(value) || isIterable(value)) entries = (exists instanceof Set || exists instanceof WeakSet ? value?.values?.() : value?.entries?.()) || (Array.isArray(value) || isIterable(value) ? value : []);
	else if (typeof value == "object" || typeof value == "function") entries = exists instanceof Set || exists instanceof WeakSet ? Object.values(value) : Object.entries(value);
	let exEntries = [];
	if (Array.isArray(exists)) exEntries = exists.entries();
	else if (exists instanceof Map || exists instanceof WeakMap) exEntries = exists?.entries?.();
	else if (exists instanceof Set || exists instanceof WeakSet) exEntries = exists?.values?.();
	else if (typeof exists == "object" || typeof exists == "function") exEntries = Object.entries(exists);
	const keys = new Set(Array.from(entries).map((e) => e?.[0]));
	const exe = new Set(Array.from(exEntries).map((e) => e?.[0]));
	const exclude = keys?.difference?.(exe);
	if (Array.isArray(exists)) {
		const nw = exists.filter((_, I) => !exclude.has(I));
		exists.splice(0, exists.length);
		exists.push(...nw);
	} else if (exists instanceof Map || exists instanceof Set || exists instanceof WeakMap || exists instanceof WeakSet) for (const k of exclude) exists.delete(k);
	else if (typeof exists == "function" || typeof exists == "object") for (const k of exclude) delete exists[k];
	return exists;
};
var objectAssign = (target, value, name = null, removeNotExists = true, mergeKey = "id") => {
	const exists = name != null && (typeof target == "object" || typeof target == "function") ? target?.[name] ?? target : target;
	let entries = null;
	if (removeNotExists) removeExtra(exists, value);
	if (value instanceof Set || value instanceof Map || Array.isArray(value) || isIterable(value)) entries = (exists instanceof Set || exists instanceof WeakSet ? value?.values?.() : value?.entries?.()) || (Array.isArray(value) || isIterable(value) ? value : []);
	else if (typeof value == "object" || typeof value == "function") entries = exists instanceof Set || exists instanceof WeakSet ? Object.values(value) : Object.entries(value);
	if (exists && entries && (typeof entries == "object" || typeof entries == "function")) {
		if (exists instanceof Map || exists instanceof WeakMap) {
			for (const E of entries) exists.set(...E);
			return exists;
		}
		if (exists instanceof Set || exists instanceof WeakSet) {
			for (const E of entries) {
				const mergeObj = E?.[mergeKey] ? Array.from(exists?.values?.() || []).find((I) => !isNotEqual?.(I?.[mergeKey], E?.[mergeKey])) : null;
				if (mergeObj != null) objectAssign(mergeObj, E, null, removeNotExists, mergeKey);
				else exists.add(E);
			}
			return exists;
		}
		if (typeof exists == "object" || typeof exists == "function") {
			if (Array.isArray(exists) || isIterable(exists)) {
				let I = 0;
				for (const E of entries) if (I < exists.length) exists[I++] = E?.[1];
				else exists?.push?.(E?.[1]);
				return exists;
			}
			return Object.assign(exists, Object.fromEntries([...entries || []].filter((K) => typeof K != "symbol")));
		}
	}
	if (name != null) {
		Reflect.set(target, name, value);
		return target;
	} else if (typeof value == "object" || typeof value == "function") return Object.assign(target, value);
	return value;
};
var bindFx = (target, fx) => {
	return boundCtx.getOrInsert(target, /* @__PURE__ */ new WeakMap()).getOrInsert(fx, fx?.bind?.(target));
};
var bindCtx = (target, fx) => (typeof fx == "function" ? bindFx(target, fx) : fx) ?? fx;
var callByProp = (unwrap, prop, cb, ctx) => {
	if (prop == Symbol.iterator) return callByAllProp(unwrap, cb, ctx);
	if (prop == null || typeof prop == "symbol" || typeof prop == "object" || typeof prop == "function") return;
	const callIfNotNull = (v, ...args) => {
		if (v != null) return cb?.(v, ...args);
	};
	if (unwrap instanceof Map || unwrap instanceof WeakMap) {
		if (unwrap.has(prop)) return callIfNotNull?.(unwrap.get(prop), prop, null, "@set");
	} else if (unwrap instanceof Set || unwrap instanceof WeakSet) {
		if (unwrap.has(prop)) return callIfNotNull?.(prop, prop, null, "@add");
	} else if (Array.isArray(unwrap) && typeof prop == "string" && [...prop?.matchAll?.(/^\d+$/g)].length == 1 && Number.isInteger(typeof prop == "string" ? parseInt(prop) : prop)) {
		const index = typeof prop == "string" ? parseInt(prop) : prop;
		return callIfNotNull?.(unwrap?.[index], index, null, "@add");
	} else if (typeof unwrap == "function" || typeof unwrap == "object") return callIfNotNull?.(unwrap?.[prop], prop, null, "@set");
};
var callByAllProp = (unwrap, cb, ctx) => {
	if (unwrap == null) return;
	let keys = [];
	if (unwrap instanceof Set || unwrap instanceof Map || typeof unwrap?.keys == "function") return [...unwrap?.keys?.() || keys].forEach?.((prop) => callByProp(unwrap, prop, cb, ctx));
	if (Array.isArray(unwrap) || isIterable(unwrap)) return [...unwrap].forEach?.((v, I) => callByProp(unwrap, I, cb, ctx));
	if (typeof unwrap == "object" || typeof unwrap == "function") return [...Object.keys(unwrap) || keys].forEach?.((prop) => callByProp(unwrap, prop, cb, ctx));
};
var isNotEqual = (a, b) => {
	if (a == null && b == null) return false;
	if (a == null || b == null) return true;
	if (typeof a == "boolean" && typeof b == "boolean") return a != b;
	if (typeof a == "number" && typeof b == "number") return !(a == b || Math.abs(a - b) < 1e-9);
	if (typeof a == "string" && typeof b == "string") return a != "" && b != "" && a != b || a !== b;
	if (typeof a != typeof b) return a !== b;
	return a && b && a != b || a !== b;
};
var boundCtx = /* @__PURE__ */ new WeakMap();
var isArrayInvalidKey = (key, src) => {
	const invalidForArray = key == null || key < 0 || typeof key != "number" || key == Symbol.iterator || (src != null ? key >= (src?.length || 0) : false);
	return src != null ? Array.isArray(src) && invalidForArray : false;
};
var deepOperateAndClone = (obj, operation, $prev) => {
	if (Array.isArray(obj)) {
		if (obj.every(isCanJustReturn)) return obj.map(operation);
		return obj.map((value, index) => deepOperateAndClone(value, operation, [obj, index]));
	}
	if (obj instanceof Map) {
		const entries = Array.from(obj.entries());
		if (entries.map(([key, value]) => value).every(isCanJustReturn)) return new Map(entries.map(([key, value]) => [key, operation(value, key, obj)]));
		return new Map(entries.map(([key, value]) => [key, deepOperateAndClone(value, operation, [obj, key])]));
	}
	if (obj instanceof Set) {
		const entries = Array.from(obj.entries());
		const values = entries.map(([key, value]) => value);
		if (entries.every(isCanJustReturn)) return new Set(values.map(operation));
		return new Set(values.map((value) => deepOperateAndClone(value, operation, [obj, value])));
	}
	if (typeof obj == "object" && obj?.constructor == Object && Object.prototype.toString.call(obj) == "[object Object]") {
		const entries = Array.from(Object.entries(obj));
		if (entries.map(([key, value]) => value).every(isCanJustReturn)) return Object.fromEntries(entries.map(([key, value]) => [key, operation(value, key, obj)]));
		return Object.fromEntries(entries.map(([key, value]) => [key, deepOperateAndClone(value, operation, [obj, key])]));
	}
	return operation(obj, $prev?.[1] ?? "", $prev?.[0] ?? null);
};
//#endregion
//#region ../../modules/projects/core.ts/src/utils/Promised.ts
var resolvedMap = /* @__PURE__ */ new WeakMap();
var handledMap = /* @__PURE__ */ new WeakMap();
var actWith = (promiseOrPlain, cb) => {
	if (promiseOrPlain instanceof Promise || typeof promiseOrPlain?.then == "function") {
		if (resolvedMap?.has?.(promiseOrPlain)) return cb(resolvedMap?.get?.(promiseOrPlain));
		return Promise.try?.(async () => {
			const item = await promiseOrPlain;
			resolvedMap?.set?.(promiseOrPlain, item);
			return item;
		})?.then?.(cb);
	}
	return cb(promiseOrPlain);
};
var PromiseHandler = class {
	#resolve;
	#reject;
	constructor(resolve, reject) {
		this.#resolve = resolve;
		this.#reject = reject;
	}
	defineProperty(target, prop, descriptor) {
		if (unwrap$1(target) instanceof Promise) return Reflect.defineProperty(target, prop, descriptor);
		return actWith(unwrap$1(target), (obj) => Reflect.defineProperty(obj, prop, descriptor));
	}
	deleteProperty(target, prop) {
		if (unwrap$1(target) instanceof Promise) return Reflect.deleteProperty(target, prop);
		return actWith(unwrap$1(target), (obj) => Reflect.deleteProperty(obj, prop));
	}
	getPrototypeOf(target) {
		if (unwrap$1(target) instanceof Promise) return Reflect.getPrototypeOf(target);
		return actWith(unwrap$1(target), (obj) => Reflect.getPrototypeOf(obj));
	}
	setPrototypeOf(target, proto) {
		if (unwrap$1(target) instanceof Promise) return Reflect.setPrototypeOf(target, proto);
		return actWith(unwrap$1(target), (obj) => Reflect.setPrototypeOf(obj, proto));
	}
	isExtensible(target) {
		if (unwrap$1(target) instanceof Promise) return Reflect.isExtensible(target);
		return actWith(unwrap$1(target), (obj) => Reflect.isExtensible(obj));
	}
	preventExtensions(target) {
		if (unwrap$1(target) instanceof Promise) return Reflect.ownKeys(target);
		return actWith(unwrap$1(target), (obj) => Reflect.preventExtensions(obj));
	}
	ownKeys(target) {
		const uwp = unwrap$1(target);
		if (uwp instanceof Promise) return Object.keys(uwp);
		return actWith(uwp, (obj) => {
			return (typeof obj == "object" || typeof obj == "function") && obj != null ? Object.keys(obj) : [];
		}) ?? [];
	}
	getOwnPropertyDescriptor(target, prop) {
		if (unwrap$1(target) instanceof Promise) return Reflect.getOwnPropertyDescriptor(target, prop);
		return actWith(unwrap$1(target), (obj) => Reflect.getOwnPropertyDescriptor(obj, prop));
	}
	construct(target, args, newTarget) {
		return actWith(unwrap$1(target), (ct) => Reflect.construct(ct, args, newTarget));
	}
	has(target, prop) {
		if (unwrap$1(target) instanceof Promise) return Reflect.has(target, prop);
		return actWith(unwrap$1(target), (obj) => Reflect.has(obj, prop));
	}
	get(target, prop, receiver) {
		target = unwrap$1(target);
		if (prop == "promise") return target;
		if (prop == "resolve" && this.#resolve) return (...args) => {
			const result = this.#resolve?.(...args);
			this.#resolve = null;
			return result;
		};
		if (prop == "reject" && this.#reject) return (...args) => {
			const result = this.#reject?.(...args);
			this.#reject = null;
			return result;
		};
		if (prop == "then" || prop == "catch" || prop == "finally") if (target instanceof Promise) return target?.[prop]?.bind?.(target);
		else {
			const $tmp = Promise.try(() => target);
			return $tmp?.[prop]?.bind?.($tmp);
		}
		let result = void 0;
		if (resolvedMap?.has?.(target) && (result = resolvedMap?.get?.(target))?.[prop] != null) result = resolvedMap?.get?.(target)?.[prop];
		else result = Promised(actWith(target, async (obj) => {
			if (unwrap$1(obj) instanceof Promise) return Reflect.get(obj, prop, receiver);
			if (isPrimitive(obj)) return prop == Symbol.toPrimitive || prop == Symbol.toStringTag ? obj : void 0;
			let value = void 0;
			try {
				value = Reflect.get(obj, prop, receiver);
			} catch (e) {
				value = target?.[prop];
			}
			if (typeof value == "function") return value?.bind?.(obj);
			return value;
		}));
		if (prop == Symbol.toStringTag) {
			if (isPrimitive(result)) return String(result ?? "") || "";
			return result?.[Symbol.toStringTag]?.() || String(result ?? "") || "";
		}
		if (prop == Symbol.toPrimitive) return (hint) => {
			if (isPrimitive(result)) return tryParseByHint(result, hint);
		};
		return result;
	}
	set(target, prop, value) {
		return actWith(unwrap$1(target), (obj) => Reflect.set(obj, prop, value));
	}
	apply(target, thisArg, args) {
		if (this.#resolve) {
			const result = this.#resolve?.(...args);
			this.#resolve = null;
			return result;
		}
		return actWith(unwrap$1(target, this.#resolve), (obj) => {
			if (typeof obj == "function") {
				if (unwrap$1(obj) instanceof Promise) return Reflect.apply(obj, thisArg, args);
				return Reflect.apply(obj, thisArg, args);
			}
		});
	}
};
/**
* Wrap a promise or value in a Proxy that allows synchronous property access.
* For resolved promises, this enables accessing properties as if the promise was already resolved.
* @template T - The resolved value type
* @param promise - The promise or value to wrap
* @param resolve - Optional resolve callback
* @param reject - Optional reject callback
* @returns A proxy that allows synchronous-style access to promise values
*/
function Promised(promise, resolve, reject) {
	if (!(promise instanceof Promise || typeof promise?.then == "function")) return promise;
	if (resolvedMap?.has?.(promise)) return resolvedMap?.get?.(promise);
	if (!handledMap?.has?.(promise)) promise?.then?.((item) => resolvedMap?.set?.(promise, item));
	return handledMap?.getOrInsertComputed?.(promise, () => new Proxy(fixFx(promise), new PromiseHandler(resolve, reject)));
}
//#endregion
//#region ../../modules/projects/object.ts/src/wrap/Symbol.ts
/**
* Shared symbol registry for the `object.ts` reactive runtime.
*
* These symbols form the hidden protocol used across wrappers, proxies,
* registries, and refs so internal bookkeeping does not collide with user keys.
*/
Symbol.observable ||= Symbol.for("observable");
Symbol.subscribe ||= Symbol.for("subscribe");
Symbol.unsubscribe ||= Symbol.for("unsubscribe");
var $value = Symbol.for("@value");
var $extractKey$ = Symbol.for("@extract");
var $originalKey$ = Symbol.for("@origin");
var $registryKey$ = Symbol.for("@registry");
var $behavior = Symbol.for("@behavior");
var $promise = Symbol.for("@promise");
var $triggerLess = Symbol.for("@trigger-less");
var $triggerLock = Symbol.for("@trigger-lock");
var $triggerControl = Symbol.for("@trigger-control");
var $trigger = Symbol.for("@trigger");
var $affected = Symbol.for("@subscribe");
var $isNotEqual = Symbol.for("@isNotEqual");
var $realProp = Symbol.for("@realProp");
//#endregion
//#region ../../modules/projects/object.ts/src/wrap/Utils.ts
/**
* Shared type and utility layer for `object.ts`.
*
* This file defines the loose observable/subscription type contracts plus
* helper functions for unwrapping, dereferencing, safe serialization, dispose
* chaining, promise-aware flows, and the Set-as-array adapter.
*/
var $originalObjects$ = /* @__PURE__ */ new WeakMap();
/** Clone an observable-like structure into plain serializable data. */
var safe = (target) => {
	const unwrap = typeof target == "object" || typeof target == "function" ? target?.[$extractKey$] ?? target : target, mapped = (e) => safe(e);
	if (Array.isArray(unwrap)) return unwrap?.map?.(mapped) || Array.from(unwrap || [])?.map?.(mapped) || [];
	else if (unwrap instanceof Map || unwrap instanceof WeakMap) return new Map(Array.from(unwrap?.entries?.() || [])?.map?.(([K, V]) => [K, safe(V)]));
	else if (unwrap instanceof Set || unwrap instanceof WeakSet) return new Set(Array.from(unwrap?.values?.() || [])?.map?.(mapped));
	else if (unwrap != null && typeof unwrap == "function" || typeof unwrap == "object") return Object.fromEntries(Array.from(Object.entries(unwrap || {}) || [])?.filter?.(([K]) => K != $extractKey$ && K != $originalKey$ && K != $registryKey$)?.map?.(([K, V]) => [K, safe(V)]));
	return unwrap;
};
/** Return the raw target behind a proxy/wrapper when one exists. */
var unwrap = (arr) => {
	return arr?.[$extractKey$] ?? arr?.["@target"] ?? arr;
};
/** Dereference WeakRef-like wrappers and recursively unwrap observable containers. */
var deref = (target, discountValue = false) => {
	const original = target;
	if (isPrimitive(target) || typeof target == "symbol") return target;
	if (target != null && (target instanceof WeakRef || "deref" in target && typeof target?.deref == "function")) target = target?.deref?.();
	if (target != null && (typeof target == "object" || typeof target == "function")) {
		target = unwrap(target);
		const $val = discountValue && hasValue(target) && target?.value;
		if ($val != null && (typeof $val == "object" || typeof $val == "function")) target = $val;
		if (original != target) return deref(target, discountValue);
	}
	return target;
};
/** Promise-like guard used by subscription helpers that accept thenables. */
var isThenable = (val) => val != null && typeof val.then === "function";
/** Run a callback once the target or its embedded promise has resolved. */
var withPromise = (target, cb) => {
	if (isPrimitive(target) || typeof target == "function") return cb?.(target);
	if (isThenable(target)) return target.then(cb);
	if (target?.promise && isThenable(target.promise)) return target.promise.then(cb);
	return cb?.(target);
};
var disposeMap = /* @__PURE__ */ new WeakMap();
var disposeRegistry = new FinalizationRegistry((callstack) => {
	callstack?.forEach?.((cb) => cb?.());
});
/**
* Append a callback to an object's disposal/call chain.
*
* AI-READ: `Symbol.dispose` is treated specially and kept in a side registry so
* multiple callbacks can be composed without overwriting each other.
*/
function addToCallChain(obj, methodKey, callback) {
	if (!callback || typeof callback != "function" || typeof obj != "object" && typeof obj != "function") return;
	if (methodKey == Symbol.dispose) {
		const chainTarget = obj?.[$extractKey$] ?? obj;
		disposeMap?.getOrInsertComputed?.(chainTarget, () => {
			const CallChain = /* @__PURE__ */ new Set();
			if (typeof chainTarget == "object" || typeof chainTarget == "function") {
				disposeRegistry.register(chainTarget, CallChain);
				disposeMap.set(chainTarget, CallChain);
				chainTarget[Symbol.dispose] ??= () => CallChain.forEach((cb) => {
					cb?.();
				});
			}
			return CallChain;
		})?.add?.(callback);
	} else obj[methodKey] = function(...args) {
		const original = obj?.[methodKey];
		if (typeof original == "function") original.apply(this, args);
		callback.apply(this, args);
	};
}
//#endregion
//#region ../../modules/projects/object.ts/src/wrap/AssignObject.ts
/**
* Proxy helper that forces property writes through `objectAssign`.
*
* WHY: some callers want an object that looks ordinary but still normalizes
* assignment semantics the same way the rest of the reactive stack does.
*/
/** Proxy handler that redirects `set` operations to the Fest assignment helper. */
var AssignObjectHandler = class {
	constructor() {}
	deleteProperty(target, name) {
		return Reflect.deleteProperty(target, name);
	}
	construct(target, args, newT) {
		return Reflect.construct(target, args, newT);
	}
	apply(target, ctx, args) {
		return Reflect.apply(target, ctx, args);
	}
	has(target, prop) {
		return Reflect.has(target, prop);
	}
	set(target, name, value) {
		objectAssign(target, value, name);
		return true;
	}
	get(target, name, ctx) {
		if (typeof name == "symbol") return target?.[name] ?? target;
		return Reflect.get(target, name, ctx);
	}
};
/** Wrap an object in an assignment-aware proxy once, preserving the original-object lookup table. */
var makeObjectAssignable = (obj) => {
	if (obj?.[$originalKey$] || $originalObjects$.has(obj)) return obj;
	const px = new Proxy(obj, new AssignObjectHandler());
	$originalObjects$.set(px, obj);
	return px;
};
//#endregion
//#region ../../modules/projects/object.ts/src/core/Subscript.ts
/**
* Listener registry and proxy wrapper backbone for `object.ts`.
*
* The `Subscript` class stores callbacks, batches dispatches, exposes a
* minimal Observable-compatible surface, and helps observable wrappers share
* one registry per underlying target.
*
* INVARIANT: dispatch never awaits or aggregates listener Promises.
* Async returns are fire-and-forget (rejection → console.warn only).
*/
/** Track disposer rewrites for Observable-style subscribers so completion also unsubscribes. */
var withUnsub = /* @__PURE__ */ new WeakMap();
var completeWithUnsub = (subscriber, weak, handler) => {
	return withUnsub.getOrInsert(subscriber, () => {
		const registry = weak?.deref?.();
		registry?.affected?.(handler);
		const savComplete = subscriber?.complete?.bind?.(subscriber);
		const unaffected = () => {
			const r = savComplete?.();
			registry?.unaffected?.(handler);
			return r;
		};
		subscriber.complete = unaffected;
		return {
			unaffected,
			[Symbol.dispose]: unaffected,
			[Symbol.asyncDispose]: unaffected
		};
	});
};
/** Global registry that maps raw targets to their `Subscript` instance. */
var subscriptRegistry = /* @__PURE__ */ new WeakMap();
var globalEffectListeners = /* @__PURE__ */ new Map();
var wrapped = /* @__PURE__ */ new WeakMap();
/** Ensure a target has a registry before reusing or returning a reactive handle. */
var register = (what, handle) => {
	const unwrap = what?.[$extractKey$] ?? what;
	let registry = subscriptRegistry.get(unwrap);
	if (!registry) {
		registry = new Subscript(unwrap);
		subscriptRegistry.set(unwrap, registry);
	} else registry.bindSource(unwrap);
	return handle;
};
/** Wrap a raw target in a proxy backed by the provided handler, memoized per original object. */
var wrapWith = (what, handle) => {
	what = deref(what?.[$extractKey$] ?? what);
	if (typeof what == "symbol" || !(typeof what == "object" || typeof what == "function") || what == null) return what;
	return wrapped.getOrInsertComputed(what, () => new Proxy(what, register(what, handle)));
};
var forAll = Symbol.for("@allProps");
var wildcardTriggers = /* @__PURE__ */ new Set(["*", "all"]);
var triggerAliases = /* @__PURE__ */ new Map([
	["set", ["setter", "@set"]],
	["add", ["@add"]],
	["delete", ["@delete"]],
	["invalidate", ["@invalidate"]],
	["manual", ["@manual"]],
	["custom", ["@custom"]],
	["setAll", ["@setAll"]],
	["addAll", ["@addAll"]],
	["deleteAll", ["@deleteAll", "@clear"]]
]);
var triggerCanonicalNames = new Map(Array.from(triggerAliases.entries()).flatMap(([canonical, aliases]) => aliases.map((alias) => [alias, canonical])));
var normalizeTriggerName = (trigger = "set") => {
	if (trigger == null) return trigger;
	const name = String(trigger || "set");
	return triggerCanonicalNames.get(name) ?? name;
};
var triggerNamesOf = (trigger) => {
	const name = trigger == null ? "all" : String(normalizeTriggerName(trigger) ?? "all");
	return [name, ...triggerAliases.get(name) ?? []];
};
var expandTriggerFilter = (types = ["*"]) => {
	return new Set([...normalizeTriggerFilter(types)].flatMap((name) => [name, ...triggerAliases.get(name) ?? []]));
};
var normalizeTriggerFilter = (triggers = ["*"]) => {
	const list = typeof triggers == "string" ? [triggers] : Array.from(triggers ?? ["*"]);
	const normalized = new Set(list.map((item) => {
		const name = String(item || "*");
		return wildcardTriggers.has(name) ? name : String(normalizeTriggerName(name) ?? name);
	}));
	return normalized.size ? normalized : /* @__PURE__ */ new Set(["*"]);
};
var triggerFilterAllows = (triggers, trigger) => {
	const filter = triggers instanceof Set ? triggers : normalizeTriggerFilter(triggers);
	return [...wildcardTriggers].some((name) => filter.has(name)) || triggerNamesOf(trigger).some((name) => filter.has(name));
};
var isOptionsObject = (options) => {
	return !!options && typeof options == "object" && !Array.isArray(options) && ("affectTypes" in options || "triggers" in options || "triggerImmediately" in options);
};
var normalizeAffectedOptions = (options = ["*"]) => {
	if (isOptionsObject(options)) return {
		affectTypes: normalizeTriggerFilter(options.affectTypes ?? options.triggers ?? ["*"]),
		triggerImmediately: options.triggerImmediately !== false
	};
	const affectTypes = normalizeTriggerFilter(options);
	return {
		affectTypes,
		triggerImmediately: triggerFilterAllows(affectTypes, "initial")
	};
};
/** Central subscription registry with batched dispatch and Observable interoperability helpers. */
var Subscript = class {
	compatible;
	#source;
	#listeners;
	#flags = /* @__PURE__ */ new WeakSet();
	#native;
	#iterator;
	#inDispatch = /* @__PURE__ */ new Set();
	#disabledTriggers = /* @__PURE__ */ new Set();
	#triggerControl;
	#pending = /* @__PURE__ */ new Map();
	#pendingByProp = /* @__PURE__ */ new Map();
	#flushScheduled = false;
	constructor(source) {
		this.#source = source;
		this.#listeners = /* @__PURE__ */ new Map();
		this.#flags = /* @__PURE__ */ new WeakSet();
		this.#triggerControl = {
			enable: (types = ["*"], cb) => cb ? this.withTriggers(types, true, cb) : this.setTriggersEnabled(types, true),
			disable: (types = ["*"], cb) => cb ? this.withTriggers(types, false, cb) : this.setTriggersEnabled(types, false),
			set: (types, enabled) => this.setTriggersEnabled(types, enabled),
			with: (types, cb) => this.withTriggers(types, true, cb),
			without: (types, cb) => this.withTriggers(types, false, cb),
			isEnabled: (trigger) => this.isTriggerEnabled(trigger)
		};
		this.#iterator = { next: (args) => {
			if (args) Array.isArray(args) ? this.#dispatch(...args) : this.#dispatch(args);
		} };
		const weak = new WeakRef(this);
		const controller = function(subscriber) {
			const handler = subscriber?.next?.bind?.(subscriber);
			return completeWithUnsub(subscriber, weak, handler);
		};
		this.#native = typeof Observable != "undefined" ? new Observable(controller) : null;
		this.compatible = () => this.#native;
	}
	bindSource(source) {
		this.#source ??= source;
		return this;
	}
	/**
	* Run one listener with re-entrancy guard (recursive $safeExec on same cb skipped).
	*
	* WHY: never return/await listener Promises — a never-settling or
	* recursively awaiting Promise would stall callers that used to
	* Promise.allSettled the dispatch batch.
	*/
	$safeExec(cb, ...args) {
		if (!cb || this.#flags.has(cb)) return;
		this.#flags.add(cb);
		try {
			const res = cb(...args);
			if (res && typeof res.then === "function") {
				res.catch(console.warn);
				return;
			}
			return res;
		} catch (e) {
			console.warn(e);
		} finally {
			this.#flags.delete(cb);
		}
	}
	/**
	* Invoke matching listeners synchronously.
	*
	* INVARIANT: does not collect, await, or return Promise.all* over listener
	* results. Async listeners run detached; hangs must not block the pipeline.
	*/
	#dispatch(name, value = null, oldValue, trigger = "all", ...etc) {
		trigger = normalizeTriggerName(trigger) ?? trigger;
		const listeners = this.#listeners;
		if (listeners?.size) {
			for (const [cb, record] of listeners.entries()) if ((record.prop === name || record.prop === forAll || record.prop === null) && triggerFilterAllows(record.triggers, trigger)) this.$safeExec(cb, value, name, oldValue, trigger, ...etc);
		}
		if (globalEffectListeners.size) {
			const event = {
				source: this.#source,
				target: this.#source,
				value,
				prop: name,
				name,
				oldValue,
				trigger,
				args: etc
			};
			for (const [cb, triggers] of globalEffectListeners.entries()) if (triggerFilterAllows(triggers, trigger)) this.$safeExec(cb, event);
		}
	}
	wrap(nw) {
		if (Array.isArray(nw)) return wrapWith(nw, this);
		return nw;
	}
	get triggerControl() {
		return this.#triggerControl;
	}
	isTriggerEnabled(trigger) {
		return !triggerFilterAllows(this.#disabledTriggers, "all") && !triggerNamesOf(trigger).some((name) => this.#disabledTriggers.has(name));
	}
	setTriggersEnabled(types = ["*"], enabled = true) {
		const names = expandTriggerFilter(types);
		for (const name of names) if (enabled) this.#disabledTriggers.delete(name);
		else this.#disabledTriggers.add(name);
	}
	withTriggers(types, enabled, cb) {
		const names = [...expandTriggerFilter(types)];
		const previous = new Map(names.map((name) => [name, this.#disabledTriggers.has(name)]));
		const restore = () => {
			previous.forEach((wasDisabled, name) => {
				if (wasDisabled) this.#disabledTriggers.add(name);
				else this.#disabledTriggers.delete(name);
			});
		};
		this.setTriggersEnabled(names, enabled);
		try {
			const result = cb?.();
			if (result && typeof result.finally == "function") return result.finally(restore);
			restore();
			return result;
		} catch (e) {
			restore();
			throw e;
		}
	}
	affected(cb, prop, options = ["*"]) {
		if (cb == null || typeof cb != "function") return;
		const normalized = normalizeAffectedOptions(options);
		this.#listeners.set(cb, {
			prop: prop || forAll,
			triggers: normalized.affectTypes
		});
		return () => this.unaffected(cb, prop || forAll);
	}
	unaffected(cb, prop) {
		if (cb != null && typeof cb == "function") {
			const listeners = this.#listeners;
			const record = listeners?.get(cb);
			if (record && (record.prop == prop || prop == null || prop == forAll)) {
				listeners.delete(cb);
				return () => this.affected(cb, prop || forAll, record.triggers);
			}
		}
		return this.#listeners.clear();
	}
	/**
	* Коалесит триггеры:
	* - один dispatch на name за микро-тик
	* - повторные trigger(name) до flush не вызывают повторно dispatch, а лишь обновляют аргументы
	* - другие name не блокируются
	*/
	/**
	* Queue and coalesce trigger events by property and trigger type per microtask.
	*
	* WHY: hot mutation paths can emit many intermediate writes; batching keeps
	* subscribers deterministic and avoids recursive cascades on one property.
	*/
	trigger(name, value, oldValue, trigger = "set", ...etc) {
		if (typeof name === "symbol") return;
		if (trigger === void 0) trigger = "set";
		trigger = normalizeTriggerName(trigger) ?? trigger;
		if (!this.isTriggerEnabled(trigger)) return;
		const opKey = `${trigger ?? "all"}`;
		let byOp = this.#pendingByProp.get(name);
		if (!byOp) {
			byOp = /* @__PURE__ */ new Map();
			this.#pendingByProp.set(name, byOp);
		}
		byOp.set(opKey, [
			name,
			value,
			oldValue,
			trigger,
			etc
		]);
		if (this.#flushScheduled) return;
		this.#flushScheduled = true;
		queueMicrotask(() => {
			this.#flushScheduled = false;
			const batch = this.#pendingByProp;
			this.#pendingByProp = /* @__PURE__ */ new Map();
			for (const [prop, opMap] of batch) {
				if (prop != null && this.#inDispatch.has(prop)) continue;
				if (prop != null) this.#inDispatch.add(prop);
				try {
					for (const [, args] of opMap) {
						const [nm, v, ov, tg, rest] = args;
						try {
							this.#dispatch(nm, v, ov, tg, ...rest ?? []);
						} catch (e) {
							console.warn(e);
						}
					}
				} finally {
					if (prop != null) this.#inDispatch.delete(prop);
				}
			}
		});
	}
	get iterator() {
		return this.#iterator;
	}
};
//#endregion
//#region ../../modules/projects/object.ts/src/core/Specific.ts
/**
* Concrete proxy handlers for arrays, objects, maps, and sets.
*
* This is the low-level implementation layer that intercepts reads/writes,
* translates native collection operations into normalized trigger events, and
* exposes the observable protocol used by `observe()`.
*/
var __systemSkip = /* @__PURE__ */ new Set([
	Symbol.toStringTag,
	Symbol.iterator,
	Symbol.asyncIterator,
	Symbol.toPrimitive,
	"toString",
	"valueOf",
	"inspect",
	"constructor",
	"__proto__",
	"prototype",
	"then",
	"catch",
	"finally",
	"next"
]);
var systemSkipGet = (target, name) => {
	if (!__systemSkip.has(name)) return null;
	const got = safeGet(target, name);
	return typeof got === "function" ? bindCtx(target, got) : got;
};
var __safeGetGuard = /* @__PURE__ */ new WeakMap();
function isGetter(obj, propName) {
	let got = true;
	try {
		__safeGetGuard?.getOrInsert?.(obj, /* @__PURE__ */ new Set())?.add?.(propName);
		if (__safeGetGuard?.get?.(obj)?.has?.(propName)) got = true;
		got = typeof Reflect.getOwnPropertyDescriptor(obj, propName)?.get == "function";
	} catch (e) {
		got = true;
	} finally {
		__safeGetGuard?.get?.(obj)?.delete?.(propName);
	}
	return got;
}
/** Follow `.value` chains when a wrapper stores the actual object one level deeper. */
var fallThrough = (obj, key) => {
	if (isPrimitive(obj)) return obj;
	const value = safeGet(obj, key);
	if (value == null && key != "value") {
		const tmp = safeGet(obj, "value");
		if (tmp != null && !isPrimitive(tmp)) return fallThrough(tmp, key);
		else return value;
	} else if (key == "value" && value != null && !isPrimitive(value) && typeof value != "function") return fallThrough(value, key) ?? value ?? obj;
	return value ?? obj;
};
/** Safe setter with re-entrancy protection to avoid recursive accessor loops. */
var safeSet = (obj, key, value) => {
	if (obj == null) return false;
	let active = __safeSetGuard.getOrInsert(obj, /* @__PURE__ */ new Set());
	if (active?.has?.(key)) return false;
	active?.add?.(key);
	return Reflect.set(obj, key, value);
};
/** Safe getter with re-entrancy protection to avoid recursive accessor loops. */
var safeGet = (obj, key, rec) => {
	let result = void 0;
	if (obj == null) return obj;
	let active = __safeGetGuard.getOrInsert(obj, /* @__PURE__ */ new Set());
	if (active?.has?.(key)) return null;
	if (!isGetter(obj, key)) result ??= Reflect.get(obj, key, rec != null ? rec : obj);
	else {
		active?.add?.(key);
		try {
			result = Reflect.get(obj, key, rec != null ? rec : obj);
		} catch (_e) {
			result = void 0;
		} finally {
			active.delete(key);
			if (active?.size === 0) __safeGetGuard?.delete?.(obj);
		}
	}
	return typeof result == "function" ? bindCtx(obj, result) : result;
};
var hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
var isTriggerEmitOptions = (value, allowValueOnly = false) => {
	return !!value && typeof value == "object" && !Array.isArray(value) && (hasOwn(value, "key") || hasOwn(value, "name") || hasOwn(value, "oldValue") || hasOwn(value, "old") || hasOwn(value, "op") || hasOwn(value, "trigger") || allowValueOnly && hasOwn(value, "value"));
};
var triggerOptionValue = (options, key, fallback) => {
	if (hasOwn(options, key)) return options[key];
	if (key == "oldValue" && hasOwn(options, "old")) return options.old;
	return fallback();
};
var triggerOptionTrigger = (options, fallback = "manual") => normalizeTriggerName(options.trigger ?? options.op ?? fallback);
var isRuntimeKey = (key) => typeof key == "string" || typeof key == "number" || typeof key == "symbol";
var realPropOf$1 = (target) => {
	const prop = safeGet(target, $realProp) ?? safeGet(target, "realProp");
	return isRuntimeKey(prop) ? prop : null;
};
var triggerKeyOf = (target, key) => key == "value" ? realPropOf$1(target) ?? key : key;
var triggerValueOf = (target, key) => {
	const realProp = realPropOf$1(target);
	if (realProp != null && key == realProp) return safeGet(target, "value") ?? safeGet(target, $value) ?? safeGet(target, key);
	return key == null ? void 0 : safeGet(target, key);
};
var createTriggerAPI = (registry, emit) => {
	const api = (key, opOrOptions, trigger) => {
		if (!isTriggerEmitOptions(opOrOptions)) trigger ??= opOrOptions;
		return emit(isTriggerEmitOptions(key) ? key : isTriggerEmitOptions(opOrOptions, true) ? {
			key,
			trigger,
			...opOrOptions
		} : {
			key,
			trigger: trigger ?? opOrOptions
		});
	};
	const control = registry?.triggerControl;
	if (control) Object.assign(api, control);
	api.custom = (trigger, key, value, oldValue) => api({
		key,
		trigger,
		value,
		oldValue
	});
	return api;
};
var systemGet = (target, name, registry) => {
	if (target == null || isPrimitive(target)) return target;
	if (([
		"deref",
		"bind",
		"@target",
		$originalKey$,
		$extractKey$,
		$registryKey$
	].indexOf(name) < 0 ? safeGet(target, name)?.bind?.(target) : null) != null) return null;
	if ([$extractKey$, $originalKey$].indexOf(name) >= 0) return safeGet(target, name) ?? target;
	if (name == $value) return safeGet(target, name) ?? safeGet(target, "value");
	if (name == $registryKey$) return registry;
	if (name == $triggerControl) return registry?.triggerControl;
	if (name == Symbol.observable) return registry?.compatible;
	if (name == Symbol.subscribe) return (cb, prop, options) => affected(prop != null ? [target, prop] : target, cb, options);
	if (name == Symbol.iterator) return safeGet(target, name);
	if (name == Symbol.asyncIterator) return safeGet(target, name);
	if (name == Symbol.dispose) return (prop) => {
		safeGet(target, Symbol.dispose)?.(prop);
		unaffected(prop != null ? [target, prop] : target);
	};
	if (name == Symbol.asyncDispose) return (prop) => {
		safeGet(target, Symbol.asyncDispose)?.(prop);
		unaffected(prop != null ? [target, prop] : target);
	};
	if (name == Symbol.unsubscribe) return (prop) => unaffected(prop != null ? [target, prop] : target);
	if (typeof name == "symbol" && (name in target || safeGet(target, name) != null)) return safeGet(target, name);
};
var observableAPIMethods = (target, name, registry) => {
	if (name == "subscribe") return registry?.compatible?.[name] ?? ((handler) => {
		if (typeof handler == "function") return affected(target, handler);
		else if ("next" in handler && handler?.next != null) {
			const usub = affected(target, handler?.next), comp = handler?.["complete"];
			handler["complete"] = (...args) => {
				usub?.();
				return comp?.(...args);
			};
			return handler["complete"];
		}
	});
};
/** Wrap mutating array methods so they emit normalized add/set/delete events. */
var ObserveArrayMethod = class {
	#name;
	#self;
	#handle;
	constructor(name, self, handle) {
		this.#name = name;
		this.#self = self;
		this.#handle = handle;
	}
	get(target, name, rec) {
		const skip = systemSkipGet(target, name);
		if (skip != null) return skip;
		return Reflect.get(target, name, rec);
	}
	apply(target, ctx, args) {
		let added = [], removed = [];
		let setPairs = [];
		let oldState = [...this.#self];
		let idx = -1;
		const result = Reflect.apply(target, ctx || this.#self, args);
		if (this.#handle?.[$triggerLock]) {
			if (Array.isArray(result)) return observeArray(result);
			return result;
		}
		switch (this.#name) {
			case "push":
				idx = oldState?.length;
				added = args;
				break;
			case "unshift":
				idx = 0;
				added = args;
				break;
			case "pop":
				idx = oldState?.length - 1;
				if (oldState.length > 0) removed = [oldState[idx]];
				break;
			case "shift":
				idx = 0;
				if (oldState.length > 0) removed = [oldState[idx]];
				break;
			case "splice":
				idx = args[0];
				for (let i = 0; i < Math.max(oldState.length, this.#self.length); i++) {
					const oldValue = oldState[i];
					const newValue = this.#self[i];
					if (newValue === void 0 && i >= this.#self.length) removed.push(oldValue);
					else if (oldValue === void 0 && i >= oldState.length) setPairs.push([
						i,
						newValue,
						void 0,
						false
					]);
					else if (isNotEqual(oldValue, newValue)) setPairs.push([
						i,
						newValue,
						oldValue,
						true
					]);
				}
				break;
			case "sort":
			case "fill":
			case "reverse":
			case "copyWithin":
				idx = 0;
				for (let i = 0; i < oldState.length; i++) if (isNotEqual(oldState[i], this.#self[i])) setPairs.push([
					idx + i,
					this.#self[i],
					oldState[i],
					true
				]);
				break;
			case "set":
				idx = args[1];
				setPairs.push([
					idx,
					args[0],
					oldState?.[idx],
					idx in oldState
				]);
				break;
		}
		const reg = subscriptRegistry.get(this.#self);
		if (added?.length == 1) reg?.trigger?.(idx, added[0], null, "add");
		else if (added?.length > 1) {
			reg?.trigger?.(idx, added, null, "addAll");
			added.forEach((item, I) => reg?.trigger?.(idx + I, item, null, "add"));
		}
		if (setPairs?.length == 1) reg?.trigger?.(setPairs[0]?.[0] ?? idx, setPairs[0]?.[1], setPairs[0]?.[2], setPairs[0]?.[3] === false ? "add" : "set");
		else if (setPairs?.length > 1) {
			reg?.trigger?.(idx, setPairs, oldState, "setAll");
			setPairs.forEach((pair, I) => reg?.trigger?.(pair?.[0] ?? idx + I, pair?.[1], pair?.[2], pair?.[3] === false ? "add" : "set"));
		}
		if (removed?.length == 1) reg?.trigger?.(idx, null, removed[0], "delete");
		else if (removed?.length > 1) {
			reg?.trigger?.(idx, null, removed, "deleteAll");
			removed.forEach((item, I) => reg?.trigger?.(idx + I, null, item, "delete"));
		}
		if (result == target) return new Proxy(result, this.#handle);
		if (Array.isArray(result)) return observeArray(result);
		return result;
	}
};
var triggerWhenLengthChange = (self, target, oldLen, newLen) => {
	const removedItems = Number.isInteger(oldLen) && Number.isInteger(newLen) && newLen < oldLen ? target.slice(newLen, oldLen) : [];
	if (!self[$triggerLock] && oldLen !== newLen) {
		const registry = subscriptRegistry.get(target);
		if (removedItems.length === 1) registry?.trigger?.(newLen, null, removedItems[0], "delete");
		else if (removedItems.length > 1) {
			registry?.trigger?.(newLen, null, removedItems, "deleteAll");
			removedItems.forEach((item, I) => registry?.trigger?.(newLen + I, null, item, "delete"));
		}
		const addedCount = Number.isInteger(oldLen) && Number.isInteger(newLen) && newLen > oldLen ? newLen - oldLen : 0;
		if (addedCount === 1) registry?.trigger?.(oldLen, void 0, null, "add");
		else if (addedCount > 1) {
			const added = Array(addedCount).fill(void 0);
			registry?.trigger?.(oldLen, added, null, "addAll");
			added.forEach((_, I) => registry?.trigger?.(oldLen + I, void 0, null, "add"));
		}
	}
};
/** Proxy handler for observable arrays, including index writes and mutation methods. */
var ObserveArrayHandler = class {
	[$triggerLock];
	constructor() {}
	has(target, name) {
		return Reflect.has(target, name);
	}
	get(target, name, rec) {
		const skip = systemSkipGet(target, name);
		if (skip != null) return skip;
		if ([
			$extractKey$,
			$originalKey$,
			"@target",
			"deref"
		].indexOf(name) >= 0 && safeGet(target, name) != null && safeGet(target, name) != target) return typeof safeGet(target, name) == "function" ? safeGet(target, name)?.bind?.(target) : safeGet(target, name);
		const registry = subscriptRegistry?.get?.(target);
		const sys = systemGet(target, name, registry);
		if (sys != null) return sys;
		const obs = observableAPIMethods(target, name, registry);
		if (obs != null) return obs;
		if (name == $triggerLess) return makeTriggerLess.call(this, this);
		if (name == $trigger) return createTriggerAPI(registry, (options) => {
			const key = options.key ?? options.name ?? 0;
			const value = triggerOptionValue(options, "value", () => safeGet(target, key));
			const oldValue = triggerOptionValue(options, "oldValue", () => void 0);
			return registry?.trigger?.(key, value, oldValue, triggerOptionTrigger(options, "manual"));
		});
		if (name == "@target" || name == $extractKey$) return target;
		if (name == "x") return () => {
			return target?.x ?? target?.[0];
		};
		if (name == "y") return () => {
			return target?.y ?? target?.[1];
		};
		if (name == "z") return () => {
			return target?.z ?? target?.[2];
		};
		if (name == "w") return () => {
			return target?.w ?? target?.[3];
		};
		if (name == "r") return () => {
			return target?.r ?? target?.[0];
		};
		if (name == "g") return () => {
			return target?.g ?? target?.[1];
		};
		if (name == "b") return () => {
			return target?.b ?? target?.[2];
		};
		if (name == "a") return () => {
			return target?.a ?? target?.[3];
		};
		const got = safeGet(target, name) ?? (name == "value" ? safeGet(target, $value) : null);
		if (typeof got == "function") return new Proxy(typeof got == "function" ? got?.bind?.(target) : got, new ObserveArrayMethod(name, target, this));
		return got;
	}
	set(target, name, value) {
		if (typeof name != "symbol") {
			if (Number.isInteger(parseInt(name))) name = parseInt(name) ?? name;
		}
		if (name == $triggerLock && value) {
			this[$triggerLock] = !!value;
			return true;
		}
		if (name == $triggerLock && !value) {
			delete this[$triggerLock];
			return true;
		}
		const old = safeGet(target, name);
		const xyzw = [
			"x",
			"y",
			"z",
			"w"
		];
		const rgba = [
			"r",
			"g",
			"b",
			"a"
		];
		const xyzw_idx = xyzw.indexOf(name);
		const rgba_idx = rgba.indexOf(name);
		let got = false;
		if (xyzw_idx >= 0) got = Reflect.set(target, xyzw_idx, value);
		else if (rgba_idx >= 0) got = Reflect.set(target, rgba_idx, value);
		else got = Reflect.set(target, name, value);
		if (name == "length") {
			if (isNotEqual(old, value)) triggerWhenLengthChange(this, target, old, value);
		}
		if (!this[$triggerLock] && typeof name != "symbol" && isNotEqual(old, value)) subscriptRegistry?.get?.(target)?.trigger?.(name, value, old, "set");
		return got;
	}
	deleteProperty(target, name) {
		if (typeof name != "symbol") {
			if (Number.isInteger(parseInt(name))) name = parseInt(name) ?? name;
		}
		if (name == $triggerLock) {
			delete this[$triggerLock];
			return true;
		}
		const old = safeGet(target, name);
		const got = Reflect.deleteProperty(target, name);
		if (!this[$triggerLock] && name != "length" && name != $triggerLock && typeof name != "symbol") {
			if (old != null) subscriptRegistry.get(target)?.trigger?.(name, name, old, "delete");
		}
		return got;
	}
};
/** Proxy handler for observable objects and ref-like `{ value }` containers. */
var ObserveObjectHandler = class {
	[$triggerLock];
	constructor() {}
	get(target, name, ctx) {
		if ([
			$extractKey$,
			$originalKey$,
			"@target",
			"deref",
			"then",
			"catch",
			"finally"
		].indexOf(name) >= 0 && safeGet(target, name) != null && safeGet(target, name) != target) return typeof safeGet(target, name) == "function" ? bindCtx(target, safeGet(target, name)) : safeGet(target, name);
		const registry = subscriptRegistry.get(target) ?? subscriptRegistry.get(safeGet(target, "value") ?? target);
		const sys = systemGet(target, name, registry);
		if (sys != null) return sys;
		if (safeGet(target, name) == null && name != "value" && hasValue(target) && safeGet(target, "value") != null && (typeof safeGet(target, "value") == "object" || typeof safeGet(target, "value") == "function") && safeGet(safeGet(target, "value"), name) != null) target = safeGet(target, "value") ?? target;
		const obs = observableAPIMethods(target, name, registry);
		if (obs != null) return obs;
		if (name == $triggerLess) return makeTriggerLess.call(this, this);
		if (name == $trigger) return createTriggerAPI(registry, (options) => {
			const key = triggerKeyOf(target, options.key ?? options.name ?? realPropOf$1(target) ?? "value");
			const oldValue = triggerOptionValue(options, "oldValue", () => key == "value" || key == realPropOf$1(target) ? safeGet(target, $value) : void 0);
			const value = triggerOptionValue(options, "value", () => triggerValueOf(target, key));
			return registry?.trigger?.(key, value, oldValue, triggerOptionTrigger(options, "manual"));
		});
		if (name == Symbol.toPrimitive) return (hint) => {
			const ft = fallThrough(target, name);
			if (safeGet(ft, name)) return safeGet(ft, name)?.(hint);
			if (isPrimitive(ft)) return tryParseByHint(ft, hint);
			if (isPrimitive(safeGet(ft, "value"))) return tryParseByHint(safeGet(ft, "value"), hint);
			return tryParseByHint(safeGet(ft, "value") ?? ft, hint);
		};
		if (name == Symbol.toStringTag) return () => {
			const ft = fallThrough(target, name);
			if (safeGet(ft, name)) return safeGet(ft, name)?.();
			if (isPrimitive(ft)) return String(ft ?? "") || "";
			if (isPrimitive(safeGet(ft, "value"))) return String(safeGet(ft, "value") ?? "") || "";
			return String(safeGet(ft, "value") ?? ft ?? "") || "";
		};
		if (name == "toString") return () => {
			const ft = fallThrough(target, name);
			if (safeGet(ft, name)) return safeGet(ft, name)?.();
			if (safeGet(ft, Symbol.toStringTag)) return safeGet(ft, Symbol.toStringTag)?.();
			if (isPrimitive(ft)) return String(ft ?? "") || "";
			if (isPrimitive(safeGet(ft, "value"))) return String(safeGet(ft, "value") ?? "") || "";
			return String(safeGet(ft, "value") ?? ft ?? "") || "";
		};
		if (name == "valueOf") return () => {
			const ft = fallThrough(target, name);
			if (safeGet(ft, name)) return safeGet(ft, name)?.();
			if (safeGet(ft, Symbol.toPrimitive)) return safeGet(ft, Symbol.toPrimitive)?.();
			if (isPrimitive(ft)) return ft;
			if (isPrimitive(safeGet(ft, "value"))) return safeGet(ft, "value");
			return safeGet(ft, "value") ?? ft;
		};
		if (typeof name == "symbol" && (name in target || safeGet(target, name) != null)) return safeGet(target, name);
		return fallThrough(target, name);
	}
	apply(target, ctx, args) {
		return Reflect.apply(target, ctx, args);
	}
	ownKeys(target) {
		return Reflect.ownKeys(target);
	}
	construct(target, args, newT) {
		return Reflect.construct(target, args, newT);
	}
	isExtensible(target) {
		return Reflect.isExtensible(target);
	}
	getOwnPropertyDescriptor(target, key) {
		let got = void 0;
		try {
			__safeGetGuard?.getOrInsert?.(target, /* @__PURE__ */ new Set())?.add?.(key);
			if (__safeGetGuard?.get?.(target)?.has?.(key)) got = void 0;
			got = Reflect.getOwnPropertyDescriptor(target, key);
		} catch (e) {
			got = void 0;
		} finally {
			__safeGetGuard?.get?.(target)?.delete?.(key);
		}
		return got;
	}
	has(target, prop) {
		return prop in target;
	}
	set(target, name, value) {
		const skip = systemSkipGet(target, name);
		if (skip != null) return skip;
		return potentiallyAsync(value, (v) => {
			const skip = systemSkipGet(v, name);
			if (skip != null) return skip;
			if (name == $triggerLock && value) {
				this[$triggerLock] = !!value;
				return true;
			}
			if (name == $triggerLock && !value) {
				delete this[$triggerLock];
				return true;
			}
			const $original = target;
			if (safeGet(target, name) == null && name != "value" && hasValue(target) && safeGet(target, "value") != null && (typeof safeGet(target, "value") == "object" || typeof safeGet(target, "value") == "function") && safeGet(safeGet(target, "value"), name) != null) target = safeGet(target, "value") ?? target;
			if (typeof name == "symbol" && !(safeGet(target, name) != null && name in target)) return;
			const triggerName = triggerKeyOf(target, name);
			const oldValue = name == "value" ? safeGet(target, $value) ?? safeGet(target, name) : safeGet(target, name);
			target[name] = v;
			const newValue = safeGet(target, name) ?? v;
			if (!this[$triggerLock] && typeof name != "symbol" && (safeGet(target, $isNotEqual) ?? isNotEqual)?.(oldValue, newValue)) (subscriptRegistry.get(target) ?? subscriptRegistry.get($original))?.trigger?.(triggerName, v, oldValue);
			return true;
		});
	}
	defineProperty(target, name, descriptor) {
		const skip = systemSkipGet(target, name);
		if (skip != null) return skip;
		if (name == $triggerLock && descriptor.value) {
			this[$triggerLock] = !!descriptor.value;
			return true;
		}
		if (name == $triggerLock && !descriptor.value) {
			delete this[$triggerLock];
			return true;
		}
		if (safeGet(target, name) == null && name != "value" && hasValue(target) && safeGet(target, "value") != null && (typeof safeGet(target, "value") == "object" || typeof safeGet(target, "value") == "function") && safeGet(safeGet(target, "value"), name) != null) target = safeGet(target, "value") ?? target;
		if (descriptor.get == void 0 && descriptor.set == void 0) return Reflect.defineProperty(target, name, descriptor);
		const oldValue = safeGet(target, name);
		const $result = Reflect.defineProperty(target, name, {
			get: descriptor.get,
			set: descriptor.set,
			enumerable: descriptor.enumerable ?? true,
			configurable: descriptor.configurable ?? true
		});
		safeSet(target, name, oldValue);
		return $result;
	}
	deleteProperty(target, name) {
		if (name == $triggerLock) {
			delete this[$triggerLock];
			return true;
		}
		if (safeGet(target, name) == null && name != "value" && hasValue(target) && safeGet(target, "value") != null && (typeof safeGet(target, "value") == "object" || typeof safeGet(target, "value") == "function") && safeGet(safeGet(target, "value"), name) != null) target = safeGet(target, "value") ?? target;
		const oldValue = safeGet(target, name);
		const result = Reflect.deleteProperty(target, name);
		if (!this[$triggerLock] && name != $triggerLock && typeof name != "symbol") subscriptRegistry.get(target)?.trigger?.(name, null, oldValue, "delete");
		return result;
	}
};
/** Proxy handler for observable maps, mapping native map operations to trigger events. */
var ObserveMapHandler = class {
	[$triggerLock];
	constructor() {}
	get(target, name, ctx) {
		if ([
			$extractKey$,
			$originalKey$,
			"@target",
			"deref"
		].indexOf(name) >= 0 && safeGet(target, name) != null && safeGet(target, name) != target) return typeof safeGet(target, name) == "function" ? bindCtx(target, safeGet(target, name)) : safeGet(target, name);
		const registry = subscriptRegistry.get(target);
		const sys = systemGet(target, name, registry);
		if (sys != null) return sys;
		const obs = observableAPIMethods(target, name, registry);
		if (obs != null) return obs;
		target = safeGet(target, $extractKey$) ?? safeGet(target, $originalKey$) ?? target;
		const valueOrFx = bindCtx(target, safeGet(target, name));
		if (typeof name == "symbol" && (name in target || safeGet(target, name) != null)) return valueOrFx;
		if (name == $triggerLess) return makeTriggerLess.call(this, this);
		if (name == $trigger) return createTriggerAPI(registry, (options) => {
			const key = options.key ?? options.name;
			if (key == null) return;
			const value = triggerOptionValue(options, "value", () => target.get(key));
			if (value == null && !hasOwn(options, "value")) return;
			const oldValue = triggerOptionValue(options, "oldValue", () => void 0);
			return registry?.trigger?.(key, value, oldValue, triggerOptionTrigger(options, "manual"));
		});
		if (name == "clear") return () => {
			const oldValues = Array.from(target?.entries?.() || []), result = valueOrFx();
			oldValues.forEach(([prop, oldValue]) => {
				if (!this[$triggerLock]) subscriptRegistry.get(target)?.trigger?.(prop, null, oldValue, "delete");
			});
			return result;
		};
		if (name == "delete") return (prop, _ = null) => {
			const had = target.has(prop), oldValue = target.get(prop), result = valueOrFx(prop);
			if (!this[$triggerLock] && had) subscriptRegistry.get(target)?.trigger?.(prop, null, oldValue, "delete");
			return result;
		};
		if (name == "set") return (prop, value) => potentiallyAsyncMap(value, (v) => {
			const had = target.has(prop), oldValue = target.get(prop), result = valueOrFx(prop, v);
			if (!had || isNotEqual(oldValue, v)) {
				if (!this[$triggerLock]) subscriptRegistry.get(target)?.trigger?.(prop, v, had ? oldValue : null, had ? "set" : "add");
			}
			return result;
		});
		return valueOrFx;
	}
	set(target, name, value) {
		if (name == $triggerLock) {
			this[$triggerLock] = !!value;
			return true;
		}
		if (name == $triggerLock && !value) {
			delete this[$triggerLock];
			return true;
		}
		return Reflect.set(target, name, value);
	}
	has(target, prop) {
		return Reflect.has(target, prop);
	}
	apply(target, ctx, args) {
		return Reflect.apply(target, ctx, args);
	}
	construct(target, args, newT) {
		return Reflect.construct(target, args, newT);
	}
	ownKeys(target) {
		return Reflect.ownKeys(target);
	}
	isExtensible(target) {
		return Reflect.isExtensible(target);
	}
	getOwnPropertyDescriptor(target, key) {
		let got = void 0;
		try {
			__safeGetGuard?.getOrInsert?.(target, /* @__PURE__ */ new Set())?.add?.(key);
			if (__safeGetGuard?.get?.(target)?.has?.(key)) got = void 0;
			got = Reflect.getOwnPropertyDescriptor(target, key);
		} catch (e) {
			got = void 0;
		} finally {
			__safeGetGuard?.get?.(target)?.delete?.(key);
		}
		return got;
	}
	deleteProperty(target, name) {
		if (name == $triggerLock) {
			delete this[$triggerLock];
			return true;
		}
		return Reflect.deleteProperty(target, name);
	}
};
/** Proxy handler for observable sets, emitting membership changes as reactive events. */
var ObserveSetHandler = class {
	[$triggerLock] = false;
	constructor() {}
	get(target, name, ctx) {
		if ([
			$extractKey$,
			$originalKey$,
			"@target",
			"deref"
		].indexOf(name) >= 0 && safeGet(target, name) != null && safeGet(target, name) != target) return typeof safeGet(target, name) == "function" ? bindCtx(target, safeGet(target, name)) : safeGet(target, name);
		const registry = subscriptRegistry.get(target);
		const sys = systemGet(target, name, registry);
		if (sys != null) return sys;
		const obs = observableAPIMethods(target, name, registry);
		if (obs != null) return obs;
		target = safeGet(target, $extractKey$) ?? safeGet(target, $originalKey$) ?? target;
		const valueOrFx = bindCtx(target, safeGet(target, name));
		if (typeof name == "symbol" && (name in target || safeGet(target, name) != null)) return valueOrFx;
		if (name == $triggerLess) return makeTriggerLess.call(this, this);
		if (name == $trigger) return createTriggerAPI(registry, (options) => {
			const key = options.key ?? options.name;
			if (key == null) return;
			const value = triggerOptionValue(options, "value", () => target.has(key));
			const oldValue = triggerOptionValue(options, "oldValue", () => void 0);
			return registry?.trigger?.(key, value, oldValue, triggerOptionTrigger(options, "manual"));
		});
		if (name == "clear") return () => {
			const oldValues = Array.from(target?.values?.() || []), result = valueOrFx();
			oldValues.forEach((oldValue) => {
				if (!this[$triggerLock]) subscriptRegistry.get(target)?.trigger?.(null, null, oldValue, "delete");
			});
			return result;
		};
		if (name == "delete") return (value) => {
			const had = target.has(value), oldValue = had ? value : null, result = valueOrFx(value);
			if (!this[$triggerLock] && had) subscriptRegistry.get(target)?.trigger?.(value, null, oldValue, "delete");
			return result;
		};
		if (name == "add") return (value) => {
			const had = target.has(value), oldValue = had ? value : null, result = valueOrFx(value);
			if (!had) {
				if (!this[$triggerLock]) subscriptRegistry.get(target)?.trigger?.(value, value, oldValue, "add");
			}
			return result;
		};
		return valueOrFx;
	}
	set(target, name, value) {
		if (name == $triggerLock && value) {
			this[$triggerLock] = !!value;
			return true;
		}
		if (name == $triggerLock && !value) {
			delete this[$triggerLock];
			return true;
		}
		return Reflect.set(target, name, value);
	}
	has(target, prop) {
		return Reflect.has(target, prop);
	}
	apply(target, ctx, args) {
		return Reflect.apply(target, ctx, args);
	}
	construct(target, args, newT) {
		return Reflect.construct(target, args, newT);
	}
	ownKeys(target) {
		return Reflect.ownKeys(target);
	}
	isExtensible(target) {
		return Reflect.isExtensible(target);
	}
	getOwnPropertyDescriptor(target, key) {
		let got = void 0;
		try {
			__safeGetGuard?.getOrInsert?.(target, /* @__PURE__ */ new Set())?.add?.(key);
			if (__safeGetGuard?.get?.(target)?.has?.(key)) got = void 0;
			got = Reflect.getOwnPropertyDescriptor(target, key);
		} catch (e) {
			got = void 0;
		} finally {
			__safeGetGuard?.get?.(target)?.delete?.(key);
		}
		return got;
	}
	deleteProperty(target, name) {
		if (name == $triggerLock) {
			delete this[$triggerLock];
			return true;
		}
		return Reflect.deleteProperty(target, name);
	}
};
/** Lightweight internal check used before wrapping a target again. */
var $isObservable = (target) => {
	return !!((typeof target == "object" || typeof target == "function") && target != null && (target?.[$extractKey$] || target?.[$affected]));
};
/** Wrap an array with the array-specific observable proxy. */
var observeArray = (arr) => {
	return $isObservable(arr) ? arr : wrapWith(arr, new ObserveArrayHandler());
};
/** Wrap an object with the object-specific observable proxy. */
var observeObject = (obj) => {
	return $isObservable(obj) ? obj : wrapWith(obj, new ObserveObjectHandler());
};
/** Wrap a map with the map-specific observable proxy. */
var observeMap = (map) => {
	return $isObservable(map) ? map : wrapWith(map, new ObserveMapHandler());
};
/** Wrap a set with the set-specific observable proxy. */
var observeSet = (set) => {
	return $isObservable(set) ? set : wrapWith(set, new ObserveSetHandler());
};
//#endregion
//#region ../../modules/projects/object.ts/src/core/Primitives.ts
/**
* Reactive primitive/ref helpers plus the main `observe()` entrypoint.
*
* This module creates typed refs (`numberRef`, `stringRef`, `booleanRef`),
* property refs, delayed trigger behaviors, and the canonical dispatcher that
* chooses the correct observable wrapper for arrays, objects, maps, and sets.
*/
/** Numeric ref with coercion, primitive conversion hooks, and optional promise initialization. */
var numberRef = (initial, behavior) => {
	const isPromise = initial instanceof Promise || typeof initial?.then == "function";
	const $r = observe({
		[$promise]: isPromise ? initial : null,
		[$value]: isPromise ? 0 : Number(deref(initial) || 0) || 0,
		[$behavior]: behavior,
		[Symbol?.toStringTag]() {
			return String(this?.[$value] ?? "") || "";
		},
		[Symbol?.toPrimitive](hint) {
			return tryParseByHint((typeof this?.[$value] != "object" ? this?.[$value] : this?.[$value]?.value || 0) ?? 0, hint);
		},
		set value(v) {
			this[$value] = (v != null && !Number.isNaN(v) ? Number(v) : this[$value]) || 0;
		},
		get value() {
			return Number(this[$value] || 0) || 0;
		}
	});
	initial?.then?.((v) => $r.value = v);
	return $r;
};
/** String ref with coercion, primitive conversion hooks, and optional promise initialization. */
var stringRef = (initial, behavior) => {
	const isPromise = initial instanceof Promise || typeof initial?.then == "function";
	const $r = observe({
		[$promise]: isPromise ? initial : null,
		[$value]: (isPromise ? "" : String(deref(typeof initial == "number" ? String(initial) : initial || ""))) ?? "",
		[$behavior]: behavior,
		[Symbol?.toStringTag]() {
			return String(this?.[$value] ?? "") ?? "";
		},
		[Symbol?.toPrimitive](hint) {
			return tryParseByHint(this?.[$value] ?? "", hint);
		},
		set value(v) {
			this[$value] = String(typeof v == "number" ? String(v) : v || "") ?? "";
		},
		get value() {
			return String(this[$value] ?? "") ?? "";
		}
	});
	initial?.then?.((v) => $r.value = v);
	return $r;
};
/** Boolean ref with truthy/falsy coercion and optional promise initialization. */
var booleanRef = (initial, behavior) => {
	const isPromise = initial instanceof Promise || typeof initial?.then == "function";
	const $r = observe({
		[$promise]: isPromise ? initial : null,
		[$value]: (isPromise ? false : (deref(initial) != null ? typeof deref(initial) == "string" ? true : !!deref(initial) : false) || false) || false,
		[$behavior]: behavior,
		[Symbol?.toStringTag]() {
			return String(this?.[$value] ?? "") || "";
		},
		[Symbol?.toPrimitive](hint) {
			return tryParseByHint(!!this?.[$value] || false, hint);
		},
		set value(v) {
			this[$value] = (v != null ? typeof v == "string" ? true : !!v : this[$value]) || false;
		},
		get value() {
			return this[$value] || false;
		}
	});
	initial?.then?.((v) => $r.value = v);
	return $r;
};
/** Generic ref wrapper for values that do not need one of the specialized primitive ref shapes. */
var wrapRef = (initial, behavior) => {
	const isPromise = initial instanceof Promise || typeof initial?.then == "function";
	const $r = observe({
		[$promise]: isPromise ? initial : null,
		[$behavior]: behavior,
		[Symbol?.toStringTag]() {
			return String(this.value ?? "") || "";
		},
		[Symbol?.toPrimitive](hint) {
			return tryParseByHint(this.value, hint);
		},
		value: isPromise ? null : deref(initial)
	});
	initial?.then?.((v) => $r.value = v);
	affected(initial, (v) => {
		$r?.[$trigger]?.();
	});
	return $r;
};
var markRealProp = (target, realProp) => {
	if (target == null || typeof target != "object" && typeof target != "function") return target;
	try {
		Object.defineProperty(target, $realProp, {
			value: realProp,
			writable: true,
			configurable: true
		});
	} catch {
		try {
			target[$realProp] = realProp;
		} catch {}
	}
	try {
		Object.defineProperty(target, "realProp", {
			value: realProp,
			writable: true,
			configurable: true
		});
	} catch {
		try {
			target.realProp = realProp;
		} catch {}
	}
	return target;
};
/**
* Create a reactive reference to one property/slot of an observable source.
*
* WHY: this keeps duplex synchronization between the source slot and the
* returned ref-like object while still behaving like a regular `value` ref.
*
* Supported sources:
* - object / array: `src[srcProp]`
* - Map / WeakMap: `src.get(srcProp)` / `src.set(srcProp, v)`
* - Set / WeakSet: boolean membership of `srcProp` (`has` / `add` / `delete`)
*
* Also accepts `[map|set, key]` pair form (same shape as `affected()`).
*
* WHY (Set → boolean): observable object `fallThrough` maps `null`/`undefined`
* `.value` back to the wrapper itself, so absence must be a real primitive (`false`).
*/
var propRef = (src, srcProp = "value", initial, behavior) => {
	if (isPrimitive(src) || !src) return src;
	if (Array.isArray(src) && src.length == 2 && src[0] != null && (src[0] instanceof Map || src[0] instanceof WeakMap || src[0] instanceof Set || src[0] instanceof WeakSet)) {
		if (srcProp == null || srcProp === "value") srcProp = src[1];
		src = src[0];
	} else if (Array.isArray(src) && !isArrayInvalidKey(src?.[1], src) && (Array.isArray(src?.[0]) || typeof src?.[0] == "object" || typeof src?.[0] == "function")) src = src?.[0];
	const isMap = src instanceof Map || src instanceof WeakMap;
	const isSet = src instanceof Set || src instanceof WeakSet;
	if (isMap || isSet) {
		if (srcProp == null) return;
	} else if ((srcProp ??= Array.isArray(src) ? null : "value") == null || isArrayInvalidKey(srcProp, src)) return;
	const readSlot = () => {
		if (isMap) return src.get(srcProp);
		if (isSet) return src.has(srcProp);
		return src?.[srcProp];
	};
	const writeSlot = (v) => {
		if (isMap) {
			src.set(srcProp, v);
			return v;
		}
		if (isSet) {
			if (v) src.add(srcProp);
			else src.delete(srcProp);
			return src.has(srcProp);
		}
		return src[srcProp] = v;
	};
	if (isMap && initial !== void 0 && !src.has(srcProp)) src.set(srcProp, initial);
	else if (isSet && initial && !src.has(srcProp)) src.add(srcProp);
	const current = readSlot();
	if (!isSet && srcProp != null && hasValue(current) && isObservable(current)) return markRealProp(recoverReactive(current), srcProp);
	if (!isMap && !isSet && srcProp && typeof src?.getProperty == "function" && isObservable(src?.getProperty?.(srcProp))) return markRealProp(src?.getProperty?.(srcProp), srcProp);
	if (!isMap && !isSet) src[srcProp] ??= initial ?? src[srcProp];
	const r = observe({
		[$value]: isSet ? !!readSlot() : readSlot() ?? initial,
		[$behavior]: behavior,
		[Symbol?.toStringTag]() {
			return String(readSlot() ?? this[$value] ?? "") || "";
		},
		[Symbol?.toPrimitive](hint) {
			return tryParseByHint(readSlot(), hint);
		},
		set value(v) {
			r[$triggerLock$1] = true;
			if (isSet) this[$value] = writeSlot(v);
			else {
				const next = v ?? defaultByType(readSlot());
				this[$value] = writeSlot(next);
			}
			r[$triggerLock$1] = false;
		},
		get value() {
			const slot = readSlot();
			return this[$value] = isSet ? !!slot : slot ?? this[$value];
		}
	});
	markRealProp(r, srcProp);
	const usb = affected(src, (v, _prop, old, trigger) => {
		if (_prop === srcProp) {
			const value = isSet ? v != null : v;
			const oldValue = isSet ? old != null : old;
			r?.[$trigger]?.({
				key: srcProp,
				value,
				oldValue,
				trigger
			});
		}
	});
	addToCallChain(r, Symbol.dispose, usb);
	return r;
};
/** Pick the most suitable ref implementation for the provided value type. */
var $ref = (typed, behavior) => {
	switch (typeof typed) {
		case "boolean": return booleanRef(typed, behavior);
		case "number": return numberRef(typed, behavior);
		case "string": return stringRef(typed, behavior);
		case "object": if (typed != null) return wrapRef(observe(typed), behavior);
		default: return wrapRef(typed, behavior);
	}
};
/** Public ref helper that can either wrap a value or target one specific property. */
var ref = (typed, prop = "value", behavior) => {
	const $r = isObservable(typed) ? typed : $ref(typed, behavior);
	if (prop != null) return propRef($r, prop, behavior);
	else return $r;
};
/** `function` (not `const`) so circular Mainline ↔ Primitives/Assigned init cannot TDZ in bundled output. */
function observe(target, stateName) {
	if (target == null || typeof target == "symbol" || !(typeof target == "object" || typeof target == "function") || $isObservable(target)) return target;
	if ((target = deref?.(target)) == null || target instanceof Promise || target instanceof WeakRef || $isObservable(target)) return target;
	const unwrap = target;
	if (unwrap == null || typeof unwrap == "symbol" || !(typeof unwrap == "object" || typeof unwrap == "function") || unwrap instanceof Promise || unwrap instanceof WeakRef) return unwrap;
	let reactive = unwrap;
	if (Array.isArray(unwrap)) {
		reactive = observeArray(unwrap);
		return reactive;
	} else if (unwrap instanceof Map) {
		reactive = observeMap(unwrap);
		return reactive;
	} else if (unwrap instanceof Set) {
		reactive = observeSet(unwrap);
		return reactive;
	} else if (typeof unwrap == "function" || typeof unwrap == "object") {
		reactive = observeObject(unwrap);
		return reactive;
	}
	return reactive;
}
/** Detect whether a value is already wrapped in the `object.ts` observable protocol. */
var isObservable = (target) => {
	if (typeof HTMLInputElement != "undefined" && target instanceof HTMLInputElement) return true;
	return !!((typeof target == "object" || typeof target == "function") && target != null && (target?.[$extractKey$] || target?.[$affected] || subscriptRegistry?.has?.(target)));
};
/** Re-enter the observable pipeline only when the target already carries observable metadata. */
var recoverReactive = (target) => {
	return isObservable(target) ? observe(target) : null;
};
//#endregion
//#region ../../modules/projects/object.ts/src/core/Mainline.ts
/**
* Subscription and derivation pipeline for `object.ts`.
*
* This module resolves how callbacks subscribe to observable values, tuples,
* promises, DOM inputs, and iteration sources, then builds higher-level
* combinators like `assign`, `link`, `computed`, and `derivate`.
*/
var specializedSubscribe = /* @__PURE__ */ new WeakMap();
var checkValidObj = (obj) => {
	if (typeof obj == "symbol" || obj == null || !(typeof obj == "object" || typeof obj == "function")) return;
	return obj;
};
var initialTrigger = "initial";
var realPropOf = (target) => {
	const prop = target?.[$realProp] ?? target?.realProp;
	return isKeyType(prop) ? prop : null;
};
var normalizeAffectedProp = (target, prop) => {
	const realProp = realPropOf(target);
	if (realProp != null && (prop == null || prop == "value")) return realProp;
	return prop;
};
var propValueOf = (target, prop) => {
	if (prop != null && prop == realPropOf(target)) return target?.value;
	return target?.[prop];
};
var callByPropRefAware = (target, prop, cb, ctx) => {
	if (prop != null && prop == realPropOf(target)) {
		const value = propValueOf(target, prop);
		if (value != null) return cb?.(value, prop, null, "set");
	}
	return callByProp(target, prop, cb, ctx);
};
var withTrigger = (cb, options, trigger) => {
	const normalized = normalizeAffectedOptions(options);
	if (trigger == initialTrigger) {
		if (!normalized.triggerImmediately) return;
	} else if (!triggerFilterAllows(normalized.affectTypes, trigger)) return;
	return (value, name, oldValue, ...etc) => cb?.(value, name, oldValue, trigger, ...etc);
};
/** Default subscription strategy for already-observable targets. */
var subscribeDirectly = (target, prop, cb, options = ["*"]) => {
	if (!target) return;
	if (!checkValidObj(target)) return;
	const tProp = prop != Symbol.iterator ? normalizeAffectedProp(target, prop) : null;
	let registry = target?.[$registryKey$] ?? subscriptRegistry.get(target);
	target = target?.[$extractKey$] ?? target;
	queueMicrotask(() => {
		const initialCb = withTrigger(cb, options, initialTrigger);
		if (!initialCb) return;
		if (tProp != null && tProp != Symbol.iterator) callByPropRefAware(target, tProp, initialCb, null);
		else callByAllProp(target, initialCb, null);
	});
	let unSub = registry?.affected?.(cb, tProp, options);
	if (target?.[Symbol.dispose]) return unSub;
	addToCallChain(unSub, Symbol.dispose, unSub);
	addToCallChain(unSub, Symbol.asyncDispose, unSub);
	addToCallChain(target, Symbol.dispose, unSub);
	addToCallChain(target, Symbol.asyncDispose, unSub);
	return unSub;
};
/** Subscription adapter for DOM inputs, mapping `change` events onto reactive callbacks. */
var subscribeInput = (tg, _, cb, options = ["*"]) => {
	const affectTypes = normalizeAffectedOptions(options).affectTypes;
	const $opt = {};
	let oldValue = tg?.value;
	const $cb = (ev) => {
		const value = ev?.target?.value;
		if (triggerFilterAllows(affectTypes, "set")) cb?.(value, "value", oldValue, "set", ev);
		oldValue = value;
	};
	tg?.addEventListener?.("change", $cb, $opt);
	return () => tg?.removeEventListener?.("change", $cb, $opt);
};
var checkIsPaired = (tg) => {
	return Array.isArray(tg) && tg?.length == 2 && checkValidObj(tg?.[0]) && (isKeyType(tg?.[1]) || tg?.[1] == Symbol.iterator);
};
/** Subscription adapter for `[target, prop]` tuples. */
var subscribePaired = (tg, _, cb, options = ["*"]) => {
	const prop = isKeyType(tg?.[1]) ? tg?.[1] : null;
	return affected(tg?.[0], prop, cb, options);
};
/** Defer subscription until a thenable source resolves. */
var subscribeThenable = (obj, prop, cb, options = ["*"]) => {
	return obj?.then?.((obj) => affected?.(obj, prop, cb, options))?.catch?.((e) => {
		console.warn(e);
		return null;
	});
};
/** `function` (not `const`) so circular imports from Assigned/Primitives cannot hit TDZ during bundle init. */
var affected = (obj, prop, cb = () => {}, options) => {
	if (typeof prop == "function") {
		options = cb;
		cb = prop;
		prop = null;
	} else prop = normalizeAffectedProp(obj, prop);
	if (typeof cb == "object" || Array.isArray(cb)) {
		options = cb;
		cb = () => {};
	}
	if (isPrimitive(obj) || typeof obj == "symbol") {
		if (normalizeAffectedOptions(options).triggerImmediately) return Promised(globalThis?.Promise?.try?.(() => {
			return cb?.(obj, null, null, null, initialTrigger);
		}));
	}
	if (typeof obj?.[$affected] == "function") return obj?.[$affected]?.(cb, prop, options);
	else if (checkValidObj(obj)) {
		const wrapped = obj;
		if (specializedSubscribe?.has?.(obj = obj?.[$extractKey$] ?? obj)) return specializedSubscribe?.get?.(obj)?.(wrapped, prop, cb, options);
		if (isObservable(wrapped) || checkIsPaired(obj) && isObservable(obj?.[0])) if (isThenable(obj)) return specializedSubscribe?.getOrInsert?.(obj, subscribeThenable)?.(obj, prop, cb, options);
		else if (checkIsPaired(obj)) return specializedSubscribe?.getOrInsert?.(obj, subscribePaired)?.(obj, prop, cb, options);
		else if (typeof HTMLInputElement != "undefined" && obj instanceof HTMLInputElement) return specializedSubscribe?.getOrInsert?.(obj, subscribeInput)?.(obj, prop, cb, options);
		else return specializedSubscribe?.getOrInsert?.(obj, subscribeDirectly)?.(wrapped, prop, cb, options);
		else {
			const initialCb = withTrigger(cb, options, initialTrigger);
			if (!initialCb) return;
			return Promised(globalThis?.Promise?.try?.(() => {
				if (checkIsPaired(obj)) return callByPropRefAware?.(obj?.[0], obj?.[1], initialCb, null);
				else if (prop != null && prop != Symbol.iterator) return callByPropRefAware?.(obj, prop, initialCb, null);
				else return callByAllProp?.(obj, initialCb, null);
			}));
		}
	}
};
/** Two-level WeakMap used to memoize subscriptions keyed by `[target, callback]` pairs. */
var DoubleWeakMap = class {
	#top = /* @__PURE__ */ new WeakMap();
	#ensureInner(key1) {
		let inner = this.#top.get(key1);
		if (!inner) {
			inner = /* @__PURE__ */ new WeakMap();
			this.#top.set(key1, inner);
		}
		return inner;
	}
	#splitPair(pair) {
		if (!Array.isArray(pair) || pair.length !== 2) return [null, null];
		return pair;
	}
	hasL1(key1) {
		return this.#top.has(key1);
	}
	set(pair, value) {
		const [key1, key2] = this.#splitPair(pair);
		this.#ensureInner(key1).set(key2, value);
		return this;
	}
	get(pair) {
		const [key1, key2] = this.#splitPair(pair);
		return this.#top.get(key1)?.get(key2);
	}
	has(pair) {
		const [key1, key2] = this.#splitPair(pair);
		return this.#top.get(key1)?.has(key2) ?? false;
	}
	delete(pair) {
		const [key1, key2] = this.#splitPair(pair);
		const inner = this.#top.get(key1);
		return inner ? inner.delete(key2) : false;
	}
	deleteTop(key1) {
		return this.#top.delete(key1);
	}
	getOrCreate(pair, factory) {
		const [key1, key2] = this.#splitPair(pair);
		const inner = this.#ensureInner(key1);
		if (inner.has(key2)) return inner.get(key2);
		const value = factory();
		inner.set(key2, value);
		return value;
	}
	getOrInsert(pair, value) {
		const [key1, key2] = this.#splitPair(pair);
		const inner = this.#ensureInner(key1);
		if (inner.has(key2)) return inner.get(key2);
		inner.set(key2, value);
		return value;
	}
	getOrInsertComputed(pair, compute) {
		const [key1, key2] = this.#splitPair(pair);
		const inner = this.#ensureInner(key1);
		if (inner.has(key2)) return inner.get(key2);
		const value = compute([key1, key2]);
		inner.set(key2, value);
		return value;
	}
};
var registeredIterated = new DoubleWeakMap();
/**
* Subscribe to iteration-level changes for arrays, sets, maps, and ref-like
* containers whose `value` should itself be treated as a collection.
*/
function iterated(tg, cb, options = ["*"]) {
	if (!tg) return;
	if (registeredIterated.has([tg, cb])) return registeredIterated.get([tg, cb]);
	const $sub = (value, name, old, trigger) => {
		if (name == "value") {
			const entries = (old?.value ?? old)?.entries?.();
			const basis = tg?.value ?? value?.value ?? value;
			if (entries) for (const [idx, item] of entries) {
				const ofOld = item ?? (old?.value ?? old)?.[idx] ?? null;
				const ofNew = basis?.[idx];
				if (ofOld == null && ofNew != null) cb(ofNew, idx, null, "add");
				else if (ofOld != null && ofNew == null) cb(null, idx, ofOld, "delete");
				else if (isNotEqual(ofOld, ofNew)) cb(ofNew, idx, ofOld, "set");
			}
			return iterated(value ?? tg?.value, cb, options);
		}
		return name == null ? void 0 : tg[name];
	};
	return registeredIterated.getOrInsertComputed([tg, cb], () => {
		if (tg instanceof Set) return affected([observableBySet(tg), Symbol.iterator], cb, options);
		if (tg instanceof Map) return affected(tg, cb, options);
		if (hasValue(tg)) return affected(tg, $sub, options);
		if (Array.isArray(tg) && !(tg?.length == 2 && isKeyType(tg?.[1]) && isObservable(tg?.[0]))) return affected([tg, Symbol.iterator], cb, options);
		return affected(tg, cb, options);
	});
}
/** Remove a previously registered subscription. */
function unaffected(tg, cb) {
	return withPromise(tg, (target) => {
		const isPair = Array.isArray(target) && target?.length == 2 && ["object", "function"].indexOf(typeof target?.[0]) >= 0 && isKeyType(target?.[1]);
		const prop = isPair ? target?.[1] : null;
		target = isPair && prop != null ? target?.[0] ?? target : target;
		const unwrap = typeof target == "object" || typeof target == "function" ? target?.[$extractKey$] ?? target : target;
		(target?.[$registryKey$] ?? subscriptRegistry.get(unwrap))?.unaffected?.(cb, prop);
	});
}
//#endregion
//#region ../../modules/projects/object.ts/src/core/Assigned.ts
/**
* Higher-level composition helpers built on top of the primitive observer layer.
*
* This file provides conditional refs, collection-to-array adapters, duplex
* assignment/linking, and computed values that mirror changes back into refs.
*/
/** View a `Set` as a reactive array that stays synchronized with set membership. */
var observableBySet = (set) => {
	const obs = observe([]);
	obs.push(...Array.from(set?.values?.() || []));
	addToCallChain(obs, Symbol.dispose, affected(set, (value, _, old) => {
		if (isNotEqual(value, old)) if (old == null && value != null) obs.push(value);
		else if (old != null && value == null) {
			const idx = obs.indexOf(old);
			if (idx >= 0) obs.splice(idx, 1);
		} else {
			const idx = obs.indexOf(old);
			if (idx >= 0 && isNotEqual(obs[idx], value)) obs[idx] = value;
		}
	}));
	return obs;
};
//#endregion
export { isCanJustReturn as A, normalizePrimitive as B, camelToKebab as C, handleListeners as D, getValue as E, isPrimitive as F, tryStringAsNumber as H, isVal as I, isValueRef as L, isNotComplexArray as M, isObject as N, hasValue as O, isObservable$1 as P, isValueUnit as R, UUIDv4 as S, deref$1 as T, toRef as V, deepOperateAndClone as _, numberRef as a, $getValue as b, ref as c, addToCallChain as d, safe as f, Promised as g, $triggerControl as h, booleanRef as i, isCanTransfer as j, isArrayOrIterable as k, stringRef as l, $affected as m, affected as n, observe as o, unwrap as p, iterated as r, propRef as s, DoubleWeakMap as t, makeObjectAssignable as u, isNotEqual as v, canBeInteger as w, $set as x, $avoidTrigger as y, kebabToCamel as z };
