import { C as getCorrectOrientation, T as whenAnyScreenChanges, w as orientationNumberMap } from "../fest/dom.js";
//#region ../../node_modules/culori/src/rgb/parseNumber.js
var parseNumber = (color, len) => {
	if (typeof color !== "number") return;
	if (len === 3) return {
		mode: "rgb",
		r: (color >> 8 & 15 | color >> 4 & 240) / 255,
		g: (color >> 4 & 15 | color & 240) / 255,
		b: (color & 15 | color << 4 & 240) / 255
	};
	if (len === 4) return {
		mode: "rgb",
		r: (color >> 12 & 15 | color >> 8 & 240) / 255,
		g: (color >> 8 & 15 | color >> 4 & 240) / 255,
		b: (color >> 4 & 15 | color & 240) / 255,
		alpha: (color & 15 | color << 4 & 240) / 255
	};
	if (len === 6) return {
		mode: "rgb",
		r: (color >> 16 & 255) / 255,
		g: (color >> 8 & 255) / 255,
		b: (color & 255) / 255
	};
	if (len === 8) return {
		mode: "rgb",
		r: (color >> 24 & 255) / 255,
		g: (color >> 16 & 255) / 255,
		b: (color >> 8 & 255) / 255,
		alpha: (color & 255) / 255
	};
};
//#endregion
//#region ../../node_modules/culori/src/colors/named.js
var named = {
	aliceblue: 15792383,
	antiquewhite: 16444375,
	aqua: 65535,
	aquamarine: 8388564,
	azure: 15794175,
	beige: 16119260,
	bisque: 16770244,
	black: 0,
	blanchedalmond: 16772045,
	blue: 255,
	blueviolet: 9055202,
	brown: 10824234,
	burlywood: 14596231,
	cadetblue: 6266528,
	chartreuse: 8388352,
	chocolate: 13789470,
	coral: 16744272,
	cornflowerblue: 6591981,
	cornsilk: 16775388,
	crimson: 14423100,
	cyan: 65535,
	darkblue: 139,
	darkcyan: 35723,
	darkgoldenrod: 12092939,
	darkgray: 11119017,
	darkgreen: 25600,
	darkgrey: 11119017,
	darkkhaki: 12433259,
	darkmagenta: 9109643,
	darkolivegreen: 5597999,
	darkorange: 16747520,
	darkorchid: 10040012,
	darkred: 9109504,
	darksalmon: 15308410,
	darkseagreen: 9419919,
	darkslateblue: 4734347,
	darkslategray: 3100495,
	darkslategrey: 3100495,
	darkturquoise: 52945,
	darkviolet: 9699539,
	deeppink: 16716947,
	deepskyblue: 49151,
	dimgray: 6908265,
	dimgrey: 6908265,
	dodgerblue: 2003199,
	firebrick: 11674146,
	floralwhite: 16775920,
	forestgreen: 2263842,
	fuchsia: 16711935,
	gainsboro: 14474460,
	ghostwhite: 16316671,
	gold: 16766720,
	goldenrod: 14329120,
	gray: 8421504,
	green: 32768,
	greenyellow: 11403055,
	grey: 8421504,
	honeydew: 15794160,
	hotpink: 16738740,
	indianred: 13458524,
	indigo: 4915330,
	ivory: 16777200,
	khaki: 15787660,
	lavender: 15132410,
	lavenderblush: 16773365,
	lawngreen: 8190976,
	lemonchiffon: 16775885,
	lightblue: 11393254,
	lightcoral: 15761536,
	lightcyan: 14745599,
	lightgoldenrodyellow: 16448210,
	lightgray: 13882323,
	lightgreen: 9498256,
	lightgrey: 13882323,
	lightpink: 16758465,
	lightsalmon: 16752762,
	lightseagreen: 2142890,
	lightskyblue: 8900346,
	lightslategray: 7833753,
	lightslategrey: 7833753,
	lightsteelblue: 11584734,
	lightyellow: 16777184,
	lime: 65280,
	limegreen: 3329330,
	linen: 16445670,
	magenta: 16711935,
	maroon: 8388608,
	mediumaquamarine: 6737322,
	mediumblue: 205,
	mediumorchid: 12211667,
	mediumpurple: 9662683,
	mediumseagreen: 3978097,
	mediumslateblue: 8087790,
	mediumspringgreen: 64154,
	mediumturquoise: 4772300,
	mediumvioletred: 13047173,
	midnightblue: 1644912,
	mintcream: 16121850,
	mistyrose: 16770273,
	moccasin: 16770229,
	navajowhite: 16768685,
	navy: 128,
	oldlace: 16643558,
	olive: 8421376,
	olivedrab: 7048739,
	orange: 16753920,
	orangered: 16729344,
	orchid: 14315734,
	palegoldenrod: 15657130,
	palegreen: 10025880,
	paleturquoise: 11529966,
	palevioletred: 14381203,
	papayawhip: 16773077,
	peachpuff: 16767673,
	peru: 13468991,
	pink: 16761035,
	plum: 14524637,
	powderblue: 11591910,
	purple: 8388736,
	rebeccapurple: 6697881,
	red: 16711680,
	rosybrown: 12357519,
	royalblue: 4286945,
	saddlebrown: 9127187,
	salmon: 16416882,
	sandybrown: 16032864,
	seagreen: 3050327,
	seashell: 16774638,
	sienna: 10506797,
	silver: 12632256,
	skyblue: 8900331,
	slateblue: 6970061,
	slategray: 7372944,
	slategrey: 7372944,
	snow: 16775930,
	springgreen: 65407,
	steelblue: 4620980,
	tan: 13808780,
	teal: 32896,
	thistle: 14204888,
	tomato: 16737095,
	turquoise: 4251856,
	violet: 15631086,
	wheat: 16113331,
	white: 16777215,
	whitesmoke: 16119285,
	yellow: 16776960,
	yellowgreen: 10145074
};
//#endregion
//#region ../../node_modules/culori/src/rgb/parseNamed.js
var parseNamed = (color) => {
	return parseNumber(named[color.toLowerCase()], 6);
};
//#endregion
//#region ../../node_modules/culori/src/rgb/parseHex.js
var hex = /^#?([0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})$/i;
var parseHex = (color) => {
	let match;
	return (match = color.match(hex)) ? parseNumber(parseInt(match[1], 16), match[1].length) : void 0;
};
//#endregion
//#region ../../node_modules/culori/src/util/regex.js
var num$1 = "([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)";
`${num$1}`;
var per = `${num$1}%`;
`${num$1}`;
var num_per = `(?:${num$1}%|${num$1})`;
var num_per_none = `(?:${num$1}%|${num$1}|none)`;
var hue$1 = `(?:${num$1}(deg|grad|rad|turn)|${num$1})`;
`${num$1}${num$1}`;
var c = `\\s*,\\s*`;
new RegExp("^" + num_per_none + "$");
//#endregion
//#region ../../node_modules/culori/src/rgb/parseRgbLegacy.js
var rgb_num_old = new RegExp(`^rgba?\\(\\s*${num$1}${c}${num$1}${c}${num$1}\\s*(?:,\\s*${num_per}\\s*)?\\)$`);
var rgb_per_old = new RegExp(`^rgba?\\(\\s*${per}${c}${per}${c}${per}\\s*(?:,\\s*${num_per}\\s*)?\\)$`);
var parseRgbLegacy = (color) => {
	let res = { mode: "rgb" };
	let match;
	if (match = color.match(rgb_num_old)) {
		if (match[1] !== void 0) res.r = match[1] / 255;
		if (match[2] !== void 0) res.g = match[2] / 255;
		if (match[3] !== void 0) res.b = match[3] / 255;
	} else if (match = color.match(rgb_per_old)) {
		if (match[1] !== void 0) res.r = match[1] / 100;
		if (match[2] !== void 0) res.g = match[2] / 100;
		if (match[3] !== void 0) res.b = match[3] / 100;
	} else return;
	if (match[4] !== void 0) res.alpha = Math.max(0, Math.min(1, match[4] / 100));
	else if (match[5] !== void 0) res.alpha = Math.max(0, Math.min(1, +match[5]));
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/_prepare.js
var prepare = (color, mode) => color === void 0 ? void 0 : typeof color !== "object" ? parse(color) : color.mode !== void 0 ? color : mode ? {
	...color,
	mode
} : void 0;
//#endregion
//#region ../../node_modules/culori/src/converter.js
var converter = (target_mode = "rgb") => (color) => (color = prepare(color, target_mode)) !== void 0 ? color.mode === target_mode ? color : converters[color.mode][target_mode] ? converters[color.mode][target_mode](color) : target_mode === "rgb" ? converters[color.mode].rgb(color) : converters.rgb[target_mode](converters[color.mode].rgb(color)) : void 0;
//#endregion
//#region ../../node_modules/culori/src/modes.js
var converters = {};
var modes = {};
var parsers = [];
var colorProfiles = {};
var identity = (v) => v;
var useMode = (definition) => {
	converters[definition.mode] = {
		...converters[definition.mode],
		...definition.toMode
	};
	Object.keys(definition.fromMode || {}).forEach((k) => {
		if (!converters[k]) converters[k] = {};
		converters[k][definition.mode] = definition.fromMode[k];
	});
	if (!definition.ranges) definition.ranges = {};
	if (!definition.difference) definition.difference = {};
	definition.channels.forEach((channel) => {
		if (definition.ranges[channel] === void 0) definition.ranges[channel] = [0, 1];
		if (!definition.interpolate[channel]) throw new Error(`Missing interpolator for: ${channel}`);
		if (typeof definition.interpolate[channel] === "function") definition.interpolate[channel] = { use: definition.interpolate[channel] };
		if (!definition.interpolate[channel].fixup) definition.interpolate[channel].fixup = identity;
	});
	modes[definition.mode] = definition;
	(definition.parse || []).forEach((parser) => {
		useParser(parser, definition.mode);
	});
	return converter(definition.mode);
};
var getMode = (mode) => modes[mode];
var useParser = (parser, mode) => {
	if (typeof parser === "string") {
		if (!mode) throw new Error(`'mode' required when 'parser' is a string`);
		colorProfiles[parser] = mode;
	} else if (typeof parser === "function") {
		if (parsers.indexOf(parser) < 0) parsers.push(parser);
	}
};
//#endregion
//#region ../../node_modules/culori/src/parse.js
var IdentStartCodePoint = /[^\x00-\x7F]|[a-zA-Z_]/;
var IdentCodePoint = /[^\x00-\x7F]|[-\w]/;
var Tok = {
	Function: "function",
	Ident: "ident",
	Number: "number",
	Percentage: "percentage",
	ParenClose: ")",
	None: "none",
	Hue: "hue",
	Alpha: "alpha"
};
var _i = 0;
function is_num(chars) {
	let ch = chars[_i];
	let ch1 = chars[_i + 1];
	if (ch === "-" || ch === "+") return /\d/.test(ch1) || ch1 === "." && /\d/.test(chars[_i + 2]);
	if (ch === ".") return /\d/.test(ch1);
	return /\d/.test(ch);
}
function is_ident(chars) {
	if (_i >= chars.length) return false;
	let ch = chars[_i];
	if (IdentStartCodePoint.test(ch)) return true;
	if (ch === "-") {
		if (chars.length - _i < 2) return false;
		let ch1 = chars[_i + 1];
		if (ch1 === "-" || IdentStartCodePoint.test(ch1)) return true;
		return false;
	}
	return false;
}
var huenits = {
	deg: 1,
	rad: 180 / Math.PI,
	grad: 9 / 10,
	turn: 360
};
function num(chars) {
	let value = "";
	if (chars[_i] === "-" || chars[_i] === "+") value += chars[_i++];
	value += digits(chars);
	if (chars[_i] === "." && /\d/.test(chars[_i + 1])) value += chars[_i++] + digits(chars);
	if (chars[_i] === "e" || chars[_i] === "E") {
		if ((chars[_i + 1] === "-" || chars[_i + 1] === "+") && /\d/.test(chars[_i + 2])) value += chars[_i++] + chars[_i++] + digits(chars);
		else if (/\d/.test(chars[_i + 1])) value += chars[_i++] + digits(chars);
	}
	if (is_ident(chars)) {
		let id = ident(chars);
		if (id === "deg" || id === "rad" || id === "turn" || id === "grad") return {
			type: Tok.Hue,
			value: value * huenits[id]
		};
		return;
	}
	if (chars[_i] === "%") {
		_i++;
		return {
			type: Tok.Percentage,
			value: +value
		};
	}
	return {
		type: Tok.Number,
		value: +value
	};
}
function digits(chars) {
	let v = "";
	while (/\d/.test(chars[_i])) v += chars[_i++];
	return v;
}
function ident(chars) {
	let v = "";
	while (_i < chars.length && IdentCodePoint.test(chars[_i])) v += chars[_i++];
	return v;
}
function identlike(chars) {
	let v = ident(chars);
	if (chars[_i] === "(") {
		_i++;
		return {
			type: Tok.Function,
			value: v
		};
	}
	if (v === "none") return {
		type: Tok.None,
		value: void 0
	};
	return {
		type: Tok.Ident,
		value: v
	};
}
function tokenize(str = "") {
	let chars = str.trim();
	let tokens = [];
	let ch;
	_i = 0;
	while (_i < chars.length) {
		ch = chars[_i++];
		if (ch === "\n" || ch === "	" || ch === " ") {
			while (_i < chars.length && (chars[_i] === "\n" || chars[_i] === "	" || chars[_i] === " ")) _i++;
			continue;
		}
		if (ch === ",") return;
		if (ch === ")") {
			tokens.push({ type: Tok.ParenClose });
			continue;
		}
		if (ch === "+") {
			_i--;
			if (is_num(chars)) {
				tokens.push(num(chars));
				continue;
			}
			return;
		}
		if (ch === "-") {
			_i--;
			if (is_num(chars)) {
				tokens.push(num(chars));
				continue;
			}
			if (is_ident(chars)) {
				tokens.push({
					type: Tok.Ident,
					value: ident(chars)
				});
				continue;
			}
			return;
		}
		if (ch === ".") {
			_i--;
			if (is_num(chars)) {
				tokens.push(num(chars));
				continue;
			}
			return;
		}
		if (ch === "/") {
			while (_i < chars.length && (chars[_i] === "\n" || chars[_i] === "	" || chars[_i] === " ")) _i++;
			let alpha;
			if (is_num(chars)) {
				alpha = num(chars);
				if (alpha.type !== Tok.Hue) {
					tokens.push({
						type: Tok.Alpha,
						value: alpha
					});
					continue;
				}
			}
			if (is_ident(chars)) {
				if (ident(chars) === "none") {
					tokens.push({
						type: Tok.Alpha,
						value: {
							type: Tok.None,
							value: void 0
						}
					});
					continue;
				}
			}
			return;
		}
		if (/\d/.test(ch)) {
			_i--;
			tokens.push(num(chars));
			continue;
		}
		if (IdentStartCodePoint.test(ch)) {
			_i--;
			tokens.push(identlike(chars));
			continue;
		}
		return;
	}
	return tokens;
}
function parseColorSyntax(tokens) {
	tokens._i = 0;
	let token = tokens[tokens._i++];
	if (!token || token.type !== Tok.Function || token.value !== "color") return;
	token = tokens[tokens._i++];
	if (token.type !== Tok.Ident) return;
	const mode = colorProfiles[token.value];
	if (!mode) return;
	const res = { mode };
	const coords = consumeCoords(tokens, false);
	if (!coords) return;
	const channels = getMode(mode).channels;
	for (let ii = 0, c, ch; ii < channels.length; ii++) {
		c = coords[ii];
		ch = channels[ii];
		if (c.type !== Tok.None) {
			res[ch] = c.type === Tok.Number ? c.value : c.value / 100;
			if (ch === "alpha") res[ch] = Math.max(0, Math.min(1, res[ch]));
		}
	}
	return res;
}
function consumeCoords(tokens, includeHue) {
	const coords = [];
	let token;
	while (tokens._i < tokens.length) {
		token = tokens[tokens._i++];
		if (token.type === Tok.None || token.type === Tok.Number || token.type === Tok.Alpha || token.type === Tok.Percentage || includeHue && token.type === Tok.Hue) {
			coords.push(token);
			continue;
		}
		if (token.type === Tok.ParenClose) {
			if (tokens._i < tokens.length) return;
			continue;
		}
		return;
	}
	if (coords.length < 3 || coords.length > 4) return;
	if (coords.length === 4) {
		if (coords[3].type !== Tok.Alpha) return;
		coords[3] = coords[3].value;
	}
	if (coords.length === 3) coords.push({
		type: Tok.None,
		value: void 0
	});
	return coords.every((c) => c.type !== Tok.Alpha) ? coords : void 0;
}
function parseModernSyntax(tokens, includeHue) {
	tokens._i = 0;
	let token = tokens[tokens._i++];
	if (!token || token.type !== Tok.Function) return;
	let coords = consumeCoords(tokens, includeHue);
	if (!coords) return;
	coords.unshift(token.value);
	return coords;
}
var parse = (color) => {
	if (typeof color !== "string") return;
	const tokens = tokenize(color);
	const parsed = tokens ? parseModernSyntax(tokens, true) : void 0;
	let result = void 0;
	let i = 0;
	let len = parsers.length;
	while (i < len) if ((result = parsers[i++](color, parsed)) !== void 0) return result;
	return tokens ? parseColorSyntax(tokens) : void 0;
};
//#endregion
//#region ../../node_modules/culori/src/rgb/parseRgb.js
function parseRgb(color, parsed) {
	if (!parsed || parsed[0] !== "rgb" && parsed[0] !== "rgba") return;
	const res = { mode: "rgb" };
	const [, r, g, b, alpha] = parsed;
	if (r.type === Tok.Hue || g.type === Tok.Hue || b.type === Tok.Hue) return;
	if (r.type !== Tok.None) res.r = r.type === Tok.Number ? r.value / 255 : r.value / 100;
	if (g.type !== Tok.None) res.g = g.type === Tok.Number ? g.value / 255 : g.value / 100;
	if (b.type !== Tok.None) res.b = b.type === Tok.Number ? b.value / 255 : b.value / 100;
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/rgb/parseTransparent.js
var parseTransparent = (c) => c === "transparent" ? {
	mode: "rgb",
	r: 0,
	g: 0,
	b: 0,
	alpha: 0
} : void 0;
//#endregion
//#region ../../node_modules/culori/src/interpolate/lerp.js
var lerp = (a, b, t) => a + t * (b - a);
//#endregion
//#region ../../node_modules/culori/src/interpolate/piecewise.js
var get_classes = (arr) => {
	let classes = [];
	for (let i = 0; i < arr.length - 1; i++) {
		let a = arr[i];
		let b = arr[i + 1];
		if (a === void 0 && b === void 0) classes.push(void 0);
		else if (a !== void 0 && b !== void 0) classes.push([a, b]);
		else classes.push(a !== void 0 ? [a, a] : [b, b]);
	}
	return classes;
};
var interpolatorPiecewise = (interpolator) => (arr) => {
	let classes = get_classes(arr);
	return (t) => {
		let cls = t * classes.length;
		let idx = t >= 1 ? classes.length - 1 : Math.max(Math.floor(cls), 0);
		let pair = classes[idx];
		return pair === void 0 ? void 0 : interpolator(pair[0], pair[1], cls - idx);
	};
};
//#endregion
//#region ../../node_modules/culori/src/interpolate/linear.js
var interpolatorLinear = interpolatorPiecewise(lerp);
//#endregion
//#region ../../node_modules/culori/src/fixup/alpha.js
var fixupAlpha = (arr) => {
	let some_defined = false;
	let res = arr.map((v) => {
		if (v !== void 0) {
			some_defined = true;
			return v;
		}
		return 1;
	});
	return some_defined ? res : arr;
};
//#endregion
//#region ../../node_modules/culori/src/rgb/definition.js
var definition$27 = {
	mode: "rgb",
	channels: [
		"r",
		"g",
		"b",
		"alpha"
	],
	parse: [
		parseRgb,
		parseHex,
		parseRgbLegacy,
		parseNamed,
		parseTransparent,
		"srgb"
	],
	serialize: "srgb",
	interpolate: {
		r: interpolatorLinear,
		g: interpolatorLinear,
		b: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	gamut: true,
	white: {
		r: 1,
		g: 1,
		b: 1
	},
	black: {
		r: 0,
		g: 0,
		b: 0
	}
};
//#endregion
//#region ../../node_modules/culori/src/a98/convertA98ToXyz65.js
var linearize$2 = (v = 0) => Math.pow(Math.abs(v), 563 / 256) * Math.sign(v);
var convertA98ToXyz65 = (a98) => {
	let r = linearize$2(a98.r);
	let g = linearize$2(a98.g);
	let b = linearize$2(a98.b);
	let res = {
		mode: "xyz65",
		x: .5766690429101305 * r + .1855582379065463 * g + .1882286462349947 * b,
		y: .297344975250536 * r + .6273635662554661 * g + .0752914584939979 * b,
		z: .0270313613864123 * r + .0706888525358272 * g + .9913375368376386 * b
	};
	if (a98.alpha !== void 0) res.alpha = a98.alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/a98/convertXyz65ToA98.js
var gamma$2 = (v) => Math.pow(Math.abs(v), 256 / 563) * Math.sign(v);
var convertXyz65ToA98 = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = {
		mode: "a98",
		r: gamma$2(x * 2.0415879038107465 - y * .5650069742788597 - .3447313507783297 * z),
		g: gamma$2(x * -.9692436362808798 + y * 1.8759675015077206 + .0415550574071756 * z),
		b: gamma$2(x * .0134442806320312 - y * .1183623922310184 + 1.0151749943912058 * z)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lrgb/convertRgbToLrgb.js
var fn$3 = (c = 0) => {
	const abs = Math.abs(c);
	if (abs <= .04045) return c / 12.92;
	return (Math.sign(c) || 1) * Math.pow((abs + .055) / 1.055, 2.4);
};
var convertRgbToLrgb = ({ r, g, b, alpha }) => {
	let res = {
		mode: "lrgb",
		r: fn$3(r),
		g: fn$3(g),
		b: fn$3(b)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyz65/convertRgbToXyz65.js
var convertRgbToXyz65 = (rgb) => {
	let { r, g, b, alpha } = convertRgbToLrgb(rgb);
	let res = {
		mode: "xyz65",
		x: .4123907992659593 * r + .357584339383878 * g + .1804807884018343 * b,
		y: .2126390058715102 * r + .715168678767756 * g + .0721923153607337 * b,
		z: .0193308187155918 * r + .119194779794626 * g + .9505321522496607 * b
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lrgb/convertLrgbToRgb.js
var fn$2 = (c = 0) => {
	const abs = Math.abs(c);
	if (abs > .0031308) return (Math.sign(c) || 1) * (1.055 * Math.pow(abs, 1 / 2.4) - .055);
	return c * 12.92;
};
var convertLrgbToRgb = ({ r, g, b, alpha }, mode = "rgb") => {
	let res = {
		mode,
		r: fn$2(r),
		g: fn$2(g),
		b: fn$2(b)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyz65/convertXyz65ToRgb.js
var convertXyz65ToRgb = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = convertLrgbToRgb({
		r: x * 3.2409699419045226 - y * 1.537383177570094 - .4986107602930034 * z,
		g: x * -.9692436362808796 + y * 1.8759675015077204 + .0415550574071756 * z,
		b: x * .0556300796969936 - y * .2039769588889765 + 1.0569715142428784 * z
	});
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/a98/definition.js
var definition$26 = {
	...definition$27,
	mode: "a98",
	parse: ["a98-rgb"],
	serialize: "a98-rgb",
	fromMode: {
		rgb: (color) => convertXyz65ToA98(convertRgbToXyz65(color)),
		xyz65: convertXyz65ToA98
	},
	toMode: {
		rgb: (color) => convertXyz65ToRgb(convertA98ToXyz65(color)),
		xyz65: convertA98ToXyz65
	}
};
//#endregion
//#region ../../node_modules/culori/src/util/normalizeHue.js
var normalizeHue = (hue) => (hue = hue % 360) < 0 ? hue + 360 : hue;
//#endregion
//#region ../../node_modules/culori/src/fixup/hue.js
var hue = (hues, fn) => {
	return hues.map((hue, idx, arr) => {
		if (hue === void 0) return hue;
		let normalized = normalizeHue(hue);
		if (idx === 0 || hues[idx - 1] === void 0) return normalized;
		return fn(normalized - normalizeHue(arr[idx - 1]));
	}).reduce((acc, curr) => {
		if (!acc.length || curr === void 0 || acc[acc.length - 1] === void 0) {
			acc.push(curr);
			return acc;
		}
		acc.push(curr + acc[acc.length - 1]);
		return acc;
	}, []);
};
var fixupHueShorter = (arr) => hue(arr, (d) => Math.abs(d) <= 180 ? d : d - 360 * Math.sign(d));
//#endregion
//#region ../../node_modules/culori/src/cubehelix/constants.js
var M = [
	-.14861,
	1.78277,
	-.29227,
	-.90649,
	1.97294,
	0
];
var degToRad = Math.PI / 180;
var radToDeg = 180 / Math.PI;
//#endregion
//#region ../../node_modules/culori/src/cubehelix/convertRgbToCubehelix.js
var DE = M[3] * M[4];
var BE = M[1] * M[4];
var BCAD = M[1] * M[2] - M[0] * M[3];
var convertRgbToCubehelix = ({ r, g, b, alpha }) => {
	if (r === void 0) r = 0;
	if (g === void 0) g = 0;
	if (b === void 0) b = 0;
	let l = (BCAD * b + r * DE - g * BE) / (BCAD + DE - BE);
	let x = b - l;
	let y = (M[4] * (g - l) - M[2] * x) / M[3];
	let res = {
		mode: "cubehelix",
		l,
		s: l === 0 || l === 1 ? void 0 : Math.sqrt(x * x + y * y) / (M[4] * l * (1 - l))
	};
	if (res.s) res.h = Math.atan2(y, x) * radToDeg - 120;
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/cubehelix/convertCubehelixToRgb.js
var convertCubehelixToRgb = ({ h, s, l, alpha }) => {
	let res = { mode: "rgb" };
	h = (h === void 0 ? 0 : h + 120) * degToRad;
	if (l === void 0) l = 0;
	let amp = s === void 0 ? 0 : s * l * (1 - l);
	let cosh = Math.cos(h);
	let sinh = Math.sin(h);
	res.r = l + amp * (M[0] * cosh + M[1] * sinh);
	res.g = l + amp * (M[2] * cosh + M[3] * sinh);
	res.b = l + amp * (M[4] * cosh + M[5] * sinh);
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/difference.js
var differenceHueSaturation = (std, smp) => {
	if (std.h === void 0 || smp.h === void 0 || !std.s || !smp.s) return 0;
	let std_h = normalizeHue(std.h);
	let smp_h = normalizeHue(smp.h);
	let dH = Math.sin((smp_h - std_h + 360) / 2 * Math.PI / 180);
	return 2 * Math.sqrt(std.s * smp.s) * dH;
};
var differenceHueNaive = (std, smp) => {
	if (std.h === void 0 || smp.h === void 0) return 0;
	let std_h = normalizeHue(std.h);
	let smp_h = normalizeHue(smp.h);
	if (Math.abs(smp_h - std_h) > 180) return std_h - (smp_h - 360 * Math.sign(smp_h - std_h));
	return smp_h - std_h;
};
var differenceHueChroma = (std, smp) => {
	if (std.h === void 0 || smp.h === void 0 || !std.c || !smp.c) return 0;
	let std_h = normalizeHue(std.h);
	let smp_h = normalizeHue(smp.h);
	let dH = Math.sin((smp_h - std_h + 360) / 2 * Math.PI / 180);
	return 2 * Math.sqrt(std.c * smp.c) * dH;
};
//#endregion
//#region ../../node_modules/culori/src/average.js
var averageAngle = (val) => {
	let sum = val.reduce((sum, val) => {
		if (val !== void 0) {
			let rad = val * Math.PI / 180;
			sum.sin += Math.sin(rad);
			sum.cos += Math.cos(rad);
		}
		return sum;
	}, {
		sin: 0,
		cos: 0
	});
	let angle = Math.atan2(sum.sin, sum.cos) * 180 / Math.PI;
	return angle < 0 ? 360 + angle : angle;
};
//#endregion
//#region ../../node_modules/culori/src/cubehelix/definition.js
var definition$25 = {
	mode: "cubehelix",
	channels: [
		"h",
		"s",
		"l",
		"alpha"
	],
	parse: ["--cubehelix"],
	serialize: "--cubehelix",
	ranges: {
		h: [0, 360],
		s: [0, 4.614],
		l: [0, 1]
	},
	fromMode: { rgb: convertRgbToCubehelix },
	toMode: { rgb: convertCubehelixToRgb },
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		s: interpolatorLinear,
		l: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueSaturation },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/lch/convertLabToLch.js
var convertLabToLch = ({ l, a, b, alpha }, mode = "lch") => {
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let c = Math.sqrt(a * a + b * b);
	let res = {
		mode,
		l,
		c
	};
	if (c) res.h = normalizeHue(Math.atan2(b, a) * 180 / Math.PI);
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lch/convertLchToLab.js
var convertLchToLab = ({ l, c, h, alpha }, mode = "lab") => {
	if (h === void 0) h = 0;
	let res = {
		mode,
		l,
		a: c ? c * Math.cos(h / 180 * Math.PI) : 0,
		b: c ? c * Math.sin(h / 180 * Math.PI) : 0
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyz65/constants.js
var k$2 = Math.pow(29, 3) / Math.pow(3, 3);
var e$2 = Math.pow(6, 3) / Math.pow(29, 3);
//#endregion
//#region ../../node_modules/culori/src/constants.js
var D50 = {
	X: .3457 / .3585,
	Y: 1,
	Z: .2958 / .3585
};
var D65 = {
	X: .3127 / .329,
	Y: 1,
	Z: .3583 / .329
};
Math.pow(29, 3) / Math.pow(3, 3);
Math.pow(6, 3) / Math.pow(29, 3);
//#endregion
//#region ../../node_modules/culori/src/lab65/convertLab65ToXyz65.js
var fn$1 = (v) => Math.pow(v, 3) > e$2 ? Math.pow(v, 3) : (116 * v - 16) / k$2;
var convertLab65ToXyz65 = ({ l, a, b, alpha }) => {
	if (l === void 0) l = 0;
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let fy = (l + 16) / 116;
	let fx = a / 500 + fy;
	let fz = fy - b / 200;
	let res = {
		mode: "xyz65",
		x: fn$1(fx) * D65.X,
		y: fn$1(fy) * D65.Y,
		z: fn$1(fz) * D65.Z
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lab65/convertLab65ToRgb.js
var convertLab65ToRgb = (lab) => convertXyz65ToRgb(convertLab65ToXyz65(lab));
//#endregion
//#region ../../node_modules/culori/src/lab65/convertXyz65ToLab65.js
var f$1 = (value) => value > e$2 ? Math.cbrt(value) : (k$2 * value + 16) / 116;
var convertXyz65ToLab65 = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let f0 = f$1(x / D65.X);
	let f1 = f$1(y / D65.Y);
	let f2 = f$1(z / D65.Z);
	let res = {
		mode: "lab65",
		l: 116 * f1 - 16,
		a: 500 * (f0 - f1),
		b: 200 * (f1 - f2)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lab65/convertRgbToLab65.js
var convertRgbToLab65 = (rgb) => {
	let res = convertXyz65ToLab65(convertRgbToXyz65(rgb));
	if (rgb.r === rgb.b && rgb.b === rgb.g) res.a = res.b = 0;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/dlch/constants.js
var θ = 26 / 180 * Math.PI;
var cosθ = Math.cos(θ);
var sinθ = Math.sin(θ);
var factor = 100 / Math.log(139 / 100);
//#endregion
//#region ../../node_modules/culori/src/dlch/convertDlchToLab65.js
var convertDlchToLab65 = ({ l, c, h, alpha }) => {
	if (l === void 0) l = 0;
	if (c === void 0) c = 0;
	if (h === void 0) h = 0;
	let res = {
		mode: "lab65",
		l: (Math.exp(l * 1 / factor) - 1) / .0039
	};
	let G = (Math.exp(.0435 * c * 1 * 1) - 1) / .075;
	let e = G * Math.cos(h / 180 * Math.PI - θ);
	let f = G * Math.sin(h / 180 * Math.PI - θ);
	res.a = e * cosθ - f / .83 * sinθ;
	res.b = e * sinθ + f / .83 * cosθ;
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/dlch/convertLab65ToDlch.js
var convertLab65ToDlch = ({ l, a, b, alpha }) => {
	if (l === void 0) l = 0;
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let e = a * cosθ + b * sinθ;
	let f = .83 * (b * cosθ - a * sinθ);
	let G = Math.sqrt(e * e + f * f);
	let res = {
		mode: "dlch",
		l: factor / 1 * Math.log(1 + .0039 * l),
		c: Math.log(1 + .075 * G) / (.0435 * 1 * 1)
	};
	if (res.c) res.h = normalizeHue((Math.atan2(f, e) + θ) / Math.PI * 180);
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/dlab/definition.js
var convertDlabToLab65 = (c) => convertDlchToLab65(convertLabToLch(c, "dlch"));
var convertLab65ToDlab = (c) => convertLchToLab(convertLab65ToDlch(c), "dlab");
var definition$24 = {
	mode: "dlab",
	parse: ["--din99o-lab"],
	serialize: "--din99o-lab",
	toMode: {
		lab65: convertDlabToLab65,
		rgb: (c) => convertLab65ToRgb(convertDlabToLab65(c))
	},
	fromMode: {
		lab65: convertLab65ToDlab,
		rgb: (c) => convertLab65ToDlab(convertRgbToLab65(c))
	},
	channels: [
		"l",
		"a",
		"b",
		"alpha"
	],
	ranges: {
		l: [0, 100],
		a: [-40.09, 45.501],
		b: [-40.469, 44.344]
	},
	interpolate: {
		l: interpolatorLinear,
		a: interpolatorLinear,
		b: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/dlch/definition.js
var definition$23 = {
	mode: "dlch",
	parse: ["--din99o-lch"],
	serialize: "--din99o-lch",
	toMode: {
		lab65: convertDlchToLab65,
		dlab: (c) => convertLchToLab(c, "dlab"),
		rgb: (c) => convertLab65ToRgb(convertDlchToLab65(c))
	},
	fromMode: {
		lab65: convertLab65ToDlch,
		dlab: (c) => convertLabToLch(c, "dlch"),
		rgb: (c) => convertLab65ToDlch(convertRgbToLab65(c))
	},
	channels: [
		"l",
		"c",
		"h",
		"alpha"
	],
	ranges: {
		l: [0, 100],
		c: [0, 51.484],
		h: [0, 360]
	},
	interpolate: {
		l: interpolatorLinear,
		c: interpolatorLinear,
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueChroma },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/hsi/convertHsiToRgb.js
function convertHsiToRgb({ h, s, i, alpha }) {
	h = normalizeHue(h !== void 0 ? h : 0);
	if (s === void 0) s = 0;
	if (i === void 0) i = 0;
	let f = Math.abs(h / 60 % 2 - 1);
	let res;
	switch (Math.floor(h / 60)) {
		case 0:
			res = {
				r: i * (1 + s * (3 / (2 - f) - 1)),
				g: i * (1 + s * (3 * (1 - f) / (2 - f) - 1)),
				b: i * (1 - s)
			};
			break;
		case 1:
			res = {
				r: i * (1 + s * (3 * (1 - f) / (2 - f) - 1)),
				g: i * (1 + s * (3 / (2 - f) - 1)),
				b: i * (1 - s)
			};
			break;
		case 2:
			res = {
				r: i * (1 - s),
				g: i * (1 + s * (3 / (2 - f) - 1)),
				b: i * (1 + s * (3 * (1 - f) / (2 - f) - 1))
			};
			break;
		case 3:
			res = {
				r: i * (1 - s),
				g: i * (1 + s * (3 * (1 - f) / (2 - f) - 1)),
				b: i * (1 + s * (3 / (2 - f) - 1))
			};
			break;
		case 4:
			res = {
				r: i * (1 + s * (3 * (1 - f) / (2 - f) - 1)),
				g: i * (1 - s),
				b: i * (1 + s * (3 / (2 - f) - 1))
			};
			break;
		case 5:
			res = {
				r: i * (1 + s * (3 / (2 - f) - 1)),
				g: i * (1 - s),
				b: i * (1 + s * (3 * (1 - f) / (2 - f) - 1))
			};
			break;
		default: res = {
			r: i * (1 - s),
			g: i * (1 - s),
			b: i * (1 - s)
		};
	}
	res.mode = "rgb";
	if (alpha !== void 0) res.alpha = alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hsi/convertRgbToHsi.js
function convertRgbToHsi({ r, g, b, alpha }) {
	if (r === void 0) r = 0;
	if (g === void 0) g = 0;
	if (b === void 0) b = 0;
	let M = Math.max(r, g, b), m = Math.min(r, g, b);
	let res = {
		mode: "hsi",
		s: r + g + b === 0 ? 0 : 1 - 3 * m / (r + g + b),
		i: (r + g + b) / 3
	};
	if (M - m !== 0) res.h = (M === r ? (g - b) / (M - m) + (g < b) * 6 : M === g ? (b - r) / (M - m) + 2 : (r - g) / (M - m) + 4) * 60;
	if (alpha !== void 0) res.alpha = alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hsi/definition.js
var definition$22 = {
	mode: "hsi",
	toMode: { rgb: convertHsiToRgb },
	parse: ["--hsi"],
	serialize: "--hsi",
	fromMode: { rgb: convertRgbToHsi },
	channels: [
		"h",
		"s",
		"i",
		"alpha"
	],
	ranges: { h: [0, 360] },
	gamut: "rgb",
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		s: interpolatorLinear,
		i: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueSaturation },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/hsl/convertHslToRgb.js
function convertHslToRgb({ h, s, l, alpha }) {
	h = normalizeHue(h !== void 0 ? h : 0);
	if (s === void 0) s = 0;
	if (l === void 0) l = 0;
	let m1 = l + s * (l < .5 ? l : 1 - l);
	let m2 = m1 - (m1 - l) * 2 * Math.abs(h / 60 % 2 - 1);
	let res;
	switch (Math.floor(h / 60)) {
		case 0:
			res = {
				r: m1,
				g: m2,
				b: 2 * l - m1
			};
			break;
		case 1:
			res = {
				r: m2,
				g: m1,
				b: 2 * l - m1
			};
			break;
		case 2:
			res = {
				r: 2 * l - m1,
				g: m1,
				b: m2
			};
			break;
		case 3:
			res = {
				r: 2 * l - m1,
				g: m2,
				b: m1
			};
			break;
		case 4:
			res = {
				r: m2,
				g: 2 * l - m1,
				b: m1
			};
			break;
		case 5:
			res = {
				r: m1,
				g: 2 * l - m1,
				b: m2
			};
			break;
		default: res = {
			r: 2 * l - m1,
			g: 2 * l - m1,
			b: 2 * l - m1
		};
	}
	res.mode = "rgb";
	if (alpha !== void 0) res.alpha = alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hsl/convertRgbToHsl.js
function convertRgbToHsl({ r, g, b, alpha }) {
	if (r === void 0) r = 0;
	if (g === void 0) g = 0;
	if (b === void 0) b = 0;
	let M = Math.max(r, g, b), m = Math.min(r, g, b);
	let res = {
		mode: "hsl",
		s: M === m ? 0 : (M - m) / (1 - Math.abs(M + m - 1)),
		l: .5 * (M + m)
	};
	if (M - m !== 0) res.h = (M === r ? (g - b) / (M - m) + (g < b) * 6 : M === g ? (b - r) / (M - m) + 2 : (r - g) / (M - m) + 4) * 60;
	if (alpha !== void 0) res.alpha = alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/util/hue.js
var hueToDeg = (val, unit) => {
	switch (unit) {
		case "deg": return +val;
		case "rad": return val / Math.PI * 180;
		case "grad": return val / 10 * 9;
		case "turn": return val * 360;
	}
};
//#endregion
//#region ../../node_modules/culori/src/hsl/parseHslLegacy.js
var hsl_old = new RegExp(`^hsla?\\(\\s*${hue$1}${c}${per}${c}${per}\\s*(?:,\\s*${num_per}\\s*)?\\)$`);
var parseHslLegacy = (color) => {
	let match = color.match(hsl_old);
	if (!match) return;
	let res = { mode: "hsl" };
	if (match[3] !== void 0) res.h = +match[3];
	else if (match[1] !== void 0 && match[2] !== void 0) res.h = hueToDeg(match[1], match[2]);
	if (match[4] !== void 0) res.s = Math.min(Math.max(0, match[4] / 100), 1);
	if (match[5] !== void 0) res.l = Math.min(Math.max(0, match[5] / 100), 1);
	if (match[6] !== void 0) res.alpha = Math.max(0, Math.min(1, match[6] / 100));
	else if (match[7] !== void 0) res.alpha = Math.max(0, Math.min(1, +match[7]));
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/hsl/parseHsl.js
function parseHsl(color, parsed) {
	if (!parsed || parsed[0] !== "hsl" && parsed[0] !== "hsla") return;
	const res = { mode: "hsl" };
	const [, h, s, l, alpha] = parsed;
	if (h.type !== Tok.None) {
		if (h.type === Tok.Percentage) return;
		res.h = h.value;
	}
	if (s.type !== Tok.None) {
		if (s.type === Tok.Hue) return;
		res.s = s.value / 100;
	}
	if (l.type !== Tok.None) {
		if (l.type === Tok.Hue) return;
		res.l = l.value / 100;
	}
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hsl/definition.js
var definition$21 = {
	mode: "hsl",
	toMode: { rgb: convertHslToRgb },
	fromMode: { rgb: convertRgbToHsl },
	channels: [
		"h",
		"s",
		"l",
		"alpha"
	],
	ranges: { h: [0, 360] },
	gamut: "rgb",
	parse: [parseHsl, parseHslLegacy],
	serialize: (c) => `hsl(${c.h !== void 0 ? c.h : "none"} ${c.s !== void 0 ? c.s * 100 + "%" : "none"} ${c.l !== void 0 ? c.l * 100 + "%" : "none"}${c.alpha < 1 ? ` / ${c.alpha}` : ""})`,
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		s: interpolatorLinear,
		l: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueSaturation },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/hsv/convertHsvToRgb.js
function convertHsvToRgb({ h, s, v, alpha }) {
	h = normalizeHue(h !== void 0 ? h : 0);
	if (s === void 0) s = 0;
	if (v === void 0) v = 0;
	let f = Math.abs(h / 60 % 2 - 1);
	let res;
	switch (Math.floor(h / 60)) {
		case 0:
			res = {
				r: v,
				g: v * (1 - s * f),
				b: v * (1 - s)
			};
			break;
		case 1:
			res = {
				r: v * (1 - s * f),
				g: v,
				b: v * (1 - s)
			};
			break;
		case 2:
			res = {
				r: v * (1 - s),
				g: v,
				b: v * (1 - s * f)
			};
			break;
		case 3:
			res = {
				r: v * (1 - s),
				g: v * (1 - s * f),
				b: v
			};
			break;
		case 4:
			res = {
				r: v * (1 - s * f),
				g: v * (1 - s),
				b: v
			};
			break;
		case 5:
			res = {
				r: v,
				g: v * (1 - s),
				b: v * (1 - s * f)
			};
			break;
		default: res = {
			r: v * (1 - s),
			g: v * (1 - s),
			b: v * (1 - s)
		};
	}
	res.mode = "rgb";
	if (alpha !== void 0) res.alpha = alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hsv/convertRgbToHsv.js
function convertRgbToHsv({ r, g, b, alpha }) {
	if (r === void 0) r = 0;
	if (g === void 0) g = 0;
	if (b === void 0) b = 0;
	let M = Math.max(r, g, b), m = Math.min(r, g, b);
	let res = {
		mode: "hsv",
		s: M === 0 ? 0 : 1 - m / M,
		v: M
	};
	if (M - m !== 0) res.h = (M === r ? (g - b) / (M - m) + (g < b) * 6 : M === g ? (b - r) / (M - m) + 2 : (r - g) / (M - m) + 4) * 60;
	if (alpha !== void 0) res.alpha = alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hsv/definition.js
var definition$20 = {
	mode: "hsv",
	toMode: { rgb: convertHsvToRgb },
	parse: ["--hsv"],
	serialize: "--hsv",
	fromMode: { rgb: convertRgbToHsv },
	channels: [
		"h",
		"s",
		"v",
		"alpha"
	],
	ranges: { h: [0, 360] },
	gamut: "rgb",
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		s: interpolatorLinear,
		v: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueSaturation },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/hwb/convertHwbToRgb.js
function convertHwbToRgb({ h, w, b, alpha }) {
	if (w === void 0) w = 0;
	if (b === void 0) b = 0;
	if (w + b > 1) {
		let s = w + b;
		w /= s;
		b /= s;
	}
	return convertHsvToRgb({
		h,
		s: b === 1 ? 1 : 1 - w / (1 - b),
		v: 1 - b,
		alpha
	});
}
//#endregion
//#region ../../node_modules/culori/src/hwb/convertRgbToHwb.js
function convertRgbToHwb(rgba) {
	let hsv = convertRgbToHsv(rgba);
	if (hsv === void 0) return void 0;
	let s = hsv.s !== void 0 ? hsv.s : 0;
	let v = hsv.v !== void 0 ? hsv.v : 0;
	let res = {
		mode: "hwb",
		w: (1 - s) * v,
		b: 1 - v
	};
	if (hsv.h !== void 0) res.h = hsv.h;
	if (hsv.alpha !== void 0) res.alpha = hsv.alpha;
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hwb/parseHwb.js
function ParseHwb(color, parsed) {
	if (!parsed || parsed[0] !== "hwb") return;
	const res = { mode: "hwb" };
	const [, h, w, b, alpha] = parsed;
	if (h.type !== Tok.None) {
		if (h.type === Tok.Percentage) return;
		res.h = h.value;
	}
	if (w.type !== Tok.None) {
		if (w.type === Tok.Hue) return;
		res.w = w.value / 100;
	}
	if (b.type !== Tok.None) {
		if (b.type === Tok.Hue) return;
		res.b = b.value / 100;
	}
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/hwb/definition.js
var definition$19 = {
	mode: "hwb",
	toMode: { rgb: convertHwbToRgb },
	fromMode: { rgb: convertRgbToHwb },
	channels: [
		"h",
		"w",
		"b",
		"alpha"
	],
	ranges: { h: [0, 360] },
	gamut: "rgb",
	parse: [ParseHwb],
	serialize: (c) => `hwb(${c.h !== void 0 ? c.h : "none"} ${c.w !== void 0 ? c.w * 100 + "%" : "none"} ${c.b !== void 0 ? c.b * 100 + "%" : "none"}${c.alpha < 1 ? ` / ${c.alpha}` : ""})`,
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		w: interpolatorLinear,
		b: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueNaive },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/hdr/transfer.js
var M1 = .1593017578125;
var M2 = 78.84375;
var C1 = .8359375;
var C2 = 18.8515625;
var C3 = 18.6875;
function transferPqDecode(v) {
	if (v < 0) return 0;
	const c = Math.pow(v, 1 / M2);
	return 1e4 * Math.pow(Math.max(0, c - C1) / (C2 - C3 * c), 1 / M1);
}
function transferPqEncode(v) {
	if (v < 0) return 0;
	const c = Math.pow(v / 1e4, M1);
	return Math.pow((C1 + C2 * c) / (1 + C3 * c), M2);
}
//#endregion
//#region ../../node_modules/culori/src/itp/convertItpToXyz65.js
var toRel = (c) => Math.max(c / 203, 0);
var convertItpToXyz65 = ({ i, t, p, alpha }) => {
	if (i === void 0) i = 0;
	if (t === void 0) t = 0;
	if (p === void 0) p = 0;
	const l = transferPqDecode(i + .008609037037932761 * t + .11102962500302593 * p);
	const m = transferPqDecode(i - .00860903703793275 * t - .11102962500302599 * p);
	const s = transferPqDecode(i + .5600313357106791 * t - .32062717498731885 * p);
	const res = {
		mode: "xyz65",
		x: toRel(2.070152218389422 * l - 1.3263473389671556 * m + .2066510476294051 * s),
		y: toRel(.3647385209748074 * l + .680566024947227 * m - .0453045459220346 * s),
		z: toRel(-.049747207535812 * l - .0492609666966138 * m + 1.1880659249923042 * s)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/itp/convertXyz65ToItp.js
var toAbs = (c = 0) => Math.max(c * 203, 0);
var convertXyz65ToItp = ({ x, y, z, alpha }) => {
	const absX = toAbs(x);
	const absY = toAbs(y);
	const absZ = toAbs(z);
	const l = transferPqEncode(.3592832590121217 * absX + .6976051147779502 * absY - .0358915932320289 * absZ);
	const m = transferPqEncode(-.1920808463704995 * absX + 1.1004767970374323 * absY + .0753748658519118 * absZ);
	const s = transferPqEncode(.0070797844607477 * absX + .0748396662186366 * absY + .8433265453898765 * absZ);
	const res = {
		mode: "itp",
		i: .5 * l + .5 * m,
		t: 1.61376953125 * l - 3.323486328125 * m + 1.709716796875 * s,
		p: 4.378173828125 * l - 4.24560546875 * m - .132568359375 * s
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/itp/definition.js
var definition$18 = {
	mode: "itp",
	channels: [
		"i",
		"t",
		"p",
		"alpha"
	],
	parse: ["--ictcp"],
	serialize: "--ictcp",
	toMode: {
		xyz65: convertItpToXyz65,
		rgb: (color) => convertXyz65ToRgb(convertItpToXyz65(color))
	},
	fromMode: {
		xyz65: convertXyz65ToItp,
		rgb: (color) => convertXyz65ToItp(convertRgbToXyz65(color))
	},
	ranges: {
		i: [0, .581],
		t: [-.369, .272],
		p: [-.164, .331]
	},
	interpolate: {
		i: interpolatorLinear,
		t: interpolatorLinear,
		p: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/jab/convertXyz65ToJab.js
var p$1 = 134.03437499999998;
var d0$1 = 16295499532821565e-27;
var jabPqEncode = (v) => {
	if (v < 0) return 0;
	let vn = Math.pow(v / 1e4, M1);
	return Math.pow((C1 + C2 * vn) / (1 + C3 * vn), p$1);
};
var abs = (v = 0) => Math.max(v * 203, 0);
var convertXyz65ToJab = ({ x, y, z, alpha }) => {
	x = abs(x);
	y = abs(y);
	z = abs(z);
	let xp = 1.15 * x - .15 * z;
	let yp = .66 * y + .34 * x;
	let l = jabPqEncode(.41478972 * xp + .579999 * yp + .014648 * z);
	let m = jabPqEncode(-.20151 * xp + 1.120649 * yp + .0531008 * z);
	let s = jabPqEncode(-.0166008 * xp + .2648 * yp + .6684799 * z);
	let i = (l + m) / 2;
	let res = {
		mode: "jab",
		j: .44 * i / (1 - .56 * i) - d0$1,
		a: 3.524 * l - 4.066708 * m + .542708 * s,
		b: .199076 * l + 1.096799 * m - 1.295875 * s
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/jab/convertJabToXyz65.js
var p = 134.03437499999998;
var d0 = 16295499532821565e-27;
var jabPqDecode = (v) => {
	if (v < 0) return 0;
	let vp = Math.pow(v, 1 / p);
	return 1e4 * Math.pow((C1 - vp) / (C3 * vp - C2), 1 / M1);
};
var rel = (v) => v / 203;
var convertJabToXyz65 = ({ j, a, b, alpha }) => {
	if (j === void 0) j = 0;
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let i = (j + d0) / (.44 + .56 * (j + d0));
	let l = jabPqDecode(i + .13860504 * a + .058047316 * b);
	let m = jabPqDecode(i - .13860504 * a - .058047316 * b);
	let s = jabPqDecode(i - .096019242 * a - .8118919 * b);
	let res = {
		mode: "xyz65",
		x: rel(1.661373024652174 * l - .914523081304348 * m + .23136208173913045 * s),
		y: rel(-.3250758611844533 * l + 1.571847026732543 * m - .21825383453227928 * s),
		z: rel(-.090982811 * l - .31272829 * m + 1.5227666 * s)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/jab/convertRgbToJab.js
var convertRgbToJab = (rgb) => {
	let res = convertXyz65ToJab(convertRgbToXyz65(rgb));
	if (rgb.r === rgb.b && rgb.b === rgb.g) res.a = res.b = 0;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/jab/convertJabToRgb.js
var convertJabToRgb = (color) => convertXyz65ToRgb(convertJabToXyz65(color));
//#endregion
//#region ../../node_modules/culori/src/jab/definition.js
var definition$17 = {
	mode: "jab",
	channels: [
		"j",
		"a",
		"b",
		"alpha"
	],
	parse: ["--jzazbz"],
	serialize: "--jzazbz",
	fromMode: {
		rgb: convertRgbToJab,
		xyz65: convertXyz65ToJab
	},
	toMode: {
		rgb: convertJabToRgb,
		xyz65: convertJabToXyz65
	},
	ranges: {
		j: [0, .222],
		a: [-.109, .129],
		b: [-.185, .134]
	},
	interpolate: {
		j: interpolatorLinear,
		a: interpolatorLinear,
		b: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/jch/convertJabToJch.js
var convertJabToJch = ({ j, a, b, alpha }) => {
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let c = Math.sqrt(a * a + b * b);
	let res = {
		mode: "jch",
		j,
		c
	};
	if (c) res.h = normalizeHue(Math.atan2(b, a) * 180 / Math.PI);
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/jch/convertJchToJab.js
var convertJchToJab = ({ j, c, h, alpha }) => {
	if (h === void 0) h = 0;
	let res = {
		mode: "jab",
		j,
		a: c ? c * Math.cos(h / 180 * Math.PI) : 0,
		b: c ? c * Math.sin(h / 180 * Math.PI) : 0
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/jch/definition.js
var definition$16 = {
	mode: "jch",
	parse: ["--jzczhz"],
	serialize: "--jzczhz",
	toMode: {
		jab: convertJchToJab,
		rgb: (c) => convertJabToRgb(convertJchToJab(c))
	},
	fromMode: {
		rgb: (c) => convertJabToJch(convertRgbToJab(c)),
		jab: convertJabToJch
	},
	channels: [
		"j",
		"c",
		"h",
		"alpha"
	],
	ranges: {
		j: [0, .221],
		c: [0, .19],
		h: [0, 360]
	},
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		c: interpolatorLinear,
		j: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueChroma },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/xyz50/constants.js
var k = Math.pow(29, 3) / Math.pow(3, 3);
var e = Math.pow(6, 3) / Math.pow(29, 3);
//#endregion
//#region ../../node_modules/culori/src/lab/convertLabToXyz50.js
var fn = (v) => Math.pow(v, 3) > e ? Math.pow(v, 3) : (116 * v - 16) / k;
var convertLabToXyz50 = ({ l, a, b, alpha }) => {
	if (l === void 0) l = 0;
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let fy = (l + 16) / 116;
	let fx = a / 500 + fy;
	let fz = fy - b / 200;
	let res = {
		mode: "xyz50",
		x: fn(fx) * D50.X,
		y: fn(fy) * D50.Y,
		z: fn(fz) * D50.Z
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyz50/convertXyz50ToRgb.js
var convertXyz50ToRgb = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = convertLrgbToRgb({
		r: x * 3.1341359569958707 - y * 1.6173863321612538 - .4906619460083532 * z,
		g: x * -.978795502912089 + y * 1.916254567259524 + .03344273116131949 * z,
		b: x * .07195537988411677 - y * .2289768264158322 + 1.405386058324125 * z
	});
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lab/convertLabToRgb.js
var convertLabToRgb = (lab) => convertXyz50ToRgb(convertLabToXyz50(lab));
//#endregion
//#region ../../node_modules/culori/src/xyz50/convertRgbToXyz50.js
var convertRgbToXyz50 = (rgb) => {
	let { r, g, b, alpha } = convertRgbToLrgb(rgb);
	let res = {
		mode: "xyz50",
		x: .436065742824811 * r + .3851514688337912 * g + .14307845442264197 * b,
		y: .22249319175623702 * r + .7168870538238823 * g + .06061979053616537 * b,
		z: .013923904500943465 * r + .09708128566574634 * g + .7140993584005155 * b
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lab/convertXyz50ToLab.js
var f = (value) => value > e ? Math.cbrt(value) : (k * value + 16) / 116;
var convertXyz50ToLab = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let f0 = f(x / D50.X);
	let f1 = f(y / D50.Y);
	let f2 = f(z / D50.Z);
	let res = {
		mode: "lab",
		l: 116 * f1 - 16,
		a: 500 * (f0 - f1),
		b: 200 * (f1 - f2)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lab/convertRgbToLab.js
var convertRgbToLab = (rgb) => {
	let res = convertXyz50ToLab(convertRgbToXyz50(rgb));
	if (rgb.r === rgb.b && rgb.b === rgb.g) res.a = res.b = 0;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lab/parseLab.js
function parseLab(color, parsed) {
	if (!parsed || parsed[0] !== "lab") return;
	const res = { mode: "lab" };
	const [, l, a, b, alpha] = parsed;
	if (l.type === Tok.Hue || a.type === Tok.Hue || b.type === Tok.Hue) return;
	if (l.type !== Tok.None) res.l = Math.min(Math.max(0, l.value), 100);
	if (a.type !== Tok.None) res.a = a.type === Tok.Number ? a.value : a.value * 125 / 100;
	if (b.type !== Tok.None) res.b = b.type === Tok.Number ? b.value : b.value * 125 / 100;
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/lab/definition.js
var definition$15 = {
	mode: "lab",
	toMode: {
		xyz50: convertLabToXyz50,
		rgb: convertLabToRgb
	},
	fromMode: {
		xyz50: convertXyz50ToLab,
		rgb: convertRgbToLab
	},
	channels: [
		"l",
		"a",
		"b",
		"alpha"
	],
	ranges: {
		l: [0, 100],
		a: [-125, 125],
		b: [-125, 125]
	},
	parse: [parseLab],
	serialize: (c) => `lab(${c.l !== void 0 ? c.l : "none"} ${c.a !== void 0 ? c.a : "none"} ${c.b !== void 0 ? c.b : "none"}${c.alpha < 1 ? ` / ${c.alpha}` : ""})`,
	interpolate: {
		l: interpolatorLinear,
		a: interpolatorLinear,
		b: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/lab65/definition.js
var definition$14 = {
	...definition$15,
	mode: "lab65",
	parse: ["--lab-d65"],
	serialize: "--lab-d65",
	toMode: {
		xyz65: convertLab65ToXyz65,
		rgb: convertLab65ToRgb
	},
	fromMode: {
		xyz65: convertXyz65ToLab65,
		rgb: convertRgbToLab65
	},
	ranges: {
		l: [0, 100],
		a: [-125, 125],
		b: [-125, 125]
	}
};
//#endregion
//#region ../../node_modules/culori/src/lch/parseLch.js
function parseLch(color, parsed) {
	if (!parsed || parsed[0] !== "lch") return;
	const res = { mode: "lch" };
	const [, l, c, h, alpha] = parsed;
	if (l.type !== Tok.None) {
		if (l.type === Tok.Hue) return;
		res.l = Math.min(Math.max(0, l.value), 100);
	}
	if (c.type !== Tok.None) res.c = Math.max(0, c.type === Tok.Number ? c.value : c.value * 150 / 100);
	if (h.type !== Tok.None) {
		if (h.type === Tok.Percentage) return;
		res.h = h.value;
	}
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/lch/definition.js
var definition$13 = {
	mode: "lch",
	toMode: {
		lab: convertLchToLab,
		rgb: (c) => convertLabToRgb(convertLchToLab(c))
	},
	fromMode: {
		rgb: (c) => convertLabToLch(convertRgbToLab(c)),
		lab: convertLabToLch
	},
	channels: [
		"l",
		"c",
		"h",
		"alpha"
	],
	ranges: {
		l: [0, 100],
		c: [0, 150],
		h: [0, 360]
	},
	parse: [parseLch],
	serialize: (c) => `lch(${c.l !== void 0 ? c.l : "none"} ${c.c !== void 0 ? c.c : "none"} ${c.h !== void 0 ? c.h : "none"}${c.alpha < 1 ? ` / ${c.alpha}` : ""})`,
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		c: interpolatorLinear,
		l: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueChroma },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/lch65/definition.js
var definition$12 = {
	...definition$13,
	mode: "lch65",
	parse: ["--lch-d65"],
	serialize: "--lch-d65",
	toMode: {
		lab65: (c) => convertLchToLab(c, "lab65"),
		rgb: (c) => convertLab65ToRgb(convertLchToLab(c, "lab65"))
	},
	fromMode: {
		rgb: (c) => convertLabToLch(convertRgbToLab65(c), "lch65"),
		lab65: (c) => convertLabToLch(c, "lch65")
	},
	ranges: {
		l: [0, 100],
		c: [0, 150],
		h: [0, 360]
	}
};
//#endregion
//#region ../../node_modules/culori/src/lchuv/convertLuvToLchuv.js
var convertLuvToLchuv = ({ l, u, v, alpha }) => {
	if (u === void 0) u = 0;
	if (v === void 0) v = 0;
	let c = Math.sqrt(u * u + v * v);
	let res = {
		mode: "lchuv",
		l,
		c
	};
	if (c) res.h = normalizeHue(Math.atan2(v, u) * 180 / Math.PI);
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lchuv/convertLchuvToLuv.js
var convertLchuvToLuv = ({ l, c, h, alpha }) => {
	if (h === void 0) h = 0;
	let res = {
		mode: "luv",
		l,
		u: c ? c * Math.cos(h / 180 * Math.PI) : 0,
		v: c ? c * Math.sin(h / 180 * Math.PI) : 0
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/luv/convertXyz50ToLuv.js
var u_fn$1 = (x, y, z) => 4 * x / (x + 15 * y + 3 * z);
var v_fn$1 = (x, y, z) => 9 * y / (x + 15 * y + 3 * z);
var un$1 = u_fn$1(D50.X, D50.Y, D50.Z);
var vn$1 = v_fn$1(D50.X, D50.Y, D50.Z);
var l_fn = (value) => value <= e ? k * value : 116 * Math.cbrt(value) - 16;
var convertXyz50ToLuv = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let l = l_fn(y / D50.Y);
	let u = u_fn$1(x, y, z);
	let v = v_fn$1(x, y, z);
	if (!isFinite(u) || !isFinite(v)) l = u = v = 0;
	else {
		u = 13 * l * (u - un$1);
		v = 13 * l * (v - vn$1);
	}
	let res = {
		mode: "luv",
		l,
		u,
		v
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/luv/convertLuvToXyz50.js
var u_fn = (x, y, z) => 4 * x / (x + 15 * y + 3 * z);
var v_fn = (x, y, z) => 9 * y / (x + 15 * y + 3 * z);
var un = u_fn(D50.X, D50.Y, D50.Z);
var vn = v_fn(D50.X, D50.Y, D50.Z);
var convertLuvToXyz50 = ({ l, u, v, alpha }) => {
	if (l === void 0) l = 0;
	if (l === 0) return {
		mode: "xyz50",
		x: 0,
		y: 0,
		z: 0
	};
	if (u === void 0) u = 0;
	if (v === void 0) v = 0;
	let up = u / (13 * l) + un;
	let vp = v / (13 * l) + vn;
	let y = D50.Y * (l <= 8 ? l / k : Math.pow((l + 16) / 116, 3));
	let res = {
		mode: "xyz50",
		x: y * (9 * up) / (4 * vp),
		y,
		z: y * (12 - 3 * up - 20 * vp) / (4 * vp)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/lchuv/definition.js
var convertRgbToLchuv = (rgb) => convertLuvToLchuv(convertXyz50ToLuv(convertRgbToXyz50(rgb)));
var convertLchuvToRgb = (lchuv) => convertXyz50ToRgb(convertLuvToXyz50(convertLchuvToLuv(lchuv)));
var definition$11 = {
	mode: "lchuv",
	toMode: {
		luv: convertLchuvToLuv,
		rgb: convertLchuvToRgb
	},
	fromMode: {
		rgb: convertRgbToLchuv,
		luv: convertLuvToLchuv
	},
	channels: [
		"l",
		"c",
		"h",
		"alpha"
	],
	parse: ["--lchuv"],
	serialize: "--lchuv",
	ranges: {
		l: [0, 100],
		c: [0, 176.956],
		h: [0, 360]
	},
	interpolate: {
		h: {
			use: interpolatorLinear,
			fixup: fixupHueShorter
		},
		c: interpolatorLinear,
		l: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	},
	difference: { h: differenceHueChroma },
	average: { h: averageAngle }
};
//#endregion
//#region ../../node_modules/culori/src/lrgb/definition.js
var definition$10 = {
	...definition$27,
	mode: "lrgb",
	toMode: { rgb: convertLrgbToRgb },
	fromMode: { rgb: convertRgbToLrgb },
	parse: ["srgb-linear"],
	serialize: "srgb-linear"
};
//#endregion
//#region ../../node_modules/culori/src/luv/definition.js
var definition$9 = {
	mode: "luv",
	toMode: {
		xyz50: convertLuvToXyz50,
		rgb: (luv) => convertXyz50ToRgb(convertLuvToXyz50(luv))
	},
	fromMode: {
		xyz50: convertXyz50ToLuv,
		rgb: (rgb) => convertXyz50ToLuv(convertRgbToXyz50(rgb))
	},
	channels: [
		"l",
		"u",
		"v",
		"alpha"
	],
	parse: ["--luv"],
	serialize: "--luv",
	ranges: {
		l: [0, 100],
		u: [-84.936, 175.042],
		v: [-125.882, 87.243]
	},
	interpolate: {
		l: interpolatorLinear,
		u: interpolatorLinear,
		v: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/oklab/convertLrgbToOklab.js
var convertLrgbToOklab = ({ r, g, b, alpha }) => {
	if (r === void 0) r = 0;
	if (g === void 0) g = 0;
	if (b === void 0) b = 0;
	let L = Math.cbrt(.412221469470763 * r + .5363325372617348 * g + .0514459932675022 * b);
	let M = Math.cbrt(.2119034958178252 * r + .6806995506452344 * g + .1073969535369406 * b);
	let S = Math.cbrt(.0883024591900564 * r + .2817188391361215 * g + .6299787016738222 * b);
	let res = {
		mode: "oklab",
		l: .210454268309314 * L + .7936177747023054 * M - .0040720430116193 * S,
		a: 1.9779985324311684 * L - 2.42859224204858 * M + .450593709617411 * S,
		b: .0259040424655478 * L + .7827717124575296 * M - .8086757549230774 * S
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/oklab/convertRgbToOklab.js
var convertRgbToOklab = (rgb) => {
	let res = convertLrgbToOklab(convertRgbToLrgb(rgb));
	if (rgb.r === rgb.b && rgb.b === rgb.g) res.a = res.b = 0;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/oklab/convertOklabToLrgb.js
var convertOklabToLrgb = ({ l, a, b, alpha }) => {
	if (l === void 0) l = 0;
	if (a === void 0) a = 0;
	if (b === void 0) b = 0;
	let L = Math.pow(l + .3963377773761749 * a + .2158037573099136 * b, 3);
	let M = Math.pow(l - .1055613458156586 * a - .0638541728258133 * b, 3);
	let S = Math.pow(l - .0894841775298119 * a - 1.2914855480194092 * b, 3);
	let res = {
		mode: "lrgb",
		r: 4.076741636075957 * L - 3.3077115392580616 * M + .2309699031821044 * S,
		g: -1.2684379732850317 * L + 2.6097573492876887 * M - .3413193760026573 * S,
		b: -.0041960761386756 * L - .7034186179359362 * M + 1.7076146940746117 * S
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/oklab/convertOklabToRgb.js
var convertOklabToRgb = (c) => convertLrgbToRgb(convertOklabToLrgb(c));
//#endregion
//#region ../../node_modules/culori/src/okhsl/helpers.js
function toe(x) {
	const k_1 = .206;
	const k_2 = .03;
	const k_3 = 1.206 / 1.03;
	return .5 * (k_3 * x - k_1 + Math.sqrt((k_3 * x - k_1) * (k_3 * x - k_1) + 4 * k_2 * k_3 * x));
}
function toe_inv(x) {
	return (x * x + .206 * x) / (1.206 / 1.03 * (x + .03));
}
function compute_max_saturation(a, b) {
	let k0, k1, k2, k3, k4, wl, wm, ws;
	if (-1.88170328 * a - .80936493 * b > 1) {
		k0 = 1.19086277;
		k1 = 1.76576728;
		k2 = .59662641;
		k3 = .75515197;
		k4 = .56771245;
		wl = 4.0767416621;
		wm = -3.3077115913;
		ws = .2309699292;
	} else if (1.81444104 * a - 1.19445276 * b > 1) {
		k0 = .73956515;
		k1 = -.45954404;
		k2 = .08285427;
		k3 = .1254107;
		k4 = .14503204;
		wl = -1.2684380046;
		wm = 2.6097574011;
		ws = -.3413193965;
	} else {
		k0 = 1.35733652;
		k1 = -.00915799;
		k2 = -1.1513021;
		k3 = -.50559606;
		k4 = .00692167;
		wl = -.0041960863;
		wm = -.7034186147;
		ws = 1.707614701;
	}
	let S = k0 + k1 * a + k2 * b + k3 * a * a + k4 * a * b;
	let k_l = .3963377774 * a + .2158037573 * b;
	let k_m = -.1055613458 * a - .0638541728 * b;
	let k_s = -.0894841775 * a - 1.291485548 * b;
	{
		let l_ = 1 + S * k_l;
		let m_ = 1 + S * k_m;
		let s_ = 1 + S * k_s;
		let l = l_ * l_ * l_;
		let m = m_ * m_ * m_;
		let s = s_ * s_ * s_;
		let l_dS = 3 * k_l * l_ * l_;
		let m_dS = 3 * k_m * m_ * m_;
		let s_dS = 3 * k_s * s_ * s_;
		let l_dS2 = 6 * k_l * k_l * l_;
		let m_dS2 = 6 * k_m * k_m * m_;
		let s_dS2 = 6 * k_s * k_s * s_;
		let f = wl * l + wm * m + ws * s;
		let f1 = wl * l_dS + wm * m_dS + ws * s_dS;
		let f2 = wl * l_dS2 + wm * m_dS2 + ws * s_dS2;
		S = S - f * f1 / (f1 * f1 - .5 * f * f2);
	}
	return S;
}
function find_cusp(a, b) {
	let S_cusp = compute_max_saturation(a, b);
	let rgb = convertOklabToLrgb({
		l: 1,
		a: S_cusp * a,
		b: S_cusp * b
	});
	let L_cusp = Math.cbrt(1 / Math.max(rgb.r, rgb.g, rgb.b));
	return [L_cusp, L_cusp * S_cusp];
}
function find_gamut_intersection(a, b, L1, C1, L0, cusp = null) {
	if (!cusp) cusp = find_cusp(a, b);
	let t;
	if ((L1 - L0) * cusp[1] - (cusp[0] - L0) * C1 <= 0) t = cusp[1] * L0 / (C1 * cusp[0] + cusp[1] * (L0 - L1));
	else {
		t = cusp[1] * (L0 - 1) / (C1 * (cusp[0] - 1) + cusp[1] * (L0 - L1));
		{
			let dL = L1 - L0;
			let dC = C1;
			let k_l = .3963377774 * a + .2158037573 * b;
			let k_m = -.1055613458 * a - .0638541728 * b;
			let k_s = -.0894841775 * a - 1.291485548 * b;
			let l_dt = dL + dC * k_l;
			let m_dt = dL + dC * k_m;
			let s_dt = dL + dC * k_s;
			{
				let L = L0 * (1 - t) + t * L1;
				let C = t * C1;
				let l_ = L + C * k_l;
				let m_ = L + C * k_m;
				let s_ = L + C * k_s;
				let l = l_ * l_ * l_;
				let m = m_ * m_ * m_;
				let s = s_ * s_ * s_;
				let ldt = 3 * l_dt * l_ * l_;
				let mdt = 3 * m_dt * m_ * m_;
				let sdt = 3 * s_dt * s_ * s_;
				let ldt2 = 6 * l_dt * l_dt * l_;
				let mdt2 = 6 * m_dt * m_dt * m_;
				let sdt2 = 6 * s_dt * s_dt * s_;
				let r = 4.0767416621 * l - 3.3077115913 * m + .2309699292 * s - 1;
				let r1 = 4.0767416621 * ldt - 3.3077115913 * mdt + .2309699292 * sdt;
				let r2 = 4.0767416621 * ldt2 - 3.3077115913 * mdt2 + .2309699292 * sdt2;
				let u_r = r1 / (r1 * r1 - .5 * r * r2);
				let t_r = -r * u_r;
				let g = -1.2684380046 * l + 2.6097574011 * m - .3413193965 * s - 1;
				let g1 = -1.2684380046 * ldt + 2.6097574011 * mdt - .3413193965 * sdt;
				let g2 = -1.2684380046 * ldt2 + 2.6097574011 * mdt2 - .3413193965 * sdt2;
				let u_g = g1 / (g1 * g1 - .5 * g * g2);
				let t_g = -g * u_g;
				let b = -.0041960863 * l - .7034186147 * m + 1.707614701 * s - 1;
				let b1 = -.0041960863 * ldt - .7034186147 * mdt + 1.707614701 * sdt;
				let b2 = -.0041960863 * ldt2 - .7034186147 * mdt2 + 1.707614701 * sdt2;
				let u_b = b1 / (b1 * b1 - .5 * b * b2);
				let t_b = -b * u_b;
				t_r = u_r >= 0 ? t_r : 1e6;
				t_g = u_g >= 0 ? t_g : 1e6;
				t_b = u_b >= 0 ? t_b : 1e6;
				t += Math.min(t_r, Math.min(t_g, t_b));
			}
		}
	}
	return t;
}
function get_ST_max(a_, b_, cusp = null) {
	if (!cusp) cusp = find_cusp(a_, b_);
	let L = cusp[0];
	let C = cusp[1];
	return [C / L, C / (1 - L)];
}
function get_Cs(L, a_, b_) {
	let cusp = find_cusp(a_, b_);
	let C_max = find_gamut_intersection(a_, b_, L, 1, L, cusp);
	let ST_max = get_ST_max(a_, b_, cusp);
	let S_mid = .11516993 + 1 / (7.4477897 + 4.1590124 * b_ + a_ * (-2.19557347 + 1.75198401 * b_ + a_ * (-2.13704948 - 10.02301043 * b_ + a_ * (-4.24894561 + 5.38770819 * b_ + 4.69891013 * a_))));
	let T_mid = .11239642 + 1 / (1.6132032 - .68124379 * b_ + a_ * (.40370612 + .90148123 * b_ + a_ * (-.27087943 + .6122399 * b_ + a_ * (.00299215 - .45399568 * b_ - .14661872 * a_))));
	let k = C_max / Math.min(L * ST_max[0], (1 - L) * ST_max[1]);
	let C_a = L * S_mid;
	let C_b = (1 - L) * T_mid;
	let C_mid = .9 * k * Math.sqrt(Math.sqrt(1 / (1 / (C_a * C_a * C_a * C_a) + 1 / (C_b * C_b * C_b * C_b))));
	C_a = L * .4;
	C_b = (1 - L) * .8;
	return [
		Math.sqrt(1 / (1 / (C_a * C_a) + 1 / (C_b * C_b))),
		C_mid,
		C_max
	];
}
//#endregion
//#region ../../node_modules/culori/src/okhsl/convertOklabToOkhsl.js
function convertOklabToOkhsl(lab) {
	const l = lab.l !== void 0 ? lab.l : 0;
	const a = lab.a !== void 0 ? lab.a : 0;
	const b = lab.b !== void 0 ? lab.b : 0;
	const ret = {
		mode: "okhsl",
		l: toe(l)
	};
	if (lab.alpha !== void 0) ret.alpha = lab.alpha;
	let c = Math.sqrt(a * a + b * b);
	if (!c) {
		ret.s = 0;
		return ret;
	}
	let [C_0, C_mid, C_max] = get_Cs(l, a / c, b / c);
	let s;
	if (c < C_mid) {
		let k_0 = 0;
		let k_1 = .8 * C_0;
		let k_2 = 1 - k_1 / C_mid;
		s = (c - k_0) / (k_1 + k_2 * (c - k_0)) * .8;
	} else {
		let k_0 = C_mid;
		let k_1 = .2 * C_mid * C_mid * 1.25 * 1.25 / C_0;
		let k_2 = 1 - k_1 / (C_max - C_mid);
		s = .8 + .2 * ((c - k_0) / (k_1 + k_2 * (c - k_0)));
	}
	if (s) {
		ret.s = s;
		ret.h = normalizeHue(Math.atan2(b, a) * 180 / Math.PI);
	}
	return ret;
}
//#endregion
//#region ../../node_modules/culori/src/okhsl/convertOkhslToOklab.js
function convertOkhslToOklab(hsl) {
	let h = hsl.h !== void 0 ? hsl.h : 0;
	let s = hsl.s !== void 0 ? hsl.s : 0;
	let l = hsl.l !== void 0 ? hsl.l : 0;
	const ret = {
		mode: "oklab",
		l: toe_inv(l)
	};
	if (hsl.alpha !== void 0) ret.alpha = hsl.alpha;
	if (!s || l === 1) {
		ret.a = ret.b = 0;
		return ret;
	}
	let a_ = Math.cos(h / 180 * Math.PI);
	let b_ = Math.sin(h / 180 * Math.PI);
	let [C_0, C_mid, C_max] = get_Cs(ret.l, a_, b_);
	let t, k_0, k_1, k_2;
	if (s < .8) {
		t = 1.25 * s;
		k_0 = 0;
		k_1 = .8 * C_0;
		k_2 = 1 - k_1 / C_mid;
	} else {
		t = 5 * (s - .8);
		k_0 = C_mid;
		k_1 = .2 * C_mid * C_mid * 1.25 * 1.25 / C_0;
		k_2 = 1 - k_1 / (C_max - C_mid);
	}
	let C = k_0 + t * k_1 / (1 - k_2 * t);
	ret.a = C * a_;
	ret.b = C * b_;
	return ret;
}
//#endregion
//#region ../../node_modules/culori/src/okhsl/modeOkhsl.js
var modeOkhsl = {
	...definition$21,
	mode: "okhsl",
	channels: [
		"h",
		"s",
		"l",
		"alpha"
	],
	parse: ["--okhsl"],
	serialize: "--okhsl",
	fromMode: {
		oklab: convertOklabToOkhsl,
		rgb: (c) => convertOklabToOkhsl(convertRgbToOklab(c))
	},
	toMode: {
		oklab: convertOkhslToOklab,
		rgb: (c) => convertOklabToRgb(convertOkhslToOklab(c))
	}
};
//#endregion
//#region ../../node_modules/culori/src/okhsv/convertOklabToOkhsv.js
function convertOklabToOkhsv(lab) {
	let l = lab.l !== void 0 ? lab.l : 0;
	let a = lab.a !== void 0 ? lab.a : 0;
	let b = lab.b !== void 0 ? lab.b : 0;
	let c = Math.sqrt(a * a + b * b);
	let a_ = c ? a / c : 1;
	let b_ = c ? b / c : 1;
	let [S_max, T] = get_ST_max(a_, b_);
	let S_0 = .5;
	let k = 1 - S_0 / S_max;
	let t = T / (c + l * T);
	let L_v = t * l;
	let C_v = t * c;
	let L_vt = toe_inv(L_v);
	let C_vt = C_v * L_vt / L_v;
	let rgb_scale = convertOklabToLrgb({
		l: L_vt,
		a: a_ * C_vt,
		b: b_ * C_vt
	});
	let scale_L = Math.cbrt(1 / Math.max(rgb_scale.r, rgb_scale.g, rgb_scale.b, 0));
	l = l / scale_L;
	c = c / scale_L * toe(l) / l;
	l = toe(l);
	const ret = {
		mode: "okhsv",
		s: c ? (S_0 + T) * C_v / (T * S_0 + T * k * C_v) : 0,
		v: l ? l / L_v : 0
	};
	if (ret.s) ret.h = normalizeHue(Math.atan2(b, a) * 180 / Math.PI);
	if (lab.alpha !== void 0) ret.alpha = lab.alpha;
	return ret;
}
//#endregion
//#region ../../node_modules/culori/src/okhsv/convertOkhsvToOklab.js
function convertOkhsvToOklab(hsv) {
	const ret = { mode: "oklab" };
	if (hsv.alpha !== void 0) ret.alpha = hsv.alpha;
	const h = hsv.h !== void 0 ? hsv.h : 0;
	const s = hsv.s !== void 0 ? hsv.s : 0;
	const v = hsv.v !== void 0 ? hsv.v : 0;
	const a_ = Math.cos(h / 180 * Math.PI);
	const b_ = Math.sin(h / 180 * Math.PI);
	const [S_max, T] = get_ST_max(a_, b_);
	const S_0 = .5;
	const k = 1 - S_0 / S_max;
	const L_v = 1 - s * S_0 / (S_0 + T - T * k * s);
	const C_v = s * T * S_0 / (S_0 + T - T * k * s);
	const L_vt = toe_inv(L_v);
	const C_vt = C_v * L_vt / L_v;
	const rgb_scale = convertOklabToLrgb({
		l: L_vt,
		a: a_ * C_vt,
		b: b_ * C_vt
	});
	const scale_L = Math.cbrt(1 / Math.max(rgb_scale.r, rgb_scale.g, rgb_scale.b, 0));
	const L_new = toe_inv(v * L_v);
	const C = C_v * L_new / L_v;
	ret.l = L_new * scale_L;
	ret.a = C * a_ * scale_L;
	ret.b = C * b_ * scale_L;
	return ret;
}
//#endregion
//#region ../../node_modules/culori/src/okhsv/modeOkhsv.js
var modeOkhsv = {
	...definition$20,
	mode: "okhsv",
	channels: [
		"h",
		"s",
		"v",
		"alpha"
	],
	parse: ["--okhsv"],
	serialize: "--okhsv",
	fromMode: {
		oklab: convertOklabToOkhsv,
		rgb: (c) => convertOklabToOkhsv(convertRgbToOklab(c))
	},
	toMode: {
		oklab: convertOkhsvToOklab,
		rgb: (c) => convertOklabToRgb(convertOkhsvToOklab(c))
	}
};
//#endregion
//#region ../../node_modules/culori/src/oklab/parseOklab.js
function parseOklab(color, parsed) {
	if (!parsed || parsed[0] !== "oklab") return;
	const res = { mode: "oklab" };
	const [, l, a, b, alpha] = parsed;
	if (l.type === Tok.Hue || a.type === Tok.Hue || b.type === Tok.Hue) return;
	if (l.type !== Tok.None) res.l = Math.min(Math.max(0, l.type === Tok.Number ? l.value : l.value / 100), 1);
	if (a.type !== Tok.None) res.a = a.type === Tok.Number ? a.value : a.value * .4 / 100;
	if (b.type !== Tok.None) res.b = b.type === Tok.Number ? b.value : b.value * .4 / 100;
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/oklab/definition.js
var definition$8 = {
	...definition$15,
	mode: "oklab",
	toMode: {
		lrgb: convertOklabToLrgb,
		rgb: convertOklabToRgb
	},
	fromMode: {
		lrgb: convertLrgbToOklab,
		rgb: convertRgbToOklab
	},
	ranges: {
		l: [0, 1],
		a: [-.4, .4],
		b: [-.4, .4]
	},
	parse: [parseOklab],
	serialize: (c) => `oklab(${c.l !== void 0 ? c.l : "none"} ${c.a !== void 0 ? c.a : "none"} ${c.b !== void 0 ? c.b : "none"}${c.alpha < 1 ? ` / ${c.alpha}` : ""})`
};
//#endregion
//#region ../../node_modules/culori/src/oklch/parseOklch.js
function parseOklch(color, parsed) {
	if (!parsed || parsed[0] !== "oklch") return;
	const res = { mode: "oklch" };
	const [, l, c, h, alpha] = parsed;
	if (l.type !== Tok.None) {
		if (l.type === Tok.Hue) return;
		res.l = Math.min(Math.max(0, l.type === Tok.Number ? l.value : l.value / 100), 1);
	}
	if (c.type !== Tok.None) res.c = Math.max(0, c.type === Tok.Number ? c.value : c.value * .4 / 100);
	if (h.type !== Tok.None) {
		if (h.type === Tok.Percentage) return;
		res.h = h.value;
	}
	if (alpha.type !== Tok.None) res.alpha = Math.min(1, Math.max(0, alpha.type === Tok.Number ? alpha.value : alpha.value / 100));
	return res;
}
//#endregion
//#region ../../node_modules/culori/src/oklch/definition.js
var definition$7 = {
	...definition$13,
	mode: "oklch",
	toMode: {
		oklab: (c) => convertLchToLab(c, "oklab"),
		rgb: (c) => convertOklabToRgb(convertLchToLab(c, "oklab"))
	},
	fromMode: {
		rgb: (c) => convertLabToLch(convertRgbToOklab(c), "oklch"),
		oklab: (c) => convertLabToLch(c, "oklch")
	},
	parse: [parseOklch],
	serialize: (c) => `oklch(${c.l !== void 0 ? c.l : "none"} ${c.c !== void 0 ? c.c : "none"} ${c.h !== void 0 ? c.h : "none"}${c.alpha < 1 ? ` / ${c.alpha}` : ""})`,
	ranges: {
		l: [0, 1],
		c: [0, .4],
		h: [0, 360]
	}
};
//#endregion
//#region ../../node_modules/culori/src/p3/convertP3ToXyz65.js
var convertP3ToXyz65 = (rgb) => {
	let { r, g, b, alpha } = convertRgbToLrgb(rgb);
	let res = {
		mode: "xyz65",
		x: .486570948648216 * r + .265667693169093 * g + .1982172852343625 * b,
		y: .2289745640697487 * r + .6917385218365062 * g + .079286914093745 * b,
		z: 0 * r + .0451133818589026 * g + 1.043944368900976 * b
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/p3/convertXyz65ToP3.js
var convertXyz65ToP3 = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = convertLrgbToRgb({
		r: x * 2.4934969119414263 - y * .9313836179191242 - .402710784450717 * z,
		g: x * -.8294889695615749 + y * 1.7626640603183465 + .0236246858419436 * z,
		b: x * .0358458302437845 - y * .0761723892680418 + .9568845240076871 * z
	}, "p3");
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/p3/definition.js
var definition$6 = {
	...definition$27,
	mode: "p3",
	parse: ["display-p3"],
	serialize: "display-p3",
	fromMode: {
		rgb: (color) => convertXyz65ToP3(convertRgbToXyz65(color)),
		xyz65: convertXyz65ToP3
	},
	toMode: {
		rgb: (color) => convertXyz65ToRgb(convertP3ToXyz65(color)),
		xyz65: convertP3ToXyz65
	}
};
//#endregion
//#region ../../node_modules/culori/src/prophoto/convertXyz50ToProphoto.js
var gamma$1 = (v) => {
	let abs = Math.abs(v);
	if (abs >= 1 / 512) return Math.sign(v) * Math.pow(abs, 1 / 1.8);
	return 16 * v;
};
var convertXyz50ToProphoto = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = {
		mode: "prophoto",
		r: gamma$1(x * 1.3457868816471585 - y * .2555720873797946 - .0511018649755453 * z),
		g: gamma$1(x * -.5446307051249019 + y * 1.5082477428451466 + .0205274474364214 * z),
		b: gamma$1(x * 0 + y * 0 + 1.2119675456389452 * z)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/prophoto/convertProphotoToXyz50.js
var linearize$1 = (v = 0) => {
	let abs = Math.abs(v);
	if (abs >= 16 / 512) return Math.sign(v) * Math.pow(abs, 1.8);
	return v / 16;
};
var convertProphotoToXyz50 = (prophoto) => {
	let r = linearize$1(prophoto.r);
	let g = linearize$1(prophoto.g);
	let b = linearize$1(prophoto.b);
	let res = {
		mode: "xyz50",
		x: .7977666449006423 * r + .1351812974005331 * g + .0313477341283922 * b,
		y: .2880748288194013 * r + .7118352342418731 * g + 899369387256e-16 * b,
		z: 0 * r + 0 * g + .8251046025104602 * b
	};
	if (prophoto.alpha !== void 0) res.alpha = prophoto.alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/prophoto/definition.js
var definition$5 = {
	...definition$27,
	mode: "prophoto",
	parse: ["prophoto-rgb"],
	serialize: "prophoto-rgb",
	fromMode: {
		xyz50: convertXyz50ToProphoto,
		rgb: (color) => convertXyz50ToProphoto(convertRgbToXyz50(color))
	},
	toMode: {
		xyz50: convertProphotoToXyz50,
		rgb: (color) => convertXyz50ToRgb(convertProphotoToXyz50(color))
	}
};
//#endregion
//#region ../../node_modules/culori/src/rec2020/convertXyz65ToRec2020.js
var α$1 = 1.09929682680944;
var β$1 = .018053968510807;
var gamma = (v) => {
	const abs = Math.abs(v);
	if (abs > β$1) return (Math.sign(v) || 1) * (α$1 * Math.pow(abs, .45) - (α$1 - 1));
	return 4.5 * v;
};
var convertXyz65ToRec2020 = ({ x, y, z, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = {
		mode: "rec2020",
		r: gamma(x * 1.7166511879712683 - y * .3556707837763925 - .2533662813736599 * z),
		g: gamma(x * -.6666843518324893 + y * 1.6164812366349395 + .0157685458139111 * z),
		b: gamma(x * .0176398574453108 - y * .0427706132578085 + .9421031212354739 * z)
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/rec2020/convertRec2020ToXyz65.js
var α = 1.09929682680944;
var β = .018053968510807;
var linearize = (v = 0) => {
	let abs = Math.abs(v);
	if (abs < β * 4.5) return v / 4.5;
	return (Math.sign(v) || 1) * Math.pow((abs + α - 1) / α, 1 / .45);
};
var convertRec2020ToXyz65 = (rec2020) => {
	let r = linearize(rec2020.r);
	let g = linearize(rec2020.g);
	let b = linearize(rec2020.b);
	let res = {
		mode: "xyz65",
		x: .6369580483012911 * r + .1446169035862083 * g + .1688809751641721 * b,
		y: .262700212011267 * r + .6779980715188708 * g + .059301716469862 * b,
		z: 0 * r + .0280726930490874 * g + 1.0609850577107909 * b
	};
	if (rec2020.alpha !== void 0) res.alpha = rec2020.alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/rec2020/definition.js
var definition$4 = {
	...definition$27,
	mode: "rec2020",
	fromMode: {
		xyz65: convertXyz65ToRec2020,
		rgb: (color) => convertXyz65ToRec2020(convertRgbToXyz65(color))
	},
	toMode: {
		xyz65: convertRec2020ToXyz65,
		rgb: (color) => convertXyz65ToRgb(convertRec2020ToXyz65(color))
	},
	parse: ["rec2020"],
	serialize: "rec2020"
};
//#endregion
//#region ../../node_modules/culori/src/xyb/constants.js
var bias = .0037930732552754493;
var bias_cbrt = Math.cbrt(bias);
//#endregion
//#region ../../node_modules/culori/src/xyb/convertRgbToXyb.js
var transfer$1 = (v) => Math.cbrt(v) - bias_cbrt;
var convertRgbToXyb = (color) => {
	const { r, g, b, alpha } = convertRgbToLrgb(color);
	const l = transfer$1(.3 * r + .622 * g + .078 * b + bias);
	const m = transfer$1(.23 * r + .692 * g + .078 * b + bias);
	const s = transfer$1(.2434226892454782 * r + .2047674442449682 * g + .5518098665095535 * b + bias);
	const res = {
		mode: "xyb",
		x: (l - m) / 2,
		y: (l + m) / 2,
		b: s - (l + m) / 2
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyb/convertXybToRgb.js
var transfer = (v) => Math.pow(v + bias_cbrt, 3);
var convertXybToRgb = ({ x, y, b, alpha }) => {
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (b === void 0) b = 0;
	const l = transfer(x + y) - bias;
	const m = transfer(y - x) - bias;
	const s = transfer(b + y) - bias;
	const res = convertLrgbToRgb({
		r: 11.031566904639861 * l - 9.866943908131562 * m - .16462299650829934 * s,
		g: -3.2541473810744237 * l + 4.418770377582723 * m - .16462299650829934 * s,
		b: -3.6588512867136815 * l + 2.7129230459360922 * m + 1.9459282407775895 * s
	});
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyb/definition.js
var definition$3 = {
	mode: "xyb",
	channels: [
		"x",
		"y",
		"b",
		"alpha"
	],
	parse: ["--xyb"],
	serialize: "--xyb",
	toMode: { rgb: convertXybToRgb },
	fromMode: { rgb: convertRgbToXyb },
	ranges: {
		x: [-.0154, .0281],
		y: [0, .8453],
		b: [-.2778, .388]
	},
	interpolate: {
		x: interpolatorLinear,
		y: interpolatorLinear,
		b: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/xyz50/definition.js
var definition$2 = {
	mode: "xyz50",
	parse: ["xyz-d50"],
	serialize: "xyz-d50",
	toMode: {
		rgb: convertXyz50ToRgb,
		lab: convertXyz50ToLab
	},
	fromMode: {
		rgb: convertRgbToXyz50,
		lab: convertLabToXyz50
	},
	channels: [
		"x",
		"y",
		"z",
		"alpha"
	],
	ranges: {
		x: [0, .964],
		y: [0, .999],
		z: [0, .825]
	},
	interpolate: {
		x: interpolatorLinear,
		y: interpolatorLinear,
		z: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/xyz65/convertXyz65ToXyz50.js
var convertXyz65ToXyz50 = (xyz65) => {
	let { x, y, z, alpha } = xyz65;
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = {
		mode: "xyz50",
		x: 1.0479298208405488 * x + .0229467933410191 * y - .0501922295431356 * z,
		y: .0296278156881593 * x + .990434484573249 * y - .0170738250293851 * z,
		z: -.0092430581525912 * x + .0150551448965779 * y + .7518742899580008 * z
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyz65/convertXyz50ToXyz65.js
var convertXyz50ToXyz65 = (xyz50) => {
	let { x, y, z, alpha } = xyz50;
	if (x === void 0) x = 0;
	if (y === void 0) y = 0;
	if (z === void 0) z = 0;
	let res = {
		mode: "xyz65",
		x: .9554734527042182 * x - .0230985368742614 * y + .0632593086610217 * z,
		y: -.0283697069632081 * x + 1.0099954580058226 * y + .021041398966943 * z,
		z: .0123140016883199 * x - .0205076964334779 * y + 1.3303659366080753 * z
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/xyz65/definition.js
var definition$1 = {
	mode: "xyz65",
	toMode: {
		rgb: convertXyz65ToRgb,
		xyz50: convertXyz65ToXyz50
	},
	fromMode: {
		rgb: convertRgbToXyz65,
		xyz50: convertXyz50ToXyz65
	},
	ranges: {
		x: [0, .95],
		y: [0, 1],
		z: [0, 1.088]
	},
	channels: [
		"x",
		"y",
		"z",
		"alpha"
	],
	parse: ["xyz", "xyz-d65"],
	serialize: "xyz-d65",
	interpolate: {
		x: interpolatorLinear,
		y: interpolatorLinear,
		z: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
//#endregion
//#region ../../node_modules/culori/src/yiq/convertRgbToYiq.js
var convertRgbToYiq = ({ r, g, b, alpha }) => {
	if (r === void 0) r = 0;
	if (g === void 0) g = 0;
	if (b === void 0) b = 0;
	const res = {
		mode: "yiq",
		y: .29889531 * r + .58662247 * g + .11448223 * b,
		i: .59597799 * r - .2741761 * g - .32180189 * b,
		q: .21147017 * r - .52261711 * g + .31114694 * b
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/yiq/convertYiqToRgb.js
var convertYiqToRgb = ({ y, i, q, alpha }) => {
	if (y === void 0) y = 0;
	if (i === void 0) i = 0;
	if (q === void 0) q = 0;
	const res = {
		mode: "rgb",
		r: y + .95608445 * i + .6208885 * q,
		g: y - .27137664 * i - .6486059 * q,
		b: y - 1.10561724 * i + 1.70250126 * q
	};
	if (alpha !== void 0) res.alpha = alpha;
	return res;
};
//#endregion
//#region ../../node_modules/culori/src/yiq/definition.js
var definition = {
	mode: "yiq",
	toMode: { rgb: convertYiqToRgb },
	fromMode: { rgb: convertRgbToYiq },
	channels: [
		"y",
		"i",
		"q",
		"alpha"
	],
	parse: ["--yiq"],
	serialize: "--yiq",
	ranges: {
		i: [-.595, .595],
		q: [-.522, .522]
	},
	interpolate: {
		y: interpolatorLinear,
		i: interpolatorLinear,
		q: interpolatorLinear,
		alpha: {
			use: interpolatorLinear,
			fixup: fixupAlpha
		}
	}
};
var clamp = (value) => Math.max(0, Math.min(1, value || 0));
var fixup = (value) => Math.round(clamp(value) * 255);
var rgb$1 = converter("rgb");
var serializeHex = (color) => {
	if (color === void 0) return;
	let r = fixup(color.r);
	let g = fixup(color.g);
	let b = fixup(color.b);
	return "#" + (1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1);
};
var formatHex = (c) => serializeHex(rgb$1(c));
useMode(definition$26);
useMode(definition$25);
useMode(definition$24);
useMode(definition$23);
useMode(definition$22);
useMode(definition$21);
useMode(definition$20);
useMode(definition$19);
useMode(definition$18);
useMode(definition$17);
useMode(definition$16);
useMode(definition$15);
useMode(definition$14);
useMode(definition$13);
useMode(definition$12);
useMode(definition$11);
useMode(definition$10);
useMode(definition$9);
useMode(modeOkhsl);
useMode(modeOkhsv);
useMode(definition$8);
var oklch = useMode(definition$7);
useMode(definition$6);
useMode(definition$5);
useMode(definition$4);
useMode(definition$27);
useMode(definition$3);
useMode(definition$2);
useMode(definition$1);
useMode(definition);
//#endregion
//#region ../../modules/projects/image.ts/src/engine/KMean.ts
var sortColors = (list, criteria = "l") => list.sort((a, b) => Math.sign(oklch({
	mode: "rgb",
	r: a[0],
	g: a[1],
	b: a[2]
})?.[criteria] - oklch({
	mode: "rgb",
	r: b[0],
	g: b[1],
	b: b[2]
})?.[criteria]) || 0);
var euclideanDistance = (color1, color2) => Math.hypot(color1[0] - color2[0], color1[1] - color2[1], color1[2] - color2[2]);
var makeClusters = (data, centroids) => {
	let clusters = Array.from({ length: centroids.length }, () => ({
		points: [],
		mean: null
	}));
	data.forEach((point) => {
		let minDistance = 1e4;
		let minDistanceClusterIndex = 0;
		centroids.forEach((centroid, index) => {
			const distance = euclideanDistance(point, centroid);
			if (typeof minDistance === "undefined" || minDistance > distance) {
				minDistance = distance;
				minDistanceClusterIndex = index;
			}
		});
		clusters[minDistanceClusterIndex].points.push(point);
	});
	return clusters;
};
var computeMean = (points) => {
	return points?.length > 0 ? points.reduce((acc, point) => [
		point[0] + acc[0],
		point[1] + acc[1],
		point[2] + acc[2]
	], [
		0,
		0,
		0
	]).map((val) => val / points.length) : [
		0,
		0,
		0
	];
};
var kMeans = (data, k) => {
	let centroids = sortColors(initializeCentroids(data, k));
	const maxIterations = 10;
	for (let iteration = 0; iteration < maxIterations; iteration++) {
		const newCentroids = makeClusters(data, centroids).map((cluster) => cluster.points.length > 0 ? computeMean(cluster.points) : null);
		if (newCentroids.every((newCentroid, index) => newCentroid && euclideanDistance(newCentroid, centroids[index]) < .001)) break;
		centroids = newCentroids;
	}
	return centroids;
};
var initializeCentroids = (data, k) => {
	const centroids = [data[Math.floor(Math.random() * data.length)]];
	while (centroids.length < k) {
		const distances = data.map((point) => Math.min(...centroids.map((centroid) => euclideanDistance(point, centroid))));
		const totalDistance = distances.reduce((sum, d) => sum + d, 0);
		const probabilities = distances.map((d) => d / totalDistance);
		let cumulativeProbability = 0;
		const randomValue = Math.random();
		for (let i = 0; i < probabilities.length; i++) {
			cumulativeProbability += probabilities[i];
			if (randomValue < cumulativeProbability) {
				centroids.push(data[i]);
				break;
			}
		}
	}
	return centroids;
};
var preBlurPixels = async (imgURL) => {
	const blob = imgURL instanceof Blob || imgURL instanceof File ? imgURL : await fetch(imgURL)?.then?.((r) => r?.blob?.());
	const bitmap = await createImageBitmap(blob);
	const offset = new OffscreenCanvas(bitmap.width, bitmap.height);
	const ctx = offset.getContext("2d");
	ctx.filter = "blur(16px)";
	ctx?.drawImage?.(bitmap, 0, 0, offset.width, offset.height);
	return offset;
};
var getClusterImageData = async (imgURL) => {
	const bitmap = await preBlurPixels(imgURL);
	const offset = new OffscreenCanvas(bitmap.width * .125, bitmap.height * .125);
	const ctx = offset.getContext("2d");
	ctx?.drawImage?.(bitmap, 0, 0, offset.width, offset.height);
	const data = (ctx?.getImageData?.(0, 0, offset.width, offset.height, {
		storageFormat: "float32",
		pixelFormat: "rgba-float32",
		colorSpace: "srgb"
	})).data;
	const allCount = offset.width * offset.height || 0;
	const dv = 1 / 255;
	const fp32 = [];
	for (let s = 0; s < allCount; s++) {
		const i4 = s * 4;
		fp32.push(data instanceof Float32Array || data instanceof Float16Array ? [
			data?.[i4 + 0] || 0,
			data?.[i4 + 1] || 0,
			data?.[i4 + 2] || 0
		] : [
			(data?.[i4 + 0] || 0) * dv,
			(data?.[i4 + 1] || 0) * dv,
			(data?.[i4 + 2] || 0) * dv
		]);
	}
	return fp32;
};
var getDominantColors = async (imgURL) => {
	return sortColors(kMeans(await getClusterImageData(imgURL), 4), "h");
};
//#endregion
//#region ../../modules/projects/image.ts/src/engine/WallpaperTheme.ts
/** Persisted JSON `{ primary, secondary, tertiary }` from last wallpaper extract. */
var WALLPAPER_THEME_STORAGE_KEY = "rs-wallpaper-theme";
/** Convenience: last primary hex alone (for quick reads / debugging). */
var WALLPAPER_PRIMARY_STORAGE_KEY = "rs-wallpaper-primary";
/** Wallpaper URL/data-URL key that produced the cached theme (skip re-KMeans when unchanged). */
var WALLPAPER_THEME_SRC_STORAGE_KEY = "rs-wallpaper-theme-src";
var THEME_STORAGE_KEY = WALLPAPER_THEME_STORAGE_KEY;
var PRIMARY_STORAGE_KEY = WALLPAPER_PRIMARY_STORAGE_KEY;
var WALLPAPER_URL_KEY = WALLPAPER_THEME_SRC_STORAGE_KEY;
/** Token names written onto theme hosts (veela / wf-demo / ui-window). */
var SEED_PROPS = [
	["--color-primary", "primary"],
	["--color-secondary", "secondary"],
	["--color-tertiary", "tertiary"],
	["--base-color", "primary"],
	["--wf-md-primary", "primary"],
	["--wf-md-seed", "primary"],
	["--primary", "primary"],
	["--secondary", "secondary"],
	["--tertiary", "tertiary"]
];
var rgbToSample = (rgb) => {
	const [r, g, b] = rgb;
	if (![
		r,
		g,
		b
	].every((n) => Number.isFinite(n))) return null;
	const hex = formatHex({
		mode: "rgb",
		r,
		g,
		b
	});
	if (!hex) return null;
	const ok = oklch({
		mode: "rgb",
		r,
		g,
		b
	});
	return {
		rgb,
		hex,
		l: ok?.l ?? .5,
		c: ok?.c ?? 0,
		h: ok?.h ?? 0
	};
};
/**
* WHY: Hue-sorted KMeans often puts near-black first; UI accents need mid-L high-chroma
* (nebula teal) as primary, then distinct secondary/tertiary clusters.
*/
var rankWallpaperSeeds = (centroids) => {
	const samples = centroids.map(rgbToSample).filter(Boolean);
	if (!samples.length) return null;
	const accentPool = samples.filter((s) => s.l >= .18 && s.l <= .88 && s.c >= .02).sort((a, b) => b.c - a.c || Math.abs(b.l - .55) - Math.abs(a.l - .55));
	const pool = accentPool.length ? accentPool : [...samples].sort((a, b) => b.c - a.c);
	const primary = pool[0];
	if (!primary) return null;
	const hueDist = (a, b) => {
		const d = Math.abs(a - b) % 360;
		return d > 180 ? 360 - d : d;
	};
	const pickNext = (used) => {
		const rest = pool.filter((s) => !used.includes(s));
		if (!rest.length) {
			const base = used[used.length - 1] ?? primary;
			const nudged = formatHex({
				mode: "oklch",
				l: Math.min(.85, Math.max(.2, base.l + (used.length === 1 ? -.12 : .1))),
				c: Math.max(.04, base.c * .85),
				h: base.h
			});
			return {
				...base,
				hex: nudged || base.hex,
				l: base.l
			};
		}
		return [...rest].sort((a, b) => Math.min(...used.map((u) => hueDist(b.h, u.h))) - Math.min(...used.map((u) => hueDist(a.h, u.h))) || b.c - a.c)[0] ?? rest[0];
	};
	const secondary = pickNext([primary]);
	const tertiary = pickNext([primary, secondary]);
	return {
		primary: primary.hex,
		secondary: secondary.hex,
		tertiary: tertiary.hex
	};
};
var themeHosts = () => {
	const nodes = /* @__PURE__ */ new Set();
	nodes.add(document.documentElement);
	document.querySelectorAll(".env-shell-root, .wf-demo-root, ui-window").forEach((el) => nodes.add(el));
	return [...nodes];
};
var applyWallpaperThemeSeeds = (seeds) => {
	for (const host of themeHosts()) for (const [prop, key] of SEED_PROPS) host.style.setProperty(prop, seeds[key]);
	document.querySelectorAll(".view-explorer, [data-view='explorer'], .view-viewer, [data-view='viewer'], .view-settings, [data-view='settings']").forEach((el) => {
		el.style.setProperty("--color-primary", seeds.primary);
		el.style.setProperty("--base-color", seeds.primary);
		el.style.setProperty("--color-secondary", seeds.secondary);
		el.style.setProperty("--color-tertiary", seeds.tertiary);
	});
	try {
		localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(seeds));
		localStorage.setItem(PRIMARY_STORAGE_KEY, seeds.primary);
	} catch {}
	document.dispatchEvent(new CustomEvent("u2-theme-change", { detail: {
		source: "wallpaper",
		seeds
	} }));
};
var loadCachedWallpaperTheme = () => {
	try {
		const raw = localStorage.getItem(THEME_STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed?.primary || !parsed?.secondary || !parsed?.tertiary) return null;
		return parsed;
	} catch {
		return null;
	}
};
/**
* Extract dominant colors from wallpaper URL/Blob/data-URL and write CSS seeds.
* INVARIANT: surfaces stay `--u2-color-mod(var(--base-color), N)`; only hue seeds change.
*/
var applyThemeFromWallpaper = async (imgURL, opts) => {
	const srcKey = typeof imgURL === "string" ? imgURL.slice(0, 2048) : `blob:${imgURL.name || "wallpaper"}:${imgURL.size}`;
	if (!opts?.force) try {
		if (localStorage.getItem(WALLPAPER_URL_KEY) === srcKey) {
			const cached = loadCachedWallpaperTheme();
			if (cached) {
				applyWallpaperThemeSeeds(cached);
				return cached;
			}
		}
	} catch {}
	try {
		const seeds = rankWallpaperSeeds(await getDominantColors(imgURL));
		if (!seeds) return null;
		applyWallpaperThemeSeeds(seeds);
		try {
			localStorage.setItem(WALLPAPER_URL_KEY, srcKey);
		} catch {}
		return seeds;
	} catch (err) {
		console.warn("[fest/image] applyThemeFromWallpaper failed", err);
		const cached = loadCachedWallpaperTheme();
		if (cached) {
			applyWallpaperThemeSeeds(cached);
			return cached;
		}
		return null;
	}
};
/** Cold-start: restore last seeds before async re-extract finishes. */
var restoreWallpaperThemeCache = () => {
	const cached = loadCachedWallpaperTheme();
	if (cached) applyWallpaperThemeSeeds(cached);
	return cached;
};
//#endregion
//#region ../../modules/projects/image.ts/src/canvas/Canvas-2.ts
/**
* Underlying app canvas layer.
*
* Hosts background/image surface under shell windows.
*
* WHY: Photo data-URLs often exceed `localStorage` (~5MB). `setItem` throws, was
* swallowed, paint updated in-memory only — reload restored the previous URL.
* INVARIANT: durable custom wallpapers live in IndexedDB; `localStorage` holds
* either a short URL (`/assets/…`) or the {@link WALLPAPER_IDB_MARKER} pointer.
*/
var WALLPAPER_STORAGE_KEY = "rs-wallpaper-image";
var DEFAULT_WALLPAPER_URL = "/assets/wallpaper.jpg";
/** Marker stored in localStorage when bytes live in IndexedDB. */
var WALLPAPER_IDB_MARKER = "idb:rs-wallpaper";
var IDB_NAME = "cwsp-wallpaper-v1";
var IDB_STORE = "blobs";
var IDB_KEY = "current";
/** Prefer IDB when payload is larger than this (or always for data:/blob:). */
var LOCAL_STORAGE_SAFE_CHARS = 512e3;
var liveObjectUrl = null;
var currentOrientNumber = () => orientationNumberMap?.[getCorrectOrientation()] ?? 0;
var revokeLiveObjectUrl = () => {
	if (liveObjectUrl && liveObjectUrl.startsWith("blob:")) try {
		URL.revokeObjectURL(liveObjectUrl);
	} catch {}
	liveObjectUrl = null;
};
var openWallpaperDb = () => new Promise((resolve, reject) => {
	if (typeof indexedDB === "undefined") {
		reject(/* @__PURE__ */ new Error("indexedDB unavailable"));
		return;
	}
	const req = indexedDB.open(IDB_NAME, 1);
	req.onupgradeneeded = () => {
		const db = req.result;
		if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
	};
	req.onsuccess = () => resolve(req.result);
	req.onerror = () => reject(req.error || /* @__PURE__ */ new Error("IDB open failed"));
});
var idbPutWallpaper = async (blob) => {
	const db = await openWallpaperDb();
	try {
		await new Promise((resolve, reject) => {
			const tx = db.transaction(IDB_STORE, "readwrite");
			tx.objectStore(IDB_STORE).put(blob, IDB_KEY);
			tx.oncomplete = () => resolve();
			tx.onerror = () => reject(tx.error || /* @__PURE__ */ new Error("IDB put failed"));
		});
	} finally {
		db.close();
	}
};
var idbGetWallpaper = async () => {
	const db = await openWallpaperDb();
	try {
		return await new Promise((resolve, reject) => {
			const req = db.transaction(IDB_STORE, "readonly").objectStore(IDB_STORE).get(IDB_KEY);
			req.onsuccess = () => {
				const v = req.result;
				resolve(v instanceof Blob ? v : null);
			};
			req.onerror = () => reject(req.error || /* @__PURE__ */ new Error("IDB get failed"));
		});
	} finally {
		db.close();
	}
};
var idbClearWallpaper = async () => {
	try {
		const db = await openWallpaperDb();
		try {
			await new Promise((resolve, reject) => {
				const tx = db.transaction(IDB_STORE, "readwrite");
				tx.objectStore(IDB_STORE).delete(IDB_KEY);
				tx.oncomplete = () => resolve();
				tx.onerror = () => reject(tx.error || /* @__PURE__ */ new Error("IDB delete failed"));
			});
		} finally {
			db.close();
		}
	} catch {}
};
var readStoragePointer = () => {
	try {
		const value = localStorage.getItem(WALLPAPER_STORAGE_KEY);
		return value && value.trim() ? value.trim() : DEFAULT_WALLPAPER_URL;
	} catch {
		return DEFAULT_WALLPAPER_URL;
	}
};
var writeStoragePointer = (value) => {
	try {
		localStorage.setItem(WALLPAPER_STORAGE_KEY, value);
		return true;
	} catch {
		return false;
	}
};
var isInlinePayload = (url) => url.startsWith("data:") || url.startsWith("blob:");
/**
* Resolve the durable pointer to a paintable URL (may create a blob: object URL).
* Callers that only need the pointer should use {@link getWallpaperStoragePointer}.
*/
var resolveAppWallpaperUrl = async () => {
	const pointer = readStoragePointer();
	if (pointer === "idb:rs-wallpaper" || pointer.startsWith("idb:")) {
		try {
			const blob = await idbGetWallpaper();
			if (blob) {
				revokeLiveObjectUrl();
				liveObjectUrl = URL.createObjectURL(blob);
				return liveObjectUrl;
			}
		} catch (err) {
			console.warn("[fest/image] wallpaper IDB restore failed", err);
		}
		return DEFAULT_WALLPAPER_URL;
	}
	if (pointer.startsWith("data:") && pointer.length > LOCAL_STORAGE_SAFE_CHARS) try {
		const blob = await idbGetWallpaper();
		if (blob) {
			revokeLiveObjectUrl();
			liveObjectUrl = URL.createObjectURL(blob);
			writeStoragePointer(WALLPAPER_IDB_MARKER);
			return liveObjectUrl;
		}
	} catch {}
	return pointer || DEFAULT_WALLPAPER_URL;
};
/** Durable pointer currently stored (`/assets/…` or {@link WALLPAPER_IDB_MARKER}). */
var getWallpaperStoragePointer = () => readStoragePointer();
/**
* INVARIANT: `ui-canvas` cover-rotate reads `data-orient` (see Canvas.ts).
* Keep attr + CSS var in lockstep with {@link fixOrientToScreen} / `orientRef`.
*/
var syncCanvasOrient = (canvas) => {
	const apply = () => {
		const n = currentOrientNumber();
		const s = String(n);
		if (canvas.getAttribute("data-orient") !== s) canvas.setAttribute("data-orient", s);
		if (canvas.getAttribute("orient") !== s) canvas.setAttribute("orient", s);
		canvas.style.setProperty("--orient", s);
		canvas.orient = n;
	};
	apply();
	return whenAnyScreenChanges(apply);
};
/** Tint the soft glow with the wallpaper primary (falls back to cool blue). */
var syncGlowToTheme = (glow) => {
	const primary = getComputedStyle(document.documentElement).getPropertyValue("--color-primary").trim() || "#5b86eb";
	glow.style.background = `radial-gradient(circle at 15% 20%, color-mix(in oklab, ${primary} 45%, transparent) 0%, transparent 40%), radial-gradient(circle at 75% 72%, color-mix(in oklab, ${primary} 35%, transparent) 0%, transparent 43%)`;
};
var paintWallpaperOnCanvases = (paintUrl) => {
	const canvases = document.querySelectorAll("[data-app-layer=\"canvas\"] canvas[is=\"ui-canvas\"], [data-app-layer=\"canvas\"] canvas.ui-canvas");
	const orient = String(currentOrientNumber());
	canvases.forEach((canvas) => {
		canvas.setAttribute("data-src", paintUrl);
		canvas.setAttribute("data-orient", orient);
		canvas.setAttribute("orient", orient);
		canvas.style.setProperty("--orient", orient);
	});
};
var dataUrlToBlob = async (dataUrl) => {
	return (await fetch(dataUrl)).blob();
};
/**
* Persist + paint a wallpaper blob/File (preferred entry for file pickers).
* Stores bytes in IndexedDB and the durable marker in localStorage.
*/
var setAppWallpaperFromBlob = async (blob) => {
	if (!(blob instanceof Blob) || blob.size <= 0) {
		setAppWallpaper(DEFAULT_WALLPAPER_URL);
		return DEFAULT_WALLPAPER_URL;
	}
	revokeLiveObjectUrl();
	liveObjectUrl = URL.createObjectURL(blob);
	paintWallpaperOnCanvases(liveObjectUrl);
	applyThemeFromWallpaper(liveObjectUrl, { force: true }).then(() => {
		document.querySelectorAll(".app-canvas__glow").forEach(syncGlowToTheme);
	});
	try {
		await idbPutWallpaper(blob);
		writeStoragePointer(WALLPAPER_IDB_MARKER);
	} catch (err) {
		console.warn("[fest/image] wallpaper IDB persist failed", err);
		try {
			const reader = new FileReader();
			const dataUrl = await new Promise((resolve, reject) => {
				reader.onload = () => resolve(String(reader.result || ""));
				reader.onerror = () => reject(reader.error || /* @__PURE__ */ new Error("read failed"));
				reader.readAsDataURL(blob);
			});
			if (dataUrl && !writeStoragePointer(dataUrl)) console.warn("[fest/image] wallpaper localStorage persist also failed (quota?)");
		} catch {}
	}
	try {
		globalThis.dispatchEvent?.(new CustomEvent("cwsp-wallpaper-change", { detail: {
			pointer: WALLPAPER_IDB_MARKER,
			url: liveObjectUrl
		} }));
	} catch {}
	return liveObjectUrl;
};
var initializeAppCanvasLayer = (container) => {
	const root = container;
	root.replaceChildren();
	root.dataset.appLayer = "canvas";
	root.style.position = "absolute";
	root.style.inset = "0";
	root.style.overflow = "hidden";
	root.style.background = "radial-gradient(circle at 18% 12%, #1b2a45 0%, #0f1728 42%, #060910 100%)";
	const glow = document.createElement("div");
	glow.className = "app-canvas__glow";
	glow.style.position = "absolute";
	glow.style.inset = "-20%";
	glow.style.pointerEvents = "none";
	glow.style.opacity = "0.7";
	glow.style.background = "radial-gradient(circle at 15% 20%, rgba(145,185,255,0.45) 0%, transparent 40%), radial-gradient(circle at 75% 72%, rgba(91,134,235,0.35) 0%, transparent 43%)";
	const canvas = document.createElement("canvas", { is: "ui-canvas" });
	canvas.className = "app-canvas__image ui-canvas";
	canvas.style.position = "absolute";
	canvas.style.inset = "0";
	canvas.style.pointerEvents = "none";
	canvas.style.inlineSize = "100%";
	canvas.style.blockSize = "100%";
	canvas.style.maxInlineSize = "100%";
	canvas.style.maxBlockSize = "100%";
	canvas.style.opacity = "1";
	canvas.style.mixBlendMode = "normal";
	canvas.setAttribute("is", "ui-canvas");
	canvas.style.setProperty("dynamic-range-limit", "no-limit");
	canvas.style.setProperty("color-space", "display-p3");
	canvas.style.setProperty("background-color", "black", "important");
	canvas.style.setProperty("opacity", "1", "important");
	root.append(glow, canvas);
	const pointer = readStoragePointer();
	const coldUrl = pointer === "idb:rs-wallpaper" || pointer.startsWith("idb:") || pointer.startsWith("data:") ? DEFAULT_WALLPAPER_URL : pointer;
	canvas.setAttribute("data-src", coldUrl);
	const disposeOrient = syncCanvasOrient(canvas);
	restoreWallpaperThemeCache();
	syncGlowToTheme(glow);
	resolveAppWallpaperUrl().then((wallpaper) => {
		canvas.setAttribute("data-src", wallpaper);
		syncCanvasOrient(canvas);
		return applyThemeFromWallpaper(wallpaper).then(() => syncGlowToTheme(glow));
	});
	return {
		root,
		canvas,
		glow,
		disposeOrient
	};
};
/**
* Set wallpaper from a URL. Short asset paths stay in localStorage; `data:` / `blob:` /
* oversized payloads are persisted to IndexedDB with {@link WALLPAPER_IDB_MARKER}.
*/
var setAppWallpaper = (wallpaperUrl) => {
	const value = String(wallpaperUrl || "").trim() || DEFAULT_WALLPAPER_URL;
	if (isInlinePayload(value) || value.length > LOCAL_STORAGE_SAFE_CHARS) {
		(async () => {
			try {
				await setAppWallpaperFromBlob(value.startsWith("blob:") ? await (await fetch(value)).blob() : await dataUrlToBlob(value));
			} catch (err) {
				console.warn("[fest/image] setAppWallpaper inline persist failed", err);
				paintWallpaperOnCanvases(value);
				applyThemeFromWallpaper(value, { force: true }).then(() => {
					document.querySelectorAll(".app-canvas__glow").forEach(syncGlowToTheme);
				});
			}
		})();
		return;
	}
	idbClearWallpaper();
	revokeLiveObjectUrl();
	if (!writeStoragePointer(value)) console.warn("[fest/image] wallpaper pointer write failed");
	paintWallpaperOnCanvases(value);
	applyThemeFromWallpaper(value, { force: true }).then(() => {
		document.querySelectorAll(".app-canvas__glow").forEach(syncGlowToTheme);
	});
	try {
		globalThis.dispatchEvent?.(new CustomEvent("cwsp-wallpaper-change", { detail: {
			pointer: value,
			url: value
		} }));
	} catch {}
};
//#endregion
export { restoreWallpaperThemeCache as a, setAppWallpaperFromBlob as i, getWallpaperStoragePointer as n, initializeAppCanvasLayer as r, WALLPAPER_IDB_MARKER as t };
